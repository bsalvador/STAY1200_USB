/*     */ package br.com.schneider.sgm.config;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstanciaSGM
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int familia;
/*     */   private String porta;
/*     */   private int expansorBateria;
/*     */   private String nomeUPS;
/*     */   private Object idioma;
/*     */   private int evento;
/*     */   private String script;
/*     */   private String enderecoSMTP;
/*     */   private int portaSMTP;
/*     */   private String remetente;
/*     */   private String[] destinatarios;
/*     */   private boolean flagAutentic;
/*     */   private String usuario;
/*     */   private String senha;
/*     */   private int modeloUPS;
/*     */   private int portaRemota;
/*     */   private boolean modoRemoto;
/*     */   private boolean modoLogging;
/*     */   private boolean[][] mensagens;
/*     */   private String comunidadeLeitura;
/*     */   private String comunidadeEscrita;
/*     */   private String enderecoGerente;
/*     */   private int portaEnvio;
/*     */   private int portaPedidos;
/*     */   private int vSNMP;
/*     */   private int protocoloTransporte;
/*     */   private boolean flagShutFimAut;
/*     */   private int autonoMinima;
/*     */   private boolean flagShutFalhaEletrica;
/*     */   private int tempoFalhaEletrica;
/*     */   private double valorKW;
/*     */   private int upsServerPort;
/*     */   private Object upsServerClients;
/*     */   private boolean upsServerEnabled;
/*     */   private int horaTeste;
/*     */   private int minutoTeste;
/*     */   private int periodoTeste;
/*     */   private boolean enableTeste;
/*     */   private String caminhoArquivoXML;
/*     */   private String provedorEscolhido;
/*     */   
/*     */   public int getAutonoMinima()
/*     */   {
/* 243 */     return this.autonoMinima;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getComunidadeEscrita()
/*     */   {
/* 250 */     return this.comunidadeEscrita;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getComunidadeLeitura()
/*     */   {
/* 257 */     return this.comunidadeLeitura;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getDestinatarios()
/*     */   {
/* 264 */     return this.destinatarios;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEnderecoGerente()
/*     */   {
/* 271 */     return this.enderecoGerente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEnderecoSMTP()
/*     */   {
/* 278 */     return this.enderecoSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEvento()
/*     */   {
/* 285 */     return this.evento;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getExpansorBateria()
/*     */   {
/* 292 */     return this.expansorBateria;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFamilia()
/*     */   {
/* 299 */     return this.familia;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFlagAutentic()
/*     */   {
/* 306 */     return this.flagAutentic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFlagShutFalhaEletrica()
/*     */   {
/* 313 */     return this.flagShutFalhaEletrica;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFlagShutFimAut()
/*     */   {
/* 320 */     return this.flagShutFimAut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getIdioma()
/*     */   {
/* 327 */     return this.idioma;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean[][] getMensagens()
/*     */   {
/* 334 */     return this.mensagens;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getModeloUPS()
/*     */   {
/* 341 */     return this.modeloUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isModoRemoto()
/*     */   {
/* 348 */     return this.modoRemoto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNomeUPS()
/*     */   {
/* 355 */     return this.nomeUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPorta()
/*     */   {
/* 362 */     return this.porta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPortaEnvio()
/*     */   {
/* 369 */     return this.portaEnvio;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPortaPedidos()
/*     */   {
/* 376 */     return this.portaPedidos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPortaRemota()
/*     */   {
/* 383 */     return this.portaRemota;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPortaSMTP()
/*     */   {
/* 390 */     return this.portaSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getProtocoloTransporte()
/*     */   {
/* 397 */     return this.protocoloTransporte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRemetente()
/*     */   {
/* 404 */     return this.remetente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getScript()
/*     */   {
/* 411 */     return this.script;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSenha()
/*     */   {
/* 418 */     return this.senha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getTempoFalhaEletrica()
/*     */   {
/* 425 */     return this.tempoFalhaEletrica;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUsuario()
/*     */   {
/* 432 */     return this.usuario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double getValorKW()
/*     */   {
/* 439 */     return this.valorKW;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getVSNMP()
/*     */   {
/* 446 */     return this.vSNMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUPSServerPort()
/*     */   {
/* 454 */     return this.upsServerPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getUPSServerClients()
/*     */   {
/* 461 */     return this.upsServerClients;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUPSServerEnabled()
/*     */   {
/* 469 */     return this.upsServerEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPeriodoTeste()
/*     */   {
/* 478 */     return this.periodoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getHoraTeste()
/*     */   {
/* 485 */     return this.horaTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMinutoTeste()
/*     */   {
/* 492 */     return this.minutoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAutoTesteEnabled()
/*     */   {
/* 500 */     return this.enableTeste;
/*     */   }
/*     */   
/*     */   public boolean getModoLogging() {
/* 504 */     return this.modoLogging;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCaminhoArquivoXMLEVENTOS()
/*     */   {
/* 512 */     return this.caminhoArquivoXML;
/*     */   }
/*     */   
/*     */   public String getProvedorEscolhido() {
/* 516 */     return this.provedorEscolhido;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutonoMinima(int autonoMinima)
/*     */   {
/* 527 */     this.autonoMinima = autonoMinima;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setComunidadeEscrita(String comunidadeEscrita)
/*     */   {
/* 534 */     this.comunidadeEscrita = comunidadeEscrita;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setComunidadeLeitura(String comunidadeLeitura)
/*     */   {
/* 541 */     this.comunidadeLeitura = comunidadeLeitura;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDestinatarios(String[] destinatarios)
/*     */   {
/* 548 */     this.destinatarios = destinatarios;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEnderecoGerente(String enderecoGerente)
/*     */   {
/* 555 */     this.enderecoGerente = enderecoGerente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEnderecoSMTP(String enderecoSMTP)
/*     */   {
/* 562 */     this.enderecoSMTP = enderecoSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEvento(int evento)
/*     */   {
/* 569 */     this.evento = evento;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setExpansorBateria(int expansorBateria)
/*     */   {
/* 576 */     this.expansorBateria = expansorBateria;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFamilia(int familia)
/*     */   {
/* 583 */     this.familia = familia;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFlagAutentic(boolean flagAutentic)
/*     */   {
/* 590 */     this.flagAutentic = flagAutentic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFlagShutFalhaEletrica(boolean flagShutFalhaEletrica)
/*     */   {
/* 597 */     this.flagShutFalhaEletrica = flagShutFalhaEletrica;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFlagShutFimAut(boolean flagShutFimAut)
/*     */   {
/* 604 */     this.flagShutFimAut = flagShutFimAut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setIdioma(Object idioma)
/*     */   {
/* 611 */     this.idioma = idioma;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMensagens(boolean[][] mensagens)
/*     */   {
/* 618 */     this.mensagens = mensagens;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setModeloUPS(int modeloUPS)
/*     */   {
/* 625 */     this.modeloUPS = modeloUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setModoRemoto(boolean modoRemoto)
/*     */   {
/* 632 */     this.modoRemoto = modoRemoto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setNomeUPS(String nomeUPS)
/*     */   {
/* 639 */     this.nomeUPS = nomeUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPorta(String porta)
/*     */   {
/* 646 */     this.porta = porta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPortaEnvio(int portaEnvio)
/*     */   {
/* 653 */     this.portaEnvio = portaEnvio;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPortaPedidos(int portaPedidos)
/*     */   {
/* 660 */     this.portaPedidos = portaPedidos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPortaRemota(int portaRemota)
/*     */   {
/* 667 */     this.portaRemota = portaRemota;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPortaSMTP(int portaSMTP)
/*     */   {
/* 674 */     this.portaSMTP = portaSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProtocoloTransporte(int protocoloTransporte)
/*     */   {
/* 681 */     this.protocoloTransporte = protocoloTransporte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRemetente(String remetente)
/*     */   {
/* 688 */     this.remetente = remetente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setScript(String script)
/*     */   {
/* 695 */     this.script = script;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSenha(String senha)
/*     */   {
/* 702 */     this.senha = senha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTempoFalhaEletrica(int tempoFalhaEletrica)
/*     */   {
/* 709 */     this.tempoFalhaEletrica = tempoFalhaEletrica;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUsuario(String usuario)
/*     */   {
/* 716 */     this.usuario = usuario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValorKW(double valorKW)
/*     */   {
/* 723 */     this.valorKW = valorKW;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setVSNMP(int vsnmp)
/*     */   {
/* 730 */     this.vSNMP = vsnmp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUPSServerPort(int port)
/*     */   {
/* 739 */     this.upsServerPort = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUPSServerEnabled(boolean b)
/*     */   {
/* 747 */     this.upsServerEnabled = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUPSServerClients(Object list)
/*     */   {
/* 755 */     this.upsServerClients = list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPeriodoAutoTeste(int periodo)
/*     */   {
/* 765 */     this.periodoTeste = periodo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHoraTeste(int horaTeste)
/*     */   {
/* 772 */     this.horaTeste = horaTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMinutoTeste(int minutoTeste)
/*     */   {
/* 779 */     this.minutoTeste = minutoTeste;
/*     */   }
/*     */   
/*     */   public void setAutoTeste(boolean enable) {
/* 783 */     this.enableTeste = enable;
/*     */   }
/*     */   
/*     */   public void setModoLogging(boolean enable)
/*     */   {
/* 788 */     this.modoLogging = enable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCaminhoArquivoXMLEVENTOS(String caminhoArquivoXML)
/*     */   {
/* 796 */     this.caminhoArquivoXML = caminhoArquivoXML;
/*     */   }
/*     */   
/*     */   public void setProvedorEscolhido(String provedorEscolhido) {
/* 800 */     this.provedorEscolhido = provedorEscolhido;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\config\InstanciaSGM.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */