/*     */ package br.com.schneider.sgm.config;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class BuscaParametrosXML
/*     */ {
/*     */   private String[] resultados;
/*     */   private org.w3c.dom.Document doc;
/*     */   private String nomeDocumento;
/*     */   private String nohAtual;
/*     */   private String familia;
/*     */   private Vector<String> historico;
/*     */   private String millis;
/*     */   private String record;
/*     */   private boolean arqRemovido;
/*     */   private Vector<Node> res;
/*     */   
/*     */   public void setNomeDocumento(String nomeDocumento)
/*     */   {
/*  26 */     this.nomeDocumento = nomeDocumento;
/*     */   }
/*     */   
/*     */   public synchronized Object[] buscaFamilias()
/*     */   {
/*     */     try {
/*  32 */       this.doc = com.sun.xml.tree.XmlDocument.createXmlDocument(new FileInputStream(this.nomeDocumento), false);
/*     */     } catch (IOException e) {
/*  34 */       e.printStackTrace();
/*     */     } catch (SAXException e) {
/*  36 */       e.printStackTrace();
/*     */     }
/*  38 */     this.res = new Vector();
/*  39 */     buscaFamilias(this.doc);
/*  40 */     if (this.res != null) {
/*  41 */       return this.res.toArray();
/*     */     }
/*  43 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void buscaFamilias(Node noh)
/*     */   {
/*  50 */     if (noh == null) { return;
/*     */     }
/*  52 */     int tipo = noh.getNodeType();
/*  53 */     switch (tipo)
/*     */     {
/*     */ 
/*     */     case 9: 
/*  57 */       NodeList Lista = noh.getChildNodes();
/*     */       try
/*     */       {
/*  60 */         for (int i = 0; i <= Lista.getLength() - 1; i++) {
/*  61 */           buscaSerial(Lista.item(i));
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/*     */       try
/*     */       {
/*  72 */         if (noh.getNodeName() == "familia")
/*     */         {
/*  74 */           NamedNodeMap atributos = noh.getAttributes();
/*     */           
/*  76 */           if (!atributos.item(0).getNodeValue().equalsIgnoreCase(this.familia)) {
/*  77 */             return;
/*     */           }
/*     */           
/*  80 */           this.res.add(atributos.getNamedItem("nome"));
/*     */           
/*  82 */           return;
/*     */         }
/*     */       }
/*     */       catch (Exception localException1) {}
/*     */     case 3: 
/*     */       
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void buscaSerial(Node noh)
/*     */   {
/* 102 */     if (noh == null) { return;
/*     */     }
/* 104 */     int tipo = noh.getNodeType();
/* 105 */     switch (tipo)
/*     */     {
/*     */ 
/*     */     case 9: 
/* 109 */       NodeList Lista = noh.getChildNodes();
/*     */       try
/*     */       {
/* 112 */         for (int i = 0; i <= Lista.getLength() - 1; i++) {
/* 113 */           buscaSerial(Lista.item(i));
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/*     */       try
/*     */       {
/* 125 */         if (noh.getNodeName() == "familia")
/*     */         {
/* 127 */           NamedNodeMap atributos = noh.getAttributes();
/*     */           
/* 129 */           if (atributos.item(0).getNodeValue().equalsIgnoreCase(this.familia)) {}
/*     */ 
/*     */         }
/* 132 */         else if (noh.getNodeName() == "tempoEsperaPorta") {
/* 133 */           this.nohAtual = "tempoEsperaPorta";
/* 134 */         } else if (noh.getNodeName() == "baudRate") {
/* 135 */           this.nohAtual = "baudRate";
/* 136 */         } else if (noh.getNodeName() == "dataBits") {
/* 137 */           this.nohAtual = "dataBits";
/* 138 */         } else if (noh.getNodeName() == "stopBit") {
/* 139 */           this.nohAtual = "stopBit";
/* 140 */         } else if (noh.getNodeName() == "paridade") {
/* 141 */           this.nohAtual = "paridade";
/* 142 */         } else if (noh.getNodeName() == "delayLeitura") {
/* 143 */           this.nohAtual = "delayLeitura";
/*     */         }
/* 145 */         if ((noh.getNodeName() == "comunicacao") || 
/* 146 */           (noh.getNodeName() == "familia") || 
/* 147 */           (noh.getNodeName() == "serial") || 
/* 148 */           (noh.getNodeName() == "tempoEsperaPorta") || 
/* 149 */           (noh.getNodeName() == "baudRate") || 
/* 150 */           (noh.getNodeName() == "dataBits") || 
/* 151 */           (noh.getNodeName() == "stopBit") || 
/* 152 */           (noh.getNodeName() == "paridade") || 
/* 153 */           (noh.getNodeName() == "delayLeitura"))
/*     */         {
/*     */ 
/* 156 */           NodeList Lista = noh.getChildNodes();
/* 157 */           if (Lista != null) {
/* 158 */             for (int i = 0; i <= Lista.getLength() - 1; i++) {
/* 159 */               buscaSerial(Lista.item(i));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception localException1) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 171 */       if (noh.getNodeValue().trim().length() != 0)
/*     */       {
/*     */         try
/*     */         {
/* 175 */           if (this.nohAtual == "tempoEsperaPorta") {
/* 176 */             this.resultados[0] = noh.getNodeValue();
/* 177 */           } else if (this.nohAtual == "baudRate") {
/* 178 */             this.resultados[1] = noh.getNodeValue();
/* 179 */           } else if (this.nohAtual == "dataBits") {
/* 180 */             this.resultados[2] = noh.getNodeValue();
/* 181 */           } else if (this.nohAtual == "stopBit") {
/* 182 */             this.resultados[3] = noh.getNodeValue();
/* 183 */           } else if (this.nohAtual == "paridade") {
/* 184 */             this.resultados[4] = noh.getNodeValue();
/* 185 */           } else if (this.nohAtual == "delayLeitura") {
/* 186 */             this.resultados[5] = noh.getNodeValue();
/*     */           }
/*     */         }
/*     */         catch (Exception localException2) {}
/*     */       }
/*     */       
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */   public synchronized String[] configuraPorta(String familia, String tipo)
/*     */   {
/* 199 */     this.familia = familia;
/* 200 */     if (tipo.equalsIgnoreCase("serial"))
/*     */     {
/*     */       try {
/* 203 */         this.doc = com.sun.xml.tree.XmlDocument.createXmlDocument(new FileInputStream(this.nomeDocumento), false);
/*     */       }
/*     */       catch (SAXException|IOException e) {
/* 206 */         e.printStackTrace();
/*     */       }
/* 208 */       this.resultados = new String[6];
/* 209 */       buscaSerial(this.doc);
/*     */     }
/*     */     
/* 212 */     return this.resultados;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void imprimeRegistrosHistorico(Node noh)
/*     */   {
/* 398 */     if (noh == null) { return;
/*     */     }
/* 400 */     int tipo = noh.getNodeType();
/* 401 */     switch (tipo)
/*     */     {
/*     */ 
/*     */     case 9: 
/* 405 */       NodeList Lista = noh.getChildNodes();
/*     */       try
/*     */       {
/* 408 */         for (int i = 0; i <= Lista.getLength() - 1; i++) {
/* 409 */           imprimeRegistrosHistorico(Lista.item(i));
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/*     */       try
/*     */       {
/* 421 */         if (noh.getNodeName() == "date")
/* 422 */           this.nohAtual = "date";
/* 423 */         if (noh.getNodeName() == "millis") {
/* 424 */           this.nohAtual = "millis";
/* 425 */         } else if (noh.getNodeName() == "message") {
/* 426 */           this.nohAtual = "message";
/*     */         }
/* 428 */         if ((noh.getNodeName() == "log") || 
/* 429 */           (noh.getNodeName() == "record") || 
/* 430 */           (noh.getNodeName() == "date") || 
/* 431 */           (noh.getNodeName() == "millis") || 
/* 432 */           (noh.getNodeName() == "message"))
/*     */         {
/*     */ 
/* 435 */           NodeList Lista = noh.getChildNodes();
/* 436 */           if (Lista != null) {
/* 437 */             for (int i = 0; i <= Lista.getLength() - 1; i++) {
/* 438 */               imprimeRegistrosHistorico(Lista.item(i));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception localException1) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 450 */       if (noh.getNodeValue().trim().length() != 0)
/*     */       {
/*     */         try
/*     */         {
/* 454 */           if (this.nohAtual == "date") {
/* 455 */             this.record = noh.getNodeValue();
/* 456 */           } else if (this.nohAtual == "millis") {
/* 457 */             this.record = (this.record + "_" + noh.getNodeValue());
/* 458 */           } else if (this.nohAtual == "message")
/*     */           {
/* 460 */             this.record = (this.record + "_" + noh.getNodeValue());
/* 461 */             this.historico.add(this.record);
/*     */           }
/*     */         }
/*     */         catch (Exception localException2) {}
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */   public synchronized Vector<String> getRegistrosHistorico()
/*     */   {
/*     */     try
/*     */     {
/* 475 */       this.doc = com.sun.xml.tree.XmlDocument.createXmlDocument(new FileInputStream(this.nomeDocumento), false);
/*     */     }
/*     */     catch (IOException e) {
/* 478 */       e.printStackTrace();
/*     */     }
/*     */     catch (SAXException e) {
/* 481 */       e.printStackTrace();
/*     */     }
/*     */     
/* 484 */     this.historico = new Vector();
/* 485 */     imprimeRegistrosHistorico(this.doc);
/*     */     
/* 487 */     return this.historico;
/*     */   }
/*     */   
/* 490 */   private synchronized void removeRegistro(Node noh) { if (noh == null) { return;
/*     */     }
/* 492 */     int tipo = noh.getNodeType();
/* 493 */     switch (tipo)
/*     */     {
/*     */ 
/*     */     case 9: 
/* 497 */       NodeList Lista = noh.getChildNodes();
/*     */       try
/*     */       {
/* 500 */         for (int i = 0; i <= Lista.getLength() - 1; i++) {
/* 501 */           removeRegistro(Lista.item(i));
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/*     */       try
/*     */       {
/* 513 */         if ((noh.getNodeName() != "record") && 
/* 514 */           (noh.getNodeName() == "millis")) {
/* 515 */           this.nohAtual = "millis";
/*     */         }
/* 517 */         if ((noh.getNodeName() == "log") || 
/* 518 */           (noh.getNodeName() == "record") || 
/* 519 */           (noh.getNodeName() == "millis"))
/*     */         {
/*     */ 
/*     */ 
/* 523 */           NodeList Lista = noh.getChildNodes();
/* 524 */           if (Lista != null) {
/* 525 */             for (int i = 0; i <= Lista.getLength() - 1; i++)
/*     */             {
/* 527 */               removeRegistro(Lista.item(i));
/* 528 */               if (this.arqRemovido)
/*     */                 break;
/*     */             }
/*     */           }
/* 532 */           if (noh.getNodeName() != "log") {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception localException1) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 551 */       if (noh.getNodeValue().trim().length() != 0)
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/* 556 */           if ((this.nohAtual == "millis") && 
/* 557 */             (noh.getNodeValue().equals(this.millis)))
/*     */           {
/*     */ 
/* 560 */             this.arqRemovido = true;
/*     */           }
/*     */         }
/*     */         catch (Exception localException2) {}
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized boolean deletaRegistroHistorico(String millis)
/*     */   {
/* 576 */     this.millis = millis;
/*     */     try
/*     */     {
/* 579 */       this.doc = com.sun.xml.tree.XmlDocument.createXmlDocument(new FileInputStream(this.nomeDocumento), false);
/*     */     }
/*     */     catch (IOException e) {
/* 582 */       e.printStackTrace();
/*     */     }
/*     */     catch (SAXException e) {
/* 585 */       e.printStackTrace();
/*     */     }
/*     */     
/* 588 */     this.arqRemovido = false;
/* 589 */     removeRegistro(this.doc);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 594 */     return this.arqRemovido;
/*     */   }
/*     */   
/*     */   public void buscaAlarmes(Node noh) {
/* 598 */     if (noh == null) { return;
/*     */     }
/* 600 */     int tipo = noh.getNodeType();
/* 601 */     switch (tipo)
/*     */     {
/*     */ 
/*     */     case 9: 
/* 605 */       NodeList Lista = noh.getChildNodes();
/*     */       try
/*     */       {
/* 608 */         for (int i = 0; i <= Lista.getLength() - 1; i++) {
/* 609 */           buscaAlarmes(Lista.item(i));
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/*     */       try
/*     */       {
/* 621 */         if (noh.getNodeName() == "alarme") {
/* 622 */           this.nohAtual = "alarme";
/*     */         }
/*     */         
/* 625 */         NodeList Lista = noh.getChildNodes();
/*     */         
/* 627 */         if (Lista != null) {
/* 628 */           for (int i = 0; i <= Lista.getLength() - 1; i++) {
/* 629 */             buscaAlarmes(Lista.item(i));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception localException1) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 639 */       if (noh.getNodeValue().trim().length() != 0)
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/* 644 */           if (this.nohAtual == "alarme") {
/* 645 */             this.historico.add(noh.getNodeValue());
/*     */           }
/*     */         }
/*     */         catch (Exception localException2) {}
/*     */       }
/*     */       
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */   public synchronized String[] configuraAlarmes()
/*     */   {
/*     */     try
/*     */     {
/* 660 */       this.doc = com.sun.xml.tree.XmlDocument.createXmlDocument(new FileInputStream(this.nomeDocumento), false);
/*     */     }
/*     */     catch (IOException e) {
/* 663 */       e.printStackTrace();
/*     */     }
/*     */     catch (SAXException e) {
/* 666 */       e.printStackTrace();
/*     */     }
/*     */     
/* 669 */     this.historico = new Vector();
/*     */     
/* 671 */     buscaAlarmes(this.doc);
/*     */     
/* 673 */     if (this.historico != null)
/*     */     {
/* 675 */       String[] res = new String[this.historico.size()];
/* 676 */       for (int i = 0; i < this.historico.size(); i++) {
/* 677 */         res[i] = ((String)this.historico.get(i)).toString();
/*     */       }
/* 679 */       return res;
/*     */     }
/* 681 */     return null;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {}
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\config\BuscaParametrosXML.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */