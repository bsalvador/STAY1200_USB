/*    */ package br.com.schneider.sgm.config;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.apache.commons.lang3.SystemUtils;
/*    */ 
/*    */ 
/*    */ public class PathConfig
/*    */ {
/*    */   private static final String DIRECTORY_LINUX_USER_HOME_ENVIRONMENT_VARIABLE = "user.home";
/*    */   private static final String DIRECTORY_WINDOWS_APPDATA_ENVIRONMENT_VARIABLE = "APPDATA";
/* 11 */   private static String path = "";
/*    */   
/*    */ 
/*    */ 
/*    */   public static String getPathXML()
/*    */   {
/* 17 */     if ((path != null) && (!path.equals(""))) {
/* 18 */       return path;
/*    */     }
/* 20 */     return getPathToGui();
/*    */   }
/*    */   
/*    */ 
/*    */   private static String getPathToGui()
/*    */   {
/* 26 */     String path = "";
/*    */     
/* 28 */     if (SystemUtils.IS_OS_WINDOWS)
/*    */     {
/* 30 */       path = System.getenv("APPDATA") + File.separator + "APC" + File.separator + "XML" + File.separator;
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/* 35 */       path = 
/*    */       
/* 37 */         System.getProperty("user.home") + File.separator + "APC" + File.separator + "XML" + File.separator;
/*    */     }
/*    */     
/* 40 */     return path;
/*    */   }
/*    */   
/*    */ 
/*    */   private static String getPathToService()
/*    */   {
/* 46 */     String path = "";
/*    */     
/* 48 */     if (SystemUtils.IS_OS_WINDOWS)
/*    */     {
/* 50 */       path = File.separator + "APC" + File.separator + "XML" + File.separator;
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/* 55 */       path = File.separator + "APC" + File.separator + "XML" + File.separator;
/*    */     }
/*    */     
/*    */ 
/* 59 */     return path;
/*    */   }
/*    */   
/*    */ 
/*    */   public static String getPathConfig()
/*    */   {
/* 65 */     String path = "";
/*    */     
/* 67 */     if (SystemUtils.IS_OS_WINDOWS)
/*    */     {
/* 69 */       path = 
/* 70 */         System.getenv("APPDATA") + File.separator + "APC" + File.separator;
/*    */     }
/*    */     else
/*    */     {
/* 74 */       path = 
/* 75 */         System.getProperty("user.home") + File.separator + "APC" + File.separator;
/*    */     }
/*    */     
/* 78 */     return path;
/*    */   }
/*    */   
/*    */   public static String getPath() {
/* 82 */     return path;
/*    */   }
/*    */   
/*    */   public static void setPath(String path) {
/* 86 */     path = path + File.separator + "APC" + File.separator + "XML" + File.separator;
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\config\PathConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */