/*     */ package br.com.schneider.sgm.serial;
/*     */ 
/*     */ import br.com.schneider.sgm.comunicacao.Communication;
/*     */ import br.com.schneider.sgm.eventos.DriverListener;
/*     */ import gnu.io.CommPortIdentifier;
/*     */ import gnu.io.PortInUseException;
/*     */ import gnu.io.SerialPort;
/*     */ import gnu.io.SerialPortEvent;
/*     */ import gnu.io.SerialPortEventListener;
/*     */ import gnu.io.UnsupportedCommOperationException;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.TooManyListenersException;
/*     */ import org.apache.commons.lang3.SystemUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverSerial
/*     */   implements SerialPortEventListener, Communication
/*     */ {
/*  42 */   private final int MAXIMO_BYTES_LIDOS = 2000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] pacote;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int delayLeitura;
/*     */   
/*     */ 
/*     */ 
/*     */   private BufferedInputStream entrada;
/*     */   
/*     */ 
/*     */ 
/*     */   private BufferedOutputStream saida;
/*     */   
/*     */ 
/*     */ 
/*     */   private CommPortIdentifier[] identificadoresPortas;
/*     */   
/*     */ 
/*     */ 
/*     */   private SerialPort portaSerial;
/*     */   
/*     */ 
/*     */ 
/*     */   private int quantidadePortas;
/*     */   
/*     */ 
/*     */ 
/*  76 */   private int indice = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   private DriverListener ouvinteDriver;
/*     */   
/*     */ 
/*     */   private String portaSerialEscolhida;
/*     */   
/*     */ 
/*     */   private int tempoEspera;
/*     */   
/*     */ 
/*     */   private int baudRate;
/*     */   
/*     */ 
/*     */   private int dataBits;
/*     */   
/*     */ 
/*     */   private int stopBit;
/*     */   
/*     */ 
/*     */   private int paridade;
/*     */   
/*     */ 
/*     */ 
/*     */   public DriverSerial()
/*     */   {
/* 104 */     this.pacote = new int['ߐ'];
/*     */     
/* 106 */     Enumeration enumeraPortas = CommPortIdentifier.getPortIdentifiers();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */     this.identificadoresPortas = new CommPortIdentifier[30];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */     this.quantidadePortas = 0;
/*     */     
/*     */ 
/* 129 */     while (enumeraPortas.hasMoreElements()) {
/* 130 */       CommPortIdentifier portaId = (CommPortIdentifier)enumeraPortas.nextElement();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */       if (portaId.getPortType() == 1)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */         this.identificadoresPortas[(this.quantidadePortas++)] = portaId;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean restart()
/*     */   {
/* 165 */     switch (this.dataBits) {
/*     */     case 5: 
/*     */       break;
/*     */     case 6: 
/*     */       break;
/*     */     case 7: 
/*     */       break;
/*     */     case 8: 
/*     */       break;
/*     */     default: 
/* 175 */       return false;
/*     */     }
/*     */     
/* 178 */     switch (this.stopBit) {
/*     */     case 1: 
/*     */       break;
/*     */     case 3: 
/*     */       break;
/*     */     case 2: 
/*     */       break;
/*     */     default: 
/* 186 */       return false;
/*     */     }
/*     */     
/* 189 */     switch (this.paridade) {
/*     */     case 2: 
/*     */       break;
/*     */     case 3: 
/*     */       break;
/*     */     case 0: 
/*     */       break;
/*     */     case 1: 
/*     */       break;
/*     */     case 4: 
/*     */       break;
/*     */     default: 
/* 201 */       return false;
/*     */     }
/*     */     
/* 204 */     int i = 0;
/* 205 */     boolean encontrado = false;
/*     */     
/* 207 */     while (i < this.quantidadePortas)
/*     */     {
/* 209 */       if (this.identificadoresPortas[i].getName().equals(this.portaSerialEscolhida)) {
/* 210 */         encontrado = true;
/* 211 */         this.indice = i;
/*     */       }
/*     */       
/* 214 */       i++;
/*     */     }
/*     */     
/* 217 */     if (!encontrado) {
/* 218 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 222 */       this.portaSerial = ((SerialPort)this.identificadoresPortas[this.indice].open(
/* 223 */         "DriverSerialUPS", this.tempoEspera));
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (PortInUseException piue)
/*     */     {
/*     */ 
/*     */ 
/* 232 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 236 */       this.entrada = new BufferedInputStream(this.portaSerial.getInputStream());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */       this.saida = new BufferedOutputStream(this.portaSerial.getOutputStream());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 255 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 259 */       this.portaSerial.addEventListener(this);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (TooManyListenersException tmle)
/*     */     {
/*     */ 
/* 266 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 270 */       this.portaSerial.setSerialPortParams(this.baudRate, 
/*     */       
/* 272 */         this.dataBits, 
/* 273 */         this.stopBit, 
/* 274 */         this.paridade);
/*     */       
/* 276 */       this.portaSerial.setRTS(false);
/*     */       
/*     */ 
/* 279 */       this.portaSerial.setDTR(true);
/*     */ 
/*     */     }
/*     */     catch (UnsupportedCommOperationException ucoe)
/*     */     {
/*     */ 
/* 285 */       return false;
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 290 */       return false;
/*     */     }
/*     */     
/* 293 */     this.portaSerial.notifyOnDataAvailable(true);
/*     */     
/*     */ 
/* 296 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean open(String[] parametrosConfiguracao)
/*     */   {
/* 320 */     this.portaSerialEscolhida = parametrosConfiguracao[0];
/* 321 */     this.tempoEspera = Integer.parseInt(parametrosConfiguracao[1]);
/* 322 */     this.baudRate = Integer.parseInt(parametrosConfiguracao[2]);
/* 323 */     this.dataBits = Integer.parseInt(parametrosConfiguracao[3]);
/* 324 */     this.stopBit = Integer.parseInt(parametrosConfiguracao[4]);
/* 325 */     this.paridade = Integer.parseInt(parametrosConfiguracao[5]);
/* 326 */     this.delayLeitura = Integer.parseInt(parametrosConfiguracao[6]);
/*     */     
/* 328 */     return restart();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean close()
/*     */   {
/*     */     try
/*     */     {
/* 340 */       if (this.entrada != null) {
/* 341 */         this.entrada.close();
/* 342 */         this.entrada = null;
/* 343 */         System.out.println("fechou entrada");
/*     */       }
/* 345 */       if (this.saida != null) {
/* 346 */         this.saida.close();
/* 347 */         this.saida = null;
/* 348 */         System.out.println("fechou saida");
/*     */       }
/* 350 */       if (this.portaSerial != null) {
/* 351 */         this.portaSerial.close();
/* 352 */         this.portaSerial = null;
/* 353 */         System.out.println("fechou portaSerial");
/*     */       }
/* 355 */       this.indice = -1;
/*     */     } catch (IOException ioe) {
/* 357 */       System.err.println(ioe.getMessage());
/* 358 */       ioe.printStackTrace();
/* 359 */       return false;
/*     */     }
/*     */     
/* 362 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public BufferedInputStream getEntrada()
/*     */   {
/* 368 */     return this.entrada;
/*     */   }
/*     */   
/*     */   public BufferedOutputStream getSaida() {
/* 372 */     return this.saida;
/*     */   }
/*     */   
/*     */   public SerialPort getPortaSerial() {
/* 376 */     return this.portaSerial;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void serialEvent(SerialPortEvent spe)
/*     */   {
/* 388 */     switch (spe.getEventType())
/*     */     {
/*     */     case 2: 
/*     */     case 3: 
/*     */     case 4: 
/*     */     case 5: 
/*     */     case 6: 
/*     */     case 7: 
/*     */     case 8: 
/*     */     case 9: 
/*     */     case 10: 
/*     */       break;
/*     */     case 1: 
/*     */       try
/*     */       {
/* 403 */         Thread.sleep(this.delayLeitura);
/*     */         
/* 405 */         int bytes = this.entrada.available();
/*     */         
/*     */ 
/*     */ 
/* 409 */         for (int i = 0; i < bytes; i++) {
/* 410 */           this.pacote[i] = this.entrada.read();
/*     */         }
/*     */         
/* 413 */         this.pacote[bytes] = bytes;
/*     */         
/*     */ 
/*     */ 
/* 417 */         for (int i = bytes + 1; i < this.pacote.length; i++) {
/* 418 */           this.pacote[i] = -1;
/*     */         }
/*     */         try
/*     */         {
/* 422 */           this.ouvinteDriver.notifica();
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 426 */           e.printStackTrace();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 442 */         return;
/*     */       }
/*     */       catch (IOException localIOException) {}catch (InterruptedException localInterruptedException) {}catch (Exception e)
/*     */       {
/* 437 */         close();
/* 438 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean sendBytes(int[] pct)
/*     */   {
/*     */     try
/*     */     {
/* 454 */       StringBuilder sb = new StringBuilder();
/* 455 */       for (int i = 0; i < pct.length; i++)
/*     */       {
/* 457 */         this.saida.write(pct[i]);
/* 458 */         sb.append(Integer.toHexString(pct[i]) + " ");
/*     */       }
/* 460 */       this.saida.flush();
/* 461 */       return true;
/*     */     }
/*     */     catch (IOException ioe) {}
/*     */     
/* 465 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean sendBytes(int[] pct, int delay)
/*     */   {
/*     */     try
/*     */     {
/* 482 */       for (int i = 0; i < pct.length; i++)
/*     */       {
/* 484 */         this.saida.write(pct[i]);
/* 485 */         Thread.sleep(delay);
/*     */       }
/*     */       
/* 488 */       this.saida.flush();
/* 489 */       return true;
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 493 */       return false;
/*     */     }
/*     */     catch (InterruptedException e) {}
/*     */     
/* 497 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getBytes()
/*     */   {
/* 508 */     return this.pacote;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void finalize()
/*     */   {
/* 520 */     close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getPortas()
/*     */   {
/* 539 */     String[] portas = new String[this.quantidadePortas];
/*     */     
/* 541 */     for (int i = 0; i < portas.length; i++) {
/* 542 */       portas[i] = this.identificadoresPortas[i].getName();
/*     */     }
/* 544 */     return portas;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndicePortaAtual()
/*     */   {
/* 554 */     return this.indice;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNomePortaAtual()
/*     */   {
/* 564 */     if (!SystemUtils.IS_OS_WINDOWS) {
/* 565 */       if (this.portaSerial != null) {
/* 566 */         return this.portaSerial.getName();
/*     */       }
/* 568 */       return null;
/*     */     }
/*     */     
/* 571 */     if (this.portaSerial != null) {
/* 572 */       return this.portaSerial.getName().replaceAll("[^a-zA-Z0-9]", "");
/*     */     }
/* 574 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDriverListener(DriverListener ouvinteDriver)
/*     */   {
/* 589 */     this.ouvinteDriver = ouvinteDriver;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\serial\DriverSerial.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */