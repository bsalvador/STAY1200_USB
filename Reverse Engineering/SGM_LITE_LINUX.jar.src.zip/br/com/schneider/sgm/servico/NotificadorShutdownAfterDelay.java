/*    */ package br.com.schneider.sgm.servico;
/*    */ 
/*    */ import br.com.schneider.sgm.controle.Controle;
/*    */ import br.com.schneider.sgm.eventos.Evento;
/*    */ import br.com.schneider.sgm.snmp.UpsAlarmGroup;
/*    */ import org.snmp4j.smi.TimeTicks;
/*    */ 
/*    */ public class NotificadorShutdownAfterDelay extends NotificadorTraps
/*    */ {
/*    */   private Controle feeder;
/*    */   
/*    */   public NotificadorShutdownAfterDelay(UpsAlarmGroup grupoAlarme, org.snmp4j.agent.NotificationOriginator notificationOriginator, boolean[] alarmesUpsMIB, Evento[] alarmesMicrosol, TimeTicks horaAlarme, Controle feeder)
/*    */   {
/* 14 */     super(grupoAlarme, notificationOriginator, alarmesUpsMIB, alarmesMicrosol, horaAlarme);
/*    */     
/* 16 */     this.feeder = feeder;
/*    */   }
/*    */   
/*    */   public void run()
/*    */   {
/* 21 */     updateAlarmesUpsMIB();
/* 22 */     this.feeder.desligaUPS();
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\NotificadorShutdownAfterDelay.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */