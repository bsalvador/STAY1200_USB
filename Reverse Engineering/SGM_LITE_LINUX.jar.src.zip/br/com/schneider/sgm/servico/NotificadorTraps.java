/*     */ package br.com.schneider.sgm.servico;
/*     */ 
/*     */ import br.com.schneider.sgm.eventos.Evento;
/*     */ import br.com.schneider.sgm.snmp.UpsAlarmGroup;
/*     */ import br.com.schneider.sgm.snmp.UpsMibOids;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.snmp4j.agent.NotificationOriginator;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.TimeTicks;
/*     */ import org.snmp4j.smi.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotificadorTraps
/*     */   extends Thread
/*     */ {
/*     */   private UpsAlarmGroup grupoAlarme;
/*     */   private NotificationOriginator notificationOriginator;
/*     */   private boolean[] alarmesUpsMIB;
/*     */   private Evento[] alarmesMicrosol;
/*     */   private TimeTicks horaAlarme;
/*     */   private GregorianCalendar dataSistema;
/*     */   private GregorianCalendar dataUPS;
/*     */   
/*     */   public NotificadorTraps(UpsAlarmGroup grupoAlarme, NotificationOriginator notificationOriginator, boolean[] alarmesUpsMIB, Evento[] alarmesMicrosol, TimeTicks horaAlarme)
/*     */   {
/*  51 */     this.grupoAlarme = grupoAlarme;
/*  52 */     this.notificationOriginator = notificationOriginator;
/*  53 */     this.alarmesUpsMIB = alarmesUpsMIB;
/*  54 */     this.alarmesMicrosol = alarmesMicrosol;
/*  55 */     this.horaAlarme = horaAlarme;
/*  56 */     this.dataSistema = new GregorianCalendar();
/*  57 */     this.dataUPS = new GregorianCalendar();
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*  62 */     updateAlarmesUpsMIB();
/*  63 */     updateAlarmesMicrosol();
/*     */   }
/*     */   
/*     */   protected void updateAlarmesUpsMIB()
/*     */   {
/*  68 */     String descAlarme = "";
/*  69 */     int indice = 0;
/*  70 */     if (this.alarmesUpsMIB != null) {
/*  71 */       for (int i = 0; i < this.alarmesUpsMIB.length; i++)
/*     */       {
/*  73 */         indice++;
/*  74 */         descAlarme = UpsMibOids.getWellKnownAlarm(indice);
/*     */         
/*     */ 
/*  77 */         if (this.alarmesUpsMIB[i] != 0)
/*     */         {
/*     */ 
/*  80 */           if (this.grupoAlarme.getUpsAlarmRow(indice) == null)
/*     */           {
/*     */ 
/*  83 */             this.grupoAlarme.addUpsAlarmEntry(
/*  84 */               indice, 
/*  85 */               descAlarme, 
/*  86 */               this.horaAlarme.getValue());
/*     */             
/*     */ 
/*     */ 
/*  90 */             this.notificationOriginator.notify(
/*  91 */               new OctetString(), 
/*  92 */               new OID("1.3.6.1.2.1.33.2.3"), 
/*  93 */               this.horaAlarme, 
/*  94 */               new VariableBinding[] {
/*  95 */               new VariableBinding(
/*  96 */               new OID("1.3.6.1.2.1.33.1.6.2.1.2." + String.valueOf(indice)), 
/*  97 */               new OID(descAlarme)), 
/*     */               
/*  99 */               new VariableBinding(
/* 100 */               new OID("1.3.6.1.2.1.33.1.6.2.1.3"), 
/* 101 */               new OctetString(this.horaAlarme.toString())) });
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 111 */         else if (this.grupoAlarme.getUpsAlarmRow(indice) != null)
/*     */         {
/*     */ 
/* 114 */           this.grupoAlarme.removeUpsAlarmEntry(indice);
/*     */           
/*     */ 
/* 117 */           this.notificationOriginator.notify(
/* 118 */             new OctetString(), 
/* 119 */             new OID("1.3.6.1.2.1.33.2.4"), 
/* 120 */             this.horaAlarme, 
/* 121 */             new VariableBinding[] {
/*     */             
/* 123 */             new VariableBinding(
/* 124 */             new OID("1.3.6.1.2.1.33.1.6.2.1.2." + String.valueOf(indice)), 
/* 125 */             new OID(descAlarme)), 
/*     */             
/* 127 */             new VariableBinding(
/* 128 */             new OID("1.3.6.1.2.1.33.1.6.2.1.3"), 
/* 129 */             new OctetString(this.horaAlarme.toString())) });
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void updateAlarmesMicrosol()
/*     */   {
/* 141 */     int i = 0;
/*     */     
/* 143 */     if (this.alarmesMicrosol != null)
/*     */     {
/* 145 */       for (int k = 0; k < this.alarmesMicrosol.length; k++) {
/* 146 */         while ((i <= this.alarmesMicrosol.length - 1) && 
/* 147 */           (this.alarmesMicrosol[i] != null))
/*     */         {
/*     */ 
/* 150 */           this.notificationOriginator.notify(
/* 151 */             new OctetString(), 
/* 152 */             new OID("1.3.6.1.2.1.33.2.5"), 
/* 153 */             this.horaAlarme, 
/* 154 */             new VariableBinding[] {
/* 155 */             new VariableBinding(
/* 156 */             new OID("1.3.6.1.2.1.33.1.6.3.25"), 
/* 157 */             new OctetString(this.alarmesMicrosol[i].getTipo())), 
/*     */             
/* 159 */             new VariableBinding(
/* 160 */             new OID("1.3.6.1.2.1.33.1.6.3.25"), 
/* 161 */             new OctetString(getDataHoraAlarmeMicrosol(this.alarmesMicrosol[i]))) });
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 166 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDataHoraAlarmeMicrosol(Evento alarme)
/*     */   {
/* 179 */     this.dataSistema.setTimeInMillis(System.currentTimeMillis());
/* 180 */     this.dataSistema.set(2, 0);
/*     */     
/* 182 */     this.dataUPS.set(5, alarme.getDia());
/* 183 */     this.dataUPS.set(11, alarme.getHora());
/* 184 */     this.dataUPS.set(12, alarme.getMinuto());
/*     */     
/*     */ 
/* 187 */     if (alarme.getDia() < this.dataSistema.get(5))
/*     */     {
/*     */ 
/* 190 */       if (this.dataSistema.get(2) == 0)
/*     */       {
/* 192 */         this.dataUPS.set(1, this.dataSistema.get(1) - 1);
/* 193 */         this.dataUPS.set(2, 11);
/*     */       }
/*     */       else
/*     */       {
/* 197 */         this.dataUPS.set(1, this.dataSistema.get(1));
/* 198 */         this.dataUPS.set(2, this.dataSistema.get(2) - 1);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 203 */       this.dataUPS.set(1, this.dataSistema.get(1));
/* 204 */       this.dataUPS.set(2, this.dataSistema.get(2));
/*     */     }
/*     */     
/* 207 */     return this.dataUPS.getTime().toString();
/*     */   }
/*     */   
/*     */   private Evento[] geraAlarmesMicrosol()
/*     */   {
/* 212 */     String[] listaAlarmes = { "SUBTENSAO_ENTRADA", "SOBRETENSAO_ENTRADA", "RETORNO_REDE_ELETRICA", 
/* 213 */       "SOBRECARGA", "BATERIAS_DESCARREGADAS", "CHAVE_LIGADA", "CHAVE_DESLIGADA", 
/* 214 */       "DESLIGAMENTO", "INICIALIZACAO", "DESLIGAMENTO_REMOTO", 
/* 215 */       "SUPER_AQUECIMENTO", "DESLIGAMENTO_PROGAMADO", "ACIONAMENTO_PROGRAMADO", 
/* 216 */       "SAIDA_SEM_CONSUMO", "BATERIA_BAIXA", "SAIDA_LIGADA", 
/* 217 */       "BATERIAS_CARREGADAS" };
/*     */     
/* 219 */     Evento[] res = new Evento[listaAlarmes.length];
/*     */     
/* 221 */     GregorianCalendar dataSistema = new GregorianCalendar();
/* 222 */     dataSistema.setTimeInMillis(System.currentTimeMillis());
/*     */     
/* 224 */     int dia = 22;
/* 225 */     int hora = dataSistema.get(11);
/* 226 */     int min = dataSistema.get(12);
/* 227 */     int seg = dataSistema.get(13);
/* 228 */     int mes = dataSistema.get(2) + 1;
/* 229 */     int ano = dataSistema.get(1);
/*     */     
/* 231 */     for (int i = 0; i < res.length; i++) {
/* 232 */       res[i] = new Evento(listaAlarmes[i], hora, min, seg, dia, mes, ano);
/*     */     }
/*     */     
/* 235 */     return res;
/*     */   }
/*     */   
/*     */   public static boolean[] geraAlarmes(boolean valor)
/*     */   {
/* 240 */     boolean[] res = new boolean[24];
/*     */     
/* 242 */     for (int i = 0; i < res.length; i++) {
/* 243 */       res[i] = valor;
/*     */     }
/*     */     
/*     */ 
/* 247 */     return res;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\NotificadorTraps.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */