/*     */ package br.com.schneider.sgm.servico;
/*     */ 
/*     */ import br.com.schneider.sgm.config.PathConfig;
/*     */ import br.com.schneider.sgm.gui.PainelGraficos;
/*     */ import br.com.schneider.sgm.historico.HistoricoConsumo;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SalvaConsumo
/*     */   implements Runnable
/*     */ {
/*     */   private HistoricoConsumo historico;
/*     */   private String[] resultado;
/*     */   private String[] valor;
/*     */   private String[] dia;
/*     */   private float consumo;
/*     */   private Calendar calendar;
/*     */   private double[] valorDia;
/*     */   private PainelGraficos painelGraficos;
/*     */   
/*     */   public SalvaConsumo(float consumo, PainelGraficos pg)
/*     */   {
/*  62 */     this.historico = new HistoricoConsumo(PathConfig.getPathXML() + "consumo.xml");
/*  63 */     this.consumo = consumo;
/*  64 */     this.valorDia = new double[32];
/*  65 */     this.painelGraficos = pg;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*  70 */     salvaConsumo();
/*  71 */     this.painelGraficos.atualizaGraficos();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void leMesAtual()
/*     */   {
/*  79 */     this.calendar = Calendar.getInstance();
/*  80 */     String data = Integer.toString(this.calendar.get(2) + 1);
/*  81 */     data = data + "-" + Integer.toString(this.calendar.get(1));
/*  82 */     this.resultado = this.historico.getConsumoDiario(data).split(", ");
/*     */     try
/*     */     {
/*  85 */       for (int i = 0; i < this.resultado.length; i++)
/*     */       {
/*  87 */         this.valor = this.resultado[i].split("=");
/*  88 */         this.dia = this.valor[0].split("-");
/*  89 */         this.valorDia[Integer.parseInt(this.dia[2])] = Double.parseDouble(this.valor[1]);
/*     */       }
/*     */     }
/*     */     catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private float getAndSetConsumoDia()
/*     */   {
/* 104 */     leMesAtual();
/* 105 */     int diaAtual = this.calendar.get(5);
/* 106 */     this.consumo = ((float)(this.consumo + this.valorDia[diaAtual]));
/* 107 */     return this.consumo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void salvaConsumo()
/*     */   {
/* 115 */     this.historico.inserirDia(getAndSetConsumoDia());
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\SalvaConsumo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */