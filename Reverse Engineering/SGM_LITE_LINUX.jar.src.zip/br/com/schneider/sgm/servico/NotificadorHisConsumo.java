/*    */ package br.com.schneider.sgm.servico;
/*    */ 
/*    */ import br.com.schneider.sgm.historico.HistoricoConsumo;
/*    */ import br.com.schneider.sgm.snmp.UpsOutputGroup;
/*    */ import br.com.schneider.sgm.snmp.UpsOutputGroup.UpsOutputEnumeratedScalar;
/*    */ import org.snmp4j.agent.NotificationOriginator;
/*    */ import org.snmp4j.smi.Integer32;
/*    */ import org.snmp4j.smi.OID;
/*    */ import org.snmp4j.smi.OctetString;
/*    */ import org.snmp4j.smi.TimeTicks;
/*    */ import org.snmp4j.smi.VariableBinding;
/*    */ 
/*    */ public class NotificadorHisConsumo extends Thread
/*    */ {
/*    */   private UpsOutputGroup grupoSaida;
/*    */   private NotificationOriginator notificationOriginator;
/*    */   private HistoricoConsumo hisConsumo;
/*    */   private TimeTicks horaTrap;
/*    */   
/*    */   public NotificadorHisConsumo(UpsOutputGroup grupoSaida, NotificationOriginator notificationOriginator, HistoricoConsumo hisConsumo, TimeTicks horaTrap)
/*    */   {
/* 22 */     this.grupoSaida = grupoSaida;
/* 23 */     this.notificationOriginator = notificationOriginator;
/* 24 */     this.hisConsumo = hisConsumo;
/* 25 */     this.horaTrap = horaTrap;
/*    */   }
/*    */   
/*    */ 
/*    */   public void run()
/*    */   {
/* 31 */     int tipoHisConsulta = ((Integer32)this.grupoSaida.getUpsTipoHisConsumo().getValue()).toInt();
/* 32 */     String periodoConsulta = ((OctetString)this.grupoSaida.getUpsPeriodoConsumo().getValue()).toString();
/* 33 */     String valor = "";
/* 34 */     switch (tipoHisConsulta)
/*    */     {
/*    */ 
/*    */     case 1: 
/* 38 */       valor = this.hisConsumo.getConsumoDiario(periodoConsulta);
/* 39 */       break;
/*    */     
/*    */ 
/*    */     case 2: 
/* 43 */       valor = this.hisConsumo.getConsumoSemanal(periodoConsulta);
/* 44 */       break;
/*    */     
/*    */ 
/*    */     case 3: 
/* 48 */       valor = this.hisConsumo.getConsumoMensal(periodoConsulta);
/* 49 */       break;
/*    */     
/*    */ 
/*    */     case 4: 
/* 53 */       valor = this.hisConsumo.getConsumoAnual(periodoConsulta);
/*    */     }
/*    */     
/*    */     
/*    */ 
/* 58 */     this.grupoSaida.setsUpsResultadoConsumo(valor);
/*    */     
/*    */ 
/*    */ 
/* 62 */     this.notificationOriginator.notify(
/* 63 */       new OctetString(), 
/* 64 */       new OID("1.3.6.1.2.1.33.2.6"), 
/* 65 */       this.horaTrap, 
/* 66 */       new VariableBinding[] {
/* 67 */       new VariableBinding(
/* 68 */       new OID("1.3.6.1.2.1.33.1.4.6"), 
/* 69 */       new Integer32(tipoHisConsulta)), 
/*    */       
/* 71 */       new VariableBinding(
/* 72 */       new OID("1.3.6.1.2.1.33.1.4.7"), 
/* 73 */       new OctetString(periodoConsulta)), 
/*    */       
/* 75 */       new VariableBinding(
/* 76 */       new OID("1.3.6.1.2.1.33.1.4.8"), 
/* 77 */       new OctetString(valor)) });
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 83 */     this.grupoSaida.getUpsTipoHisConsumo().setAtualizacao(false);
/* 84 */     this.grupoSaida.getUpsTipoHisConsumo().setAtualizacao(false);
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\NotificadorHisConsumo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */