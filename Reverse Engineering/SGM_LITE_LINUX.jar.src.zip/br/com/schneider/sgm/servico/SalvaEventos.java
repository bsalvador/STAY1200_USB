/*    */ package br.com.schneider.sgm.servico;
/*    */ 
/*    */ import br.com.schneider.sgm.eventos.Evento;
/*    */ import br.com.schneider.sgm.historico.Historico;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SalvaEventos
/*    */   extends Thread
/*    */   implements Runnable
/*    */ {
/*    */   private Historico historicoEventos;
/*    */   private Evento[] eventos;
/*    */   Calendar calendar;
/*    */   
/*    */   public SalvaEventos(Evento[] eventos, Historico historico)
/*    */   {
/* 37 */     this.historicoEventos = historico;
/* 38 */     this.eventos = eventos;
/* 39 */     this.calendar = Calendar.getInstance();
/*    */   }
/*    */   
/*    */ 
/*    */   public void run()
/*    */   {
/* 45 */     if (this.eventos != null)
/*    */     {
/* 47 */       for (int i = 0; i < this.eventos.length; i++)
/*    */       {
/* 49 */         if (this.eventos[i] != null)
/*    */         {
/* 51 */           this.historicoEventos.inserirEvento(this.eventos[i], this.calendar.get(2) + 1, this.calendar.get(1));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\SalvaEventos.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */