/*    */ package br.com.schneider.sgm.servico;
/*    */ 
/*    */ import br.com.schneider.sgm.snmp.UpsBatteryGroup;
/*    */ import br.com.schneider.sgm.snmp.UpsConfigGroup;
/*    */ import org.snmp4j.agent.NotificationOriginator;
/*    */ import org.snmp4j.smi.OID;
/*    */ import org.snmp4j.smi.OctetString;
/*    */ import org.snmp4j.smi.TimeTicks;
/*    */ import org.snmp4j.smi.VariableBinding;
/*    */ 
/*    */ 
/*    */ public class NotificadorTrapOnBattery
/*    */   extends Thread
/*    */ {
/*    */   private UpsBatteryGroup grupoBateria;
/*    */   private UpsConfigGroup grupoConfig;
/*    */   private NotificationOriginator notificationOriginator;
/*    */   private TimeTicks horaAlarme;
/*    */   
/*    */   public NotificadorTrapOnBattery(UpsBatteryGroup grupoBateria, UpsConfigGroup grupoConfig, NotificationOriginator notificationOriginator, TimeTicks horaAlarme)
/*    */   {
/* 22 */     this.grupoBateria = grupoBateria;
/* 23 */     this.grupoConfig = grupoConfig;
/* 24 */     this.notificationOriginator = notificationOriginator;
/* 25 */     this.horaAlarme = horaAlarme;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/* 32 */     this.notificationOriginator.notify(new OctetString(), 
/* 33 */       new OID("1.3.6.1.2.1.33.2.1"), 
/* 34 */       this.horaAlarme, 
/* 35 */       new VariableBinding[] {
/* 36 */       new VariableBinding(
/* 37 */       new OID("1.3.6.1.2.1.33.1.2.3.0"), 
/* 38 */       this.grupoBateria.getUpsEstimatedMinutesRemaining()), 
/* 39 */       new VariableBinding(
/* 40 */       new OID("1.3.6.1.2.1.33.1.2.2.0"), 
/* 41 */       this.grupoBateria.getUpsSecondsOnBattery()), 
/* 42 */       new VariableBinding(
/* 43 */       new OID("1.3.6.1.2.1.33.1.9.7.0"), 
/* 44 */       this.grupoConfig.getUpsConfigLowBattTime()) });
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\NotificadorTrapOnBattery.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */