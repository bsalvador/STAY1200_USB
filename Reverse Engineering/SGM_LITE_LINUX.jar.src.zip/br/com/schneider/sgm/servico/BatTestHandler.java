/*     */ package br.com.schneider.sgm.servico;
/*     */ 
/*     */ import br.com.schneider.sgm.controle.Controle;
/*     */ import br.com.schneider.sgm.eventos.BatTesteListener;
/*     */ import br.com.schneider.sgm.eventos.ControleListener;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatTestHandler
/*     */   implements Runnable, ControleListener
/*     */ {
/*     */   private static final int AGUARDANDO_TESTE = 0;
/*     */   private static final int INICIANDO = 1;
/*     */   private static final int AGUARDANDO_DESLIGAR = 2;
/*     */   private static final int EXECUTANDO = 3;
/*     */   private static final int AGUARDANDO_LIGAR = 4;
/*     */   private static final int FINALIZANDO = 5;
/*     */   private static final int FALHA_TIMEOUT = 1;
/*     */   private static final int FALHA_BATERIA_MUITO_BAIXA = 2;
/*     */   private static final int FALHA_COMUNICACAO = 3;
/*     */   private static final int TIME_OUT_EXECUTANDO = 20;
/*     */   private static final int TIMEOUT = 10;
/*     */   private static final int AUTO_TESTE_DIARIO = 0;
/*     */   private static final int AUTO_TESTE_SEMANAL = 1;
/*     */   private static final int AUTO_TESTE_MENSAL = 2;
/*     */   private int horaTeste;
/*     */   private int minutoTeste;
/*     */   private int periodoAutoTeste;
/*     */   private boolean autoTesteEnabled;
/*     */   private boolean executandoAutoTeste;
/*     */   private char estado;
/*     */   private float tensaoBateriaInicial;
/*     */   private float potenciaInicial;
/*     */   private float tensaoBateriaFinal;
/*     */   private float potenciaFinal;
/*     */   private int tempoTeste;
/*     */   private int timeout;
/*  67 */   private BatTesteListener batListener = null;
/*     */   
/*  69 */   private static Logger log = Logger.getLogger(BatTestHandler.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Controle controle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BatTestHandler(Controle controle, BatTesteListener bat)
/*     */   {
/*  83 */     this.horaTeste = 0;
/*  84 */     this.minutoTeste = 0;
/*  85 */     this.periodoAutoTeste = 0;
/*  86 */     this.autoTesteEnabled = false;
/*  87 */     this.controle = controle;
/*  88 */     this.estado = '\000';
/*  89 */     this.batListener = bat;
/*  90 */     controle.addControleListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BatTestHandler(int horaTeste, int minutoTeste, int periodoAutoTeste, boolean autoTesteEnabled, Controle controle)
/*     */   {
/*  99 */     this.horaTeste = horaTeste;
/* 100 */     this.minutoTeste = minutoTeste;
/* 101 */     this.periodoAutoTeste = periodoAutoTeste;
/* 102 */     this.autoTesteEnabled = autoTesteEnabled;
/* 103 */     this.controle = controle;
/* 104 */     this.controle.addControleListener(this);
/* 105 */     this.estado = '\000';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 115 */     int timeout = 0;
/*     */     
/* 117 */     boolean iniciado = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     for (;;)
/*     */     {
/*     */       try
/*     */       {
/* 127 */         Thread.sleep(15000L);
/*     */       }
/*     */       catch (InterruptedException localInterruptedException) {}
/*     */       
/* 131 */       if (!this.autoTesteEnabled) {
/* 132 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 137 */       if (this.estado != 0)
/*     */       {
/* 139 */         timeout++;
/* 140 */         if (timeout > 20)
/*     */         {
/* 142 */           this.estado = '\000';
/* 143 */           this.batListener.testeBateriaAbortado(1);
/*     */         }
/*     */       }
/*     */       
/* 147 */       if ((this.controle.getHora() != this.horaTeste) || (this.controle.getMinutos() != this.minutoTeste)) {
/* 148 */         iniciado = false;
/*     */       }
/*     */       else
/*     */       {
/* 152 */         log.info("AUTO TESTE BATERIA - Verificando se Auto Teste Bateria ï¿½ iniciado");
/*     */         
/* 154 */         if ((!iniciado) && (this.estado == 0))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */           if (!this.controle.isBatteryTestAvailable())
/*     */           {
/* 163 */             this.batListener.testeBateriaIndisponivel();
/* 164 */             iniciado = true;
/*     */           }
/*     */           else
/*     */           {
/* 168 */             switch (this.periodoAutoTeste) {
/*     */             case 0: 
/* 170 */               if (!this.executandoAutoTeste)
/*     */               {
/*     */ 
/* 173 */                 iniciarAutoTeste();
/* 174 */                 iniciado = true;
/*     */               }
/* 176 */               break;
/*     */             
/*     */ 
/*     */             case 1: 
/* 180 */               if ((this.controle.getDiaSemana() == 1) && 
/*     */               
/* 182 */                 (!this.executandoAutoTeste))
/*     */               {
/*     */ 
/* 185 */                 iniciarAutoTeste();
/* 186 */                 iniciado = true;
/*     */               }
/* 188 */               break;
/*     */             
/*     */             case 2: 
/* 191 */               if ((this.controle.getDiaMes() == 1) && 
/*     */               
/* 193 */                 (!this.executandoAutoTeste))
/*     */               {
/*     */ 
/* 196 */                 iniciarAutoTeste();
/* 197 */                 iniciado = true;
/*     */               }
/*     */               
/*     */               break;
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void iniciarAutoTeste()
/*     */   {
/* 211 */     this.controle.ligaEntrada();
/* 212 */     log.info("AUTO TESTE BATERIA -  iniciarAutoTeste()");
/*     */     
/* 214 */     if (this.controle.isRedeFalha())
/* 215 */       return;
/* 216 */     if (!this.controle.isSaidaLigada())
/* 217 */       return;
/* 218 */     if (this.controle.isBypassAtivado()) {
/* 219 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 225 */     this.estado = '\001';
/* 226 */     this.executandoAutoTeste = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void iniciando()
/*     */   {
/* 234 */     log.fine("AUTO TESTE BATERIA -  iniciando()");
/* 235 */     this.tensaoBateriaInicial = this.controle.getTensaoBateria();
/* 236 */     this.potenciaInicial = this.controle.getPotenciaReal();
/* 237 */     this.batListener.inicioTesteBateria();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean executando()
/*     */   {
/* 244 */     log.info("AUTO TESTE BATERIA -  executando()");
/* 245 */     this.tempoTeste += 1;
/*     */     
/* 247 */     if (this.tempoTeste > 60) {
/* 248 */       return false;
/*     */     }
/* 250 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void finaliza()
/*     */   {
/* 258 */     this.executandoAutoTeste = false;
/* 259 */     this.tensaoBateriaFinal = this.controle.getTensaoBateria();
/* 260 */     this.potenciaFinal = this.controle.getPotenciaReal();
/*     */     
/* 262 */     this.batListener.fimTesteBateria(this.controle.calculaEstadoBaterias(
/* 263 */       this.tensaoBateriaInicial, this.tensaoBateriaFinal, 
/* 264 */       (this.potenciaFinal + this.potenciaInicial) / 2.0F, this.tempoTeste));
/* 265 */     this.estado = '\000';
/* 266 */     log.fine("AUTO TESTE BATERIA -  finaliza() : Final!");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void autoTeste()
/*     */   {
/* 273 */     if (!this.executandoAutoTeste)
/* 274 */       return;
/* 275 */     if ((this.timeout > 10) && (this.estado != '\003'))
/* 276 */       abortar(1);
/* 277 */     if ((this.timeout > 20) && (this.estado == '\003'))
/* 278 */       abortar(1);
/* 279 */     if (this.controle.isBateriaBaixa()) {
/* 280 */       abortar(2);
/*     */     }
/* 282 */     switch (this.estado)
/*     */     {
/*     */     case '\001': 
/* 285 */       this.estado = ((char)(this.estado + '\001'));
/* 286 */       this.timeout = 0;
/* 287 */       break;
/*     */     
/*     */ 
/*     */     case '\002': 
/* 291 */       this.controle.desligaEntrada();
/*     */       
/* 293 */       if (!this.controle.isUsandoSomenteBateria())
/*     */       {
/* 295 */         this.tempoTeste = 0;
/* 296 */         this.timeout += 1;
/* 297 */         log.fine("AUTO TESTE BATERIA -  Aguardando Desligar");
/*     */       }
/*     */       else
/*     */       {
/* 301 */         this.estado = ((char)(this.estado + '\001'));
/* 302 */         this.timeout = 0;
/* 303 */         iniciando();
/*     */       }
/* 305 */       break;
/*     */     
/*     */     case '\003': 
/* 308 */       log.info("AUTO TESTE BATERIA - Executando");
/* 309 */       if (!executando()) {
/* 310 */         this.timeout = 0;
/* 311 */         this.estado = ((char)(this.estado + '\001'));
/*     */       }
/* 313 */       break;
/*     */     
/*     */     case '\004': 
/* 316 */       log.info("AUTO TESTE BATERIA - Aguardando Ligar");
/* 317 */       this.controle.ligaEntrada();
/* 318 */       if (this.controle.isUsandoSomenteBateria()) {
/* 319 */         this.estado = ((char)(this.estado + '\001'));
/* 320 */         this.timeout += 1;
/*     */       } else {
/* 322 */         this.timeout = 0; }
/* 323 */       break;
/*     */     
/*     */     case '\005': 
/* 326 */       finaliza();
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void abortar(int mensagem)
/*     */   {
/* 340 */     String msg = new String();
/*     */     
/*     */ 
/*     */ 
/* 344 */     this.controle.ligaEntrada();
/* 345 */     switch (mensagem) {
/*     */     case 2: 
/* 347 */       this.batListener.testeBateriaAbortado(2);
/* 348 */       msg = "abortado: bateria baixa";
/* 349 */       break;
/*     */     case 1: 
/* 351 */       this.batListener.testeBateriaAbortado(1);
/* 352 */       msg = "abortado: timeout";
/* 353 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 360 */       this.batListener.testeBateriaAbortado(3);
/* 361 */       msg = "abortado: falha comunicacao";
/*     */     }
/*     */     
/*     */     
/* 365 */     log.warning("AUTO TESTE BATERIA - abortar(): " + msg);
/* 366 */     this.executandoAutoTeste = false;
/* 367 */     this.controle.ligaEntrada();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPeriodoAutoTeste()
/*     */   {
/* 376 */     return this.periodoAutoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHoraTeste()
/*     */   {
/* 384 */     return this.horaTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinutoTeste()
/*     */   {
/* 392 */     return this.minutoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getAutoTesteHabilitado()
/*     */   {
/* 399 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPeriodoAutoTeste(int periodo)
/*     */   {
/* 410 */     this.periodoAutoTeste = periodo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHoraTeste(int hora)
/*     */   {
/* 418 */     if ((hora >= 0) && (hora < 24)) {
/* 419 */       this.horaTeste = hora;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinutoTeste(int minuto)
/*     */   {
/* 428 */     if ((minuto >= 0) && (minuto < 60)) {
/* 429 */       this.minutoTeste = minuto;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAutoTesteHabilitado(boolean tst)
/*     */   {
/* 436 */     this.autoTesteEnabled = tst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notificaBateriaBaixa() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notificaBateriaNormal() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notificaCargaElevada() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notificaCargaNormal() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notificaComunicacao() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notificaDados()
/*     */   {
/* 477 */     if (this.estado != 0) {
/* 478 */       autoTeste();
/*     */     }
/*     */   }
/*     */   
/*     */   public void notificaFalhaCom() {}
/*     */   
/*     */   public void notificaFalhaRede() {}
/*     */   
/*     */   public void notificaNaoUsaBateria() {}
/*     */   
/*     */   public void notificaRetornoCom() {}
/*     */   
/*     */   public void notificaRetornoRede() {}
/*     */   
/*     */   public void notificaTemperaturaElevada() {}
/*     */   
/*     */   public void notificaTemperaturaNormal() {}
/*     */   
/*     */   public void notificaUsandoBateria() {}
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\BatTestHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */