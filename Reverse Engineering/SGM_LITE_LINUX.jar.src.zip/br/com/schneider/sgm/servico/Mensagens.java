/*     */ package br.com.schneider.sgm.servico;
/*     */ 
/*     */ import br.com.schneider.sgm.eventos.MailEvent;
/*     */ import br.com.schneider.sgm.gui.InterfaceGrafica;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mensagens
/*     */   extends Thread
/*     */ {
/*     */   private String descricaoAlarme;
/*     */   private String horaAlarme;
/*     */   private String[] emails;
/*     */   private String emailRemetente;
/*     */   private String servidorSMTP;
/*     */   private int portaSMTP;
/*     */   private boolean autenticacaoSMTP;
/*     */   private String usuarioServidor;
/*     */   private String senhaServidor;
/*     */   private String enderecoAlarme;
/*     */   private String mensagemErro;
/*     */   private InterfaceGrafica gui;
/*     */   private String idioma;
/*     */   
/*     */   public Mensagens(String descricaoAlarme, String enderecoAlarme, String horaAlarme, String[] emails, String emailRemetente, String servidorSMTP, int portaSMTP, boolean autenticacaoSMTP, String usuarioServidor, String senhaServidor, String idioma)
/*     */   {
/*  73 */     this.descricaoAlarme = descricaoAlarme;
/*  74 */     this.enderecoAlarme = enderecoAlarme;
/*  75 */     this.horaAlarme = horaAlarme;
/*  76 */     this.emails = emails;
/*  77 */     this.emailRemetente = emailRemetente;
/*  78 */     this.servidorSMTP = servidorSMTP;
/*  79 */     this.portaSMTP = portaSMTP;
/*  80 */     this.autenticacaoSMTP = autenticacaoSMTP;
/*  81 */     this.usuarioServidor = usuarioServidor;
/*  82 */     this.senhaServidor = senhaServidor;
/*  83 */     this.idioma = idioma;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*  88 */     enviaEmail();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   private void enviaEmail2()
/*     */   {
/*  94 */     System.out.println("Email enviado: ALARME: " + this.descricaoAlarme + " UPS: " + this.enderecoAlarme + " HORA DO ALARME: " + this.horaAlarme);
/*     */   }
/*     */   
/*     */   private void enviaEmail() {
/*  98 */     if (this.idioma.toUpperCase().startsWith("PORTUGU")) {
/*  99 */       MailEvent.send(this.autenticacaoSMTP, this.usuarioServidor, this.senhaServidor, this.servidorSMTP, Integer.valueOf(this.portaSMTP), this.emailRemetente, this.emails[0], "Software de Gerenciamento SGM.", "ALARME: " + this.descricaoAlarme + "\n\nUPS: " + this.enderecoAlarme + "\n\nHORA DO ALARME: " + this.horaAlarme);
/*     */     } else {
/* 101 */       MailEvent.send(this.autenticacaoSMTP, this.usuarioServidor, this.senhaServidor, this.servidorSMTP, Integer.valueOf(this.portaSMTP), this.emailRemetente, this.emails[0], "SGM Management Software.", "ALARM: " + this.descricaoAlarme + "\n\nUPS: " + this.enderecoAlarme + "\n\nTIME: " + this.horaAlarme);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void enviaSMS(String url, String[] celulares) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMensagemErro()
/*     */   {
/* 116 */     return this.mensagemErro;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMensagemErro(String mensagemErro)
/*     */   {
/* 123 */     this.mensagemErro = mensagemErro;
/*     */   }
/*     */   
/*     */ 
/*     */   public InterfaceGrafica getGui()
/*     */   {
/* 129 */     return this.gui;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setGui(InterfaceGrafica gui)
/*     */   {
/* 136 */     this.gui = gui;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\Mensagens.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */