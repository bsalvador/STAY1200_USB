/*    */ package br.com.schneider.sgm.servico;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import java.net.ServerSocket;
/*    */ import java.net.Socket;
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecutaAcaoRede
/*    */   extends Thread
/*    */ {
/* 17 */   String[] ipClientesConectados = new String[20];
/* 18 */   int[] portaClientesConectados = new int[20];
/* 19 */   int numeroClientes = 0;
/*    */   int portaEscuta;
/*    */   DataInputStream in;
/*    */   DataOutputStream out;
/*    */   
/*    */   public void run()
/*    */   {
/*    */     try {
/* 27 */       ServerSocket socket = new ServerSocket(this.portaEscuta);
/*    */       for (;;) {
/* 29 */         Socket socketCliente = socket.accept();
/* 30 */         DataInputStream in = new DataInputStream(socketCliente.getInputStream());
/*    */         
/* 32 */         DataOutputStream out = new DataOutputStream(socketCliente.getOutputStream());
/*    */         
/* 34 */         if (in.readUTF().equalsIgnoreCase("ativo")) {
/* 35 */           out.writeUTF("ok");
/* 36 */           int portaCliente = Integer.parseInt(in.readUTF());
/*    */           
/* 38 */           String ip = socketCliente.getInetAddress().toString();
/* 39 */           this.ipClientesConectados[this.numeroClientes] = ip.substring(1, ip.length());
/* 40 */           this.portaClientesConectados[this.numeroClientes] = portaCliente;
/* 41 */           this.numeroClientes += 1;
/*    */         }
/* 43 */         socketCliente.close();
/*    */       }
/*    */     }
/*    */     catch (IOException e) {
/* 47 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */   public void encerraClientes()
/*    */   {
/*    */     try
/*    */     {
/* 55 */       for (int i = 0; i < this.numeroClientes; i++) {
/* 56 */         Socket socketTemp = new Socket(this.ipClientesConectados[i], this.portaClientesConectados[i]);
/*    */         
/* 58 */         this.in = new DataInputStream(socketTemp.getInputStream());
/* 59 */         this.out = new DataOutputStream(socketTemp.getOutputStream());
/*    */         
/* 61 */         this.out.writeUTF("shutdown");
/*    */         
/* 63 */         if (this.in.readUTF().equals("ok"))
/*    */         {
/* 65 */           this.in.close();
/* 66 */           this.out.close();
/* 67 */           socketTemp.close();
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (UnknownHostException ev) {
/* 72 */       ev.printStackTrace();
/*    */     }
/*    */     catch (IOException e) {
/* 75 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 80 */     ExecutaAcaoRede e = new ExecutaAcaoRede();
/* 81 */     e.start();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getPortaEscuta()
/*    */   {
/* 88 */     return this.portaEscuta;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setPortaEscuta(int portaEscuta)
/*    */   {
/* 95 */     this.portaEscuta = portaEscuta;
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\servico\ExecutaAcaoRede.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */