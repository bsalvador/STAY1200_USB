/*    */ package br.com.schneider.sgm.gui;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PainelDec
/*    */   extends JPanel
/*    */ {
/*    */   private static final long serialVersionUID = 5467150158460097260L;
/*    */   private ImageIcon fundo;
/*    */   
/*    */   public PainelDec(String caminho, int espHorizontal, int espVertical)
/*    */   {
/* 19 */     super(new BorderLayout(espHorizontal, espVertical));
/* 20 */     this.fundo = new ImageIcon(caminho);
/*    */   }
/*    */   
/*    */ 
/*    */   public void paintComponent(Graphics g)
/*    */   {
/* 26 */     super.paintComponent(g);
/* 27 */     g.drawImage(this.fundo.getImage(), 0, 0, null);
/*    */   }
/*    */   
/*    */   public ImageIcon getFundo() {
/* 31 */     return this.fundo;
/*    */   }
/*    */   
/*    */   public void setFundo(ImageIcon fundo) {
/* 35 */     this.fundo = fundo;
/* 36 */     repaint();
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelDec.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */