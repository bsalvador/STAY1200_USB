/*      */ package br.com.schneider.sgm.gui;
/*      */ 
/*      */ import br.com.schneider.sgm.grafico.GraficoBateria;
/*      */ import br.com.schneider.sgm.grafico.GraficoCorrente;
/*      */ import br.com.schneider.sgm.grafico.GraficoDiaMes;
/*      */ import br.com.schneider.sgm.grafico.GraficoMesAno;
/*      */ import br.com.schneider.sgm.grafico.GraficoPotencia;
/*      */ import br.com.schneider.sgm.grafico.GraficoSemanaMes;
/*      */ import br.com.schneider.sgm.grafico.GraficoTensao;
/*      */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTabbedPane;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PainelGraficos
/*      */   extends JPanel
/*      */ {
/*      */   private JTabbedPane painelAba;
/*      */   private GraficoBateria graficoBateria;
/*      */   private GraficoCorrente graficoCorrente;
/*      */   private GraficoDiaMes graficoDiaMes;
/*      */   private GraficoMesAno graficoMesAno;
/*      */   private GraficoPotencia graficoPotencia;
/*      */   private GraficoSemanaMes graficoSemanaMes;
/*      */   private GraficoTensao graficoTensao;
/*      */   private JPanel painelBateria;
/*      */   private JPanel painelCorrente;
/*      */   private JPanel painelDia;
/*      */   private JPanel painelMes;
/*      */   private JPanel painelPotencia;
/*      */   private JPanel painelSemana;
/*      */   private JPanel painelTensao;
/*      */   private JButton btnValor;
/*      */   private JButton btnValor1;
/*      */   private JButton btnValor2;
/*      */   private JButton btnValores;
/*      */   private JLabel valorKW0;
/*      */   private JLabel valorKW1;
/*      */   private JLabel valorKW2;
/*      */   private BotaoDec btnMesEsquerda;
/*      */   private BotaoDec btnMesDireita;
/*      */   private BotaoDec btnMesDireita1;
/*      */   private BotaoDec btnMesEsquerda1;
/*      */   private JLabel mes;
/*      */   private JLabel mes1;
/*      */   private int mesDia;
/*      */   private int anoDia;
/*      */   private int mesDia1;
/*      */   private int anoDia1;
/*      */   private BotaoDec btnAnoEsquerda;
/*      */   private BotaoDec btnAnoDireita;
/*      */   private JLabel ano;
/*      */   private int anoMes;
/*      */   private GregorianCalendar calendar;
/*      */   private String caminhoFiguras;
/*      */   private InterfaceGrafica interfaceGrafica;
/*      */   private String valorKW;
/*      */   
/*      */   public PainelGraficos(String caminhoFiguras, InterfaceGrafica interfaceGrafica)
/*      */   {
/*  246 */     this.valorKW = "0.54494";
/*  247 */     this.mesDia = 1;
/*  248 */     this.calendar = ((GregorianCalendar)Calendar.getInstance());
/*  249 */     this.caminhoFiguras = caminhoFiguras;
/*  250 */     initComponents();
/*  251 */     iniciaTempo();
/*  252 */     this.interfaceGrafica = interfaceGrafica;
/*  253 */     addListeners();
/*  254 */     validarIdioma();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void iniciaTempo()
/*      */   {
/*  262 */     String str = this.calendar.get(2) + 1 + "-" + 
/*  263 */       this.calendar.get(1);
/*  264 */     this.graficoDiaMes.setMes(str);
/*  265 */     this.graficoSemanaMes.setMes(str);
/*  266 */     this.graficoMesAno.setAno(Integer.toString(this.calendar.get(1)));
/*      */     
/*  268 */     this.mesDia = this.graficoDiaMes.getMes();
/*  269 */     this.anoDia = this.calendar.get(1);
/*      */     String str2;
/*  271 */     if (this.mesDia > 9) {
/*  272 */       str2 = this.mesDia + "-" + this.anoDia;
/*      */     } else
/*  274 */       str2 = "0" + this.mesDia + "-" + this.anoDia;
/*  275 */     this.mes.setText(str2);
/*      */     
/*  277 */     this.mesDia1 = this.graficoSemanaMes.getMes();
/*  278 */     this.anoDia1 = this.calendar.get(1);
/*  279 */     if (this.mesDia1 > 9) {
/*  280 */       str2 = this.mesDia1 + "-" + this.anoDia1;
/*      */     } else
/*  282 */       str2 = "0" + this.mesDia1 + "-" + this.anoDia1;
/*  283 */     this.mes1.setText(str2);
/*      */     
/*  285 */     this.anoMes = this.graficoMesAno.getAno();
/*  286 */     String str2 = Integer.toString(this.anoMes);
/*  287 */     this.ano.setText(str2);
/*      */   }
/*      */   
/*      */   public void atualizaGraficos()
/*      */   {
/*  292 */     String str = this.mesDia + "-" + this.anoDia;
/*  293 */     this.graficoDiaMes.setMes(str);
/*  294 */     str = this.mesDia1 + "-" + this.anoDia1;
/*  295 */     this.graficoSemanaMes.setMes(str);
/*  296 */     str = Integer.toString(this.anoMes);
/*  297 */     this.graficoMesAno.setAno(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void validarIdioma()
/*      */   {
/*  305 */     this.painelAba.setTitleAt(0, ResourceBundle.getBundle(Idioma.getIdioma())
/*  306 */       .getString("Tensao"));
/*  307 */     this.painelAba.setTitleAt(1, ResourceBundle.getBundle(Idioma.getIdioma())
/*  308 */       .getString("Corrente"));
/*  309 */     this.painelAba.setTitleAt(2, ResourceBundle.getBundle(Idioma.getIdioma())
/*  310 */       .getString("Potencia"));
/*  311 */     this.painelAba.setTitleAt(3, ResourceBundle.getBundle(Idioma.getIdioma())
/*  312 */       .getString("Bateria"));
/*  313 */     this.painelAba.setTitleAt(4, ResourceBundle.getBundle(Idioma.getIdioma())
/*  314 */       .getString("Consumo_Diario"));
/*  315 */     this.painelAba.setTitleAt(5, ResourceBundle.getBundle(Idioma.getIdioma())
/*  316 */       .getString("Consumo_Mensal"));
/*  317 */     this.painelAba.setTitleAt(6, ResourceBundle.getBundle(Idioma.getIdioma())
/*  318 */       .getString("Consumo_Anual"));
/*  319 */     this.graficoTensao.validarIdioma();
/*  320 */     this.graficoDiaMes.validarIdioma();
/*  321 */     this.graficoCorrente.validarIdioma();
/*  322 */     this.graficoPotencia.validarIdioma();
/*  323 */     this.graficoBateria.validarIdioma();
/*  324 */     this.graficoSemanaMes.validarIdioma();
/*  325 */     this.graficoMesAno.validarIdioma();
/*  326 */     this.btnValor.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  327 */       .getString("valor"));
/*  328 */     this.btnValor1.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  329 */       .getString("valor"));
/*  330 */     this.btnValor2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  331 */       .getString("valor"));
/*  332 */     this.btnValores.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  333 */       .getString("detalhes"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void restartCharts()
/*      */   {
/*  341 */     this.graficoCorrente.restartChart();
/*  342 */     this.graficoTensao.restartChart();
/*  343 */     this.graficoBateria.restartChart();
/*  344 */     this.graficoPotencia.restartChart();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stopCharts()
/*      */   {
/*  352 */     this.graficoCorrente.stopChart();
/*  353 */     this.graficoTensao.stopChart();
/*  354 */     this.graficoBateria.stopChart();
/*  355 */     this.graficoPotencia.stopChart();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addListeners()
/*      */   {
/*  363 */     this.btnValor.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  365 */         PainelGraficos.this.btnValorOnClick();
/*      */       }
/*  367 */     });
/*  368 */     this.btnValor1.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  370 */         PainelGraficos.this.btnValorOnClick();
/*      */       }
/*  372 */     });
/*  373 */     this.btnValor2.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  375 */         PainelGraficos.this.btnValorOnClick();
/*      */       }
/*      */       
/*  378 */     });
/*  379 */     this.btnValores.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  381 */         PainelGraficos.this.btnValoresOnClick();
/*      */       }
/*      */       
/*  384 */     });
/*  385 */     this.btnMesEsquerda.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  387 */         PainelGraficos.this.mesDia -= 1;
/*      */         
/*  389 */         if (PainelGraficos.this.mesDia < 1)
/*      */         {
/*  391 */           PainelGraficos.this.mesDia = 12;
/*  392 */           PainelGraficos.this.anoDia -= 1; }
/*      */         String str;
/*  394 */         String str; if (PainelGraficos.this.mesDia > 9) {
/*  395 */           str = PainelGraficos.this.mesDia + "-" + PainelGraficos.this.anoDia;
/*      */         } else
/*  397 */           str = "0" + PainelGraficos.this.mesDia + "-" + PainelGraficos.this.anoDia;
/*  398 */         PainelGraficos.this.mes.setText(str);
/*  399 */         PainelGraficos.this.graficoDiaMes.setMes(str);
/*      */       }
/*  401 */     });
/*  402 */     this.btnMesDireita.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  404 */         PainelGraficos.this.mesDia += 1;
/*      */         
/*  406 */         if (PainelGraficos.this.mesDia > 12)
/*      */         {
/*  408 */           PainelGraficos.this.mesDia = 1;
/*  409 */           PainelGraficos.this.anoDia += 1; }
/*      */         String str;
/*  411 */         String str; if (PainelGraficos.this.mesDia > 9) {
/*  412 */           str = PainelGraficos.this.mesDia + "-" + PainelGraficos.this.anoDia;
/*      */         } else
/*  414 */           str = "0" + PainelGraficos.this.mesDia + "-" + PainelGraficos.this.anoDia;
/*  415 */         PainelGraficos.this.mes.setText(str);
/*  416 */         PainelGraficos.this.graficoDiaMes.setMes(str);
/*      */       }
/*      */       
/*  419 */     });
/*  420 */     this.btnMesEsquerda1.addActionListener(new ActionListener()
/*      */     {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  423 */         PainelGraficos.this.mesDia1 -= 1;
/*      */         
/*  425 */         if (PainelGraficos.this.mesDia1 < 1)
/*      */         {
/*  427 */           PainelGraficos.this.mesDia1 = 12;
/*  428 */           PainelGraficos.this.anoDia1 -= 1; }
/*      */         String str;
/*  430 */         String str; if (PainelGraficos.this.mesDia1 > 9) {
/*  431 */           str = PainelGraficos.this.mesDia1 + "-" + PainelGraficos.this.anoDia1;
/*      */         } else
/*  433 */           str = "0" + PainelGraficos.this.mesDia1 + "-" + PainelGraficos.this.anoDia1;
/*  434 */         PainelGraficos.this.mes1.setText(str);
/*  435 */         PainelGraficos.this.graficoSemanaMes.setMes(str);
/*      */       }
/*  437 */     });
/*  438 */     this.btnMesDireita1.addActionListener(new ActionListener()
/*      */     {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  441 */         PainelGraficos.this.mesDia1 += 1;
/*      */         
/*  443 */         if (PainelGraficos.this.mesDia1 > 12)
/*      */         {
/*  445 */           PainelGraficos.this.mesDia1 = 1;
/*  446 */           PainelGraficos.this.anoDia1 += 1; }
/*      */         String str;
/*  448 */         String str; if (PainelGraficos.this.mesDia1 > 9) {
/*  449 */           str = PainelGraficos.this.mesDia1 + "-" + PainelGraficos.this.anoDia1;
/*      */         } else
/*  451 */           str = "0" + PainelGraficos.this.mesDia1 + "-" + PainelGraficos.this.anoDia1;
/*  452 */         PainelGraficos.this.mes1.setText(str);
/*  453 */         PainelGraficos.this.graficoSemanaMes.setMes(str);
/*      */       }
/*  455 */     });
/*  456 */     this.btnAnoEsquerda.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  458 */         PainelGraficos.this.anoMes -= 1;
/*      */         
/*  460 */         if (PainelGraficos.this.anoMes < 2000)
/*  461 */           PainelGraficos.this.anoMes = 2000;
/*  462 */         String str = Integer.toString(PainelGraficos.this.anoMes);
/*  463 */         PainelGraficos.this.ano.setText(str);
/*  464 */         PainelGraficos.this.graficoMesAno.setAno(str);
/*      */       }
/*  466 */     });
/*  467 */     this.btnAnoDireita.addActionListener(new ActionListener()
/*      */     {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  470 */         PainelGraficos.this.anoMes += 1;
/*      */         
/*  472 */         if (PainelGraficos.this.anoMes > 2100)
/*  473 */           PainelGraficos.this.anoMes = 2100;
/*  474 */         String str = Integer.toString(PainelGraficos.this.anoMes);
/*  475 */         PainelGraficos.this.ano.setText(str);
/*  476 */         PainelGraficos.this.graficoMesAno.setAno(str);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void btnValoresOnClick()
/*      */   {
/*  487 */     double[] d = this.graficoMesAno.passaValores();
/*  488 */     PopUpValores pop = new PopUpValores(this.caminhoFiguras, this.interfaceGrafica, 
/*  489 */       d, Double.parseDouble(this.valorKW));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void btnValorOnClick()
/*      */   {
/*  498 */     PopUpConsumo pop = new PopUpConsumo(this.interfaceGrafica, this.caminhoFiguras, 
/*  499 */       this, this.valorKW);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValorKW(double d)
/*      */   {
/*  507 */     setValorGraficos(d);
/*  508 */     setValorKW0(d);
/*  509 */     setValorKW1(d);
/*  510 */     setValorKW2(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValorGraficos(double d)
/*      */   {
/*  518 */     this.graficoSemanaMes.setValorKW(d);
/*  519 */     this.graficoDiaMes.setValorKW(d);
/*  520 */     this.graficoMesAno.setValorKW(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValorKW0(double d)
/*      */   {
/*  528 */     this.valorKW0.setText("R$ " + Double.toString(d));
/*  529 */     this.valorKW = Double.toString(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValorKW1(double d)
/*      */   {
/*  537 */     this.valorKW1.setText("R$ " + Double.toString(d));
/*  538 */     this.valorKW = Double.toString(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValorKW2(double d)
/*      */   {
/*  546 */     this.valorKW2.setText("R$ " + Double.toString(d));
/*  547 */     this.valorKW = Double.toString(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initComponents()
/*      */   {
/*  556 */     Dimension dimension = new Dimension(505, 285);
/*      */     
/*  558 */     Dimension dimension2 = new Dimension(505, 250);
/*  559 */     this.painelAba = new JTabbedPane();
/*  560 */     this.painelTensao = new JPanel();
/*  561 */     this.graficoTensao = new GraficoTensao();
/*  562 */     this.painelCorrente = new JPanel();
/*  563 */     this.graficoCorrente = new GraficoCorrente();
/*  564 */     this.painelPotencia = new JPanel();
/*  565 */     this.graficoPotencia = new GraficoPotencia();
/*  566 */     this.painelBateria = new JPanel();
/*  567 */     this.graficoBateria = new GraficoBateria();
/*  568 */     this.painelDia = new JPanel();
/*  569 */     this.graficoDiaMes = new GraficoDiaMes(Double.parseDouble(this.valorKW));
/*  570 */     this.painelSemana = new JPanel();
/*  571 */     this.graficoSemanaMes = new GraficoSemanaMes(Double.parseDouble(this.valorKW));
/*  572 */     this.painelMes = new JPanel();
/*  573 */     this.graficoMesAno = new GraficoMesAno(Double.parseDouble(this.valorKW));
/*  574 */     this.btnMesEsquerda = new BotaoDec(this.caminhoFiguras + "SetaF2.png", 
/*  575 */       this.caminhoFiguras + "SetaFPres2.png", 14, 14);
/*  576 */     this.btnMesDireita = new BotaoDec(this.caminhoFiguras + "SetaF.png", 
/*  577 */       this.caminhoFiguras + "SetaFPres.png", 14, 14);
/*  578 */     this.btnMesDireita1 = new BotaoDec(this.caminhoFiguras + "SetaF.png", 
/*  579 */       this.caminhoFiguras + "SetaFPres.png", 14, 14);
/*  580 */     this.btnMesEsquerda1 = new BotaoDec(this.caminhoFiguras + "SetaF2.png", 
/*  581 */       this.caminhoFiguras + "SetaFPres2.png", 14, 14);
/*  582 */     this.mes = new JLabel();
/*  583 */     this.mes1 = new JLabel();
/*  584 */     this.btnAnoEsquerda = new BotaoDec(this.caminhoFiguras + "SetaF2.png", 
/*  585 */       this.caminhoFiguras + "SetaFPres2.png", 14, 14);
/*  586 */     this.btnAnoDireita = new BotaoDec(this.caminhoFiguras + "SetaF.png", 
/*  587 */       this.caminhoFiguras + "SetaFPres.png", 14, 14);
/*  588 */     this.ano = new JLabel();
/*  589 */     this.btnValor = new JButton("valor");
/*  590 */     this.btnValor1 = new JButton("valor");
/*  591 */     this.btnValor2 = new JButton("valor");
/*  592 */     this.btnValores = new JButton();
/*  593 */     this.valorKW0 = new JLabel("R$ " + this.valorKW);
/*  594 */     this.valorKW1 = new JLabel("R$ " + this.valorKW);
/*  595 */     this.valorKW2 = new JLabel("R$ " + this.valorKW);
/*      */     
/*  597 */     setLayout(new BorderLayout());
/*  598 */     setOpaque(false);
/*  599 */     setMaximumSize(new Dimension(515, 315));
/*  600 */     setMinimumSize(new Dimension(515, 315));
/*  601 */     setPreferredSize(new Dimension(515, 315));
/*  602 */     this.painelTensao.setLayout(new GridBagLayout());
/*      */     
/*  604 */     this.painelAba.setBackground(new Color(230, 230, 230));
/*      */     
/*  606 */     this.painelTensao.setOpaque(false);
/*  607 */     this.graficoTensao.setMaximumSize(dimension);
/*  608 */     this.graficoTensao.setMinimumSize(dimension);
/*  609 */     this.graficoTensao.setPreferredSize(dimension);
/*  610 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  611 */     gridBagConstraints.gridx = 0;
/*  612 */     gridBagConstraints.gridy = 0;
/*  613 */     gridBagConstraints.gridwidth = 4;
/*  614 */     gridBagConstraints.fill = 1;
/*  615 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  616 */     this.painelTensao.add(this.graficoTensao, gridBagConstraints);
/*      */     
/*  618 */     this.painelAba.addTab(ResourceBundle.getBundle(Idioma.getIdioma())
/*  619 */       .getString("Tensao"), this.painelTensao);
/*      */     
/*  621 */     this.painelCorrente.setLayout(new GridBagLayout());
/*      */     
/*  623 */     this.painelCorrente.setOpaque(false);
/*  624 */     this.graficoCorrente.setBackground(new Color(0, 0, 0));
/*  625 */     this.graficoCorrente.setMaximumSize(dimension);
/*  626 */     this.graficoCorrente.setMinimumSize(dimension);
/*  627 */     this.graficoCorrente.setPreferredSize(dimension);
/*  628 */     gridBagConstraints = new GridBagConstraints();
/*  629 */     gridBagConstraints.gridx = 0;
/*  630 */     gridBagConstraints.gridy = 0;
/*  631 */     gridBagConstraints.fill = 1;
/*  632 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  633 */     this.painelCorrente.add(this.graficoCorrente, gridBagConstraints);
/*      */     
/*  635 */     this.painelAba.addTab(ResourceBundle.getBundle(Idioma.getIdioma())
/*  636 */       .getString("Corrente"), this.painelCorrente);
/*      */     
/*  638 */     this.painelPotencia.setLayout(new GridBagLayout());
/*      */     
/*  640 */     this.painelPotencia.setOpaque(false);
/*  641 */     this.graficoPotencia.setBackground(new Color(0, 0, 0));
/*  642 */     this.graficoPotencia.setMaximumSize(dimension);
/*  643 */     this.graficoPotencia.setMinimumSize(dimension);
/*  644 */     this.graficoPotencia.setPreferredSize(dimension);
/*  645 */     gridBagConstraints = new GridBagConstraints();
/*  646 */     gridBagConstraints.gridx = 0;
/*  647 */     gridBagConstraints.gridy = 0;
/*  648 */     gridBagConstraints.fill = 1;
/*  649 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  650 */     this.painelPotencia.add(this.graficoPotencia, gridBagConstraints);
/*      */     
/*  652 */     this.painelAba.addTab(ResourceBundle.getBundle(Idioma.getIdioma())
/*  653 */       .getString("Potencia"), this.painelPotencia);
/*      */     
/*  655 */     this.painelBateria.setLayout(new GridBagLayout());
/*      */     
/*  657 */     this.painelBateria.setOpaque(false);
/*  658 */     this.graficoBateria.setBackground(new Color(0, 0, 0));
/*  659 */     this.graficoBateria.setMaximumSize(dimension);
/*  660 */     this.graficoBateria.setMinimumSize(dimension);
/*  661 */     this.graficoBateria.setPreferredSize(dimension);
/*  662 */     gridBagConstraints = new GridBagConstraints();
/*  663 */     gridBagConstraints.gridx = 0;
/*  664 */     gridBagConstraints.gridy = 0;
/*  665 */     gridBagConstraints.fill = 1;
/*  666 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  667 */     this.painelBateria.add(this.graficoBateria, gridBagConstraints);
/*      */     
/*  669 */     this.painelAba.addTab(ResourceBundle.getBundle(Idioma.getIdioma())
/*  670 */       .getString("Bateria"), this.painelBateria);
/*      */     
/*  672 */     this.painelDia.setLayout(new GridBagLayout());
/*  673 */     this.painelDia.setOpaque(false);
/*  674 */     this.graficoDiaMes.setBackground(new Color(0, 0, 0));
/*  675 */     this.graficoDiaMes.setMaximumSize(dimension2);
/*  676 */     this.graficoDiaMes.setMinimumSize(dimension2);
/*  677 */     this.graficoDiaMes.setPreferredSize(dimension2);
/*  678 */     gridBagConstraints = new GridBagConstraints();
/*  679 */     gridBagConstraints.gridx = 0;
/*  680 */     gridBagConstraints.gridy = 0;
/*  681 */     gridBagConstraints.gridwidth = 12;
/*  682 */     gridBagConstraints.fill = 1;
/*  683 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  684 */     this.painelDia.add(this.graficoDiaMes, gridBagConstraints);
/*      */     
/*  686 */     gridBagConstraints.gridx = 4;
/*  687 */     gridBagConstraints.gridy = 1;
/*  688 */     gridBagConstraints.gridwidth = 1;
/*  689 */     gridBagConstraints.fill = 0;
/*  690 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  691 */     this.painelDia.add(this.btnMesEsquerda, gridBagConstraints);
/*      */     
/*  693 */     gridBagConstraints.gridx = 6;
/*  694 */     gridBagConstraints.gridy = 1;
/*  695 */     gridBagConstraints.gridwidth = 1;
/*  696 */     gridBagConstraints.fill = 0;
/*  697 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  698 */     this.painelDia.add(this.mes, gridBagConstraints);
/*      */     
/*  700 */     gridBagConstraints.gridx = 8;
/*  701 */     gridBagConstraints.gridy = 1;
/*  702 */     gridBagConstraints.gridwidth = 1;
/*  703 */     gridBagConstraints.fill = 0;
/*  704 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  705 */     this.painelDia.add(this.btnMesDireita, gridBagConstraints);
/*      */     
/*  707 */     gridBagConstraints.gridx = 0;
/*  708 */     gridBagConstraints.gridy = 1;
/*  709 */     gridBagConstraints.gridwidth = 1;
/*  710 */     gridBagConstraints.fill = 0;
/*  711 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  712 */     this.painelDia.add(this.btnValor, gridBagConstraints);
/*      */     
/*  714 */     gridBagConstraints.gridx = 2;
/*  715 */     gridBagConstraints.gridy = 1;
/*  716 */     gridBagConstraints.gridwidth = 1;
/*  717 */     gridBagConstraints.fill = 0;
/*  718 */     gridBagConstraints.insets = new Insets(5, 5, 0, 80);
/*  719 */     this.painelDia.add(this.valorKW0, gridBagConstraints);
/*      */     
/*  721 */     this.painelAba.addTab(ResourceBundle.getBundle(Idioma.getIdioma())
/*  722 */       .getString("Consumo_Diario"), this.painelDia);
/*      */     
/*      */ 
/*      */ 
/*  726 */     this.painelSemana.setLayout(new GridBagLayout());
/*      */     
/*  728 */     this.painelSemana.setOpaque(false);
/*  729 */     this.graficoSemanaMes.setBackground(new Color(0, 0, 0));
/*  730 */     this.graficoSemanaMes.setMaximumSize(dimension2);
/*  731 */     this.graficoSemanaMes.setMinimumSize(dimension2);
/*  732 */     this.graficoSemanaMes.setPreferredSize(dimension2);
/*  733 */     gridBagConstraints = new GridBagConstraints();
/*  734 */     gridBagConstraints.gridx = 0;
/*  735 */     gridBagConstraints.gridy = 0;
/*  736 */     gridBagConstraints.gridwidth = 12;
/*  737 */     gridBagConstraints.fill = 1;
/*  738 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  739 */     this.painelSemana.add(this.graficoSemanaMes, gridBagConstraints);
/*      */     
/*  741 */     gridBagConstraints.gridx = 4;
/*  742 */     gridBagConstraints.gridy = 1;
/*  743 */     gridBagConstraints.gridwidth = 1;
/*  744 */     gridBagConstraints.fill = 0;
/*  745 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  746 */     this.painelSemana.add(this.btnMesEsquerda1, gridBagConstraints);
/*      */     
/*  748 */     gridBagConstraints.gridx = 6;
/*  749 */     gridBagConstraints.gridy = 1;
/*  750 */     gridBagConstraints.gridwidth = 1;
/*  751 */     gridBagConstraints.fill = 0;
/*  752 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  753 */     this.painelSemana.add(this.mes1, gridBagConstraints);
/*      */     
/*  755 */     gridBagConstraints.gridx = 8;
/*  756 */     gridBagConstraints.gridy = 1;
/*  757 */     gridBagConstraints.gridwidth = 1;
/*  758 */     gridBagConstraints.fill = 0;
/*  759 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  760 */     this.painelSemana.add(this.btnMesDireita1, gridBagConstraints);
/*      */     
/*  762 */     gridBagConstraints.gridx = 0;
/*  763 */     gridBagConstraints.gridy = 1;
/*  764 */     gridBagConstraints.fill = 0;
/*  765 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  766 */     this.painelSemana.add(this.btnValor1, gridBagConstraints);
/*      */     
/*  768 */     gridBagConstraints.gridx = 2;
/*  769 */     gridBagConstraints.gridy = 1;
/*  770 */     gridBagConstraints.fill = 0;
/*  771 */     gridBagConstraints.insets = new Insets(5, 5, 0, 80);
/*  772 */     this.painelSemana.add(this.valorKW1, gridBagConstraints);
/*      */     
/*  774 */     this.painelAba.addTab(ResourceBundle.getBundle(Idioma.getIdioma())
/*  775 */       .getString("Consumo_Mensal"), this.painelSemana);
/*      */     
/*  777 */     this.painelMes.setLayout(new GridBagLayout());
/*      */     
/*      */ 
/*      */ 
/*  781 */     this.painelMes.setOpaque(false);
/*  782 */     this.graficoMesAno.setBackground(new Color(0, 0, 0));
/*  783 */     this.graficoMesAno.setMaximumSize(dimension2);
/*  784 */     this.graficoMesAno.setMinimumSize(dimension2);
/*  785 */     this.graficoMesAno.setPreferredSize(dimension2);
/*  786 */     gridBagConstraints = new GridBagConstraints();
/*  787 */     gridBagConstraints.gridx = 0;
/*  788 */     gridBagConstraints.gridy = 0;
/*  789 */     gridBagConstraints.gridwidth = 12;
/*  790 */     gridBagConstraints.fill = 1;
/*  791 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  792 */     this.painelMes.add(this.graficoMesAno, gridBagConstraints);
/*      */     
/*  794 */     gridBagConstraints.gridx = 4;
/*  795 */     gridBagConstraints.gridy = 1;
/*  796 */     gridBagConstraints.gridwidth = 1;
/*  797 */     gridBagConstraints.fill = 0;
/*  798 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  799 */     this.painelMes.add(this.btnAnoEsquerda, gridBagConstraints);
/*      */     
/*  801 */     gridBagConstraints.gridx = 6;
/*  802 */     gridBagConstraints.gridy = 1;
/*  803 */     gridBagConstraints.gridwidth = 1;
/*  804 */     gridBagConstraints.fill = 0;
/*  805 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  806 */     this.painelMes.add(this.ano, gridBagConstraints);
/*      */     
/*  808 */     gridBagConstraints.gridx = 8;
/*  809 */     gridBagConstraints.gridy = 1;
/*  810 */     gridBagConstraints.gridwidth = 1;
/*  811 */     gridBagConstraints.fill = 0;
/*  812 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  813 */     this.painelMes.add(this.btnAnoDireita, gridBagConstraints);
/*      */     
/*  815 */     gridBagConstraints.gridx = 10;
/*  816 */     gridBagConstraints.gridy = 1;
/*  817 */     gridBagConstraints.gridwidth = 1;
/*  818 */     gridBagConstraints.fill = 0;
/*  819 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  820 */     this.painelMes.add(this.btnValores, gridBagConstraints);
/*      */     
/*  822 */     gridBagConstraints.gridx = 0;
/*  823 */     gridBagConstraints.gridy = 1;
/*  824 */     gridBagConstraints.fill = 0;
/*  825 */     gridBagConstraints.insets = new Insets(5, 5, 0, 0);
/*  826 */     this.painelMes.add(this.btnValor2, gridBagConstraints);
/*      */     
/*  828 */     gridBagConstraints.gridx = 2;
/*  829 */     gridBagConstraints.gridy = 1;
/*  830 */     gridBagConstraints.fill = 0;
/*  831 */     gridBagConstraints.insets = new Insets(5, 5, 0, 80);
/*  832 */     this.painelMes.add(this.valorKW2, gridBagConstraints);
/*      */     
/*  834 */     this.painelAba.addTab(ResourceBundle.getBundle(Idioma.getIdioma())
/*  835 */       .getString("Consumo_Anual"), this.painelMes);
/*      */     
/*  837 */     add(this.painelAba, "Center");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JButton getBtnValor()
/*      */   {
/*  847 */     return this.btnValor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JButton getBtnValor1()
/*      */   {
/*  854 */     return this.btnValor1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JButton getBtnValor2()
/*      */   {
/*  861 */     return this.btnValor2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getCaminhoFiguras()
/*      */   {
/*  868 */     return this.caminhoFiguras;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public GraficoBateria getGraficoBateria()
/*      */   {
/*  875 */     return this.graficoBateria;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public GraficoCorrente getGraficoCorrente()
/*      */   {
/*  882 */     return this.graficoCorrente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public GraficoDiaMes getGraficoDiaMes()
/*      */   {
/*  889 */     return this.graficoDiaMes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public GraficoMesAno getGraficoMesAno()
/*      */   {
/*  896 */     return this.graficoMesAno;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public GraficoPotencia getGraficoPotencia()
/*      */   {
/*  903 */     return this.graficoPotencia;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public GraficoSemanaMes getGraficoSemanaMes()
/*      */   {
/*  910 */     return this.graficoSemanaMes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public GraficoTensao getGraficoTensao()
/*      */   {
/*  917 */     return this.graficoTensao;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InterfaceGrafica getInterfaceGrafica()
/*      */   {
/*  924 */     return this.interfaceGrafica;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JTabbedPane getPainelAba()
/*      */   {
/*  931 */     return this.painelAba;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelBateria()
/*      */   {
/*  938 */     return this.painelBateria;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelCorrente()
/*      */   {
/*  945 */     return this.painelCorrente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelDia()
/*      */   {
/*  952 */     return this.painelDia;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelMes()
/*      */   {
/*  959 */     return this.painelMes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelPotencia()
/*      */   {
/*  966 */     return this.painelPotencia;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelSemana()
/*      */   {
/*  973 */     return this.painelSemana;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelTensao()
/*      */   {
/*  980 */     return this.painelTensao;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getValorKW()
/*      */   {
/*  987 */     return this.valorKW;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getValorKW0()
/*      */   {
/*  994 */     return this.valorKW0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getValorKW1()
/*      */   {
/* 1001 */     return this.valorKW1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getValorKW2()
/*      */   {
/* 1008 */     return this.valorKW2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBtnValor(JButton btnValor)
/*      */   {
/* 1019 */     this.btnValor = btnValor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBtnValor1(JButton btnValor1)
/*      */   {
/* 1026 */     this.btnValor1 = btnValor1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBtnValor2(JButton btnValor2)
/*      */   {
/* 1033 */     this.btnValor2 = btnValor2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCaminhoFiguras(String caminhoFiguras)
/*      */   {
/* 1040 */     this.caminhoFiguras = caminhoFiguras;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGraficoBateria(GraficoBateria graficoBateria)
/*      */   {
/* 1047 */     this.graficoBateria = graficoBateria;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGraficoCorrente(GraficoCorrente graficoCorrente)
/*      */   {
/* 1054 */     this.graficoCorrente = graficoCorrente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGraficoDiaMes(GraficoDiaMes graficoDiaMes)
/*      */   {
/* 1061 */     this.graficoDiaMes = graficoDiaMes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGraficoMesAno(GraficoMesAno graficoMesAno)
/*      */   {
/* 1068 */     this.graficoMesAno = graficoMesAno;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGraficoPotencia(GraficoPotencia graficoPotencia)
/*      */   {
/* 1075 */     this.graficoPotencia = graficoPotencia;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGraficoSemanaMes(GraficoSemanaMes graficoSemanaMes)
/*      */   {
/* 1082 */     this.graficoSemanaMes = graficoSemanaMes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGraficoTensao(GraficoTensao graficoTensao)
/*      */   {
/* 1089 */     this.graficoTensao = graficoTensao;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setInterfaceGrafica(InterfaceGrafica interfaceGrafica)
/*      */   {
/* 1096 */     this.interfaceGrafica = interfaceGrafica;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelAba(JTabbedPane painelAba)
/*      */   {
/* 1103 */     this.painelAba = painelAba;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelBateria(JPanel painelBateria)
/*      */   {
/* 1110 */     this.painelBateria = painelBateria;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelCorrente(JPanel painelCorrente)
/*      */   {
/* 1117 */     this.painelCorrente = painelCorrente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelDia(JPanel painelDia)
/*      */   {
/* 1124 */     this.painelDia = painelDia;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelMes(JPanel painelMes)
/*      */   {
/* 1131 */     this.painelMes = painelMes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelPotencia(JPanel painelPotencia)
/*      */   {
/* 1138 */     this.painelPotencia = painelPotencia;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelSemana(JPanel painelSemana)
/*      */   {
/* 1145 */     this.painelSemana = painelSemana;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelTensao(JPanel painelTensao)
/*      */   {
/* 1152 */     this.painelTensao = painelTensao;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setValorKW(String valorKW)
/*      */   {
/* 1159 */     this.valorKW = valorKW;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setValorKW0(JLabel valorKW0)
/*      */   {
/* 1166 */     this.valorKW0 = valorKW0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setValorKW1(JLabel valorKW1)
/*      */   {
/* 1173 */     this.valorKW1 = valorKW1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setValorKW2(JLabel valorKW2)
/*      */   {
/* 1180 */     this.valorKW2 = valorKW2;
/*      */   }
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelGraficos.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */