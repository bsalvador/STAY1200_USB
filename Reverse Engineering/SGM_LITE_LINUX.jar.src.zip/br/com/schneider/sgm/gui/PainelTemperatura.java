/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PainelTemperatura
/*     */   extends JPanel
/*     */ {
/*     */   private JLabel labelTemp0;
/*     */   private JLabel labelTemp5;
/*     */   private JLabel labelTemp10;
/*     */   private JLabel labelTemp15;
/*     */   private JLabel labelTemp20;
/*     */   private JLabel labelTemp25;
/*     */   private JLabel labelTemp30;
/*     */   private JLabel labelTemp35;
/*     */   private JLabel labelTemp40;
/*     */   private JLabel labelTemp45;
/*     */   private JLabel labelTemp50;
/*     */   private JLabel labelTemp55;
/*     */   private JLabel labelTemp60;
/*     */   private JLabel labelTemp65;
/*     */   private JLabel labelTemp70;
/*     */   private JLabel labelTemp75;
/*     */   private JLabel labelTemp80;
/*     */   Barra3 panelBarraTemp;
/*     */   private String titulo;
/*     */   private ImageIcon imagemFundo;
/*     */   private JPanel enchimento5;
/*     */   
/*     */   public PainelTemperatura(String caminhoFiguras)
/*     */   {
/* 619 */     this.imagemFundo = new ImageIcon(caminhoFiguras + "barraTemp.png");
/* 620 */     initComponents();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 630 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString("TEMP");
/* 631 */     this.enchimento5.setBorder(BorderFactory.createTitledBorder(
/* 632 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 633 */       0, 1, 
/* 634 */       new Font("Trebuchet", 1, 12)));
/*     */   }
/*     */   
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/* 640 */     super.paintComponent(g);
/* 641 */     g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 652 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 653 */     Dimension d = new Dimension(65, 299);
/* 654 */     Dimension d2 = new Dimension(20, 245);
/* 655 */     Font fonte11 = new Font("Trebuchet", 0, 11);
/* 656 */     Font fonte12 = new Font("Trebuchet", 1, 12);
/* 657 */     Insets insets = new Insets(0, 0, 0, 8);
/* 658 */     Insets insets2 = new Insets(0, 0, 1, 0);
/*     */     
/* 660 */     this.panelBarraTemp = new Barra3();
/* 661 */     this.labelTemp0 = new JLabel();
/* 662 */     this.labelTemp5 = new JLabel();
/* 663 */     this.labelTemp10 = new JLabel();
/* 664 */     this.labelTemp15 = new JLabel();
/* 665 */     this.labelTemp20 = new JLabel();
/* 666 */     this.labelTemp25 = new JLabel();
/* 667 */     this.labelTemp30 = new JLabel();
/* 668 */     this.labelTemp35 = new JLabel();
/* 669 */     this.labelTemp40 = new JLabel();
/* 670 */     this.labelTemp45 = new JLabel();
/* 671 */     this.labelTemp50 = new JLabel();
/* 672 */     this.labelTemp55 = new JLabel();
/* 673 */     this.labelTemp60 = new JLabel();
/* 674 */     this.labelTemp65 = new JLabel();
/* 675 */     this.labelTemp70 = new JLabel();
/* 676 */     this.labelTemp75 = new JLabel();
/* 677 */     this.labelTemp80 = new JLabel();
/* 678 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString("TEMP");
/*     */     
/* 680 */     this.enchimento5 = new JPanel();
/* 681 */     setLayout(new FlowLayout(1, -3, 3));
/* 682 */     setOpaque(false);
/* 683 */     add(this.enchimento5);
/*     */     
/* 685 */     this.enchimento5.setLayout(new GridBagLayout());
/*     */     
/* 687 */     this.enchimento5.setBorder(BorderFactory.createTitledBorder(
/* 688 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 689 */       0, 1, 
/* 690 */       fonte12));
/* 691 */     this.enchimento5.setMaximumSize(d);
/* 692 */     this.enchimento5.setMinimumSize(d);
/* 693 */     this.enchimento5.setOpaque(false);
/* 694 */     this.enchimento5.setPreferredSize(d);
/*     */     
/* 696 */     this.panelBarraTemp.setMaximumSize(d2);
/* 697 */     this.panelBarraTemp.setMinimumSize(d2);
/* 698 */     this.panelBarraTemp.setPreferredSize(d2);
/* 699 */     gridBagConstraints.gridx = 0;
/* 700 */     gridBagConstraints.gridy = 1;
/* 701 */     gridBagConstraints.gridheight = 18;
/* 702 */     gridBagConstraints.insets = new Insets(0, 10, 0, 0);
/* 703 */     this.enchimento5.add(this.panelBarraTemp, gridBagConstraints);
/*     */     
/* 705 */     this.labelTemp0.setFont(fonte11);
/* 706 */     this.labelTemp0.setText("0°C");
/* 707 */     gridBagConstraints.gridx = 1;
/* 708 */     gridBagConstraints.gridy = 17;
/* 709 */     gridBagConstraints.anchor = 17;
/* 710 */     gridBagConstraints.gridheight = 1;
/* 711 */     gridBagConstraints.insets = insets;
/* 712 */     this.enchimento5.add(this.labelTemp0, gridBagConstraints);
/*     */     
/* 714 */     this.labelTemp5.setFont(fonte11);
/* 715 */     this.labelTemp5.setText("-");
/* 716 */     gridBagConstraints.gridx = 1;
/* 717 */     gridBagConstraints.gridy = 16;
/* 718 */     gridBagConstraints.anchor = 17;
/* 719 */     gridBagConstraints.gridheight = 1;
/* 720 */     gridBagConstraints.insets = insets2;
/* 721 */     this.enchimento5.add(this.labelTemp5, gridBagConstraints);
/*     */     
/* 723 */     this.labelTemp10.setFont(fonte11);
/* 724 */     this.labelTemp10.setText("10°C");
/* 725 */     gridBagConstraints.gridx = 1;
/* 726 */     gridBagConstraints.gridy = 15;
/* 727 */     gridBagConstraints.anchor = 17;
/* 728 */     gridBagConstraints.insets = insets;
/* 729 */     this.enchimento5.add(this.labelTemp10, gridBagConstraints);
/*     */     
/* 731 */     this.labelTemp15.setFont(fonte11);
/* 732 */     this.labelTemp15.setText("-");
/* 733 */     gridBagConstraints.gridx = 1;
/* 734 */     gridBagConstraints.gridy = 14;
/* 735 */     gridBagConstraints.anchor = 17;
/* 736 */     gridBagConstraints.gridheight = 1;
/* 737 */     gridBagConstraints.insets = insets2;
/* 738 */     this.enchimento5.add(this.labelTemp15, gridBagConstraints);
/*     */     
/* 740 */     this.labelTemp20.setFont(fonte11);
/* 741 */     this.labelTemp20.setText("20°C");
/* 742 */     gridBagConstraints.gridx = 1;
/* 743 */     gridBagConstraints.gridy = 13;
/* 744 */     gridBagConstraints.anchor = 17;
/* 745 */     gridBagConstraints.insets = insets;
/* 746 */     this.enchimento5.add(this.labelTemp20, gridBagConstraints);
/*     */     
/* 748 */     this.labelTemp25.setFont(fonte11);
/* 749 */     this.labelTemp25.setText("-");
/* 750 */     gridBagConstraints.gridx = 1;
/* 751 */     gridBagConstraints.gridy = 12;
/* 752 */     gridBagConstraints.anchor = 17;
/* 753 */     gridBagConstraints.gridheight = 1;
/* 754 */     gridBagConstraints.insets = insets2;
/* 755 */     this.enchimento5.add(this.labelTemp25, gridBagConstraints);
/*     */     
/* 757 */     this.labelTemp30.setFont(fonte11);
/* 758 */     this.labelTemp30.setText("30°C");
/* 759 */     gridBagConstraints.gridx = 1;
/* 760 */     gridBagConstraints.gridy = 11;
/* 761 */     gridBagConstraints.anchor = 17;
/* 762 */     gridBagConstraints.insets = insets;
/* 763 */     this.enchimento5.add(this.labelTemp30, gridBagConstraints);
/*     */     
/* 765 */     this.labelTemp35.setFont(fonte11);
/* 766 */     this.labelTemp35.setText("-");
/* 767 */     gridBagConstraints.gridx = 1;
/* 768 */     gridBagConstraints.gridy = 10;
/* 769 */     gridBagConstraints.anchor = 17;
/* 770 */     gridBagConstraints.gridheight = 1;
/* 771 */     gridBagConstraints.insets = insets2;
/* 772 */     this.enchimento5.add(this.labelTemp35, gridBagConstraints);
/*     */     
/* 774 */     this.labelTemp40.setFont(fonte11);
/* 775 */     this.labelTemp40.setText("40°C");
/* 776 */     gridBagConstraints = new GridBagConstraints();
/* 777 */     gridBagConstraints.gridx = 1;
/* 778 */     gridBagConstraints.gridy = 9;
/* 779 */     gridBagConstraints.anchor = 17;
/* 780 */     gridBagConstraints.insets = insets;
/* 781 */     this.enchimento5.add(this.labelTemp40, gridBagConstraints);
/*     */     
/* 783 */     this.labelTemp45.setFont(fonte11);
/* 784 */     this.labelTemp45.setText("-");
/* 785 */     gridBagConstraints.gridx = 1;
/* 786 */     gridBagConstraints.gridy = 8;
/* 787 */     gridBagConstraints.anchor = 17;
/* 788 */     gridBagConstraints.gridheight = 1;
/* 789 */     gridBagConstraints.insets = insets2;
/* 790 */     this.enchimento5.add(this.labelTemp45, gridBagConstraints);
/*     */     
/* 792 */     this.labelTemp50.setFont(fonte11);
/* 793 */     this.labelTemp50.setText("50°C");
/* 794 */     gridBagConstraints.gridx = 1;
/* 795 */     gridBagConstraints.gridy = 7;
/* 796 */     gridBagConstraints.anchor = 17;
/* 797 */     gridBagConstraints.insets = insets;
/* 798 */     this.enchimento5.add(this.labelTemp50, gridBagConstraints);
/*     */     
/* 800 */     this.labelTemp55.setFont(fonte11);
/* 801 */     this.labelTemp55.setText("-");
/* 802 */     gridBagConstraints.gridx = 1;
/* 803 */     gridBagConstraints.gridy = 6;
/* 804 */     gridBagConstraints.anchor = 17;
/* 805 */     gridBagConstraints.gridheight = 1;
/* 806 */     gridBagConstraints.insets = insets2;
/* 807 */     this.enchimento5.add(this.labelTemp55, gridBagConstraints);
/*     */     
/* 809 */     this.labelTemp60.setFont(fonte11);
/* 810 */     this.labelTemp60.setText("60°C");
/* 811 */     gridBagConstraints.gridx = 1;
/* 812 */     gridBagConstraints.gridy = 5;
/* 813 */     gridBagConstraints.anchor = 17;
/* 814 */     gridBagConstraints.insets = insets;
/* 815 */     this.enchimento5.add(this.labelTemp60, gridBagConstraints);
/*     */     
/* 817 */     this.labelTemp65.setFont(fonte11);
/* 818 */     this.labelTemp65.setText("-");
/* 819 */     gridBagConstraints.gridx = 1;
/* 820 */     gridBagConstraints.gridy = 4;
/* 821 */     gridBagConstraints.anchor = 17;
/* 822 */     gridBagConstraints.gridheight = 1;
/* 823 */     gridBagConstraints.insets = insets2;
/* 824 */     this.enchimento5.add(this.labelTemp65, gridBagConstraints);
/*     */     
/* 826 */     this.labelTemp70.setFont(fonte11);
/* 827 */     this.labelTemp70.setText("70°C");
/* 828 */     gridBagConstraints.gridx = 1;
/* 829 */     gridBagConstraints.gridy = 3;
/* 830 */     gridBagConstraints.anchor = 17;
/* 831 */     gridBagConstraints.insets = insets;
/* 832 */     this.enchimento5.add(this.labelTemp70, gridBagConstraints);
/*     */     
/* 834 */     this.labelTemp75.setFont(fonte11);
/* 835 */     this.labelTemp75.setText("-");
/* 836 */     gridBagConstraints.gridx = 1;
/* 837 */     gridBagConstraints.gridy = 2;
/* 838 */     gridBagConstraints.anchor = 17;
/* 839 */     gridBagConstraints.gridheight = 1;
/* 840 */     gridBagConstraints.insets = insets2;
/* 841 */     this.enchimento5.add(this.labelTemp75, gridBagConstraints);
/*     */     
/* 843 */     this.labelTemp80.setFont(fonte11);
/* 844 */     this.labelTemp80.setText("80°C");
/* 845 */     gridBagConstraints.gridx = 1;
/* 846 */     gridBagConstraints.gridy = 1;
/* 847 */     gridBagConstraints.anchor = 17;
/* 848 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/* 849 */     this.enchimento5.add(this.labelTemp80, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelTemp0(JLabel l)
/*     */   {
/* 858 */     this.labelTemp0 = l;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabelTemp20(JLabel l)
/*     */   {
/* 864 */     this.labelTemp20 = l;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabelTemp40(JLabel l)
/*     */   {
/* 870 */     this.labelTemp40 = l;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabelTemp60(JLabel l)
/*     */   {
/* 876 */     this.labelTemp60 = l;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabelTemp80(JLabel l)
/*     */   {
/* 882 */     this.labelTemp80 = l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JLabel getLabelTemp0()
/*     */   {
/* 893 */     return this.labelTemp0;
/*     */   }
/*     */   
/*     */   public JLabel getLabelTemp20()
/*     */   {
/* 898 */     return this.labelTemp20;
/*     */   }
/*     */   
/*     */   public JLabel getLabelTemp40()
/*     */   {
/* 903 */     return this.labelTemp40;
/*     */   }
/*     */   
/*     */   public JLabel getLabelTemp60()
/*     */   {
/* 908 */     return this.labelTemp60;
/*     */   }
/*     */   
/*     */   public JLabel getLabelTemp80()
/*     */   {
/* 913 */     return this.labelTemp80;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelTemperatura.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */