/*      */ package br.com.schneider.sgm.gui;
/*      */ 
/*      */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.border.SoftBevelBorder;
/*      */ import javax.swing.event.CaretEvent;
/*      */ import javax.swing.event.CaretListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PainelSNMP
/*      */   extends JPanel
/*      */ {
/*      */   private JButton btnCancel;
/*      */   private JButton btnOk;
/*      */   private JComboBox cbSNMP;
/*      */   private JComboBox cbTransporte;
/*      */   private JLabel labelEnvio;
/*      */   private JLabel labelEscrita;
/*      */   private JLabel labelGerente;
/*      */   private JLabel labelLeitura;
/*      */   private JLabel labelPedidos;
/*      */   private JLabel labelSNMP;
/*      */   private JLabel labelTransporte;
/*      */   private JPanel painelGeral;
/*      */   private JPanel painelTrap;
/*      */   private JTextField tfEnvio;
/*      */   private JTextField tfEscrita;
/*      */   private JTextField tfGerente;
/*      */   private JTextField tfLeitura;
/*      */   private JTextField tfPedidos;
/*      */   private String escritaAntiga;
/*      */   private String leituraAntiga;
/*      */   private boolean flagEscrita;
/*      */   private boolean flagLeitura;
/*      */   private boolean flag;
/*      */   private boolean flagCancel;
/*      */   private boolean flagPedidos;
/*      */   private int pedidoAntigo;
/*      */   private boolean flagEnvio;
/*      */   private int envioAntigo;
/*      */   private boolean flagGetAndSet;
/*      */   private boolean flagTraps;
/*      */   
/*      */   public PainelSNMP()
/*      */   {
/*  199 */     initComponents();
/*  200 */     validarIdioma();
/*  201 */     this.escritaAntiga = this.tfEscrita.getText();
/*  202 */     this.leituraAntiga = this.tfLeitura.getText();
/*  203 */     this.pedidoAntigo = Integer.parseInt(this.tfPedidos.getText());
/*  204 */     this.envioAntigo = Integer.parseInt(this.tfEnvio.getText());
/*  205 */     addListeners();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPedidosInvalido()
/*      */   {
/*      */     try
/*      */     {
/*  216 */       this.pedidoAntigo = Integer.parseInt(this.tfPedidos.getText());
/*  217 */       return false;
/*      */     } catch (NumberFormatException nfe) {}
/*  219 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPortaPedidos()
/*      */   {
/*      */     try
/*      */     {
/*  229 */       this.pedidoAntigo = Integer.parseInt(this.tfPedidos.getText());
/*  230 */       return this.pedidoAntigo;
/*      */     } catch (NumberFormatException nfe) {
/*  232 */       this.tfPedidos.setText(Integer.toString(this.pedidoAntigo)); }
/*  233 */     return this.pedidoAntigo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnvioInvalido()
/*      */   {
/*      */     try
/*      */     {
/*  243 */       this.envioAntigo = Integer.parseInt(this.tfEnvio.getText());
/*  244 */       return false;
/*      */     } catch (NumberFormatException nfe) {}
/*  246 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPortaEnvio()
/*      */   {
/*      */     try
/*      */     {
/*  256 */       this.envioAntigo = Integer.parseInt(this.tfEnvio.getText());
/*  257 */       return this.envioAntigo;
/*      */     } catch (NumberFormatException nfe) {
/*  259 */       this.tfEnvio.setText(Integer.toString(this.envioAntigo)); }
/*  260 */     return this.envioAntigo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void validarIdioma()
/*      */   {
/*  268 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  269 */       "OK"));
/*  270 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  271 */       .getString("CANCELAR"));
/*  272 */     this.painelGeral.setBorder(BorderFactory.createTitledBorder(
/*  273 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 170)), 
/*  274 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  275 */       "CONFIGURACOES_DE_GETS_E_SETS"), 
/*  276 */       0, 
/*  277 */       0, new Font("Trebuchet", 1, 12), 
/*  278 */       new Color(0, 0, 0)));
/*  279 */     this.labelPedidos.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  280 */       .getString("PORTA_DE_PEDIDOS"));
/*  281 */     this.labelLeitura.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  282 */       .getString("COMUNIDADE_DE_LEITURA"));
/*  283 */     this.labelEscrita.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  284 */       .getString("COMUNIDADE_DE_ESCRITA"));
/*  285 */     this.labelGerente.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  286 */       .getString("ENDERECO_DE_GERENTE"));
/*  287 */     this.labelSNMP.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  288 */       .getString("VERSAO_DE_SNMP"));
/*  289 */     this.labelTransporte.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  290 */       .getString("PROTOCOLO_DE_TRANSPORTE"));
/*  291 */     this.labelEnvio.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  292 */       .getString("PORTA_DE_ENVIO"));
/*  293 */     this.painelTrap.setBorder(BorderFactory.createTitledBorder(
/*  294 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 170)), 
/*  295 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  296 */       "CONFIGURACOES_DE_TRAPS"), 
/*  297 */       0, 
/*  298 */       0, new Font("Trebuchet", 1, 12), 
/*  299 */       new Color(0, 0, 0)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addListeners()
/*      */   {
/*  307 */     this.cbSNMP.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  309 */         PainelSNMP.this.flag = true;
/*  310 */         PainelSNMP.this.flagTraps = true;
/*      */       }
/*      */       
/*  313 */     });
/*  314 */     this.cbTransporte.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  316 */         PainelSNMP.this.flag = true;
/*  317 */         PainelSNMP.this.flagTraps = true;
/*      */       }
/*      */       
/*  320 */     });
/*  321 */     this.tfPedidos.addCaretListener(new CaretListener() {
/*      */       public void caretUpdate(CaretEvent ce) {
/*  323 */         if (!PainelSNMP.this.flagPedidos) {
/*  324 */           PainelSNMP.this.flagPedidos = true;
/*      */         }
/*  326 */         PainelSNMP.this.flag = true;
/*  327 */         PainelSNMP.this.flagCancel = false;
/*  328 */         PainelSNMP.this.flagGetAndSet = true;
/*      */       }
/*      */       
/*  331 */     });
/*  332 */     this.tfEnvio.addCaretListener(new CaretListener() {
/*      */       public void caretUpdate(CaretEvent ce) {
/*  334 */         if (!PainelSNMP.this.flagEnvio) {
/*  335 */           PainelSNMP.this.flagEnvio = true;
/*      */         }
/*  337 */         PainelSNMP.this.flag = true;
/*  338 */         PainelSNMP.this.flagCancel = false;
/*  339 */         PainelSNMP.this.flagTraps = true;
/*      */       }
/*      */       
/*  342 */     });
/*  343 */     this.tfEscrita.addCaretListener(new CaretListener() {
/*      */       public void caretUpdate(CaretEvent ce) {
/*  345 */         if (!PainelSNMP.this.flagEscrita) {
/*  346 */           PainelSNMP.this.escritaAntiga = PainelSNMP.this.tfEscrita.getText();
/*  347 */           PainelSNMP.this.flagEscrita = true;
/*      */         }
/*  349 */         PainelSNMP.this.flag = true;
/*  350 */         PainelSNMP.this.flagCancel = false;
/*  351 */         PainelSNMP.this.flagGetAndSet = true;
/*      */       }
/*      */       
/*  354 */     });
/*  355 */     this.tfLeitura.addCaretListener(new CaretListener() {
/*      */       public void caretUpdate(CaretEvent ce) {
/*  357 */         if (!PainelSNMP.this.flagLeitura) {
/*  358 */           PainelSNMP.this.leituraAntiga = PainelSNMP.this.tfLeitura.getText();
/*  359 */           PainelSNMP.this.flagLeitura = true;
/*      */         }
/*  361 */         PainelSNMP.this.flag = true;
/*  362 */         PainelSNMP.this.flagCancel = false;
/*  363 */         PainelSNMP.this.flagGetAndSet = true;
/*      */       }
/*      */       
/*  366 */     });
/*  367 */     this.tfGerente.addCaretListener(new CaretListener() {
/*      */       public void caretUpdate(CaretEvent ce) {
/*  369 */         PainelSNMP.this.flag = true;
/*  370 */         PainelSNMP.this.flagCancel = false;
/*  371 */         PainelSNMP.this.flagTraps = true;
/*      */       }
/*      */       
/*  374 */     });
/*  375 */     this.btnOk.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  377 */         PainelSNMP.this.flagEscrita = false;
/*  378 */         PainelSNMP.this.flagLeitura = false;
/*  379 */         PainelSNMP.this.flag = false;
/*      */       }
/*      */       
/*  382 */     });
/*  383 */     this.btnCancel.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  385 */         if (!PainelSNMP.this.flagCancel) {
/*  386 */           if (PainelSNMP.this.flagEscrita) {
/*  387 */             PainelSNMP.this.tfEscrita.setText(PainelSNMP.this.escritaAntiga);
/*  388 */             PainelSNMP.this.flagEscrita = false;
/*      */           }
/*  390 */           if (PainelSNMP.this.flagLeitura) {
/*  391 */             PainelSNMP.this.tfLeitura.setText(PainelSNMP.this.leituraAntiga);
/*  392 */             PainelSNMP.this.flagLeitura = false;
/*      */           }
/*  394 */           PainelSNMP.this.flag = false;
/*  395 */           PainelSNMP.this.flagCancel = true;
/*      */         }
/*  397 */         PainelSNMP.this.flagTraps = false;
/*  398 */         PainelSNMP.this.flagGetAndSet = false;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initComponents()
/*      */   {
/*  409 */     Font fonte11 = new Font("Trebuchet", 1, 11);
/*      */     
/*  411 */     this.painelGeral = new JPanel();
/*  412 */     this.labelPedidos = new JLabel();
/*  413 */     this.labelLeitura = new JLabel();
/*  414 */     this.labelEscrita = new JLabel();
/*  415 */     this.tfPedidos = new JTextField();
/*  416 */     this.tfEscrita = new JTextField();
/*  417 */     this.tfLeitura = new JTextField();
/*  418 */     this.painelTrap = new JPanel();
/*  419 */     this.labelGerente = new JLabel();
/*  420 */     this.labelSNMP = new JLabel();
/*  421 */     this.labelTransporte = new JLabel();
/*  422 */     this.labelEnvio = new JLabel();
/*  423 */     this.tfEnvio = new JTextField();
/*  424 */     this.cbTransporte = new JComboBox();
/*  425 */     this.cbSNMP = new JComboBox();
/*  426 */     this.tfGerente = new JTextField();
/*  427 */     this.btnOk = new JButton();
/*  428 */     this.btnCancel = new JButton();
/*      */     
/*  430 */     setLayout(new GridBagLayout());
/*      */     
/*  432 */     setMaximumSize(new Dimension(384, 335));
/*  433 */     setMinimumSize(new Dimension(384, 335));
/*  434 */     setOpaque(false);
/*  435 */     setPreferredSize(new Dimension(384, 335));
/*  436 */     this.painelGeral.setLayout(new GridBagLayout());
/*      */     
/*  438 */     this.painelGeral.setMaximumSize(new Dimension(384, 110));
/*  439 */     this.painelGeral.setMinimumSize(new Dimension(384, 110));
/*  440 */     this.painelGeral.setOpaque(false);
/*  441 */     this.painelGeral.setPreferredSize(new Dimension(384, 110));
/*      */     
/*  443 */     this.labelPedidos.setFont(fonte11);
/*  444 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  445 */     gridBagConstraints.fill = 1;
/*  446 */     gridBagConstraints.insets = new Insets(0, 5, 5, 20);
/*  447 */     this.painelGeral.add(this.labelPedidos, gridBagConstraints);
/*      */     
/*  449 */     this.labelLeitura.setFont(fonte11);
/*  450 */     gridBagConstraints = new GridBagConstraints();
/*  451 */     gridBagConstraints.gridx = 0;
/*  452 */     gridBagConstraints.gridy = 2;
/*  453 */     gridBagConstraints.fill = 1;
/*  454 */     gridBagConstraints.insets = new Insets(0, 5, 5, 20);
/*  455 */     this.painelGeral.add(this.labelLeitura, gridBagConstraints);
/*      */     
/*  457 */     this.labelEscrita.setFont(fonte11);
/*  458 */     gridBagConstraints = new GridBagConstraints();
/*  459 */     gridBagConstraints.gridx = 0;
/*  460 */     gridBagConstraints.gridy = 4;
/*  461 */     gridBagConstraints.fill = 1;
/*  462 */     gridBagConstraints.insets = new Insets(0, 5, 5, 20);
/*  463 */     this.painelGeral.add(this.labelEscrita, gridBagConstraints);
/*      */     
/*  465 */     this.tfPedidos.setText("161");
/*  466 */     this.tfPedidos.setBorder(new SoftBevelBorder(1, new Color(
/*  467 */       204, 204, 204), new Color(204, 204, 204), null, null));
/*  468 */     this.tfPedidos.setMaximumSize(new Dimension(100, 21));
/*  469 */     this.tfPedidos.setMinimumSize(new Dimension(100, 21));
/*  470 */     this.tfPedidos.setPreferredSize(new Dimension(100, 21));
/*  471 */     gridBagConstraints = new GridBagConstraints();
/*  472 */     gridBagConstraints.gridx = 2;
/*  473 */     gridBagConstraints.gridy = 0;
/*  474 */     gridBagConstraints.fill = 2;
/*  475 */     gridBagConstraints.anchor = 17;
/*  476 */     gridBagConstraints.insets = new Insets(0, 5, 5, 98);
/*  477 */     this.painelGeral.add(this.tfPedidos, gridBagConstraints);
/*      */     
/*  479 */     this.tfEscrita.setText("private");
/*  480 */     this.tfEscrita.setBorder(new SoftBevelBorder(1, new Color(
/*  481 */       204, 204, 204), new Color(204, 204, 204), null, null));
/*  482 */     this.tfEscrita.setMaximumSize(new Dimension(100, 21));
/*  483 */     this.tfEscrita.setMinimumSize(new Dimension(100, 21));
/*  484 */     this.tfEscrita.setPreferredSize(new Dimension(100, 21));
/*  485 */     gridBagConstraints = new GridBagConstraints();
/*  486 */     gridBagConstraints.gridx = 2;
/*  487 */     gridBagConstraints.gridy = 4;
/*  488 */     gridBagConstraints.fill = 2;
/*  489 */     gridBagConstraints.anchor = 17;
/*  490 */     gridBagConstraints.insets = new Insets(0, 5, 5, 98);
/*  491 */     this.painelGeral.add(this.tfEscrita, gridBagConstraints);
/*      */     
/*  493 */     this.tfLeitura.setText("public");
/*  494 */     this.tfLeitura.setBorder(new SoftBevelBorder(1, new Color(
/*  495 */       204, 204, 204), new Color(204, 204, 204), null, null));
/*  496 */     this.tfLeitura.setMaximumSize(new Dimension(100, 21));
/*  497 */     this.tfLeitura.setMinimumSize(new Dimension(100, 21));
/*  498 */     this.tfLeitura.setPreferredSize(new Dimension(100, 21));
/*  499 */     gridBagConstraints = new GridBagConstraints();
/*  500 */     gridBagConstraints.gridx = 2;
/*  501 */     gridBagConstraints.gridy = 2;
/*  502 */     gridBagConstraints.fill = 2;
/*  503 */     gridBagConstraints.anchor = 17;
/*  504 */     gridBagConstraints.insets = new Insets(0, 5, 5, 98);
/*  505 */     this.painelGeral.add(this.tfLeitura, gridBagConstraints);
/*      */     
/*  507 */     gridBagConstraints = new GridBagConstraints();
/*  508 */     gridBagConstraints.gridwidth = 3;
/*  509 */     gridBagConstraints.fill = 1;
/*  510 */     add(this.painelGeral, gridBagConstraints);
/*      */     
/*  512 */     this.painelTrap.setLayout(new GridBagLayout());
/*      */     
/*  514 */     this.painelTrap.setMaximumSize(new Dimension(384, 140));
/*  515 */     this.painelTrap.setMinimumSize(new Dimension(384, 140));
/*  516 */     this.painelTrap.setOpaque(false);
/*  517 */     this.painelTrap.setPreferredSize(new Dimension(384, 140));
/*      */     
/*  519 */     this.labelGerente.setFont(fonte11);
/*  520 */     gridBagConstraints = new GridBagConstraints();
/*  521 */     gridBagConstraints.fill = 1;
/*  522 */     gridBagConstraints.insets = new Insets(0, 5, 5, 0);
/*  523 */     this.painelTrap.add(this.labelGerente, gridBagConstraints);
/*      */     
/*  525 */     this.labelSNMP.setFont(fonte11);
/*  526 */     gridBagConstraints = new GridBagConstraints();
/*  527 */     gridBagConstraints.gridx = 0;
/*  528 */     gridBagConstraints.gridy = 4;
/*  529 */     gridBagConstraints.fill = 1;
/*  530 */     gridBagConstraints.insets = new Insets(0, 5, 5, 0);
/*  531 */     this.painelTrap.add(this.labelSNMP, gridBagConstraints);
/*      */     
/*  533 */     this.labelTransporte.setFont(fonte11);
/*  534 */     gridBagConstraints = new GridBagConstraints();
/*  535 */     gridBagConstraints.gridx = 0;
/*  536 */     gridBagConstraints.gridy = 6;
/*  537 */     gridBagConstraints.fill = 1;
/*  538 */     gridBagConstraints.insets = new Insets(0, 5, 5, 0);
/*  539 */     this.painelTrap.add(this.labelTransporte, gridBagConstraints);
/*      */     
/*  541 */     this.labelEnvio.setFont(fonte11);
/*  542 */     gridBagConstraints = new GridBagConstraints();
/*  543 */     gridBagConstraints.gridx = 0;
/*  544 */     gridBagConstraints.gridy = 2;
/*  545 */     gridBagConstraints.fill = 1;
/*  546 */     gridBagConstraints.insets = new Insets(0, 5, 5, 0);
/*  547 */     this.painelTrap.add(this.labelEnvio, gridBagConstraints);
/*      */     
/*  549 */     this.tfEnvio.setText("162");
/*  550 */     this.tfEnvio.setBorder(new SoftBevelBorder(1, new Color(
/*  551 */       204, 204, 204), new Color(204, 204, 204), null, null));
/*  552 */     this.tfEnvio.setMaximumSize(new Dimension(100, 21));
/*  553 */     this.tfEnvio.setMinimumSize(new Dimension(100, 21));
/*  554 */     this.tfEnvio.setPreferredSize(new Dimension(100, 21));
/*  555 */     gridBagConstraints = new GridBagConstraints();
/*  556 */     gridBagConstraints.gridx = 2;
/*  557 */     gridBagConstraints.gridy = 2;
/*  558 */     gridBagConstraints.fill = 2;
/*  559 */     gridBagConstraints.anchor = 17;
/*  560 */     gridBagConstraints.insets = new Insets(0, 5, 5, 100);
/*  561 */     this.painelTrap.add(this.tfEnvio, gridBagConstraints);
/*      */     
/*  563 */     this.cbTransporte.setModel(new DefaultComboBoxModel(new String[] { "UDP", 
/*  564 */       "TCP" }));
/*  565 */     gridBagConstraints = new GridBagConstraints();
/*  566 */     gridBagConstraints.gridx = 2;
/*  567 */     gridBagConstraints.gridy = 6;
/*  568 */     gridBagConstraints.fill = 1;
/*  569 */     gridBagConstraints.insets = new Insets(0, 5, 5, 100);
/*  570 */     this.painelTrap.add(this.cbTransporte, gridBagConstraints);
/*      */     
/*  572 */     this.cbSNMP.setModel(new DefaultComboBoxModel(new String[] { "1", "2" }));
/*  573 */     gridBagConstraints = new GridBagConstraints();
/*  574 */     gridBagConstraints.gridx = 2;
/*  575 */     gridBagConstraints.gridy = 4;
/*  576 */     gridBagConstraints.fill = 1;
/*  577 */     gridBagConstraints.insets = new Insets(0, 5, 5, 100);
/*  578 */     this.painelTrap.add(this.cbSNMP, gridBagConstraints);
/*      */     
/*  580 */     this.tfGerente.setText("127.0.0.1");
/*  581 */     this.tfGerente.setBorder(new SoftBevelBorder(1, new Color(
/*  582 */       204, 204, 204), new Color(204, 204, 204), null, null));
/*  583 */     this.tfGerente.setMaximumSize(new Dimension(100, 21));
/*  584 */     this.tfGerente.setMinimumSize(new Dimension(100, 21));
/*  585 */     this.tfGerente.setPreferredSize(new Dimension(100, 21));
/*  586 */     gridBagConstraints = new GridBagConstraints();
/*  587 */     gridBagConstraints.gridx = 2;
/*  588 */     gridBagConstraints.gridy = 0;
/*  589 */     gridBagConstraints.fill = 2;
/*  590 */     gridBagConstraints.anchor = 17;
/*  591 */     gridBagConstraints.insets = new Insets(0, 5, 5, 100);
/*  592 */     this.painelTrap.add(this.tfGerente, gridBagConstraints);
/*      */     
/*  594 */     gridBagConstraints = new GridBagConstraints();
/*  595 */     gridBagConstraints.gridx = 0;
/*  596 */     gridBagConstraints.gridy = 1;
/*  597 */     gridBagConstraints.gridwidth = 3;
/*  598 */     gridBagConstraints.fill = 1;
/*  599 */     add(this.painelTrap, gridBagConstraints);
/*      */     
/*  601 */     this.btnOk.setText("OK");
/*  602 */     this.btnOk.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(
/*  603 */       160, 160, 160)));
/*  604 */     this.btnOk.setFocusPainted(false);
/*  605 */     this.btnOk.setHorizontalTextPosition(0);
/*  606 */     this.btnOk.setMaximumSize(new Dimension(101, 30));
/*  607 */     this.btnOk.setMinimumSize(new Dimension(101, 30));
/*  608 */     this.btnOk.setPreferredSize(new Dimension(101, 30));
/*  609 */     gridBagConstraints = new GridBagConstraints();
/*  610 */     gridBagConstraints.gridx = 1;
/*  611 */     gridBagConstraints.gridy = 5;
/*  612 */     gridBagConstraints.anchor = 13;
/*  613 */     gridBagConstraints.insets = new Insets(10, 160, 0, 0);
/*  614 */     add(this.btnOk, gridBagConstraints);
/*      */     
/*  616 */     this.btnCancel.setText("CANCELAR");
/*  617 */     this.btnCancel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/*  618 */       new Color(160, 160, 160)));
/*  619 */     this.btnCancel.setFocusPainted(false);
/*  620 */     this.btnCancel.setMaximumSize(new Dimension(101, 30));
/*  621 */     this.btnCancel.setMinimumSize(new Dimension(101, 30));
/*  622 */     this.btnCancel.setPreferredSize(new Dimension(101, 30));
/*  623 */     gridBagConstraints = new GridBagConstraints();
/*  624 */     gridBagConstraints.gridx = 2;
/*  625 */     gridBagConstraints.gridy = 5;
/*  626 */     gridBagConstraints.anchor = 13;
/*  627 */     gridBagConstraints.insets = new Insets(10, 0, 0, 10);
/*  628 */     add(this.btnCancel, gridBagConstraints);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JButton getBtnCancel()
/*      */   {
/*  637 */     return this.btnCancel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getEscritaAntiga()
/*      */   {
/*  644 */     return this.escritaAntiga;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlag()
/*      */   {
/*  651 */     return this.flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlagCancel()
/*      */   {
/*  658 */     return this.flagCancel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlagEscrita()
/*      */   {
/*  665 */     return this.flagEscrita;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlagLeitura()
/*      */   {
/*  672 */     return this.flagLeitura;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getLeituraAntiga()
/*      */   {
/*  679 */     return this.leituraAntiga;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JButton getBtnOk()
/*      */   {
/*  686 */     return this.btnOk;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JComboBox getCbSNMP()
/*      */   {
/*  693 */     return this.cbSNMP;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JComboBox getCbTransporte()
/*      */   {
/*  700 */     return this.cbTransporte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getLabelEnvio()
/*      */   {
/*  707 */     return this.labelEnvio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getLabelEscrita()
/*      */   {
/*  714 */     return this.labelEscrita;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getLabelGerente()
/*      */   {
/*  721 */     return this.labelGerente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getLabelLeitura()
/*      */   {
/*  728 */     return this.labelLeitura;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlagGetAndSet()
/*      */   {
/*  735 */     return this.flagGetAndSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlagTraps()
/*      */   {
/*  742 */     return this.flagTraps;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getLabelPedidos()
/*      */   {
/*  749 */     return this.labelPedidos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getLabelSNMP()
/*      */   {
/*  756 */     return this.labelSNMP;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JLabel getLabelTransporte()
/*      */   {
/*  763 */     return this.labelTransporte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelGeral()
/*      */   {
/*  770 */     return this.painelGeral;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JPanel getPainelTrap()
/*      */   {
/*  777 */     return this.painelTrap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JTextField getTfEnvio()
/*      */   {
/*  784 */     return this.tfEnvio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JTextField getTfEscrita()
/*      */   {
/*  791 */     return this.tfEscrita;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JTextField getTfGerente()
/*      */   {
/*  798 */     return this.tfGerente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JTextField getTfLeitura()
/*      */   {
/*  805 */     return this.tfLeitura;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getEnvioAntigo()
/*      */   {
/*  812 */     return this.envioAntigo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlagEnvio()
/*      */   {
/*  819 */     return this.flagEnvio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlagPedidos()
/*      */   {
/*  826 */     return this.flagPedidos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getPedidoAntigo()
/*      */   {
/*  833 */     return this.pedidoAntigo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JTextField getTfPedidos()
/*      */   {
/*  840 */     return this.tfPedidos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBtnCancel(JButton btnCancel)
/*      */   {
/*  847 */     this.btnCancel = btnCancel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBtnOk(JButton btnOk)
/*      */   {
/*  857 */     this.btnOk = btnOk;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEscritaAntiga(String escritaAntiga)
/*      */   {
/*  864 */     this.escritaAntiga = escritaAntiga;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlagGetAndSet(boolean flagGetAndSet)
/*      */   {
/*  871 */     this.flagGetAndSet = flagGetAndSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlagTraps(boolean flagTraps)
/*      */   {
/*  878 */     this.flagTraps = flagTraps;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlag(boolean flag)
/*      */   {
/*  885 */     this.flag = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlagCancel(boolean flagCancel)
/*      */   {
/*  892 */     this.flagCancel = flagCancel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlagEscrita(boolean flagEscrita)
/*      */   {
/*  899 */     this.flagEscrita = flagEscrita;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlagLeitura(boolean flagLeitura)
/*      */   {
/*  906 */     this.flagLeitura = flagLeitura;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLeituraAntiga(String leituraAntiga)
/*      */   {
/*  913 */     this.leituraAntiga = leituraAntiga;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCbSNMP(JComboBox cbSNMP)
/*      */   {
/*  920 */     this.cbSNMP = cbSNMP;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCbTransporte(JComboBox cbTransporte)
/*      */   {
/*  927 */     this.cbTransporte = cbTransporte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLabelEnvio(JLabel labelEnvio)
/*      */   {
/*  934 */     this.labelEnvio = labelEnvio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLabelEscrita(JLabel labelEscrita)
/*      */   {
/*  941 */     this.labelEscrita = labelEscrita;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLabelGerente(JLabel labelGerente)
/*      */   {
/*  948 */     this.labelGerente = labelGerente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLabelLeitura(JLabel labelLeitura)
/*      */   {
/*  955 */     this.labelLeitura = labelLeitura;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLabelPedidos(JLabel labelPedidos)
/*      */   {
/*  962 */     this.labelPedidos = labelPedidos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLabelSNMP(JLabel labelSNMP)
/*      */   {
/*  969 */     this.labelSNMP = labelSNMP;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLabelTransporte(JLabel labelTransporte)
/*      */   {
/*  976 */     this.labelTransporte = labelTransporte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelGeral(JPanel painelGeral)
/*      */   {
/*  983 */     this.painelGeral = painelGeral;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPainelTrap(JPanel painelTrap)
/*      */   {
/*  990 */     this.painelTrap = painelTrap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTfEnvio(JTextField tfEnvio)
/*      */   {
/*  997 */     this.tfEnvio = tfEnvio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTfEscrita(JTextField tfEscrita)
/*      */   {
/* 1004 */     this.tfEscrita = tfEscrita;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTfGerente(JTextField tfGerente)
/*      */   {
/* 1011 */     this.tfGerente = tfGerente;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEnvioAntigo(int envioAntigo)
/*      */   {
/* 1018 */     this.envioAntigo = envioAntigo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlagEnvio(boolean flagEnvio)
/*      */   {
/* 1025 */     this.flagEnvio = flagEnvio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlagPedidos(boolean flagPedidos)
/*      */   {
/* 1032 */     this.flagPedidos = flagPedidos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPedidoAntigo(int pedidoAntigo)
/*      */   {
/* 1039 */     this.pedidoAntigo = pedidoAntigo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTfLeitura(JTextField tfLeitura)
/*      */   {
/* 1046 */     this.tfLeitura = tfLeitura;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTfPedidos(JTextField tfPedidos)
/*      */   {
/* 1053 */     this.tfPedidos = tfPedidos;
/*      */   }
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelSNMP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */