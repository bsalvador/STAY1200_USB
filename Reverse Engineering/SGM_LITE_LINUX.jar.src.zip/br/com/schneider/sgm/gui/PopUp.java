/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PopUp
/*     */   extends JFrame
/*     */ {
/*     */   private PainelDec painel;
/*     */   private JButton botaoOk;
/*     */   private JButton botaoNo;
/*     */   private JButton botaoYes;
/*  61 */   private short posJanX = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private short posJanY = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private InterfaceGrafica pai;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PopUp(String caminhoFundo, String caminhoBotao, String mensagem, String caminhoFigura, int espHorizontal, int espVertical, InterfaceGrafica pai, boolean alerta, boolean okQuestion)
/*     */   {
/*  84 */     super(mensagem);
/*  85 */     this.pai = pai;
/*  86 */     setIconImage(new ImageIcon(caminhoBotao + "IconeSGM.png").getImage());
/*  87 */     this.painel = new PainelDec(caminhoFundo, espHorizontal, espVertical);
/*  88 */     this.painel.setLayout(new FlowLayout(1, 100, 10));
/*  89 */     this.painel.setPreferredSize(new Dimension(400, 134));
/*  90 */     getContentPane().setLayout(new BorderLayout());
/*  91 */     add(this.painel, "Center");
/*  92 */     Icon icone2 = new ImageIcon(caminhoBotao + "PopUpTitulo.png");
/*  93 */     Preenche0 preenche1 = new Preenche0(icone2);
/*  94 */     add(preenche1, "North");
/*     */     Icon icone;
/*     */     Icon icone;
/*  97 */     if (alerta) {
/*  98 */       icone = new ImageIcon(caminhoFigura + "okpop.png");
/*     */     } else {
/* 100 */       icone = new ImageIcon(caminhoFigura + "okpop.png");
/*     */     }
/* 102 */     JTextPane texto = new JTextPane();
/* 103 */     JLabel rotulo = new JLabel(" ", icone, 0);
/* 104 */     texto.insertComponent(rotulo);
/* 105 */     JTextArea textoInt = new JTextArea(mensagem);
/* 106 */     textoInt.setFont(new Font("Trebuchet", 1, 12));
/* 107 */     texto.insertComponent(textoInt);
/* 108 */     texto.setOpaque(false);
/* 109 */     texto.setEnabled(false);
/* 110 */     texto.setDisabledTextColor(Color.BLACK);
/* 111 */     textoInt.setOpaque(false);
/* 112 */     textoInt.setEnabled(false);
/* 113 */     textoInt.setDisabledTextColor(Color.BLACK);
/* 114 */     this.painel.add(texto);
/* 115 */     if (okQuestion) {
/* 116 */       this.botaoOk = new JButton(ResourceBundle.getBundle(Idioma.getIdioma())
/* 117 */         .getString("Ok"));
/* 118 */       this.botaoOk.addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent ae) {
/* 120 */           PopUp.this.pai.setXPop(PopUp.this.pai.getXPop() - 10);
/* 121 */           PopUp.this.pai.setYPop(PopUp.this.pai.getYPop() - 10);
/* 122 */           PopUp.this.dispose();
/*     */         }
/* 124 */       });
/* 125 */       this.painel.add(this.botaoOk);
/*     */     } else {
/* 127 */       this.botaoNo = new JButton(ResourceBundle.getBundle(Idioma.getIdioma())
/* 128 */         .getString("Nao"));
/* 129 */       this.botaoNo.addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent ae) {
/* 131 */           PopUp.this.pai.setXPop(PopUp.this.pai.getXPop() - 10);
/* 132 */           PopUp.this.pai.setYPop(PopUp.this.pai.getYPop() - 10);
/* 133 */           PopUp.this.dispose();
/*     */         }
/* 135 */       });
/* 136 */       this.botaoYes = new JButton(ResourceBundle.getBundle(Idioma.getIdioma())
/* 137 */         .getString("Sim"));
/* 138 */       this.botaoYes.addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent ae) {
/* 140 */           PopUp.this.pai.setXPop(PopUp.this.pai.getXPop() - 10);
/* 141 */           PopUp.this.pai.setYPop(PopUp.this.pai.getYPop() - 10);
/* 142 */           PopUp.this.dispose();
/*     */         }
/* 144 */       });
/* 145 */       this.painel.add(this.botaoYes);
/* 146 */       this.painel.add(this.botaoNo);
/*     */     }
/* 148 */     setResizable(false);
/* 149 */     setSize(399, 149);
/* 150 */     setUndecorated(true);
/* 151 */     setVisible(true);
/* 152 */     setAlwaysOnTop(true);
/* 153 */     setLocation(this.pai.getXPop(), this.pai.getYPop());
/* 154 */     this.posJanX = ((short)this.pai.getXPop());
/* 155 */     this.posJanY = ((short)this.pai.getYPop());
/* 156 */     this.pai.setXPop(this.pai.getXPop() + 10);
/* 157 */     this.pai.setYPop(this.pai.getYPop() + 10);
/*     */     
/* 159 */     addMouseListener(
/* 160 */       new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent me) {
/* 162 */           PopUp.this.posJanX = ((short)(me.getX() - PopUp.this.posJanX));
/* 163 */           PopUp.this.posJanY = ((short)(me.getY() - PopUp.this.posJanY));
/*     */         }
/*     */         
/*     */         public void mouseReleased(MouseEvent me) {
/* 167 */           PopUp.this.posJanX = ((short)(me.getX() - PopUp.this.posJanX));
/* 168 */           PopUp.this.posJanY = ((short)(me.getY() - PopUp.this.posJanY));
/* 169 */           PopUp.this.setLocation(PopUp.this.posJanX, PopUp.this.posJanY);
/*     */         }
/*     */         
/* 172 */       });
/* 173 */     addWindowListener(new WindowAdapter() {
/*     */       public void windowClosing(WindowEvent we) {
/* 175 */         PopUp.this.pai.setXPop(PopUp.this.pai.getXPop() - 10);
/* 176 */         PopUp.this.pai.setYPop(PopUp.this.pai.getYPop() - 10);
/*     */       }
/*     */       
/* 179 */     });
/* 180 */     pai.setState(0);
/* 181 */     pai.setVisible(true);
/*     */   }
/*     */   
/*     */   public JButton getBtnOk() {
/* 185 */     return this.botaoOk;
/*     */   }
/*     */   
/*     */   public JButton getBtnYes() {
/* 189 */     return this.botaoYes;
/*     */   }
/*     */   
/*     */   public JButton getBtnNo() {
/* 193 */     return this.botaoNo;
/*     */   }
/*     */   
/*     */   class Preenche0
/*     */     extends JPanel
/*     */   {
/*     */     ImageIcon imagemFundo;
/*     */     
/*     */     public Preenche0(Icon imagemFundo)
/*     */     {
/* 203 */       setPreferredSize(new Dimension(400, 18));
/* 204 */       this.imagemFundo = ((ImageIcon)imagemFundo);
/*     */     }
/*     */     
/*     */     public void paintComponent(Graphics g)
/*     */     {
/* 209 */       super.paintComponent(g);
/* 210 */       g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PopUp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */