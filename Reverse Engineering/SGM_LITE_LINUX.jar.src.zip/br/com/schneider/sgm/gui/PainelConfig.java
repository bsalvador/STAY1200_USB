/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelConfig
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 5943891401314392058L;
/*     */   PainelBtnCtrl pbc;
/*     */   static CardLayout card;
/*     */   private JPanel panelMaster;
/*     */   private static JPanel panelSlave;
/*     */   PainelGeral painelGeral;
/*     */   PainelMensg painelMensg;
/*     */   PainelUPS painelUPS;
/*     */   PainelSMTP painelSMTP;
/*     */   PainelSNMP painelSNMP;
/*     */   PainelAutoTeste painelAutoTeste;
/*     */   
/*     */   public PainelConfig(String caminhoFiguras, InterfaceGrafica interfaceGrafica)
/*     */   {
/*  82 */     initComponents();
/*  83 */     this.pbc = new PainelBtnCtrl(caminhoFiguras, interfaceGrafica);
/*  84 */     card = new CardLayout();
/*  85 */     panelSlave.setLayout(card);
/*  86 */     this.panelMaster.add(this.pbc);
/*     */     
/*  88 */     this.painelGeral = new PainelGeral();
/*  89 */     panelSlave.add(this.painelGeral, "painelGeral");
/*     */     
/*  91 */     this.painelMensg = new PainelMensg();
/*  92 */     panelSlave.add(this.painelMensg, "painelMensagens");
/*     */     
/*  94 */     this.painelUPS = new PainelUPS(caminhoFiguras, interfaceGrafica);
/*  95 */     panelSlave.add(this.painelUPS, "painelUPS");
/*     */     
/*  97 */     this.painelSMTP = new PainelSMTP();
/*  98 */     panelSlave.add(this.painelSMTP, "painelSMTP");
/*     */     
/* 100 */     this.painelSNMP = new PainelSNMP();
/* 101 */     panelSlave.add(this.painelSNMP, "painelSNMP");
/*     */     
/* 103 */     this.painelAutoTeste = new PainelAutoTeste();
/* 104 */     panelSlave.add(this.painelAutoTeste, "painelAutoTeste");
/*     */     
/* 106 */     this.pbc.setPainelUPS(this.painelUPS);
/* 107 */     this.pbc.setPainelMensg(this.painelMensg);
/* 108 */     this.pbc.setPainelGeral(this.painelGeral);
/* 109 */     this.pbc.setPainelSMTP(this.painelSMTP);
/* 110 */     this.pbc.setPainelSNMP(this.painelSNMP);
/* 111 */     this.pbc.setPainelAutoTeste(this.painelAutoTeste);
/* 112 */     this.pbc.setPainelConfig(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 121 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 122 */     Dimension d1 = new Dimension(515, 335);
/*     */     
/* 124 */     Dimension d2 = new Dimension(100, 300);
/*     */     
/* 126 */     int i = 170;
/* 127 */     Color c1 = new Color(i, i, i);
/*     */     
/*     */ 
/* 130 */     this.panelMaster = new JPanel();
/* 131 */     panelSlave = new JPanel();
/*     */     
/*     */ 
/* 134 */     setLayout(new GridBagLayout());
/* 135 */     setMaximumSize(d1);
/* 136 */     setMinimumSize(d1);
/* 137 */     setPreferredSize(d1);
/* 138 */     setOpaque(false);
/*     */     
/*     */ 
/* 141 */     this.panelMaster.setMaximumSize(d2);
/* 142 */     this.panelMaster.setMinimumSize(d2);
/* 143 */     this.panelMaster.setPreferredSize(d2);
/* 144 */     this.panelMaster.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, c1));
/* 145 */     this.panelMaster.setOpaque(false);
/* 146 */     gridBagConstraints.gridwidth = 7;
/* 147 */     gridBagConstraints.fill = 1;
/* 148 */     add(this.panelMaster, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 152 */     panelSlave.setLayout(new CardLayout());
/* 153 */     panelSlave.setMaximumSize(new Dimension(384, 300));
/* 154 */     panelSlave.setMinimumSize(new Dimension(384, 300));
/* 155 */     panelSlave.setPreferredSize(new Dimension(384, 300));
/* 156 */     panelSlave.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, c1));
/* 157 */     panelSlave.setOpaque(false);
/* 158 */     gridBagConstraints.gridwidth = 1;
/* 159 */     gridBagConstraints.fill = 0;
/* 160 */     gridBagConstraints.gridx = 8;
/* 161 */     gridBagConstraints.gridy = 0;
/* 162 */     gridBagConstraints.insets = new Insets(0, 10, 0, 0);
/* 163 */     add(panelSlave, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CardLayout getCard()
/*     */   {
/* 172 */     return card;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JPanel getPanelSlave()
/*     */   {
/* 179 */     return panelSlave;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelGeral getPainelGeral()
/*     */   {
/* 186 */     return this.painelGeral;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelGeral getPainelConfigGeral()
/*     */   {
/* 193 */     return this.painelGeral;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelMensg getPainelMensg()
/*     */   {
/* 200 */     return this.painelMensg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelSMTP getPainelSMTP()
/*     */   {
/* 207 */     return this.painelSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelSNMP getPainelSNMP()
/*     */   {
/* 214 */     return this.painelSNMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelUPS getPainelUPS()
/*     */   {
/* 221 */     return this.painelUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JPanel getPanelMaster()
/*     */   {
/* 228 */     return this.panelMaster;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PainelAutoTeste getPainelAutoTeste()
/*     */   {
/* 236 */     return this.painelAutoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelBtnCtrl getPbc()
/*     */   {
/* 243 */     return this.pbc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setCard(CardLayout card)
/*     */   {
/* 254 */     card = card;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void setPanelSlave(JPanel panelSlave)
/*     */   {
/* 261 */     panelSlave = panelSlave;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPainelGeral(PainelGeral painelGeral)
/*     */   {
/* 268 */     this.painelGeral = painelGeral;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPainelMensg(PainelMensg painelMensg)
/*     */   {
/* 275 */     this.painelMensg = painelMensg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPainelSMTP(PainelSMTP painelSMTP)
/*     */   {
/* 282 */     this.painelSMTP = painelSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPainelSNMP(PainelSNMP painelSNMP)
/*     */   {
/* 289 */     this.painelSNMP = painelSNMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPainelUPS(PainelUPS painelUPS)
/*     */   {
/* 296 */     this.painelUPS = painelUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPanelMaster(JPanel panelMaster)
/*     */   {
/* 303 */     this.panelMaster = panelMaster;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPbc(PainelBtnCtrl pbc)
/*     */   {
/* 310 */     this.pbc = pbc;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */