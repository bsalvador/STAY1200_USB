/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelSuperior
/*     */   extends JPanel
/*     */ {
/*  25 */   private short posJanX = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  30 */   private short posJanY = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JFrame pai;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JPanel controleJanela;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JPanel painelBotoes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JPanel painelRotulos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JPanel painelVisoes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PainelSuperior(int espHorizontal, int espVertical, int largura, int altura, JFrame containerPai)
/*     */   {
/*  70 */     super(new BorderLayout(espHorizontal, espVertical));
/*  71 */     setPreferredSize(new Dimension(largura, altura));
/*  72 */     setOpaque(false);
/*  73 */     this.pai = containerPai;
/*  74 */     addMouseListener(
/*  75 */       new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent me) {
/*  77 */           PainelSuperior.this.posJanX = ((short)(me.getX() - PainelSuperior.this.posJanX));
/*  78 */           PainelSuperior.this.posJanY = ((short)(me.getY() - PainelSuperior.this.posJanY));
/*     */         }
/*     */         
/*     */         public void mouseReleased(MouseEvent me) {
/*  82 */           PainelSuperior.this.posJanX = ((short)(me.getX() - PainelSuperior.this.posJanX));
/*  83 */           PainelSuperior.this.posJanY = ((short)(me.getY() - PainelSuperior.this.posJanY));
/*  84 */           PainelSuperior.this.pai.setLocation(PainelSuperior.this.posJanX, PainelSuperior.this.posJanY);
/*     */         }
/*  86 */       });
/*  87 */     this.controleJanela = new JPanel(new FlowLayout(2, 0, 0));
/*  88 */     this.controleJanela.setPreferredSize(new Dimension(700, 18));
/*  89 */     this.controleJanela.setOpaque(false);
/*  90 */     add(this.controleJanela, "North");
/*  91 */     this.painelVisoes = new JPanel(new FlowLayout(2, 0, 0));
/*  92 */     this.painelVisoes.setPreferredSize(new Dimension(500, 61));
/*  93 */     this.painelVisoes.setOpaque(false);
/*  94 */     this.painelBotoes = new JPanel(new FlowLayout(1, 33, 5));
/*  95 */     this.painelBotoes.setPreferredSize(new Dimension(500, 44));
/*  96 */     this.painelBotoes.setOpaque(false);
/*  97 */     this.painelRotulos = new JPanel(new GridLayout(1, 0, 0, 15));
/*  98 */     this.painelRotulos.setPreferredSize(new Dimension(498, 16));
/*  99 */     this.painelRotulos.setOpaque(false);
/* 100 */     this.painelVisoes.add(this.painelBotoes);
/* 101 */     this.painelVisoes.add(this.painelRotulos);
/* 102 */     add(this.painelVisoes, "East");
/*     */   }
/*     */   
/*     */   public short getPosJanX()
/*     */   {
/* 107 */     return this.posJanX;
/*     */   }
/*     */   
/*     */   public short getPosJanY() {
/* 111 */     return this.posJanY;
/*     */   }
/*     */   
/*     */   public void setPosJanX(short x) {
/* 115 */     this.posJanX = x;
/*     */   }
/*     */   
/*     */   public void setPosJanY(short y) {
/* 119 */     this.posJanY = y;
/*     */   }
/*     */   
/*     */   public JPanel getControleJanela() {
/* 123 */     return this.controleJanela;
/*     */   }
/*     */   
/*     */   public JPanel getPainelBotoes() {
/* 127 */     return this.painelBotoes;
/*     */   }
/*     */   
/*     */   public JPanel getPainelRotulos() {
/* 131 */     return this.painelRotulos;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelSuperior.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */