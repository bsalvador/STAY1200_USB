/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelBarrado
/*     */   extends PainelDec
/*     */ {
/*     */   private static final long serialVersionUID = 2198731463974630460L;
/*     */   public static final byte APAGADO = 1;
/*     */   public static final byte ALERTA = 2;
/*     */   public static final byte OK = 3;
/*     */   private JPanel painelIndicadores;
/*     */   private JPanel preenche;
/*     */   private JLabel[] indicadores;
/*     */   private Icon[] leds;
/*     */   private JLabel rotuloTitulo;
/*     */   private Font fonteIndicadores;
/*     */   private Color corIndicadores;
/*     */   private GridLayout layoutIndicadores;
/*     */   
/*     */   public PainelBarrado(String caminhoImagem, String caminhoLeds, int espHorizontal, int espVertical, String titulo)
/*     */   {
/* 105 */     super(caminhoImagem, espHorizontal, espVertical);
/*     */     
/* 107 */     this.rotuloTitulo = new JLabel(titulo);
/* 108 */     this.rotuloTitulo.setHorizontalAlignment(0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 113 */     this.rotuloTitulo.setVerticalAlignment(0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     this.rotuloTitulo.setPreferredSize(new Dimension(125, 20));
/*     */     
/*     */ 
/* 121 */     add(this.rotuloTitulo, "North");
/*     */     
/*     */ 
/* 124 */     this.indicadores = new JLabel[10];
/*     */     
/* 126 */     this.leds = new Icon[3];
/*     */     
/* 128 */     this.leds[0] = new ImageIcon(caminhoLeds + "Apagado.png");
/*     */     
/*     */ 
/* 131 */     this.leds[1] = new ImageIcon(caminhoLeds + "Alerta.png");
/*     */     
/*     */ 
/* 134 */     this.leds[2] = new ImageIcon(caminhoLeds + "ok.png");
/*     */     
/*     */ 
/* 137 */     this.layoutIndicadores = new GridLayout(0, 2);
/*     */     
/* 139 */     this.painelIndicadores = new JPanel(this.layoutIndicadores);
/*     */     
/* 141 */     this.painelIndicadores.setPreferredSize(new Dimension(125, 151));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */     this.painelIndicadores.setOpaque(false);
/*     */     
/* 150 */     add(this.painelIndicadores, "Center");
/*     */     
/*     */ 
/*     */ 
/* 154 */     this.preenche = new JPanel();
/*     */     
/*     */ 
/* 157 */     this.preenche.setPreferredSize(new Dimension(3, 151));
/*     */     
/*     */ 
/* 160 */     this.preenche.setOpaque(false);
/* 161 */     add(this.preenche, "West");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIndicador(String indicador)
/*     */   {
/* 175 */     this.indicadores[this.layoutIndicadores.getRows()] = new JLabel(indicador, 
/* 176 */       this.leds[0], 2);
/* 177 */     this.layoutIndicadores.setRows(this.layoutIndicadores.getRows() + 1);
/*     */     
/*     */ 
/*     */ 
/* 181 */     this.painelIndicadores.add(this.indicadores[(this.layoutIndicadores.getRows() - 1)]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIndicador(int i, JLabel label)
/*     */   {
/* 199 */     this.indicadores[i] = label;
/*     */   }
/*     */   
/*     */   public JLabel getIndicador(int i) {
/* 203 */     return this.indicadores[i];
/*     */   }
/*     */   
/*     */   public JPanel getPainelIndicador() {
/* 207 */     return this.painelIndicadores;
/*     */   }
/*     */   
/*     */   public JLabel getRotuloTitulo() {
/* 211 */     return this.rotuloTitulo;
/*     */   }
/*     */   
/*     */   public void setRotuloTitulo(JLabel rotuloTitulo) {
/* 215 */     this.rotuloTitulo = rotuloTitulo;
/*     */   }
/*     */   
/*     */   public Font getFonteIndicadores() {
/* 219 */     return this.fonteIndicadores;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFonteIndicadores(Font fonteIndicadores)
/*     */   {
/* 227 */     this.fonteIndicadores = fonteIndicadores;
/*     */     
/* 229 */     for (int i = 0; i < this.layoutIndicadores.getRows(); i++)
/*     */     {
/* 231 */       this.indicadores[i].setFont(fonteIndicadores);
/*     */     }
/*     */   }
/*     */   
/*     */   public Color getCorIndicadores()
/*     */   {
/* 237 */     return this.corIndicadores;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCorIndicadores(Color corIndicadores)
/*     */   {
/* 244 */     this.corIndicadores = corIndicadores;
/*     */     
/*     */ 
/* 247 */     for (int i = 0; i < this.layoutIndicadores.getRows(); i++)
/*     */     {
/* 249 */       this.indicadores[i].setForeground(corIndicadores);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void chaveiaLed(int estado, int indicador)
/*     */   {
/* 265 */     switch (estado) {
/*     */     case 1: 
/* 267 */       this.indicadores[indicador].setIcon(this.leds[0]);
/* 268 */       break;
/*     */     case 2: 
/* 270 */       this.indicadores[indicador].setIcon(this.leds[1]);
/* 271 */       break;
/*     */     case 3: 
/* 273 */       this.indicadores[indicador].setIcon(this.leds[2]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelBarrado.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */