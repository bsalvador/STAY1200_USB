/*      */ package br.com.schneider.sgm.gui;
/*      */ 
/*      */ import br.com.schneider.sgm.controle.Controle;
/*      */ import br.com.schneider.sgm.eventos.ControleListener;
/*      */ import br.com.schneider.sgm.eventos.Evento;
/*      */ import br.com.schneider.sgm.grafico.GraficoBateria;
/*      */ import br.com.schneider.sgm.grafico.GraficoCorrente;
/*      */ import br.com.schneider.sgm.grafico.GraficoPotencia;
/*      */ import br.com.schneider.sgm.grafico.GraficoTensao;
/*      */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*      */ import br.com.schneider.sgm.persistencia.Persistencia;
/*      */ import br.com.schneider.sgm.servico.ExecutaAcaoRede;
/*      */ import java.awt.AWTException;
/*      */ import java.awt.CardLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FlowLayout;
/*      */ import java.awt.Font;
/*      */ import java.awt.Point;
/*      */ import java.awt.SystemTray;
/*      */ import java.awt.TrayIcon;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.io.File;
/*      */ import java.io.PrintStream;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Hashtable;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JPasswordField;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.JSpinner;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.ListSelectionModel;
/*      */ import javax.swing.SpinnerModel;
/*      */ import javax.swing.event.CaretEvent;
/*      */ import javax.swing.event.CaretListener;
/*      */ import javax.swing.table.DefaultTableModel;
/*      */ import javax.swing.table.TableModel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class InterfaceGrafica
/*      */   extends JFrame
/*      */   implements ControleListener
/*      */ {
/*      */   private Hashtable<String, Integer> messagePopupCache;
/*      */   private static final long serialVersionUID = 8673075460832518164L;
/*      */   private boolean energiaPop;
/*      */   private boolean energiaEmail;
/*      */   private boolean bateriaPop;
/*      */   private boolean bateriaEmail;
/*      */   private boolean cargaPop;
/*      */   private boolean cargaEmail;
/*      */   private boolean temperaturaPop;
/*      */   private boolean temperaturaEmail;
/*      */   private boolean bateriaUsoPop;
/*      */   private boolean bateriaUsoEmail;
/*      */   private boolean comEmail;
/*      */   private int xPop;
/*      */   private int yPop;
/*      */   private PainelDec painelFundo;
/*      */   private PainelCentral painelFuncional;
/*      */   private PainelSuperior painelSuperior;
/*      */   private JPanel painelStatusAlertas;
/*      */   private BotaoDec botaoMinimizar;
/*      */   private BotaoDec botaoTray;
/*      */   private BotaoDec botaoFechar;
/*      */   private BotaoDec botaoMonitor;
/*      */   private BotaoDec botaoGraficos;
/*      */   private BotaoDec botaoConfiguracoes;
/*      */   private BotaoDec botaoComandos;
/*      */   private BotaoDec botaoHistorico;
/*      */   private BotaoDec botaoSobre;
/*      */   private JLabel rotuloMonitor;
/*      */   private JLabel rotuloConfiguracoes;
/*      */   private JLabel rotuloGrafico;
/*      */   private JLabel rotuloHistorico;
/*      */   private JLabel rotuloSobre;
/*      */   private JLabel rotuloComandos;
/*      */   private PainelMonitorCentral painelMonitoramento;
/*      */   private PainelGraficos painelGraficos;
/*      */   private PainelComando painelComandos;
/*      */   private PainelConfig painelConfig;
/*      */   private PainelHistorico painelHistorico;
/*      */   private PainelSobre painelSobre;
/*      */   private SystemTray systemTray;
/*      */   private TrayIcon iconeTray;
/*      */   private boolean liga;
/*      */   private TrataEventos trataEventos;
/*      */   private TrataStatusAlertas trataStsAls;
/*      */   private PainelBarrado painelStatus;
/*      */   private PainelBarrado painelAlertas;
/*      */   private Controle controle;
/*      */   private String caminhoFiguras;
/*      */   private DecimalFormat formatador;
/*  304 */   private boolean comunicou = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  309 */   private final String VALIDA_ENDERECO_IP = "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean flagPedidos;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String pedidoAntigo;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Calendar calendar;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean monitor;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean graficos;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InterfaceGrafica(String caminhoFigura, Controle controle, String[] portasSeriais)
/*      */   {
/*  359 */     super("SGM Light " + controle.getVersaoSoftware());
/*  360 */     this.messagePopupCache = new Hashtable();
/*  361 */     this.caminhoFiguras = caminhoFigura;
/*  362 */     addWindowListener(
/*  363 */       new WindowAdapter()
/*      */       {
/*      */         public void windowClosing(WindowEvent we)
/*      */         {
/*  367 */           InterfaceGrafica.this.encerraAplicativo();
/*      */         }
/*  369 */       });
/*  370 */     setResizable(false);
/*  371 */     setIconImage(new ImageIcon(this.caminhoFiguras + "IconeSGM.png").getImage());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  376 */     this.painelFundo = new PainelDec(this.caminhoFiguras + "Fundo.png", 0, 2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  383 */     this.trataEventos = new TrataEventos();
/*      */     
/*  385 */     this.controle = controle;
/*      */     
/*  387 */     this.trataStsAls = new TrataStatusAlertas();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  395 */     Idioma.setIdiomaPortugues();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  402 */     this.calendar = Calendar.getInstance();
/*  403 */     this.calendar.setLenient(true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  409 */     this.painelSuperior = new PainelSuperior(50, 0, 700, 76, this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  415 */     this.botaoTray = new BotaoDec(this.caminhoFiguras + "Tray.png", this.caminhoFiguras + 
/*  416 */       "TrayP.png", 22, 12);
/*  417 */     this.botaoTray.setRolloverIcon(new ImageIcon(this.caminhoFiguras + "TrayR.png"));
/*  418 */     this.botaoTray.addActionListener(this.trataEventos);
/*  419 */     this.painelSuperior.getControleJanela().add(this.botaoTray);
/*  420 */     this.botaoMinimizar = new BotaoDec(this.caminhoFiguras + "Minimizar.png", 
/*  421 */       this.caminhoFiguras + "MinimizarP.png", 20, 12);
/*  422 */     this.botaoMinimizar.setRolloverIcon(new ImageIcon(this.caminhoFiguras + 
/*  423 */       "MinimizarR.png"));
/*  424 */     this.botaoMinimizar.addActionListener(this.trataEventos);
/*  425 */     this.painelSuperior.getControleJanela().add(this.botaoMinimizar);
/*  426 */     this.botaoFechar = new BotaoDec(this.caminhoFiguras + "Fechar.png", 
/*  427 */       this.caminhoFiguras + "FecharP.png", 30, 12);
/*  428 */     this.botaoFechar.setRolloverIcon(new ImageIcon(this.caminhoFiguras + 
/*  429 */       "FecharR.png"));
/*  430 */     this.botaoFechar.addActionListener(this.trataEventos);
/*  431 */     this.painelSuperior.getControleJanela().add(this.botaoFechar);
/*  432 */     this.painelSuperior.getControleJanela().add(new JLabel("       "));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */     this.botaoMonitor = new BotaoDec(this.caminhoFiguras + "Monitor.png", 
/*  444 */       this.caminhoFiguras + "MonitorP.png", 46, 35);
/*  445 */     this.botaoMonitor.setRolloverIcon(new ImageIcon(this.caminhoFiguras + 
/*  446 */       "MonitorR.png"));
/*  447 */     this.botaoMonitor.setFocusPainted(false);
/*  448 */     this.botaoMonitor.addActionListener(this.trataEventos);
/*  449 */     this.painelSuperior.getPainelBotoes().add(this.botaoMonitor);
/*  450 */     this.botaoGraficos = new BotaoDec(this.caminhoFiguras + "Grafico.png", 
/*  451 */       this.caminhoFiguras + "GraficoP.png", 46, 35);
/*  452 */     this.botaoGraficos.setRolloverIcon(new ImageIcon(this.caminhoFiguras + 
/*  453 */       "GraficoR.png"));
/*  454 */     this.botaoGraficos.setFocusPainted(false);
/*  455 */     this.botaoGraficos.addActionListener(this.trataEventos);
/*  456 */     this.painelSuperior.getPainelBotoes().add(this.botaoGraficos);
/*  457 */     this.botaoConfiguracoes = new BotaoDec(this.caminhoFiguras + "Configuracoes.png", 
/*  458 */       this.caminhoFiguras + "ConfiguracoesP.png", 46, 35);
/*  459 */     this.botaoConfiguracoes.setRolloverIcon(new ImageIcon(this.caminhoFiguras + 
/*  460 */       "ConfiguracoesR.png"));
/*  461 */     this.botaoConfiguracoes.setFocusPainted(false);
/*  462 */     this.botaoConfiguracoes.addActionListener(this.trataEventos);
/*  463 */     this.painelSuperior.getPainelBotoes().add(this.botaoConfiguracoes);
/*  464 */     this.botaoComandos = new BotaoDec(this.caminhoFiguras + "Comandos.png", 
/*  465 */       this.caminhoFiguras + "ComandosP.png", 46, 35);
/*  466 */     this.botaoComandos.setRolloverIcon(new ImageIcon(this.caminhoFiguras + 
/*  467 */       "ComandosR.png"));
/*  468 */     this.botaoComandos.setFocusPainted(false);
/*  469 */     this.botaoComandos.addActionListener(this.trataEventos);
/*  470 */     this.painelSuperior.getPainelBotoes().add(this.botaoComandos);
/*  471 */     this.botaoHistorico = new BotaoDec(this.caminhoFiguras + "Historico.png", 
/*  472 */       this.caminhoFiguras + "HistoricoP.png", 46, 35);
/*  473 */     this.botaoHistorico.setRolloverIcon(new ImageIcon(this.caminhoFiguras + 
/*  474 */       "HistoricoR.png"));
/*  475 */     this.botaoHistorico.setFocusPainted(false);
/*  476 */     this.botaoHistorico.addActionListener(this.trataEventos);
/*  477 */     this.painelSuperior.getPainelBotoes().add(this.botaoHistorico);
/*  478 */     this.botaoSobre = new BotaoDec(this.caminhoFiguras + "Sobre.png", this.caminhoFiguras + 
/*  479 */       "SobreP.png", 46, 35);
/*  480 */     this.botaoSobre
/*  481 */       .setRolloverIcon(new ImageIcon(this.caminhoFiguras + "SobreR.png"));
/*  482 */     this.botaoSobre.setFocusPainted(false);
/*  483 */     this.botaoSobre.addActionListener(this.trataEventos);
/*  484 */     this.painelSuperior.getPainelBotoes().add(this.botaoSobre);
/*      */     
/*      */ 
/*  487 */     this.rotuloMonitor = new JLabel(ResourceBundle.getBundle(Idioma.getIdioma())
/*  488 */       .getString("MONITOR"));
/*  489 */     this.rotuloMonitor.setForeground(Color.BLACK);
/*  490 */     this.rotuloMonitor.setHorizontalAlignment(0);
/*  491 */     this.rotuloMonitor.setFont(new Font("Trebuchet MS", 1, 9));
/*  492 */     this.painelSuperior.getPainelRotulos().add(this.rotuloMonitor);
/*  493 */     this.rotuloGrafico = new JLabel(ResourceBundle.getBundle(Idioma.getIdioma())
/*  494 */       .getString("GRAFICO"));
/*  495 */     this.rotuloGrafico.setForeground(Color.BLACK);
/*  496 */     this.rotuloGrafico.setHorizontalAlignment(0);
/*  497 */     this.rotuloGrafico.setFont(new Font("Trebuchet MS", 1, 9));
/*  498 */     this.painelSuperior.getPainelRotulos().add(this.rotuloGrafico);
/*  499 */     this.rotuloConfiguracoes = new JLabel(ResourceBundle.getBundle(
/*  500 */       Idioma.getIdioma()).getString("CONFIGURACOES"));
/*  501 */     this.rotuloConfiguracoes.setForeground(Color.BLACK);
/*  502 */     this.rotuloConfiguracoes.setHorizontalAlignment(0);
/*  503 */     this.rotuloConfiguracoes.setFont(new Font("Trebuchet MS", 1, 9));
/*  504 */     this.painelSuperior.getPainelRotulos().add(this.rotuloConfiguracoes);
/*  505 */     this.rotuloComandos = new JLabel(
/*  506 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString("COMANDOS"));
/*  507 */     this.rotuloComandos.setForeground(Color.BLACK);
/*  508 */     this.rotuloComandos.setHorizontalAlignment(0);
/*  509 */     this.rotuloComandos.setFont(new Font("Trebuchet MS", 1, 9));
/*  510 */     this.painelSuperior.getPainelRotulos().add(this.rotuloComandos);
/*  511 */     this.rotuloHistorico = new JLabel(ResourceBundle.getBundle(
/*  512 */       Idioma.getIdioma()).getString("HISTORICO"));
/*  513 */     this.rotuloHistorico.setForeground(Color.BLACK);
/*  514 */     this.rotuloHistorico.setHorizontalAlignment(0);
/*  515 */     this.rotuloHistorico.setFont(new Font("Trebuchet MS", 1, 9));
/*  516 */     this.painelSuperior.getPainelRotulos().add(this.rotuloHistorico);
/*  517 */     this.rotuloSobre = new JLabel(ResourceBundle.getBundle(Idioma.getIdioma())
/*  518 */       .getString("SOBRE"));
/*  519 */     this.rotuloSobre.setForeground(Color.BLACK);
/*  520 */     this.rotuloSobre.setHorizontalAlignment(0);
/*  521 */     this.rotuloSobre.setFont(new Font("Trebuchet MS", 1, 9));
/*  522 */     this.painelSuperior.getPainelRotulos().add(this.rotuloSobre);
/*  523 */     this.painelFundo.add(this.painelSuperior, "North");
/*      */     
/*      */ 
/*  526 */     this.painelStatusAlertas = new JPanel(new FlowLayout(3, 0, 
/*  527 */       0));
/*  528 */     this.painelStatusAlertas.setPreferredSize(new Dimension(145, 355));
/*  529 */     this.painelStatusAlertas.setOpaque(false);
/*      */     
/*      */ 
/*  532 */     this.painelStatus = new PainelBarrado(this.caminhoFiguras + "Painel_barrado.png", 
/*  533 */       this.caminhoFiguras, 0, 0, ResourceBundle.getBundle(
/*  534 */       Idioma.getIdioma()).getString("STATUS"));
/*  535 */     this.painelStatus.setPreferredSize(new Dimension(125, 171));
/*  536 */     this.painelStatus.getRotuloTitulo().setFont(
/*  537 */       new Font("SansSerif", 1, 11));
/*  538 */     this.painelStatus.getRotuloTitulo().setForeground(Color.BLACK);
/*  539 */     this.painelStatus.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  540 */       .getString("CARREGANDO"));
/*  541 */     this.painelStatus.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  542 */       .getString("USANDO_BATERIA"));
/*  543 */     this.painelStatus.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  544 */       .getString("REDE_LIGADA"));
/*  545 */     this.painelStatus.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  546 */       .getString("SAIDA_LIGADA"));
/*  547 */     this.painelStatus.setFonteIndicadores(new Font("SansSerif", 1, 9));
/*  548 */     this.painelStatus.setCorIndicadores(Color.BLACK);
/*  549 */     this.painelStatus.setOpaque(false);
/*  550 */     this.painelStatusAlertas.add(this.painelStatus);
/*      */     
/*      */ 
/*  553 */     JPanel preenche1 = new JPanel();
/*  554 */     preenche1.setPreferredSize(new Dimension(140, 13));
/*  555 */     preenche1.setOpaque(false);
/*  556 */     this.painelStatusAlertas.add(preenche1);
/*      */     
/*      */ 
/*  559 */     this.painelAlertas = new PainelBarrado(
/*  560 */       this.caminhoFiguras + "Painel_barrado.png", this.caminhoFiguras, 0, 0, 
/*  561 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  562 */       "ALERTAS"));
/*  563 */     this.painelAlertas.setPreferredSize(new Dimension(125, 171));
/*  564 */     this.painelAlertas.getRotuloTitulo().setFont(
/*  565 */       new Font("SansSerif", 1, 11));
/*  566 */     this.painelAlertas.getRotuloTitulo().setForeground(Color.BLACK);
/*  567 */     this.painelAlertas.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  568 */       .getString("SUPER_AQUECIMENTO"));
/*  569 */     this.painelAlertas.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  570 */       .getString("BATERIA_BAIXA"));
/*  571 */     this.painelAlertas.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  572 */       .getString("SOBRECARGA"));
/*  573 */     this.painelAlertas.addIndicador(ResourceBundle.getBundle(Idioma.getIdioma())
/*  574 */       .getString("ATIVA_BYPASS"));
/*  575 */     this.painelAlertas.setFonteIndicadores(new Font("SansSerif", 1, 9));
/*  576 */     this.painelAlertas.setCorIndicadores(Color.BLACK);
/*  577 */     this.painelAlertas.setOpaque(false);
/*  578 */     this.painelStatusAlertas.add(this.painelAlertas);
/*      */     
/*  580 */     this.painelFundo.add(this.painelStatusAlertas, "East");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  592 */     this.painelFuncional = new PainelCentral(this.caminhoFiguras, this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  601 */     this.painelFuncional.setPreferredSize(new Dimension(515, 355));
/*  602 */     this.painelFuncional.setOpaque(false);
/*  603 */     this.painelFundo.add(this.painelFuncional, "Center");
/*      */     
/*      */ 
/*      */ 
/*  607 */     this.painelMonitoramento = new PainelMonitorCentral(this.caminhoFiguras);
/*  608 */     this.painelFuncional.getPainelCentral().add(this.painelMonitoramento, 
/*  609 */       "PainelMonitor");
/*      */     
/*      */ 
/*  612 */     this.painelComandos = new PainelComando(this.caminhoFiguras, this);
/*  613 */     this.painelComandos.getBtnAgendar().addActionListener(this.trataEventos);
/*  614 */     this.painelComandos.getBtnAgendar2().addActionListener(this.trataEventos);
/*  615 */     this.painelComandos.getBtnShutdown().addActionListener(this.trataEventos);
/*  616 */     this.painelComandos.getBtnShutdownReligamento().addActionListener(
/*  617 */       this.trataEventos);
/*  618 */     this.painelComandos.getTextFieldAutonomia().addActionListener(this.trataEventos);
/*  619 */     this.painelComandos.getTextFieldTempoFalha().addActionListener(this.trataEventos);
/*  620 */     this.painelFuncional.getPainelCentral()
/*  621 */       .add(this.painelComandos, "PainelComandos");
/*      */     
/*      */ 
/*      */ 
/*  625 */     this.painelConfig = new PainelConfig(this.caminhoFiguras, this);
/*      */     
/*  627 */     JComboBox serialComboBox = this.painelConfig.getPainelUPS()
/*  628 */       .getComboBoxSerial();
/*      */     
/*  630 */     for (int i = 0; i < portasSeriais.length; i++)
/*  631 */       serialComboBox.addItem(portasSeriais[i]);
/*  632 */     this.painelConfig.getPainelUPS().setFlag(false);
/*      */     
/*  634 */     this.painelConfig.getPainelConfigGeral().getBtnOk().addActionListener(
/*  635 */       this.trataEventos);
/*  636 */     this.painelConfig.getPainelConfigGeral().getComboBoxIdioma()
/*  637 */       .addActionListener(this.trataEventos);
/*  638 */     this.painelConfig.getPainelConfigGeral().getBtnProcura().addActionListener(
/*  639 */       this.trataEventos);
/*  640 */     this.painelConfig.getPbc().getBtnGeral().addActionListener(this.trataEventos);
/*  641 */     this.painelConfig.getPbc().getBtnSNMP().addActionListener(this.trataEventos);
/*  642 */     this.painelConfig.getPbc().getBtnGeral().addActionListener(this.trataEventos);
/*  643 */     this.painelConfig.getPbc().getBtnUPS().addActionListener(this.trataEventos);
/*  644 */     this.painelConfig.getPainelUPS().getBtnOk().addActionListener(this.trataEventos);
/*  645 */     this.painelConfig.getPainelMensg().getBtnOk()
/*  646 */       .addActionListener(this.trataEventos);
/*  647 */     this.painelConfig.getPainelSMTP().getBtnOk().addActionListener(this.trataEventos);
/*  648 */     this.painelConfig.getPainelSMTP().getBtnCancel().addActionListener(
/*  649 */       this.trataEventos);
/*  650 */     this.painelConfig.getPainelSNMP().getBtnOk().addActionListener(this.trataEventos);
/*  651 */     this.painelConfig.getPainelSNMP().getBtnCancel().addActionListener(
/*  652 */       this.trataEventos);
/*  653 */     this.painelConfig.getPainelSNMP().getTfPedidos().addCaretListener(
/*  654 */       this.trataEventos);
/*      */     
/*      */ 
/*  657 */     this.painelConfig.getPainelAutoTeste().getBtnOk().addActionListener(this.trataEventos);
/*  658 */     this.painelConfig.getPainelAutoTeste().getBtnCancel().addActionListener(this.trataEventos);
/*      */     
/*  660 */     this.painelFuncional.getPainelCentral().add(this.painelConfig, "PainelConfig");
/*      */     
/*      */ 
/*  663 */     this.painelHistorico = new PainelHistorico(this.caminhoFiguras, this, controle
/*  664 */       .getArrayEventos());
/*  665 */     this.painelFuncional.getPainelCentral().add(this.painelHistorico, 
/*  666 */       "PainelHistorico");
/*  667 */     this.painelHistorico.getBtnLimparSelecao().addActionListener(this.trataEventos);
/*  668 */     this.painelHistorico.getBtnLimparTudo().addActionListener(this.trataEventos);
/*      */     
/*  670 */     this.painelGraficos = new PainelGraficos(this.caminhoFiguras, this);
/*  671 */     this.painelFuncional.getPainelCentral()
/*  672 */       .add(this.painelGraficos, "PainelGraficos");
/*      */     
/*      */ 
/*  675 */     this.painelSobre = new PainelSobre(this.caminhoFiguras, controle.getVersaoSoftware());
/*  676 */     this.painelFuncional.getPainelCentral().add(this.painelSobre, "PainelSobre");
/*      */     
/*      */ 
/*  679 */     JPanel preenche2 = new JPanel();
/*  680 */     preenche2.setPreferredSize(new Dimension(20, 515));
/*  681 */     preenche2.setOpaque(false);
/*  682 */     this.painelFundo.add(preenche2, "West");
/*      */     
/*  684 */     getContentPane().add(this.painelFundo);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  690 */     if (SystemTray.isSupported()) {
/*  691 */       this.systemTray = SystemTray.getSystemTray();
/*  692 */       this.iconeTray = new TrayIcon(new ImageIcon(this.caminhoFiguras + 
/*  693 */         "IconeSGMTray.png").getImage(), "SGM Lite");
/*  694 */       this.iconeTray.addMouseListener(this.trataEventos);
/*  695 */       this.iconeTray.setImageAutoSize(true);
/*      */       try {
/*  697 */         this.systemTray.add(this.iconeTray);
/*      */       } catch (AWTException awte) {
/*  699 */         System.err.println(awte);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  708 */     setUndecorated(true);
/*  709 */     setSize(700, 450);
/*      */     
/*      */ 
/*  712 */     setLocationRelativeTo(null);
/*  713 */     setVisible(true);
/*  714 */     this.xPop = (this.painelSuperior.getPosJanX() + 180);
/*  715 */     this.yPop = (this.painelSuperior.getPosJanY() + 150);
/*  716 */     Point p = getLocationOnScreen();
/*  717 */     this.painelSuperior.setPosJanX(new Double(p.getX()).shortValue());
/*  718 */     this.painelSuperior.setPosJanY(new Double(p.getY()).shortValue());
/*      */     
/*  720 */     if (controle.isPrimeiraExecucao())
/*      */     {
/*      */ 
/*  723 */       CardLayout card = (CardLayout)getPainelCentral().getLayout();
/*  724 */       card.show(getPainelCentral(), "PainelConfig");
/*  725 */       getPainelConfig();card = (CardLayout)PainelConfig.getPanelSlave().getLayout();
/*  726 */       getPainelConfig();card.show(PainelConfig.getPanelSlave(), "painelUPS");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  731 */     this.formatador = new DecimalFormat("00");
/*  732 */     validarIdioma();
/*  733 */     this.painelFuncional.mudaPrompt(2, 2);
/*  734 */     limpaGUI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lePersistencia()
/*      */   {
/*  746 */     if (this.controle.getPersistencia().isPrimeiraExec()) {
/*  747 */       this.controle.salvaPersistenciaSNMP(161, "public", "private", 
/*  748 */         "127.0.0.1", 162, 0, 0);
/*  749 */       this.controle.salvaNomeUPS("vazio");
/*  750 */       this.controle.salvaMensagens(this.painelConfig.getPainelMensg()
/*  751 */         .getCheckBoxSelected());
/*  752 */       this.painelConfig.getPainelSMTP().getTfPorta().setText("587");
/*      */     }
/*      */     else {
/*  755 */       this.painelConfig.getPainelConfigGeral().getComboBoxIdioma().setSelectedItem(this.controle.getIdiomaPersistencia());
/*      */       
/*  757 */       validarAllIdioma();
/*      */       
/*  759 */       this.painelConfig.getPainelConfigGeral().getComboBoxEvento()
/*  760 */         .setSelectedIndex(this.controle.getEventoPersistencia());
/*      */       
/*  762 */       this.painelConfig.getPainelConfigGeral().getCbVarLogging()
/*  763 */         .setSelected(this.controle.getModoLoggingPersitencia());
/*      */       
/*  765 */       this.painelConfig.getPainelConfigGeral().getTfScript().setText(
/*  766 */         this.controle.getScript());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  779 */       boolean[][] temp = this.controle.getMensagensPersistencia();
/*  780 */       this.painelConfig.getPainelMensg().getCbEnergiaEmail().setSelected(
/*  781 */         temp[0][0]);
/*  782 */       this.painelConfig.getPainelMensg().getCbEnergiaPop().setSelected(
/*  783 */         temp[0][1]);
/*  784 */       this.painelConfig.getPainelMensg().getCbBateriaFracaEmail().setSelected(
/*  785 */         temp[1][0]);
/*  786 */       this.painelConfig.getPainelMensg().getCbBateriaFracaPop().setSelected(
/*  787 */         temp[1][1]);
/*  788 */       this.painelConfig.getPainelMensg().getCbSobrecargaEmail().setSelected(
/*  789 */         temp[2][0]);
/*  790 */       this.painelConfig.getPainelMensg().getCbSobrecargaPop().setSelected(
/*  791 */         temp[2][1]);
/*  792 */       this.painelConfig.getPainelMensg().getCbAquecimentoEmail().setSelected(
/*  793 */         temp[3][0]);
/*  794 */       this.painelConfig.getPainelMensg().getCbAquecimentoPop().setSelected(
/*  795 */         temp[3][1]);
/*  796 */       this.painelConfig.getPainelMensg().getCbBateriaUsoEmail().setSelected(
/*  797 */         temp[4][0]);
/*  798 */       this.painelConfig.getPainelMensg().getCbBateriaUsoPop().setSelected(
/*  799 */         temp[4][1]);
/*  800 */       this.painelConfig.getPainelMensg().getCbComunicaEmail().setSelected(
/*  801 */         temp[5][0]);
/*      */       
/*  803 */       setMensagens();
/*      */       
/*  805 */       this.painelConfig.getPainelUPS().getComboBoxSerial().setSelectedItem(this.controle.getPortaSerial());
/*      */       
/*  807 */       int n = this.controle.getFamiliaUPSPersistencia();
/*  808 */       switch (n)
/*      */       {
/*      */       case 1: 
/*  811 */         this.painelConfig.getPainelUPS().getRadioSolis().setSelected(true);
/*  812 */         break;
/*      */       case 2: 
/*  814 */         this.painelConfig.getPainelUPS().getRadioRhino().setSelected(true);
/*  815 */         break;
/*      */       case 3: 
/*  817 */         this.painelConfig.getPainelUPS().getRadioStay().setSelected(true);
/*      */       }
/*      */       
/*      */       
/*  821 */       this.painelConfig.getPainelUPS().getTextFieldExpanBat().setText(
/*  822 */         Integer.toString(this.controle
/*  823 */         .getExpansorBateriaPersistencia()));
/*      */       
/*  825 */       if (this.controle.getNomeUPSPersistencia().equals("vazio")) {
/*  826 */         this.painelConfig.getPainelUPS().getNomeUPS().setText("");
/*      */       } else {
/*  828 */         this.painelConfig.getPainelUPS().getNomeUPS().setText(
/*  829 */           this.controle.getNomeUPSPersistencia());
/*      */       }
/*  831 */       this.painelConfig.getPainelSMTP().getTfEndServidor().setText(
/*  832 */         this.controle.getEnderecoSMTPPersistencia());
/*      */       
/*  834 */       this.painelConfig.getPainelSMTP().getCbAutenticacao().setSelected(
/*  835 */         this.controle.getFlagAutenticacoPersistencia());
/*      */       
/*  837 */       this.painelConfig.getPainelSMTP().cbAutenticacaoSelected(
/*  838 */         this.controle.getFlagAutenticacoPersistencia());
/*      */       
/*      */ 
/*  841 */       this.painelConfig.getPainelSMTP().getTfUsuario().setText(
/*  842 */         this.controle.getUsuarioPersistencia());
/*      */       
/*  844 */       this.painelConfig.getPainelSMTP().getPfSenha().setText(
/*  845 */         this.controle.getSenhaPersistencia());
/*      */       
/*  847 */       this.painelConfig.getPainelSMTP().getTfRemetente().setText(
/*  848 */         this.controle.getRemetentePersistencia());
/*      */       
/*  850 */       String[] tempDest = this.controle.getDestinatariosPersistencia();
/*  851 */       String tempDest2 = "";
/*  852 */       for (int i = 0; i < tempDest.length; i++)
/*  853 */         tempDest2 = tempDest2 + tempDest[i] + ", ";
/*  854 */       this.painelConfig.getPainelSMTP().getTfDestinatario().setText(tempDest2);
/*      */       
/*      */ 
/*  857 */       if (this.painelConfig.getPainelSMTP().getTfDestinatario().getText().equals(", ")) {
/*  858 */         this.painelConfig.getPainelSMTP().getTfDestinatario().setText("");
/*      */       }
/*  860 */       this.painelConfig.getPainelSMTP().getTfPorta().setText(
/*  861 */         Integer.toString(this.controle.getPortaSMTPPersistencia()));
/*      */       
/*      */ 
/*  864 */       if (!this.controle.getProvedorEscolhidoPersitencia().equals("")) {
/*  865 */         this.painelConfig.getPainelSMTP().setProvedor(this.controle.getProvedorEscolhidoPersitencia());
/*  866 */         this.painelConfig.getPainelSMTP().getCmbProvedores().setSelectedItem(this.controle.getProvedorEscolhidoPersitencia());
/*      */       } else {
/*  868 */         this.painelConfig.getPainelSMTP().setProvedor("");
/*      */       }
/*      */       
/*  871 */       this.painelConfig.getPainelSNMP().getTfPedidos().setText(
/*  872 */         Integer.toString(this.controle.getPortaPedidos()));
/*      */       
/*  874 */       this.painelConfig.getPainelSNMP().getTfLeitura().setText(
/*  875 */         this.controle.getComunidadeLeitura());
/*      */       
/*  877 */       this.painelConfig.getPainelSNMP().getTfEscrita().setText(
/*  878 */         this.controle.getComunidadeEscrita());
/*      */       
/*  880 */       this.painelConfig.getPainelSNMP().getTfGerente().setText(
/*  881 */         this.controle.getEnderecoGerente());
/*      */       
/*  883 */       this.painelConfig.getPainelSNMP().getTfEnvio().setText(
/*  884 */         Integer.toString(this.controle.getPortaEnvio()));
/*      */       
/*  886 */       this.painelConfig.getPainelSNMP().getCbSNMP().setSelectedIndex(
/*  887 */         this.controle.getVSNMP());
/*      */       
/*  889 */       this.painelConfig.getPainelSNMP().getCbTransporte().setSelectedIndex(
/*  890 */         this.controle.getProtocoloTransportePersistencia());
/*      */       
/*  892 */       this.painelComandos.getTextFieldAutonomia().setText(
/*  893 */         Integer.toString(this.controle.getAutonomiaMinimaPersistencia()));
/*      */       
/*  895 */       this.painelComandos.getCbAutonomia().setSelected(
/*  896 */         this.controle.getFlagShutFimAut());
/*      */       
/*  898 */       this.painelComandos.getTextFieldTempoFalha().setText(
/*  899 */         Integer.toString(this.controle.getTempoFalhaEletrica()));
/*      */       
/*  901 */       this.painelComandos.getCbTempoFalha().setSelected(
/*  902 */         this.controle.getFlagShutFalhaEletrica());
/*      */       
/*  904 */       if (this.painelComandos.getCbAutonomia().isSelected())
/*      */       {
/*  906 */         this.controle.setFlagShutFimAut(true);
/*  907 */         this.controle.setAutonomiaMinima(this.painelComandos
/*  908 */           .getTempoAutonomia());
/*      */       }
/*      */       
/*  911 */       if (this.painelComandos.getCbTempoFalha().isSelected())
/*      */       {
/*  913 */         this.controle.setTempoFalha(this.painelComandos.getTempoFalha());
/*  914 */         this.controle.setShutdownTempoFalha(true);
/*      */       }
/*      */       
/*      */ 
/*  918 */       this.painelConfig.getPainelConfigGeral().getTfPortaShutdownRemoto().setText(Integer.toString(this.controle.getPortaRemota()));
/*      */       
/*  920 */       this.painelConfig.getPainelConfigGeral().getCbShutdownRemoto()
/*  921 */         .setSelected(this.controle.getModoRemoto());
/*      */       
/*      */ 
/*  924 */       this.painelConfig.getPainelAutoTeste().setAutoTesteHabilitado(this.controle.getAutoTesteEnabledPersitencia());
/*  925 */       this.painelConfig.getPainelAutoTeste().setHoraTeste(this.controle.getHoraTestePersistencia());
/*  926 */       this.painelConfig.getPainelAutoTeste().setMinutoTeste(this.controle.getMinutoTestePersistencia());
/*  927 */       this.painelConfig.getPainelAutoTeste().setPeriodoAutoTeste(this.controle.getPeriodoTestePersistencia());
/*      */       
/*      */ 
/*  930 */       this.painelGraficos.setValorKW(this.controle.getValorKw());
/*      */       
/*      */ 
/*  933 */       this.painelComandos.setFlag(false);
/*  934 */       this.painelConfig.getPainelConfigGeral().setFlag(false);
/*  935 */       this.painelConfig.getPainelMensg().setFlag(false);
/*  936 */       this.painelConfig.getPainelSMTP().setFlag(false);
/*  937 */       this.painelConfig.getPainelSNMP().setFlag(false);
/*  938 */       this.painelConfig.getPainelUPS().setFlag(false);
/*  939 */       this.painelConfig.getPainelAutoTeste().setFlag(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void validarAllIdioma()
/*      */   {
/*  949 */     if (this.painelConfig.getPainelConfigGeral().getComboBoxIdioma().getSelectedItem().equals("ENGLISH")) {
/*  950 */       Idioma.setIdiomaIngles();
/*      */     } else {
/*  952 */       Idioma.setIdiomaPortugues();
/*      */     }
/*      */     
/*  955 */     int j = this.painelConfig.getPainelConfigGeral().getComboBoxEvento()
/*  956 */       .getSelectedIndex();
/*  957 */     setEventos(this.controle.getTipoEventos());
/*  958 */     this.painelConfig.getPainelConfigGeral().validarIdioma();
/*  959 */     this.painelConfig.getPbc().validarIdioma();
/*  960 */     this.painelConfig.getPainelMensg().validarIdioma();
/*  961 */     this.painelConfig.getPainelUPS().validarIdioma();
/*  962 */     this.painelConfig.getPainelSMTP().validarIdioma();
/*  963 */     this.painelConfig.getPainelSNMP().validarIdioma();
/*  964 */     this.painelConfig.getPainelAutoTeste().validarIdioma();
/*  965 */     this.painelComandos.validarIdioma();
/*  966 */     this.painelHistorico.validarIdioma();
/*  967 */     this.painelMonitoramento.painelPotencia.validarIdioma();
/*  968 */     this.painelMonitoramento.painelTemperatura.validarIdioma();
/*  969 */     this.painelMonitoramento.painelEntrada.validarIdioma();
/*  970 */     this.painelMonitoramento.painelBateria.validarIdioma();
/*  971 */     this.painelMonitoramento.painelSaida.validarIdioma();
/*  972 */     this.painelFuncional.validarIdioma();
/*  973 */     this.painelFuncional.mudaPrompt(2, 2);
/*  974 */     this.painelGraficos.validarIdioma();
/*  975 */     this.painelSobre.validarIdioma();
/*  976 */     validarIdioma();
/*  977 */     this.painelConfig.getPainelConfigGeral().getComboBoxEvento()
/*  978 */       .setSelectedIndex(j);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void validarIdioma()
/*      */   {
/*  985 */     this.rotuloSobre.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  986 */       .getString("SOBRE") + 
/*  987 */       "      ");
/*  988 */     this.rotuloHistorico.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  989 */       .getString("HISTORICO") + 
/*  990 */       "    ");
/*  991 */     this.rotuloComandos.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  992 */       .getString("COMANDOS"));
/*  993 */     this.rotuloConfiguracoes.setText(
/*  994 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString("CONFIGURACOES"));
/*  995 */     this.rotuloMonitor.setText("      " + 
/*  996 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  997 */       "MONITOR"));
/*  998 */     this.rotuloGrafico.setText("   " + 
/*  999 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1000 */       "GRAFICO"));
/*      */     
/* 1002 */     this.painelStatus.getRotuloTitulo().setText(
/* 1003 */       ResourceBundle.getBundle(Idioma.getIdioma())
/* 1004 */       .getString("STATUS"));
/* 1005 */     this.painelAlertas.getRotuloTitulo().setText(
/* 1006 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1007 */       "ALERTAS"));
/* 1008 */     this.painelStatus.getIndicador(0).setText(
/* 1009 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1010 */       "CARREGANDO"));
/* 1011 */     this.painelStatus.getIndicador(1).setText(
/* 1012 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1013 */       "USANDO_BATERIA"));
/* 1014 */     this.painelStatus.getIndicador(2).setText(
/* 1015 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1016 */       "REDE_LIGADA"));
/* 1017 */     this.painelStatus.getIndicador(3).setText(
/* 1018 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1019 */       "SAIDA_LIGADA"));
/*      */     
/* 1021 */     this.painelAlertas.getIndicador(0).setText(
/* 1022 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1023 */       "SUPER_AQUECIMENTO"));
/* 1024 */     this.painelAlertas.getIndicador(1).setText(
/* 1025 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1026 */       "BATERIA_BAIXA"));
/* 1027 */     this.painelAlertas.getIndicador(2).setText(
/* 1028 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1029 */       "SOBRECARGA"));
/* 1030 */     this.painelAlertas.getIndicador(3).setText(
/* 1031 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1032 */       "ATIVA_BYPASS"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void encerraAplicativo()
/*      */   {
/* 1042 */     if (this.painelConfig.getPainelConfigGeral().getComboBoxEvento()
/* 1043 */       .getSelectedIndex() == 17) {
/* 1044 */       if (this.controle.isFlagShutdown()) {
/* 1045 */         Evento evt = new Evento("SHUTDOWN", this.calendar.get(10), 
/* 1046 */           this.calendar.get(12), this.calendar
/* 1047 */           .get(13), this.calendar
/* 1048 */           .get(5), this.calendar
/* 1049 */           .get(2), this.calendar.get(1));
/* 1050 */         Evento[] evts = new Evento[1];
/* 1051 */         evts[0] = evt;
/* 1052 */         this.controle.verificaArquivoLote(evts);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1059 */     String[] tempDest = this.painelConfig.getPainelSMTP().getTfDestinatario()
/* 1060 */       .getText().split(", ");
/* 1061 */     this.controle.encerraAplicativo(this.painelConfig
/* 1062 */       .getPainelConfigGeral().getComboBoxIdioma().getSelectedItem(), 
/* 1063 */       this.painelConfig.getPainelConfigGeral().getComboBoxEvento()
/* 1064 */       .getSelectedIndex(), this.painelConfig
/* 1065 */       .getPainelConfigGeral().getTfScript().getText(), 
/* 1066 */       this.painelConfig.getPainelMensg().getCheckBoxSelected(), 
/* 1067 */       this.painelConfig.getPainelUPS().getExpansorBateria(), this.painelConfig
/* 1068 */       .getPainelUPS().getNomeUPS().getText(), this.painelConfig
/* 1069 */       .getPainelSMTP().getTfEndServidor().getText(), 
/* 1070 */       this.painelConfig.getPainelSMTP().getCbAutenticacao().isSelected(), 
/* 1071 */       this.painelConfig.getPainelSMTP().getTfUsuario().getText(), 
/* 1072 */       this.painelConfig.getPainelSMTP().getPfSenha().getText(), 
/* 1073 */       this.painelConfig.getPainelSMTP().getTfRemetente().getText(), 
/* 1074 */       tempDest, this.painelConfig.getPainelSMTP().getPorta(), 
/* 1075 */       Integer.parseInt(this.painelConfig.getPainelSNMP().getTfPedidos()
/* 1076 */       .getText()), this.painelConfig.getPainelSNMP()
/* 1077 */       .getTfLeitura().getText(), this.painelConfig.getPainelSNMP()
/* 1078 */       .getTfEscrita().getText(), this.painelConfig.getPainelSNMP()
/* 1079 */       .getTfGerente().getText(), 
/* 1080 */       Integer.parseInt(this.painelConfig.getPainelSNMP().getTfEnvio()
/* 1081 */       .getText()), this.painelConfig.getPainelSNMP()
/* 1082 */       .getCbSNMP().getSelectedIndex(), this.painelConfig
/* 1083 */       .getPainelSNMP().getCbTransporte().getSelectedIndex(), 
/* 1084 */       this.painelComandos.getTempoAutonomia(), this.painelComandos
/* 1085 */       .getTempoFalha(), this.painelConfig.getPainelConfigGeral()
/* 1086 */       .getPorta(), this.painelConfig.getPainelConfigGeral()
/* 1087 */       .getCbShutdownRemoto().isSelected(), 
/* 1088 */       Double.parseDouble(this.painelGraficos.getValorKW()), 
/* 1089 */       this.painelComandos.getCbAutonomia().isSelected(), 
/* 1090 */       this.painelComandos.getCbTempoFalha().isSelected(), this.painelConfig.getPainelSMTP().getProvedor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void eventoOcorreu(Evento[] evento)
/*      */   {
/* 1099 */     if (evento != null) {
/* 1100 */       this.painelHistorico.inserirRegistros(evento, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaDados()
/*      */   {
/* 1110 */     if (!this.comunicou) {
/* 1111 */       this.comunicou = true;
/*      */     }
/* 1113 */     if (this.controle.isFlagShutdown()) {
/* 1114 */       encerraAplicativo();
/*      */     }
/* 1116 */     eventoOcorreu(this.controle.getEventos());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1121 */     this.painelGraficos.getGraficoCorrente().addValue(
/* 1122 */       this.controle.getCorrenteEntrada(), this.controle.getCorrenteSaida());
/* 1123 */     this.painelGraficos.getGraficoTensao().addValue(this.controle.getTensaoEntrada(), 
/* 1124 */       this.controle.getTensaoSaida());
/*      */     
/* 1126 */     this.painelGraficos.getGraficoPotencia().addValue(
/* 1127 */       this.controle.getPotenciaReal(), this.controle.getPotenciaAparente());
/* 1128 */     this.painelGraficos.getGraficoBateria()
/* 1129 */       .addValue(this.controle.getTensaoBateria());
/*      */     
/*      */ 
/*      */ 
/* 1133 */     this.painelMonitoramento.painelEntrada.setEntrada(
/* 1134 */       (int)this.controle.getTensaoEntradaNominal());
/*      */     
/*      */ 
/* 1137 */     float f1 = this.controle.getTensaoEntrada() - this.controle.getLimiteInferiorTensaoEntrada();
/* 1138 */     float f2 = this.controle.getLimiteSuperiorTensaoEntrada() - this.controle.getLimiteInferiorTensaoEntrada();
/*      */     
/* 1140 */     this.painelMonitoramento.painelEntrada.panelBarraTensao.setCont(
/* 1141 */       Math.round(20.0F * (f1 / f2)), 
/* 1142 */       this.controle.getTensaoEntrada());
/*      */     
/* 1144 */     this.painelMonitoramento.painelEntrada.setCorrente(this.controle
/* 1145 */       .getCorrenteEntrada());
/* 1146 */     this.painelMonitoramento.painelEntrada.setFrequencia(this.controle
/* 1147 */       .getFrequenciaEntrada());
/* 1148 */     this.painelMonitoramento.painelEntrada.setBarraLimSuperior(this.controle
/* 1149 */       .getLimiteSuperiorTensaoEntrada());
/* 1150 */     this.painelMonitoramento.painelEntrada.setBarraLimInferior(this.controle
/* 1151 */       .getLimiteInferiorTensaoEntrada());
/*      */     
/*      */ 
/*      */ 
/* 1155 */     this.painelMonitoramento.painelSaida.setSaida((int)this.controle.getTensaoSaidaNominal());
/*      */     
/*      */ 
/* 1158 */     float f4 = this.controle.getTensaoSaida() - this.controle.getLimiteInferiorTensaoSaida();
/* 1159 */     float f3 = this.controle.getLimiteSuperiorTensaoSaida() - this.controle.getLimiteInferiorTensaoSaida();
/*      */     
/*      */ 
/*      */ 
/* 1163 */     this.painelMonitoramento.painelSaida.panelBarraTensao.setCont(
/* 1164 */       Math.round(20.0F * (f4 / f3)), this.controle.getTensaoSaida());
/*      */     
/* 1166 */     this.painelMonitoramento.painelSaida
/* 1167 */       .setCorrente(this.controle.getCorrenteSaida());
/* 1168 */     this.painelMonitoramento.painelSaida.setFrequencia(this.controle
/* 1169 */       .getFrequenciaSaida());
/* 1170 */     this.painelMonitoramento.painelSaida.setBarraLimSuperior(this.controle
/* 1171 */       .getLimiteSuperiorTensaoSaida());
/* 1172 */     this.painelMonitoramento.painelSaida.setBarraLimInferior(this.controle
/* 1173 */       .getLimiteInferiorTensaoSaida());
/*      */     
/*      */ 
/*      */ 
/* 1177 */     this.painelMonitoramento.painelPotencia.setPotAp(this.controle
/* 1178 */       .getPotenciaAparente());
/* 1179 */     this.painelMonitoramento.painelPotencia.setPotReal(this.controle
/* 1180 */       .getPotenciaReal());
/* 1181 */     this.painelMonitoramento.painelPotencia.setFPot(this.controle
/* 1182 */       .getFatorPotenciaCarga());
/*      */     
/*      */ 
/*      */ 
/* 1186 */     this.painelMonitoramento.painelBateria.panelBarraTensaoBat.setCont(
/* 1187 */       Math.round(this.controle.getPercentualBateria() / 5.0F));
/* 1188 */     this.painelMonitoramento.painelBateria.setAutonomia(this.controle
/* 1189 */       .getAutonomiaBateria());
/* 1190 */     this.painelMonitoramento.painelBateria
/* 1191 */       .setTensao(this.controle.getTensaoBateria());
/*      */     
/*      */ 
/*      */ 
/* 1195 */     this.painelMonitoramento.painelTemperatura.panelBarraTemp.setCont(
/* 1196 */       Math.round(this.controle.getTemperaturaUPS() / 2.0F));
/* 1197 */     this.painelMonitoramento.painelTemperatura.panelBarraTemp.disabled = (!this.controle.isTemperaturaAvaliable());
/*      */     
/*      */ 
/*      */ 
/* 1201 */     this.trataStsAls.setCarregandoBateria(this.controle.isCarregandoBateria());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1206 */     this.trataStsAls.setBateriaEmUso(this.controle.isUsandoSomenteBateria());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1212 */     this.trataStsAls.setModoInversor(this.controle.isSaidaLigada());
/*      */     
/*      */ 
/* 1215 */     this.trataStsAls.setFalhaRede(this.controle.isModoRede());
/*      */     
/*      */ 
/* 1218 */     this.trataStsAls.setBateriaBaixa(this.controle.isBateriaBaixa());
/*      */     
/*      */ 
/* 1221 */     this.trataStsAls.setBateriaCritica(this.controle.isBateriaCritica());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1226 */     this.trataStsAls.setTemperaturaElevada(this.controle.isTemperaturaElevada());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1231 */     this.trataStsAls.setSuperAquecimento(this.controle.isSuperAquecimento());
/*      */     
/*      */ 
/*      */ 
/* 1235 */     this.trataStsAls.setCargaElevada(this.controle.isCargaElevada());
/*      */     
/*      */ 
/* 1238 */     this.trataStsAls.setSobrecarga(this.controle.isSobrecarga());
/*      */     
/* 1240 */     this.trataStsAls.setBypass(this.controle.isModoBypass());
/*      */     
/*      */ 
/* 1243 */     this.trataStsAls.processaStatusAlertas();
/*      */     
/*      */ 
/*      */ 
/* 1247 */     if (this.trataStsAls.getIndicaCarregandoBateria() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1253 */       if (this.trataStsAls.getIndicaCarregandoBateria() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1257 */         this.painelStatus.chaveiaLed(3, 0);
/*      */       }
/*      */       else {
/* 1260 */         this.painelStatus.chaveiaLed(1, 0);
/*      */       }
/*      */     }
/* 1263 */     if (this.trataStsAls.getIndicaBateriaEmUso() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1269 */       if (this.trataStsAls.getIndicaBateriaEmUso() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1273 */         this.painelStatus.chaveiaLed(3, 1);
/*      */       }
/*      */       else {
/* 1276 */         this.painelStatus.chaveiaLed(1, 1);
/*      */       }
/*      */     }
/* 1279 */     if (this.trataStsAls.getIndicaFalhaRede() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1285 */       if (this.trataStsAls.getIndicaFalhaRede() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1289 */         this.painelStatus.chaveiaLed(3, 2);
/*      */       }
/*      */       else {
/* 1292 */         this.painelStatus.chaveiaLed(1, 2);
/*      */       }
/*      */     }
/* 1295 */     if (this.trataStsAls.getIndicaModoInversor() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1301 */       if (this.trataStsAls.getIndicaModoInversor() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1305 */         this.painelStatus.chaveiaLed(3, 3);
/*      */       }
/*      */       else {
/* 1308 */         this.painelStatus.chaveiaLed(1, 3);
/*      */       }
/*      */     }
/* 1311 */     if ((this.trataStsAls.getIndicaTemperaturaElevada() == 1) && 
/* 1312 */       (!this.trataStsAls.getSuperAquecimento()))
/*      */     {
/* 1314 */       if (this.liga) {
/* 1315 */         this.painelAlertas.chaveiaLed(2, 0);
/*      */       }
/*      */       else
/*      */       {
/* 1319 */         this.painelAlertas.chaveiaLed(1, 0);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1324 */     else if (!this.trataStsAls.getSuperAquecimento()) {
/* 1325 */       this.painelAlertas.chaveiaLed(1, 0);
/*      */     }
/* 1327 */     if (this.trataStsAls.getIndicaSuperAquecimento() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1333 */       if (this.trataStsAls.getIndicaSuperAquecimento() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1337 */         this.painelAlertas.chaveiaLed(2, 0);
/*      */       }
/*      */       else
/*      */       {
/* 1341 */         this.painelAlertas.chaveiaLed(1, 0);
/*      */       }
/*      */     }
/* 1344 */     if ((this.trataStsAls.getIndicaBateriaBaixa() == 1) && 
/* 1345 */       (!this.trataStsAls.getBateriaCritica()))
/*      */     {
/* 1347 */       if (this.liga) {
/* 1348 */         this.painelAlertas.chaveiaLed(2, 1);
/*      */       }
/*      */       else
/*      */       {
/* 1352 */         this.painelAlertas.chaveiaLed(1, 1);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1357 */     else if (!this.trataStsAls.getBateriaCritica()) {
/* 1358 */       this.painelAlertas.chaveiaLed(1, 1);
/*      */     }
/* 1360 */     if (this.trataStsAls.getIndicaBateriaCritica() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1366 */       if (this.trataStsAls.getIndicaBateriaCritica() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1370 */         this.painelAlertas.chaveiaLed(2, 1);
/*      */       }
/*      */       else
/*      */       {
/* 1374 */         this.painelAlertas.chaveiaLed(1, 1);
/*      */       }
/*      */     }
/* 1377 */     if ((this.trataStsAls.getIndicaCargaElevada() == 1) && 
/* 1378 */       (!this.trataStsAls.getSobrecarga()))
/*      */     {
/* 1380 */       if (this.liga) {
/* 1381 */         this.painelAlertas.chaveiaLed(2, 2);
/*      */       }
/*      */       else
/*      */       {
/* 1385 */         this.painelAlertas.chaveiaLed(1, 2);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1390 */     else if (!this.trataStsAls.getSobrecarga()) {
/* 1391 */       this.painelAlertas.chaveiaLed(1, 2);
/*      */     }
/* 1393 */     if (this.trataStsAls.getIndicaSobrecarga() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1399 */       if (this.trataStsAls.getIndicaSobrecarga() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1403 */         this.painelAlertas.chaveiaLed(2, 2);
/*      */       }
/*      */       else
/*      */       {
/* 1407 */         this.painelAlertas.chaveiaLed(1, 2);
/*      */       }
/*      */     }
/*      */     
/* 1411 */     if ((this.trataStsAls.getIndicaBypass() == 1) && 
/* 1412 */       (!this.trataStsAls.getBypass()))
/*      */     {
/* 1414 */       if (this.liga) {
/* 1415 */         this.painelAlertas.chaveiaLed(2, 3);
/*      */       }
/*      */       else
/*      */       {
/* 1419 */         this.painelAlertas.chaveiaLed(1, 3);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1424 */     else if (!this.trataStsAls.getBypass()) {
/* 1425 */       this.painelAlertas.chaveiaLed(1, 3);
/*      */     }
/* 1427 */     if (this.trataStsAls.getIndicaBypass() != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1433 */       if (this.trataStsAls.getIndicaBypass() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1437 */         this.painelAlertas.chaveiaLed(2, 3);
/*      */       }
/*      */       else
/*      */       {
/* 1441 */         this.painelAlertas.chaveiaLed(1, 3);
/*      */       }
/*      */     }
/* 1444 */     this.liga = (!this.liga);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaFalhaCom()
/*      */   {
/* 1455 */     Calendar cal = Calendar.getInstance();
/* 1456 */     limpaGUI();
/* 1457 */     String messageKey = "Sem_comunicacao_com_o_UPS__Horario";
/* 1458 */     mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1459 */       .getString(messageKey) + 
/* 1460 */       this.formatador.format(this.controle.getHora()) + 
/* 1461 */       ":" + 
/* 1462 */       this.formatador.format(this.controle.getMinutos()), true);
/*      */     
/* 1464 */     Evento evt = new Evento("FALHA_NA_COMUNICACAO", cal
/* 1465 */       .get(11), cal.get(12), cal
/* 1466 */       .get(13), cal.get(5), 
/* 1467 */       cal.get(2) + 1, cal.get(1));
/* 1468 */     Evento[] evts = { evt };
/* 1469 */     this.controle.salvaEventos(evts);
/*      */     
/* 1471 */     this.controle.putEventos(evts);
/* 1472 */     eventoOcorreu(evts);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaRetornoCom()
/*      */   {
/* 1481 */     Calendar cal = Calendar.getInstance();
/* 1482 */     String messageKey = "Retorno_da_comunicacao_com_UPS__Horario";
/* 1483 */     mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1484 */       .getString(messageKey) + 
/* 1485 */       this.formatador.format(this.controle.getHora()) + 
/* 1486 */       ":" + 
/* 1487 */       this.formatador.format(this.controle.getMinutos()), false);
/*      */     
/* 1489 */     Evento evt = new Evento("RETORNO_DE_COMUNICACAO", cal
/* 1490 */       .get(11), cal.get(12), cal
/* 1491 */       .get(13), cal.get(5), 
/* 1492 */       cal.get(2) + 1, cal.get(1));
/* 1493 */     Evento[] evts = { evt };
/* 1494 */     this.controle.salvaEventos(evts);
/*      */     
/* 1496 */     this.controle.putEventos(evts);
/* 1497 */     eventoOcorreu(evts);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaFalhaRede()
/*      */   {
/* 1506 */     if (this.energiaPop)
/*      */     {
/* 1508 */       String messageKey = "Falta_de_energia__Horario";
/*      */       
/* 1510 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1511 */         .getString(messageKey) + 
/* 1512 */         this.formatador.format(this.controle.getHora()) + 
/* 1513 */         ":" + 
/* 1514 */         this.formatador.format(this.controle.getMinutos()), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaRetornoRede()
/*      */   {
/* 1524 */     if (this.energiaPop)
/*      */     {
/* 1526 */       String messageKey = "Retorno_de_energia__Horario";
/*      */       
/* 1528 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1529 */         .getString(messageKey) + 
/* 1530 */         this.formatador.format(this.controle.getHora()) + 
/* 1531 */         ":" + 
/* 1532 */         this.formatador.format(this.controle.getMinutos()), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaBateriaBaixa()
/*      */   {
/* 1542 */     if (this.bateriaPop)
/*      */     {
/* 1544 */       String messageKey = "A_bateria_esta_fraca__Horario";
/*      */       
/* 1546 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1547 */         .getString(messageKey) + 
/* 1548 */         this.formatador.format(this.controle.getHora()) + 
/* 1549 */         ":" + 
/* 1550 */         this.formatador.format(this.controle.getMinutos()), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaBateriaNormal()
/*      */   {
/* 1560 */     if (this.bateriaPop)
/*      */     {
/* 1562 */       String messageKey = "A_bateria_esta_normal__Horario";
/*      */       
/* 1564 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1565 */         .getString(messageKey) + 
/* 1566 */         this.formatador.format(this.controle.getHora()) + 
/* 1567 */         ":" + 
/* 1568 */         this.formatador.format(this.controle.getMinutos()), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaCargaElevada()
/*      */   {
/* 1578 */     if (this.cargaPop)
/*      */     {
/* 1580 */       String messageKey = "A_carga_esta_elevada__Horario";
/*      */       
/* 1582 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1583 */         .getString(messageKey) + 
/* 1584 */         this.formatador.format(this.controle.getHora()) + 
/* 1585 */         ":" + 
/* 1586 */         this.formatador.format(this.controle.getMinutos()), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaCargaNormal()
/*      */   {
/* 1595 */     if (this.cargaPop)
/*      */     {
/* 1597 */       String messageKey = "A_carga_esta_normal__Horario";
/*      */       
/* 1599 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1600 */         .getString(messageKey) + 
/* 1601 */         this.formatador.format(this.controle.getHora()) + 
/* 1602 */         ":" + 
/* 1603 */         this.formatador.format(this.controle.getMinutos()), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaTemperaturaElevada()
/*      */   {
/* 1613 */     if (this.temperaturaPop)
/*      */     {
/* 1615 */       String messageKey = "A_temperatura_esta_elevada__Horario";
/*      */       
/* 1617 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1618 */         .getString(messageKey) + 
/* 1619 */         this.formatador.format(this.controle.getHora()) + 
/* 1620 */         ":" + 
/* 1621 */         this.formatador.format(this.controle.getMinutos()), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaTemperaturaNormal()
/*      */   {
/* 1630 */     if (this.temperaturaPop)
/*      */     {
/* 1632 */       String messageKey = "A_temperatura_esta_normal__Horario";
/*      */       
/* 1634 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1635 */         .getString(messageKey) + 
/* 1636 */         this.formatador.format(this.controle.getHora()) + 
/* 1637 */         ":" + 
/* 1638 */         this.formatador.format(this.controle.getMinutos()), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaUsandoBateria()
/*      */   {
/* 1648 */     if (this.bateriaUsoPop) {
/* 1649 */       String messageKey = "A_bateria_esta_em_uso__Horario";
/*      */       
/* 1651 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1652 */         .getString(messageKey) + 
/* 1653 */         this.formatador.format(this.controle.getHora()) + 
/* 1654 */         ":" + 
/* 1655 */         this.formatador.format(this.controle.getMinutos()), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaNaoUsaBateria()
/*      */   {
/* 1664 */     if (this.bateriaUsoPop)
/*      */     {
/* 1666 */       String messageKey = "A_bateria_nao_esta_mais_em_uso__Horario";
/*      */       
/* 1668 */       mostraPopUpAlerta(messageKey, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1669 */         .getString(messageKey) + 
/* 1670 */         this.formatador.format(this.controle.getHora()) + 
/* 1671 */         ":" + 
/* 1672 */         this.formatador.format(this.controle.getMinutos()), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaComunicacao()
/*      */   {
/* 1683 */     this.controle.setExpansorBateria(this.painelConfig.getPainelUPS()
/* 1684 */       .getExpansorBateria());
/* 1685 */     this.painelMonitoramento.coletaDados();
/* 1686 */     CardLayout card = (CardLayout)getPainelCentral().getLayout();
/* 1687 */     card.show(getPainelCentral(), "PainelMonitor");
/* 1688 */     this.painelFuncional.mudaPrompt(0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void mostraPopUpAlerta(String messageKey, String mensagem, boolean alerta)
/*      */   {
/* 1703 */     if (!addPopupCache(messageKey)) {
/* 1704 */       return;
/*      */     }
/* 1706 */     PopUpAlerta falha = new PopUpAlerta(this.caminhoFiguras + "PopUp.png", 
/* 1707 */       this.caminhoFiguras, mensagem, this.caminhoFiguras, this, alerta);
/*      */     
/* 1709 */     falha.setMessageKey(messageKey);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean addPopupCache(String message)
/*      */   {
/* 1722 */     if (this.messagePopupCache.containsKey(message))
/* 1723 */       return false;
/* 1724 */     this.messagePopupCache.put(message, Integer.valueOf(1));
/* 1725 */     return true;
/*      */   }
/*      */   
/*      */   public synchronized void delPopupCache(String message) {
/* 1729 */     if (this.messagePopupCache.containsKey(message)) {
/* 1730 */       this.messagePopupCache.remove(message);
/*      */     }
/*      */   }
/*      */   
/*      */   public void mostraPopUp(String mensagem) {
/* 1735 */     if (!addPopupCache(mensagem)) {
/* 1736 */       return;
/*      */     }
/* 1738 */     PopUpAlerta falha = new PopUpAlerta(this.caminhoFiguras + "PopUp.png", 
/* 1739 */       this.caminhoFiguras, ResourceBundle.getBundle(Idioma.getIdioma())
/* 1740 */       .getString(mensagem) + 
/* 1741 */       this.formatador.format(this.controle.getHora()) + 
/* 1742 */       ":" + 
/* 1743 */       this.formatador.format(this.controle.getMinutos()), 
/* 1744 */       this.caminhoFiguras, this, true);
/*      */     
/* 1746 */     falha.setMessageKey(mensagem);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void atualizaProgramacao()
/*      */   {
/* 1755 */     boolean[] prog = this.controle.getDiasSemanaProgramados();
/*      */     
/* 1757 */     this.painelComandos.getCbDomingo().setSelected(prog[0]);
/* 1758 */     this.painelComandos.getCbSegunda().setSelected(prog[1]);
/* 1759 */     this.painelComandos.getCbTerca().setSelected(prog[2]);
/* 1760 */     this.painelComandos.getCbQuarta().setSelected(prog[3]);
/* 1761 */     this.painelComandos.getCbQuinta().setSelected(prog[4]);
/* 1762 */     this.painelComandos.getCbSexta().setSelected(prog[5]);
/* 1763 */     this.painelComandos.getCbSabado().setSelected(prog[6]);
/*      */     
/* 1765 */     if ((prog[0] != 0) && (prog[1] != 0) && (prog[2] != 0) && 
/* 1766 */       (prog[3] != 0) && (prog[4] != 0) && (prog[5] != 0) && 
/* 1767 */       (prog[6] != 0)) {
/* 1768 */       this.painelComandos.getCbTodos().setSelected(true);
/*      */     } else {
/* 1770 */       this.painelComandos.getCbTodos().setSelected(false);
/*      */     }
/* 1772 */     this.painelComandos.getSpinnerHoraLigar().getModel().setValue(
/* 1773 */       this.formatador.format(this.controle.getHoraLigar()));
/* 1774 */     this.painelComandos.getSpinnerHoraDesligar().getModel().setValue(
/* 1775 */       this.formatador.format(this.controle.getHoraDesligar()));
/* 1776 */     this.painelComandos.getSpinnerMinutoLigar().getModel().setValue(
/* 1777 */       this.formatador.format(this.controle.getMinutoLigar()));
/* 1778 */     this.painelComandos.getSpinnerMinutoDesligar().getModel().setValue(
/* 1779 */       this.formatador.format(this.controle.getMinutoDesligar()));
/*      */     
/* 1781 */     this.painelComandos.setFlag(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void limpaGUI()
/*      */   {
/* 1791 */     this.painelMonitoramento.painelEntrada.setEntrada(0);
/* 1792 */     this.painelMonitoramento.painelEntrada.setCorrente(0.0F);
/* 1793 */     this.painelMonitoramento.painelEntrada.setFrequencia(0.0F);
/* 1794 */     this.painelMonitoramento.painelEntrada.panelBarraTensao.setCont(0, 0.0F);
/* 1795 */     this.painelMonitoramento.painelEntrada.setBarraLimSuperior(0.0F);
/* 1796 */     this.painelMonitoramento.painelEntrada.setBarraLimInferior(0.0F);
/*      */     
/*      */ 
/*      */ 
/* 1800 */     this.painelMonitoramento.painelSaida.setSaida(0);
/* 1801 */     this.painelMonitoramento.painelSaida.panelBarraTensao.setCont(0, 0.0F);
/* 1802 */     this.painelMonitoramento.painelSaida.setCorrente(0.0F);
/* 1803 */     this.painelMonitoramento.painelSaida.setFrequencia(0.0F);
/* 1804 */     this.painelMonitoramento.painelSaida.setBarraLimSuperior(0.0F);
/* 1805 */     this.painelMonitoramento.painelSaida.setBarraLimInferior(0.0F);
/*      */     
/*      */ 
/*      */ 
/* 1809 */     this.painelMonitoramento.painelPotencia.setPotAp(0.0F);
/* 1810 */     this.painelMonitoramento.painelPotencia.setPotReal(0.0F);
/* 1811 */     this.painelMonitoramento.painelPotencia.setFPot(0.0F);
/*      */     
/*      */ 
/*      */ 
/* 1815 */     this.painelMonitoramento.painelBateria.panelBarraTensaoBat.setCont(-1);
/* 1816 */     this.painelMonitoramento.painelBateria.setAutonomia(0);
/* 1817 */     this.painelMonitoramento.painelBateria.setTensao(0.0F);
/*      */     
/*      */ 
/*      */ 
/* 1821 */     this.painelMonitoramento.painelTemperatura.panelBarraTemp.setCont(-1);
/*      */     
/*      */ 
/*      */ 
/* 1825 */     this.trataStsAls.setCarregandoBateria(false);
/*      */     
/* 1827 */     this.trataStsAls.setBateriaEmUso(false);
/* 1828 */     this.trataStsAls.setModoInversor(false);
/*      */     
/* 1830 */     this.trataStsAls.setFalhaRede(false);
/*      */     
/* 1832 */     this.trataStsAls.setBateriaBaixa(false);
/* 1833 */     this.trataStsAls.setBateriaCritica(false);
/*      */     
/* 1835 */     this.trataStsAls.setTemperaturaElevada(false);
/*      */     
/* 1837 */     this.trataStsAls.setSuperAquecimento(false);
/*      */     
/* 1839 */     this.trataStsAls.setCargaElevada(false);
/* 1840 */     this.trataStsAls.setSobrecarga(false);
/* 1841 */     this.trataStsAls.processaStatusAlertas();
/*      */     
/*      */ 
/* 1844 */     this.painelStatus.chaveiaLed(1, 0);
/*      */     
/* 1846 */     this.painelStatus.chaveiaLed(1, 1);
/*      */     
/* 1848 */     this.painelStatus.chaveiaLed(1, 2);
/*      */     
/* 1850 */     this.painelStatus.chaveiaLed(1, 3);
/*      */     
/* 1852 */     this.painelAlertas.chaveiaLed(1, 0);
/*      */     
/* 1854 */     this.painelAlertas.chaveiaLed(1, 1);
/*      */     
/* 1856 */     this.painelAlertas.chaveiaLed(1, 2);
/*      */     
/* 1858 */     this.painelGraficos.stopCharts();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean programaSemana()
/*      */   {
/* 1865 */     boolean[] temp = {
/* 1866 */       this.painelComandos.getCbDomingo().isSelected(), 
/* 1867 */       this.painelComandos.getCbSegunda().isSelected(), 
/* 1868 */       this.painelComandos.getCbTerca().isSelected(), 
/* 1869 */       this.painelComandos.getCbQuarta().isSelected(), 
/* 1870 */       this.painelComandos.getCbQuinta().isSelected(), 
/* 1871 */       this.painelComandos.getCbSexta().isSelected(), 
/* 1872 */       this.painelComandos.getCbSabado().isSelected() };
/* 1873 */     return this.controle.programaSemana(temp, this.painelComandos.getHoraLigar(), 
/* 1874 */       this.painelComandos.getMinutoLigar(), this.painelComandos
/* 1875 */       .getHoraDesligar(), this.painelComandos.getMinutoDesligar());
/*      */   }
/*      */   
/*      */ 
/*      */   private void btnAgendarOnClick()
/*      */   {
/*      */     Object localObject;
/* 1882 */     if (programaSemana())
/*      */     {
/*      */ 
/* 1885 */       localObject = new PopUp(this.caminhoFiguras + "PopUp.png", this.caminhoFiguras, 
/* 1886 */         ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1887 */         "Agendamento_realizado_com_sucesso"), this.caminhoFiguras, 
/* 1888 */         10, 10, this, false, true);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1893 */       localObject = new PopUpAlerta(this.caminhoFiguras + "PopUp.png", 
/* 1894 */         this.caminhoFiguras, ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1895 */         "Agendamento_realizado_sem_sucesso"), this.caminhoFiguras, this, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void btnSNMPOnClick()
/*      */   {
/* 1907 */     boolean escrita = false;
/* 1908 */     boolean leitura = false;
/* 1909 */     boolean traps = false;
/* 1910 */     boolean portaPedido = false;
/* 1911 */     boolean getAndSet = false;
/* 1912 */     String mensagem; if (this.painelConfig.getPainelSNMP().isFlagGetAndSet()) {
/* 1913 */       portaPedido = true;
/*      */       
/* 1915 */       String ip = this.controle.getEnderecoIPLocal();
/* 1916 */       String antigaComunidade; if (this.painelConfig.getPainelSNMP().isPedidosInvalido()) {
/* 1917 */         PopUp pop = new PopUp(
/* 1918 */           this.caminhoFiguras + "PopUp.png", 
/* 1919 */           this.caminhoFiguras, 
/*      */           
/* 1921 */           ResourceBundle.getBundle(Idioma.getIdioma())
/* 1922 */           .getString(
/* 1923 */           "Forneca_um_valor_valido_para_a_porta_de_pedidos"), 
/* 1924 */           this.caminhoFiguras, 10, 10, this, true, 
/* 1925 */           true);
/* 1926 */         this.painelConfig.getPainelSNMP().getPortaPedidos();
/* 1927 */         getAndSet = true;
/*      */       } else {
/* 1929 */         if (this.flagPedidos)
/*      */         {
/* 1931 */           if (!this.pedidoAntigo.equals(this.painelConfig.getPainelSNMP().getTfPedidos().getText())) {
/* 1932 */             this.controle.salvaPortaPedidos(this.painelConfig.getPainelSNMP()
/* 1933 */               .getPortaPedidos());
/* 1934 */             ip = ip + "/" + 
/* 1935 */               this.painelConfig.getPainelSNMP()
/* 1936 */               .getPortaPedidos();
/* 1937 */             this.controle.salvaPortaPedidos(this.painelConfig.getPainelSNMP()
/* 1938 */               .getPortaPedidos());
/* 1939 */             this.controle.setLocalAdress(ip);
/*      */           }
/*      */         }
/* 1942 */         this.flagPedidos = false;
/*      */         
/*      */ 
/*      */ 
/* 1946 */         if (this.painelConfig.getPainelSNMP().getTfLeitura().getText().equals(this.painelConfig.getPainelSNMP().getTfEscrita().getText())) {
/* 1947 */           PopUp pop = new PopUp(
/* 1948 */             this.caminhoFiguras + "PopUp.png", 
/* 1949 */             this.caminhoFiguras, 
/*      */             
/* 1951 */             ResourceBundle.getBundle(Idioma.getIdioma())
/* 1952 */             .getString(
/* 1953 */             "Comunidade_de_leitura_e_de_escrita_devem_possuir_valores_diferentes"), 
/* 1954 */             this.caminhoFiguras, 10, 10, this, 
/* 1955 */             true, true);
/* 1956 */           this.painelConfig.getPainelSNMP().getBtnCancel().doClick();
/* 1957 */           getAndSet = true;
/*      */         }
/*      */         else
/*      */         {
/* 1961 */           if (this.painelConfig.getPainelSNMP().isFlagLeitura())
/*      */           {
/* 1963 */             String novaComunidade = this.painelConfig.getPainelSNMP()
/* 1964 */               .getTfLeitura().getText();
/* 1965 */             String antigaComunidade = this.painelConfig.getPainelSNMP()
/* 1966 */               .getLeituraAntiga();
/*      */             
/* 1968 */             if (this.controle.setComunidadeLeitura(novaComunidade, antigaComunidade))
/* 1969 */               leitura = true;
/*      */           }
/* 1971 */           if (this.painelConfig.getPainelSNMP().isFlagEscrita())
/*      */           {
/* 1973 */             String novaComunidade = this.painelConfig.getPainelSNMP()
/* 1974 */               .getTfEscrita().getText();
/* 1975 */             antigaComunidade = this.painelConfig.getPainelSNMP()
/* 1976 */               .getEscritaAntiga();
/*      */             
/* 1978 */             if (this.controle.setComunidadeEscrita(novaComunidade, antigaComunidade))
/* 1979 */               escrita = true;
/*      */           }
/*      */         }
/*      */       }
/* 1983 */       if (!getAndSet) {
/* 1984 */         if ((escrita) || (leitura) || (portaPedido)) {
/* 1985 */           PopUp pop = new PopUp(
/* 1986 */             this.caminhoFiguras + "PopUp.png", 
/* 1987 */             this.caminhoFiguras, 
/*      */             
/* 1989 */             ResourceBundle.getBundle(Idioma.getIdioma())
/* 1990 */             .getString(
/* 1991 */             "Configuracao_de_gets_e_sets_do_SNMP_realizada_com_sucesso"), 
/* 1992 */             this.caminhoFiguras, 10, 10, this, 
/* 1993 */             false, true);
/* 1994 */           this.controle.salvaPortaPedidos(this.painelConfig.getPainelSNMP()
/* 1995 */             .getPortaPedidos());
/* 1996 */           this.controle.salvaComunidadeEscrita(this.painelConfig
/* 1997 */             .getPainelSNMP().getTfEscrita().getText());
/* 1998 */           this.controle.salvaComunidadeLeitura(this.painelConfig
/* 1999 */             .getPainelSNMP().getTfLeitura().getText());
/*      */         } else {
/* 2001 */           mensagem = "";
/* 2002 */           if (!leitura)
/* 2003 */             mensagem = 
/*      */             
/* 2005 */               ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 2006 */               "Troca_de_comunidade_de_escrita_nao_pode_ser_realizada");
/* 2007 */           if (!escrita) {
/* 2008 */             mensagem = 
/* 2009 */               mensagem + "\n" + 
/* 2010 */               ResourceBundle.getBundle(Idioma.getIdioma())
/* 2011 */               .getString(
/* 2012 */               "Troca_de_comunidade_de_leitura_nao_pode_ser_realizada");
/*      */           }
/* 2014 */           antigaComunidade = new PopUp(this.caminhoFiguras + "PopUp.png", 
/* 2015 */             this.caminhoFiguras, mensagem, this.caminhoFiguras, 10, 10, 
/* 2016 */             this, true, true);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2021 */     if (this.painelConfig.getPainelSNMP().isFlagTraps())
/*      */     {
/* 2023 */       if (!this.painelConfig.getPainelSNMP().getTfGerente().getText().matches("\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b")) {
/* 2024 */         PopUp pop = new PopUp(this.caminhoFiguras + "PopUp.png", 
/* 2025 */           this.caminhoFiguras, ResourceBundle.getBundle(
/* 2026 */           Idioma.getIdioma()).getString(
/* 2027 */           "Entre_com_um_endereco_de_IP_valido"), 
/* 2028 */           this.caminhoFiguras, 10, 10, this, true, 
/* 2029 */           true);
/* 2030 */         this.painelConfig.getPainelSNMP().getBtnCancel().doClick();
/*      */       } else { PopUp pop;
/* 2032 */         if (this.painelConfig.getPainelSNMP().isEnvioInvalido()) {
/* 2033 */           pop = new PopUp(
/* 2034 */             this.caminhoFiguras + "PopUp.png", 
/* 2035 */             this.caminhoFiguras, 
/*      */             
/* 2037 */             ResourceBundle.getBundle(Idioma.getIdioma())
/* 2038 */             .getString(
/* 2039 */             "Forneca_um_valor_valido_para_a_porta_de_envio"), 
/* 2040 */             this.caminhoFiguras, 10, 10, this, 
/* 2041 */             true, true);
/* 2042 */           this.painelConfig.getPainelSNMP().getPortaEnvio();
/*      */         } else {
/* 2044 */           traps = this.controle.setConfigTraps(this.painelConfig
/* 2045 */             .getPainelSNMP().getTfGerente().getText(), 
/* 2046 */             Integer.parseInt(this.painelConfig.getPainelSNMP().getTfEnvio()
/* 2047 */             .getText()), this.painelConfig.getPainelSNMP()
/* 2048 */             .getCbSNMP().getSelectedIndex() + 1, this.painelConfig
/* 2049 */             .getPainelSNMP().getCbTransporte()
/* 2050 */             .getSelectedItem().toString(), this.painelConfig
/* 2051 */             .getPainelSNMP().getTfEscrita().getText());
/*      */           
/* 2053 */           if (traps) {
/* 2054 */             pop = new PopUp(
/* 2055 */               this.caminhoFiguras + "PopUp.png", 
/* 2056 */               this.caminhoFiguras, 
/*      */               
/* 2058 */               ResourceBundle.getBundle(Idioma.getIdioma())
/* 2059 */               .getString(
/* 2060 */               "Configuracao_de_traps_do_SNMP_realizada_com_sucesso"), 
/* 2061 */               this.caminhoFiguras, 10, 10, this, 
/* 2062 */               false, true);
/*      */           } else {
/* 2064 */             String mensagem = "";
/* 2065 */             if (!traps) {
/* 2066 */               mensagem = 
/*      */               
/* 2068 */                 ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 2069 */                 "Configuracao_de_traps_nao_pode_ser_realizada");
/*      */             }
/* 2071 */             mensagem = new PopUp(this.caminhoFiguras + "PopUp.png", 
/* 2072 */               this.caminhoFiguras, mensagem, this.caminhoFiguras, 10, 
/* 2073 */               10, this, true, true);
/*      */           }
/* 2075 */           this.controle.salvaEnderecoGerente(this.painelConfig.getPainelSNMP()
/* 2076 */             .getTfGerente().getText());
/* 2077 */           this.controle.salvaPortaEnvio(Integer.parseInt(this.painelConfig
/* 2078 */             .getPainelSNMP().getTfEnvio().getText()));
/* 2079 */           this.controle.salvaProtocolo(this.painelConfig.getPainelSNMP()
/* 2080 */             .getCbTransporte().getSelectedIndex());
/* 2081 */           this.controle.salvaVSnmp(this.painelConfig.getPainelSNMP()
/* 2082 */             .getCbSNMP().getSelectedIndex());
/*      */         }
/*      */       }
/*      */     }
/* 2086 */     this.painelConfig.getPainelSNMP().setFlagTraps(false);
/* 2087 */     this.painelConfig.getPainelSNMP().setFlagGetAndSet(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void enterSNMP()
/*      */   {
/* 2094 */     this.painelConfig.getPainelSNMP().getTfPedidos().setText(
/* 2095 */       Integer.toString(this.controle.getPortaPedidos()));
/*      */     
/* 2097 */     this.pedidoAntigo = Integer.toString(this.controle.getPortaPedidos());
/*      */     
/* 2099 */     this.painelConfig.getPainelSNMP().getTfLeitura().setText(
/* 2100 */       this.controle.getComunidadeLeitura());
/*      */     
/* 2102 */     this.painelConfig.getPainelSNMP().getTfEscrita().setText(
/* 2103 */       this.controle.getComunidadeEscrita());
/*      */     
/* 2105 */     this.painelConfig.getPainelSNMP().getTfGerente().setText(
/* 2106 */       this.controle.getEnderecoGerente());
/*      */     
/* 2108 */     this.painelConfig.getPainelSNMP().getTfEnvio().setText(
/* 2109 */       Integer.toString(this.controle.getPortaEnvio()));
/*      */     
/* 2111 */     this.painelConfig.getPainelSNMP().getCbSNMP().setSelectedIndex(
/* 2112 */       this.controle.getVSNMP());
/*      */     
/* 2114 */     this.painelConfig.getPainelSNMP().getCbTransporte().setSelectedIndex(
/* 2115 */       this.controle.getProtocoloTransportePersistencia());
/*      */     
/* 2117 */     this.painelConfig.getPainelSNMP().setFlagLeitura(false);
/* 2118 */     this.painelConfig.getPainelSNMP().setFlagEscrita(false);
/* 2119 */     this.painelConfig.getPainelSNMP().setFlagGetAndSet(false);
/* 2120 */     this.painelConfig.getPainelSNMP().setFlagTraps(false);
/* 2121 */     this.painelConfig.getPainelSNMP().setFlag(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void enterGeral()
/*      */   {
/* 2129 */     this.painelConfig.getPainelConfigGeral().getTfPortaShutdownRemoto().setText(
/* 2130 */       Integer.toString(this.controle.getPortaRemota()));
/* 2131 */     this.painelConfig.getPainelConfigGeral().getCbShutdownRemoto().setSelected(
/* 2132 */       this.controle.getModoRemoto());
/*      */     
/* 2134 */     this.painelConfig.getPainelConfigGeral().setFlag(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void enterUPS()
/*      */   {
/* 2141 */     if (this.controle.getNomeUPSPersistencia().equals("vazio")) {
/* 2142 */       this.painelConfig.getPainelUPS().getNomeUPS().setText("");
/*      */     } else
/* 2144 */       this.painelConfig.getPainelUPS().getNomeUPS().setText(
/* 2145 */         this.controle.getNomeUPSPersistencia());
/* 2146 */     this.painelConfig.getPainelUPS().getTextFieldExpanBat().setText(
/* 2147 */       Integer.toString(this.controle.getExpansorBateriaPersistencia()));
/* 2148 */     this.painelConfig.getPainelUPS().setFlag(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void enterSMTP()
/*      */   {
/* 2155 */     this.painelConfig.getPainelSMTP().getTfEndServidor().setText(
/* 2156 */       this.controle.getEnderecoSMTPPersistencia());
/*      */     
/* 2158 */     this.painelConfig.getPainelSMTP().getCbAutenticacao().setSelected(
/* 2159 */       this.controle.getFlagAutenticacoPersistencia());
/*      */     
/* 2161 */     this.painelConfig.getPainelSMTP().getTfUsuario().setText(
/* 2162 */       this.controle.getUsuarioPersistencia());
/*      */     
/* 2164 */     this.painelConfig.getPainelSMTP().getPfSenha().setText(
/* 2165 */       this.controle.getSenhaPersistencia());
/*      */     
/* 2167 */     this.painelConfig.getPainelSMTP().getTfRemetente().setText(
/* 2168 */       this.controle.getRemetentePersistencia());
/*      */     
/* 2170 */     String[] tempDest = this.controle.getDestinatariosPersistencia();
/* 2171 */     String tempDest2 = "";
/* 2172 */     for (int i = 0; i < tempDest.length; i++)
/* 2173 */       tempDest2 = tempDest2 + tempDest[i] + ", ";
/* 2174 */     this.painelConfig.getPainelSMTP().getTfDestinatario().setText(tempDest2);
/*      */     
/*      */ 
/* 2177 */     if (this.painelConfig.getPainelSMTP().getTfDestinatario().getText().equals(", "))
/* 2178 */       this.painelConfig.getPainelSMTP().getTfDestinatario().setText("");
/* 2179 */     this.painelConfig.getPainelSMTP().getTfPorta().setText(
/* 2180 */       Integer.toString(this.controle.getPortaSMTPPersistencia()));
/*      */     
/* 2182 */     this.painelConfig.getPainelSMTP().setFlag(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PainelConfig getPainelConfig()
/*      */   {
/* 2195 */     return this.painelConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PainelComando getPainelComando()
/*      */   {
/* 2204 */     return this.painelComandos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getXPop()
/*      */   {
/* 2213 */     return this.xPop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getYPop()
/*      */   {
/* 2223 */     return this.yPop;
/*      */   }
/*      */   
/*      */   public PainelBarrado getPainelStatus() {
/* 2227 */     return this.painelStatus;
/*      */   }
/*      */   
/*      */   public PainelBarrado getPainelAlertas() {
/* 2231 */     return this.painelAlertas;
/*      */   }
/*      */   
/*      */   public JPanel getPainelCentral() {
/* 2235 */     return this.painelFuncional.getPainelCentral();
/*      */   }
/*      */   
/*      */   public PainelMonitorCentral getPainelMonitor() {
/* 2239 */     return this.painelMonitoramento;
/*      */   }
/*      */   
/*      */   public PainelCentral getPainelFuncional() {
/* 2243 */     return this.painelFuncional;
/*      */   }
/*      */   
/*      */   public PainelGraficos getPainelGraficos() {
/* 2247 */     return this.painelGraficos;
/*      */   }
/*      */   
/*      */   public boolean isBateriaUsoEmail() {
/* 2251 */     return this.bateriaUsoEmail;
/*      */   }
/*      */   
/*      */   public boolean isBateriaUsoPop() {
/* 2255 */     return this.bateriaUsoPop;
/*      */   }
/*      */   
/*      */   public boolean isBateriaEmail() {
/* 2259 */     return this.bateriaEmail;
/*      */   }
/*      */   
/*      */   public boolean isBateriaPop() {
/* 2263 */     return this.bateriaPop;
/*      */   }
/*      */   
/*      */   public boolean isCargaEmail() {
/* 2267 */     return this.cargaEmail;
/*      */   }
/*      */   
/*      */   public boolean isCargaPop() {
/* 2271 */     return this.cargaPop;
/*      */   }
/*      */   
/*      */   public boolean isEnergiaEmail() {
/* 2275 */     return this.energiaEmail;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isComunicou()
/*      */   {
/* 2282 */     return this.comunicou;
/*      */   }
/*      */   
/*      */   public boolean isEnergiaPop() {
/* 2286 */     return this.energiaPop;
/*      */   }
/*      */   
/*      */   public boolean isComEmail() {
/* 2290 */     return this.comEmail;
/*      */   }
/*      */   
/*      */   public boolean isTemperaturaEmail() {
/* 2294 */     return this.temperaturaEmail;
/*      */   }
/*      */   
/*      */   public boolean isTemperaturaPop() {
/* 2298 */     return this.temperaturaPop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEventos(String[] eventos)
/*      */   {
/* 2310 */     JComboBox eventosBox = this.painelConfig.getPainelConfigGeral()
/* 2311 */       .getComboBoxEvento();
/* 2312 */     eventosBox.removeAllItems();
/*      */     
/* 2314 */     for (int i = 0; i < eventos.length; i++) {
/* 2315 */       eventosBox.addItem(ResourceBundle.getBundle(Idioma.getIdioma())
/* 2316 */         .getString(eventos[i]));
/*      */     }
/*      */     
/* 2319 */     this.painelConfig.getPainelConfigGeral().setFlag(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXPop(int xPop)
/*      */   {
/* 2330 */     this.xPop = xPop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setYPop(int yPop)
/*      */   {
/* 2340 */     this.yPop = yPop;
/*      */   }
/*      */   
/*      */   public void setBateriaUsoEmail(boolean bateriaUsoEmail) {
/* 2344 */     this.bateriaUsoEmail = bateriaUsoEmail;
/*      */   }
/*      */   
/*      */   public void setBateriaUsoPop(boolean bateriaUsoPop) {
/* 2348 */     this.bateriaUsoPop = bateriaUsoPop;
/*      */   }
/*      */   
/*      */   public void setBateriaEmail(boolean bateriaEmail) {
/* 2352 */     this.bateriaEmail = bateriaEmail;
/*      */   }
/*      */   
/*      */   public void setBateriaPop(boolean bateriaPop) {
/* 2356 */     this.bateriaPop = bateriaPop;
/*      */   }
/*      */   
/*      */   public void setFlagMonitor(boolean b)
/*      */   {
/* 2361 */     this.monitor = b;
/*      */   }
/*      */   
/*      */   public void setFlagGrafico(boolean b)
/*      */   {
/* 2366 */     this.graficos = b;
/*      */   }
/*      */   
/*      */   public void setCargaEmail(boolean cargaEmail) {
/* 2370 */     this.cargaEmail = cargaEmail;
/*      */   }
/*      */   
/*      */   public void setCargaPop(boolean cargaPop) {
/* 2374 */     this.cargaPop = cargaPop;
/*      */   }
/*      */   
/*      */   public void setEnergiaEmail(boolean energiaEmail) {
/* 2378 */     this.energiaEmail = energiaEmail;
/*      */   }
/*      */   
/*      */   public void setEnergiaPop(boolean energiaPop) {
/* 2382 */     this.energiaPop = energiaPop;
/*      */   }
/*      */   
/*      */   public void setComEmail(boolean comEmail) {
/* 2386 */     this.comEmail = comEmail;
/*      */   }
/*      */   
/*      */   public void setTemperaturaEmail(boolean temperaturaEmail) {
/* 2390 */     this.temperaturaEmail = temperaturaEmail;
/*      */   }
/*      */   
/*      */   public void setTemperaturaPop(boolean temperaturaPop) {
/* 2394 */     this.temperaturaPop = temperaturaPop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   class TrataEventos
/*      */     implements ActionListener, MouseListener, CaretListener
/*      */   {
/*      */     private CardLayout card;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     TrataEventos() {}
/*      */     
/*      */ 
/*      */ 
/*      */     public void caretUpdate(CaretEvent ce)
/*      */     {
/* 2414 */       if ((ce.getSource() == InterfaceGrafica.this.painelConfig.getPainelSNMP().getTfPedidos()) && 
/* 2415 */         (!InterfaceGrafica.this.flagPedidos)) {
/* 2416 */         InterfaceGrafica.this.flagPedidos = true;
/* 2417 */         InterfaceGrafica.this.pedidoAntigo = InterfaceGrafica.this.painelConfig.getPainelSNMP().getTfPedidos()
/* 2418 */           .getText();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void actionPerformed(ActionEvent ae)
/*      */     {
/* 2425 */       if (ae.getSource() == InterfaceGrafica.this.botaoMonitor) {
/* 2426 */         this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2427 */         this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelMonitor");
/* 2428 */         InterfaceGrafica.this.painelMonitoramento.coletaDados();
/*      */         
/* 2430 */         boolean b1 = InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged();
/* 2431 */         boolean b2 = InterfaceGrafica.this.painelComandos.isPainelComandoChanged();
/* 2432 */         if (InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged()) {
/* 2433 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2434 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelConfig");
/* 2435 */           InterfaceGrafica.this.painelConfig.getPbc().configChanged();
/*      */         }
/*      */         
/* 2438 */         if (b2) {
/* 2439 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2440 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelComandos");
/* 2441 */           InterfaceGrafica.this.painelComandos.painelComandosChanged();
/*      */         }
/* 2443 */         if ((!b1) && (!b2))
/* 2444 */           InterfaceGrafica.this.painelFuncional.mudaPrompt(0, 0);
/* 2445 */         InterfaceGrafica.this.painelGraficos.stopCharts();
/*      */ 
/*      */ 
/*      */       }
/* 2449 */       else if (ae.getSource() == InterfaceGrafica.this.botaoConfiguracoes)
/*      */       {
/* 2451 */         this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2452 */         this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelConfig");
/*      */         
/* 2454 */         if (InterfaceGrafica.this.painelComandos.isPainelComandoChanged()) {
/* 2455 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2456 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelComandos");
/* 2457 */           InterfaceGrafica.this.painelComandos.painelComandosChanged();
/*      */         } else {
/* 2459 */           InterfaceGrafica.this.painelFuncional.mudaPrompt(2, 2);
/* 2460 */           InterfaceGrafica.this.painelGraficos.stopCharts();
/* 2461 */           InterfaceGrafica.this.painelMonitoramento.paraColetaDados();
/* 2462 */           InterfaceGrafica.this.enterSNMP();
/* 2463 */           InterfaceGrafica.this.enterUPS();
/* 2464 */           InterfaceGrafica.this.enterGeral();
/*      */         }
/*      */         
/*      */       }
/* 2468 */       else if (ae.getSource() == InterfaceGrafica.this.botaoGraficos) {
/* 2469 */         this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2470 */         this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelGraficos");
/*      */         
/* 2472 */         InterfaceGrafica.this.painelGraficos.restartCharts();
/*      */         
/* 2474 */         boolean b1 = InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged();
/* 2475 */         boolean b2 = InterfaceGrafica.this.painelComandos.isPainelComandoChanged();
/* 2476 */         if (InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged()) {
/* 2477 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2478 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelConfig");
/* 2479 */           InterfaceGrafica.this.painelConfig.getPbc().configChanged();
/*      */         }
/*      */         
/* 2482 */         if (b2) {
/* 2483 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2484 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelComandos");
/* 2485 */           InterfaceGrafica.this.painelComandos.painelComandosChanged();
/*      */         }
/* 2487 */         if ((!b1) && (!b2))
/* 2488 */           InterfaceGrafica.this.painelFuncional.mudaPrompt(1, 1);
/* 2489 */         InterfaceGrafica.this.painelMonitoramento.paraColetaDados();
/*      */ 
/*      */       }
/* 2492 */       else if (ae.getSource() == InterfaceGrafica.this.botaoComandos)
/*      */       {
/* 2494 */         this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2495 */         this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelComandos");
/*      */         
/* 2497 */         if (InterfaceGrafica.this.comunicou)
/*      */         {
/*      */ 
/*      */ 
/* 2501 */           InterfaceGrafica.this.atualizaProgramacao();
/*      */         }
/* 2503 */         if (InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged()) {
/* 2504 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2505 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelConfig");
/* 2506 */           InterfaceGrafica.this.painelConfig.getPbc().configChanged();
/*      */         } else {
/* 2508 */           InterfaceGrafica.this.painelFuncional.mudaPrompt(3, 3);
/*      */         }
/* 2510 */         InterfaceGrafica.this.painelGraficos.stopCharts();
/* 2511 */         InterfaceGrafica.this.painelMonitoramento.paraColetaDados();
/*      */ 
/*      */       }
/* 2514 */       else if (ae.getSource() == InterfaceGrafica.this.botaoHistorico)
/*      */       {
/* 2516 */         this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2517 */         this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelHistorico");
/* 2518 */         boolean b1 = InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged();
/* 2519 */         boolean b2 = InterfaceGrafica.this.painelComandos.isPainelComandoChanged();
/*      */         
/*      */ 
/* 2522 */         InterfaceGrafica.this.controle.pedidoDumpping();
/*      */         
/*      */ 
/* 2525 */         if (InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged()) {
/* 2526 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2527 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelConfig");
/* 2528 */           InterfaceGrafica.this.painelConfig.getPbc().configChanged();
/*      */         }
/*      */         
/* 2531 */         if (b2) {
/* 2532 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2533 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelComandos");
/* 2534 */           InterfaceGrafica.this.painelComandos.painelComandosChanged();
/*      */         }
/* 2536 */         if ((!b1) && (!b2)) {
/* 2537 */           InterfaceGrafica.this.painelFuncional.mudaPrompt(4, 4);
/*      */         }
/* 2539 */         InterfaceGrafica.this.painelGraficos.stopCharts();
/* 2540 */         InterfaceGrafica.this.painelMonitoramento.paraColetaDados();
/*      */ 
/*      */ 
/*      */       }
/* 2544 */       else if (ae.getSource() == InterfaceGrafica.this.botaoSobre)
/*      */       {
/* 2546 */         this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2547 */         this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelSobre");
/*      */         
/* 2549 */         boolean b1 = InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged();
/* 2550 */         boolean b2 = InterfaceGrafica.this.painelComandos.isPainelComandoChanged();
/* 2551 */         if (InterfaceGrafica.this.painelConfig.getPbc().isConfigChanged()) {
/* 2552 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2553 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelConfig");
/* 2554 */           InterfaceGrafica.this.painelConfig.getPbc().configChanged();
/*      */         }
/*      */         
/* 2557 */         if (b2) {
/* 2558 */           this.card = ((CardLayout)InterfaceGrafica.this.getPainelCentral().getLayout());
/* 2559 */           this.card.show(InterfaceGrafica.this.getPainelCentral(), "PainelComandos");
/* 2560 */           InterfaceGrafica.this.painelComandos.painelComandosChanged();
/*      */         }
/* 2562 */         if ((!b1) && (!b2)) {
/* 2563 */           InterfaceGrafica.this.painelFuncional.mudaPrompt(5, 5);
/*      */         }
/* 2565 */         InterfaceGrafica.this.painelGraficos.stopCharts();
/* 2566 */         InterfaceGrafica.this.painelMonitoramento.paraColetaDados();
/*      */ 
/*      */ 
/*      */       }
/* 2570 */       else if (ae.getSource() == InterfaceGrafica.this.botaoMinimizar)
/*      */       {
/* 2572 */         InterfaceGrafica.this.setState(1);
/*      */ 
/*      */ 
/*      */       }
/* 2576 */       else if (ae.getSource() == InterfaceGrafica.this.botaoTray)
/*      */       {
/* 2578 */         InterfaceGrafica.this.setState(1);
/* 2579 */         InterfaceGrafica.this.setVisible(false);
/* 2580 */         InterfaceGrafica.this.painelMonitoramento.paraColetaDados();
/* 2581 */         InterfaceGrafica.this.painelGraficos.stopCharts();
/*      */ 
/*      */ 
/*      */       }
/* 2585 */       else if (ae.getSource() == InterfaceGrafica.this.botaoFechar) {
/* 2586 */         InterfaceGrafica.this.encerraAplicativo();
/*      */ 
/*      */ 
/*      */       }
/* 2590 */       else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPbc().getBtnSNMP()) {
/* 2591 */         InterfaceGrafica.this.enterSNMP();
/*      */ 
/*      */       }
/* 2594 */       else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPbc().getBtnGeral()) {
/* 2595 */         InterfaceGrafica.this.enterGeral();
/*      */ 
/*      */       }
/* 2598 */       else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPbc().getBtnUPS()) {
/* 2599 */         InterfaceGrafica.this.enterUPS();
/*      */ 
/*      */       }
/* 2602 */       else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelUPS().getBtnOk()) {
/* 2603 */         boolean falhou = false;
/* 2604 */         PopUp falha = null;
/* 2605 */         if ((InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfPorta().getText().equals("0")) || (InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfPorta().getText().equals("587")))
/*      */         {
/* 2607 */           InterfaceGrafica.this.controle.salvaPortaSMTP(587);
/* 2608 */           InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfPorta().setText(Integer.toString(InterfaceGrafica.this.controle.getPortaSMTPPersistencia()));
/* 2609 */           InterfaceGrafica.this.painelConfig.getPainelSMTP().setFlag(false);
/*      */         }
/* 2611 */         if (InterfaceGrafica.this.painelConfig.getPainelUPS().getExpansorBateria() != -1)
/*      */         {
/*      */ 
/* 2614 */           if (!InterfaceGrafica.this.controle.configuraUPSEtapa1(InterfaceGrafica.this.painelConfig.getPainelUPS().getTipoUps(), InterfaceGrafica.this.painelConfig.getPainelUPS().getPorta())) {
/* 2615 */             falha = new PopUp(
/* 2616 */               InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2617 */               InterfaceGrafica.this.caminhoFiguras, 
/*      */               
/* 2619 */               ResourceBundle.getBundle(Idioma.getIdioma())
/* 2620 */               .getString(
/* 2621 */               "Erro_de_configuracao__Verifique_a_familia_de_UPS_selecionada"), 
/* 2622 */               InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2623 */               true, true);
/* 2624 */             falhou = true;
/*      */           }
/* 2626 */           else if ((falha != null) && (falha.isVisible())) {
/* 2627 */             falha.dispose();
/*      */           } }
/* 2629 */         if (InterfaceGrafica.this.painelConfig.getPainelUPS().isExpansorBateriaValido()) {
/* 2630 */           InterfaceGrafica.this.controle.salvaExpansorBateria(InterfaceGrafica.this.painelConfig.getPainelUPS()
/* 2631 */             .getExpansorBateria());
/*      */           
/* 2633 */           if (InterfaceGrafica.this.painelConfig.getPainelUPS().getNomeUPS().getText().equals("")) {
/* 2634 */             InterfaceGrafica.this.controle.salvaNomeUPS("vazio");
/*      */           } else
/* 2636 */             InterfaceGrafica.this.controle.salvaNomeUPS(InterfaceGrafica.this.painelConfig.getPainelUPS()
/* 2637 */               .getNomeUPS().getText());
/* 2638 */           InterfaceGrafica.this.controle.setExpansorBateria(InterfaceGrafica.this.painelConfig.getPainelUPS()
/* 2639 */             .getExpansorBateria());
/* 2640 */           if (!falhou) {
/* 2641 */             PopUp localPopUp1 = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2642 */               InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 2643 */               Idioma.getIdioma()).getString(
/* 2644 */               "Sucesso_na_configuracao_do_ups"), 
/* 2645 */               InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2646 */               false, true);
/*      */           }
/*      */         } else {
/* 2649 */           InterfaceGrafica.this.painelConfig.getPainelUPS().getExpansorBateria();
/*      */         }
/*      */         
/*      */       }
/* 2653 */       else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelConfigGeral()
/* 2654 */         .getBtnProcura())
/*      */       {
/* 2656 */         JFileChooser chooser = new JFileChooser();
/* 2657 */         chooser.setApproveButtonText(ResourceBundle.getBundle(
/* 2658 */           Idioma.getIdioma()).getString("Abrir"));
/* 2659 */         chooser.setFileSelectionMode(0);
/*      */         
/*      */ 
/*      */ 
/* 2663 */         int returnVal = chooser.showOpenDialog(null);
/* 2664 */         if (returnVal == 0) {
/* 2665 */           InterfaceGrafica.this.painelConfig.getPainelConfigGeral().getTfScript().setText(
/* 2666 */             chooser.getSelectedFile().toString());
/*      */         }
/*      */       } else {
/*      */         PopUp pop;
/* 2670 */         if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelMensg().getBtnOk()) {
/* 2671 */           boolean enter = true;
/*      */           
/* 2673 */           InterfaceGrafica.this.setMensagens();
/*      */           
/* 2675 */           if ((InterfaceGrafica.this.energiaEmail) || (InterfaceGrafica.this.bateriaEmail) || (InterfaceGrafica.this.cargaEmail) || 
/* 2676 */             (InterfaceGrafica.this.temperaturaEmail) || (InterfaceGrafica.this.bateriaUsoEmail))
/*      */           {
/* 2678 */             if ((InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfEndServidor().getText().equals("")) || 
/*      */             
/* 2680 */               (InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfPorta().getText().equals(""))) {
/* 2681 */               pop = new PopUp(
/* 2682 */                 InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2683 */                 InterfaceGrafica.this.caminhoFiguras, 
/*      */                 
/* 2685 */                 ResourceBundle.getBundle(Idioma.getIdioma())
/* 2686 */                 .getString(
/* 2687 */                 "Endereco_do_servidor_ou_a_porta_de_email_nao_estao_configurados_corretamente__Emails_nao_poderao_ser_enviados_corretamente_ate_que_o_erro_seja_corrigido"), 
/* 2688 */                 InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2689 */                 true, true);
/* 2690 */               enter = false;
/*      */             }
/*      */           }
/* 2693 */           if (enter) {
/* 2694 */             pop = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2695 */               InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 2696 */               Idioma.getIdioma()).getString(
/* 2697 */               "Sucesso_na_configuracao_de_mensagens"), 
/* 2698 */               InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2699 */               false, true);
/*      */           }
/*      */         }
/* 2702 */         else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelAutoTeste().getBtnOk())
/*      */         {
/* 2704 */           InterfaceGrafica.this.painelConfig.getPainelAutoTeste().validateForm();
/* 2705 */           InterfaceGrafica.this.controle.configuraAutoTeste(InterfaceGrafica.this.painelConfig.getPainelAutoTeste().getAutoTesteHabilitado(), InterfaceGrafica.this.painelConfig.getPainelAutoTeste().getHoraTeste(), InterfaceGrafica.this.painelConfig.getPainelAutoTeste().getMinutoTeste(), InterfaceGrafica.this.painelConfig.getPainelAutoTeste().getPeriodoAutoTeste());
/* 2706 */           PopUp pop = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2707 */             InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 2708 */             Idioma.getIdioma()).getString(
/* 2709 */             "Sucesso_na_configuracao_de_auto_teste"), 
/* 2710 */             InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2711 */             false, true);
/*      */           
/* 2713 */           InterfaceGrafica.this.painelConfig.getPainelAutoTeste().setFlag(false);
/*      */ 
/*      */         }
/* 2716 */         else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelAutoTeste()
/* 2717 */           .getBtnCancel())
/*      */         {
/* 2719 */           InterfaceGrafica.this.painelConfig.getPainelAutoTeste().setHoraTeste(InterfaceGrafica.this.controle.getHoraTestePersistencia());
/* 2720 */           InterfaceGrafica.this.painelConfig.getPainelAutoTeste().setMinutoTeste(InterfaceGrafica.this.controle.getMinutoTestePersistencia());
/* 2721 */           InterfaceGrafica.this.painelConfig.getPainelAutoTeste().setPeriodoAutoTeste(InterfaceGrafica.this.controle.getPeriodoTestePersistencia());
/* 2722 */           InterfaceGrafica.this.painelConfig.getPainelAutoTeste().setAutoTesteHabilitado(InterfaceGrafica.this.controle.getAutoTesteEnabledPersitencia());
/* 2723 */           InterfaceGrafica.this.painelConfig.getPainelAutoTeste().setFlag(false);
/*      */         } else {
/*      */           boolean sucesso;
/* 2726 */           if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelConfigGeral()
/* 2727 */             .getBtnOk()) {
/* 2728 */             sucesso = false;
/*      */             
/* 2730 */             if (InterfaceGrafica.this.painelConfig.getPainelConfigGeral().getCbVarLogging().isSelected()) {
/* 2731 */               InterfaceGrafica.this.controle.salvaModoLogging(true);
/*      */             } else {
/* 2733 */               InterfaceGrafica.this.controle.salvaModoLogging(false);
/*      */             }
/*      */             
/* 2736 */             if (InterfaceGrafica.this.painelConfig.getPainelConfigGeral().getCbShutdownRemoto().isSelected()) {
/* 2737 */               if (InterfaceGrafica.this.painelConfig.getPainelConfigGeral().isPortaValida()) {
/* 2738 */                 InterfaceGrafica.this.controle.salvaPortaRemota(InterfaceGrafica.this.painelConfig
/* 2739 */                   .getPainelConfigGeral().getPorta());
/* 2740 */                 if (!InterfaceGrafica.this.controle.isModoRemoto()) {
/* 2741 */                   InterfaceGrafica.this.controle.executaAcaoRede = new ExecutaAcaoRede();
/* 2742 */                   InterfaceGrafica.this.controle.executaAcaoRede.setPortaEscuta(InterfaceGrafica.this.controle.getPortaRemota());
/* 2743 */                   InterfaceGrafica.this.controle.executaAcaoRede.start();
/*      */                 }
/* 2745 */                 InterfaceGrafica.this.controle.salvaModoRemoto(true);
/* 2746 */                 sucesso = true;
/*      */               } else {
/* 2748 */                 InterfaceGrafica.this.controle.salvaModoRemoto(false);
/*      */               }
/*      */             } else {
/* 2751 */               sucesso = true;
/*      */             }
/* 2753 */             InterfaceGrafica.this.validarAllIdioma();
/* 2754 */             InterfaceGrafica.this.controle.salvaEventoGatilho(InterfaceGrafica.this.painelConfig.getPainelConfigGeral()
/* 2755 */               .getComboBoxEvento().getSelectedIndex());
/* 2756 */             InterfaceGrafica.this.controle.salvaScript(InterfaceGrafica.this.painelConfig.getPainelConfigGeral()
/* 2757 */               .getTfScript().getText());
/*      */             
/* 2759 */             if ((!InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfEndServidor().getText().equals("")) && 
/* 2760 */               (!InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfUsuario().getText().equals("")) && 
/* 2761 */               (!InterfaceGrafica.this.painelConfig.getPainelSMTP().getPfSenha().getPassword().equals("")))
/*      */             {
/* 2763 */               InterfaceGrafica.this.controle.setEnderecoSMTP(InterfaceGrafica.this.painelConfig.getPainelSMTP()
/* 2764 */                 .getTfEndServidor().getText());
/* 2765 */               InterfaceGrafica.this.controle.setUsuario(InterfaceGrafica.this.painelConfig.getPainelSMTP()
/* 2766 */                 .getTfUsuario().getText());
/* 2767 */               InterfaceGrafica.this.controle.setSenha(InterfaceGrafica.this.painelConfig.getPainelSMTP().getPfSenha()
/* 2768 */                 .getPassword().toString());
/*      */             }
/* 2770 */             if (sucesso) {
/* 2771 */               pop = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2772 */                 InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 2773 */                 Idioma.getIdioma()).getString(
/* 2774 */                 "Sucesso_na_configuracao_geral"), 
/* 2775 */                 InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2776 */                 false, true);
/*      */             } else {
/* 2778 */               pop = new PopUp(
/* 2779 */                 InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2780 */                 InterfaceGrafica.this.caminhoFiguras, 
/*      */                 
/* 2782 */                 ResourceBundle.getBundle(Idioma.getIdioma())
/* 2783 */                 .getString(
/* 2784 */                 "Entre_com_um_valor_valido_para_a_porta_de_comunicacao_remota"), 
/* 2785 */                 InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2786 */                 true, true);
/*      */             }
/*      */             
/*      */           }
/* 2790 */           else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelSMTP().getBtnOk()) { String[] temp;
/* 2791 */             if (InterfaceGrafica.this.painelConfig.getPainelSMTP().isPortaValida())
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2806 */               if ((InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfEndServidor().getText().equals("")) || 
/* 2807 */                 (InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfPorta().getText().equals("")))
/*      */               {
/* 2809 */                 InterfaceGrafica.this.painelConfig.getPainelMensg().clearEmail();
/* 2810 */                 InterfaceGrafica.this.controle.salvaMensagens(InterfaceGrafica.this.painelConfig.getPainelMensg()
/* 2811 */                   .getCheckBoxSelected());
/*      */                 
/* 2813 */                 sucesso = new PopUp(
/* 2814 */                   InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2815 */                   InterfaceGrafica.this.caminhoFiguras, 
/*      */                   
/* 2817 */                   ResourceBundle.getBundle(Idioma.getIdioma())
/* 2818 */                   .getString(
/* 2819 */                   "O_sistema_nao_podera_lancar_email_ate_que_os_campos_de_endereco_do_gerente_e_porta_de_envio_sejam_preenchidos__Todo_o_envio_de_mensagens_por_email_foi_cancelado"), 
/* 2820 */                   InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2821 */                   false, true);
/*      */               } else {
/* 2823 */                 temp = 
/* 2824 */                   InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfDestinatario().getText().split(", ");
/* 2825 */                 InterfaceGrafica.this.controle
/* 2826 */                   .configuraEmail(temp, InterfaceGrafica.this.painelConfig
/* 2827 */                   .getPainelSMTP().getTfRemetente()
/* 2828 */                   .getText(), InterfaceGrafica.this.painelConfig
/* 2829 */                   .getPainelSMTP().getTfEndServidor()
/* 2830 */                   .getText(), InterfaceGrafica.this.painelConfig
/* 2831 */                   .getPainelSMTP().getPorta(), 
/* 2832 */                   InterfaceGrafica.this.painelConfig.getPainelSMTP()
/* 2833 */                   .getCbAutenticacao()
/* 2834 */                   .isSelected(), InterfaceGrafica.this.painelConfig
/* 2835 */                   .getPainelSMTP().getTfUsuario()
/* 2836 */                   .getText(), InterfaceGrafica.this.painelConfig
/* 2837 */                   .getPainelSMTP().getPfSenha()
/* 2838 */                   .getText());
/* 2839 */                 pop = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2840 */                   InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 2841 */                   Idioma.getIdioma()).getString(
/* 2842 */                   "Sucesso_na_configuracao_do_email"), 
/* 2843 */                   InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2844 */                   false, true);
/*      */               }
/*      */             } else {
/* 2847 */               temp = new PopUp(
/* 2848 */                 InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2849 */                 InterfaceGrafica.this.caminhoFiguras, 
/*      */                 
/* 2851 */                 ResourceBundle.getBundle(Idioma.getIdioma())
/* 2852 */                 .getString(
/* 2853 */                 "Entre_com_um_valor_valido_para_a_porta_de_envio_do_smtp"), 
/* 2854 */                 InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 2855 */                 true, true);
/*      */             }
/*      */             
/*      */ 
/*      */           }
/* 2860 */           else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelConfigGeral()
/* 2861 */             .getBtnCancel())
/*      */           {
/* 2863 */             InterfaceGrafica.this.painelConfig.getPainelConfigGeral().getTfPortaShutdownRemoto().setText(Integer.toString(InterfaceGrafica.this.controle.getPortaRemota()));
/* 2864 */             InterfaceGrafica.this.painelConfig.getPainelConfigGeral().getCbShutdownRemoto()
/* 2865 */               .setSelected(InterfaceGrafica.this.controle.getModoRemoto());
/*      */             
/* 2867 */             InterfaceGrafica.this.painelConfig.getPainelConfigGeral().setFlag(false);
/*      */ 
/*      */           }
/* 2870 */           else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelSMTP()
/* 2871 */             .getBtnCancel()) {
/* 2872 */             String[] tempDest = InterfaceGrafica.this.controle.getDestinatariosPersistencia();
/* 2873 */             String tempDest2 = "";
/* 2874 */             for (int i = 0; i < tempDest.length; i++) {
/* 2875 */               tempDest2 = tempDest2 + tempDest[i] + ", ";
/*      */             }
/* 2877 */             if (InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfDestinatario().getText().equals(", ")) {
/* 2878 */               InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfDestinatario().setText("");
/*      */             }
/* 2880 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfDestinatario().setText(
/* 2881 */               tempDest2);
/*      */             
/* 2883 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfEndServidor().setText(
/* 2884 */               InterfaceGrafica.this.controle.getEnderecoSMTPPersistencia());
/*      */             
/* 2886 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfPorta().setText(Integer.toString(
/* 2887 */               InterfaceGrafica.this.controle.getPortaSMTPPersistencia()));
/* 2888 */             System.out.println("Porta-canceçameto: " + InterfaceGrafica.this.controle.getPortaSMTPPersistencia());
/*      */             
/* 2890 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfRemetente().setText(
/* 2891 */               InterfaceGrafica.this.controle.getRemetentePersistencia());
/*      */             
/* 2893 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getTfUsuario().setText(
/* 2894 */               InterfaceGrafica.this.controle.getUsuarioPersistencia());
/*      */             
/* 2896 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getPfSenha().setText(
/* 2897 */               InterfaceGrafica.this.controle.getSenhaPersistencia());
/*      */             
/* 2899 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getCbAutenticacao().setSelected(
/* 2900 */               InterfaceGrafica.this.controle.getFlagAutenticacoPersistencia());
/*      */             
/* 2902 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().setFlag(false);
/*      */             
/* 2904 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().setProvedor(
/* 2905 */               InterfaceGrafica.this.controle.getProvedorEscolhidoPersitencia());
/*      */             
/* 2907 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().getCmbProvedores().setSelectedItem(
/* 2908 */               InterfaceGrafica.this.controle.getProvedorEscolhidoPersitencia());
/*      */             
/* 2910 */             InterfaceGrafica.this.painelConfig.getPainelSMTP().atualizarCamposEmail(
/* 2911 */               InterfaceGrafica.this.controle.getProvedorEscolhidoPersitencia());
/*      */ 
/*      */ 
/*      */           }
/* 2915 */           else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelSNMP().getBtnOk()) {
/* 2916 */             InterfaceGrafica.this.btnSNMPOnClick();
/*      */ 
/*      */           }
/* 2919 */           else if (ae.getSource() == InterfaceGrafica.this.painelConfig.getPainelSNMP()
/* 2920 */             .getBtnCancel()) {
/* 2921 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().getTfPedidos().setText(
/* 2922 */               Integer.toString(InterfaceGrafica.this.controle.getPortaPedidos()));
/*      */             
/* 2924 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().getTfLeitura().setText(
/* 2925 */               InterfaceGrafica.this.controle.getComunidadeLeitura());
/*      */             
/* 2927 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().getTfEscrita().setText(
/* 2928 */               InterfaceGrafica.this.controle.getComunidadeEscrita());
/*      */             
/* 2930 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().getTfGerente().setText(
/* 2931 */               InterfaceGrafica.this.controle.getEnderecoGerente());
/*      */             
/* 2933 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().getTfEnvio().setText(
/* 2934 */               Integer.toString(InterfaceGrafica.this.controle.getPortaEnvio()));
/*      */             
/* 2936 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().getCbSNMP().setSelectedIndex(
/* 2937 */               InterfaceGrafica.this.controle.getVSNMP());
/*      */             
/* 2939 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().getCbTransporte()
/* 2940 */               .setSelectedIndex(
/* 2941 */               InterfaceGrafica.this.controle.getProtocoloTransportePersistencia());
/*      */             
/* 2943 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().setFlagLeitura(false);
/* 2944 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().setFlagEscrita(false);
/* 2945 */             InterfaceGrafica.this.painelConfig.getPainelSNMP().setFlag(false);
/*      */           } else {
/*      */             Calendar calendar;
/* 2948 */             if (ae.getSource() == InterfaceGrafica.this.painelComandos.getBtnAgendar())
/*      */             {
/* 2950 */               calendar = Calendar.getInstance();
/* 2951 */               calendar.setLenient(true);
/*      */               
/* 2953 */               if (InterfaceGrafica.this.painelComandos.getDiasSemana()[(calendar.get(7) - 1)] != 0) {
/* 2954 */                 Calendar compare = Calendar.getInstance();
/* 2955 */                 compare.set(calendar.get(1), calendar
/* 2956 */                   .get(2), calendar
/* 2957 */                   .get(5), InterfaceGrafica.this.painelComandos
/* 2958 */                   .getHoraDesligar(), InterfaceGrafica.this.painelComandos
/* 2959 */                   .getMinutoDesligar());
/*      */                 
/* 2961 */                 calendar.add(12, 5);
/*      */                 
/* 2963 */                 int result = compare.compareTo(calendar);
/* 2964 */                 if (result > 0) {
/* 2965 */                   InterfaceGrafica.this.btnAgendarOnClick();
/*      */                 }
/*      */                 else {
/* 2968 */                   calendar.add(12, -5);
/* 2969 */                   result = compare.compareTo(calendar);
/* 2970 */                   if (result > 0) {
/* 2971 */                     PopUp pop = new PopUp(
/* 2972 */                       InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 2973 */                       InterfaceGrafica.this.caminhoFiguras, 
/*      */                       
/* 2975 */                       ResourceBundle.getBundle(Idioma.getIdioma())
/* 2976 */                       .getString(
/* 2977 */                       "Tempo_para_desligamento_do_SO_provavelmente_insuficiente__Deseja_continuar"), 
/* 2978 */                       InterfaceGrafica.this.caminhoFiguras, 10, 10, 
/* 2979 */                       InterfaceGrafica.this, false, false);
/* 2980 */                     pop.getBtnYes().addActionListener(
/* 2981 */                       new ActionListener()
/*      */                       {
/*      */                         public void actionPerformed(ActionEvent ae) {
/* 2984 */                           InterfaceGrafica.this.btnAgendarOnClick();
/* 2985 */                           InterfaceGrafica.this.controle.encerraSO();
/* 2986 */                           InterfaceGrafica.this.encerraAplicativo();
/*      */                         }
/*      */                       });
/*      */                   } else {
/* 2990 */                     InterfaceGrafica.this.btnAgendarOnClick();
/*      */                   }
/*      */                 }
/*      */               }
/*      */               else {
/* 2995 */                 InterfaceGrafica.this.btnAgendarOnClick();
/*      */               }
/*      */               
/*      */ 
/*      */             }
/* 3000 */             else if (ae.getSource() == InterfaceGrafica.this.painelComandos.getBtnAgendar2())
/*      */             {
/* 3002 */               if (InterfaceGrafica.this.painelComandos.getCbAutonomia().isSelected()) {
/* 3003 */                 InterfaceGrafica.this.controle.setFlagShutFimAut(true);
/* 3004 */                 if (InterfaceGrafica.this.painelComandos.isTempoAutonomiaValido()) {
/* 3005 */                   InterfaceGrafica.this.controle.setAutonomiaMinima(InterfaceGrafica.this.painelComandos
/* 3006 */                     .getTempoAutonomia());
/* 3007 */                   calendar = new PopUp(
/* 3008 */                     InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3009 */                     InterfaceGrafica.this.caminhoFiguras, 
/*      */                     
/* 3011 */                     ResourceBundle.getBundle(Idioma.getIdioma())
/* 3012 */                     .getString(
/* 3013 */                     "Modificacao_de_tempo_de_shutdown_apos_fim_de_autonomia_foi_realizado_com_sucesso"), 
/* 3014 */                     InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 3015 */                     false, true);
/*      */                 } else {
/* 3017 */                   calendar = new PopUp(
/* 3018 */                     InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3019 */                     InterfaceGrafica.this.caminhoFiguras, 
/*      */                     
/* 3021 */                     ResourceBundle.getBundle(Idioma.getIdioma())
/* 3022 */                     .getString(
/* 3023 */                     "Modificacao_nao_confirmada__Entre_com_um_valor_valido"), 
/* 3024 */                     InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 3025 */                     true, true);
/*      */                 }
/*      */               }
/*      */               
/* 3029 */               if (InterfaceGrafica.this.painelComandos.getCbTempoFalha().isSelected()) {
/* 3030 */                 InterfaceGrafica.this.controle.setShutdownTempoFalha(true);
/* 3031 */                 if (InterfaceGrafica.this.painelComandos.isTempoFalhaValido()) {
/* 3032 */                   InterfaceGrafica.this.controle.setTempoFalha(InterfaceGrafica.this.painelComandos.getTempoFalha());
/* 3033 */                   calendar = new PopUp(
/* 3034 */                     InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3035 */                     InterfaceGrafica.this.caminhoFiguras, 
/*      */                     
/* 3037 */                     ResourceBundle.getBundle(Idioma.getIdioma())
/* 3038 */                     .getString(
/* 3039 */                     "Modificacao_de_tempo_de_shutdown_apos_falha_na_rede_eletrica_foi_realizado_com_sucesso"), 
/* 3040 */                     InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 3041 */                     false, true);
/*      */                 } else {
/* 3043 */                   calendar = new PopUp(
/* 3044 */                     InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3045 */                     InterfaceGrafica.this.caminhoFiguras, 
/*      */                     
/* 3047 */                     ResourceBundle.getBundle(Idioma.getIdioma())
/* 3048 */                     .getString(
/* 3049 */                     "Modificacao_nao_confirmada__Entre_com_um_valor_valido"), 
/* 3050 */                     InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 3051 */                     true, true);
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */             }
/* 3057 */             else if (ae.getSource() == InterfaceGrafica.this.painelComandos.getBtnShutdown()) {
/* 3058 */               PopUp pop = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3059 */                 InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 3060 */                 Idioma.getIdioma()).getString(
/* 3061 */                 "Deseja_realizar_o_shutdown_imediato"), 
/* 3062 */                 InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, false, 
/* 3063 */                 false);
/* 3064 */               pop.getBtnYes().addActionListener(new ActionListener()
/*      */               {
/* 3066 */                 public void actionPerformed(ActionEvent ae) { InterfaceGrafica.this.controle.desligaUPS(); }
/*      */               });
/*      */             } else {
/*      */               PopUp pop;
/* 3070 */               if (ae.getSource() == InterfaceGrafica.this.painelComandos.getBtnShutdownReligamento()) {
/* 3071 */                 pop = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3072 */                   InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 3073 */                   Idioma.getIdioma()).getString(
/* 3074 */                   "Deseja_realizar_o_shutdown_com_religamento"), 
/* 3075 */                   InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, false, 
/* 3076 */                   false);
/* 3077 */                 pop.getBtnYes().addActionListener(new ActionListener() {
/*      */                   public void actionPerformed(ActionEvent ae) {
/* 3079 */                     InterfaceGrafica.this.controle.religaUPS();
/*      */                   }
/*      */                   
/*      */ 
/*      */                 });
/*      */               }
/* 3085 */               else if (ae.getSource() == InterfaceGrafica.this.painelHistorico.getBtnLimparSelecao()) {
/* 3086 */                 if (InterfaceGrafica.this.painelHistorico.getTableModel().getRowCount() != 0)
/*      */                 {
/* 3088 */                   if (!InterfaceGrafica.this.painelHistorico.getRow()) {
/* 3089 */                     pop = new PopUp(InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3090 */                       InterfaceGrafica.this.caminhoFiguras, ResourceBundle.getBundle(
/* 3091 */                       Idioma.getIdioma()).getString(
/* 3092 */                       "Linha_vazia__Escolha_um_registro_valido"), 
/* 3093 */                       InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 3094 */                       true, true);
/*      */                   } else {
/* 3096 */                     PopUp pop2 = new PopUp(
/* 3097 */                       InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3098 */                       InterfaceGrafica.this.caminhoFiguras, 
/*      */                       
/* 3100 */                       ResourceBundle.getBundle(Idioma.getIdioma())
/* 3101 */                       .getString(
/* 3102 */                       "Deseja_apagar_o_registro_selecionado_do_historico"), 
/* 3103 */                       InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, 
/* 3104 */                       false, false);
/*      */                     
/* 3106 */                     pop2.getBtnYes().addActionListener(new ActionListener()
/*      */                     {
/*      */                       public void actionPerformed(ActionEvent e) {
/* 3109 */                         if (InterfaceGrafica.this.controle.excluirEvento(InterfaceGrafica.this.painelHistorico.getSelectedRow())) {
/* 3110 */                           InterfaceGrafica.this.painelHistorico.getTableEvento().removeRow(
/* 3111 */                             InterfaceGrafica.this.painelHistorico.getSelectedRow());
/* 3112 */                           InterfaceGrafica.this.painelHistorico.setSelectedRow(-1);
/*      */                         } else {
/* 3114 */                           PopUp localPopUp = new PopUp(
/* 3115 */                             InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3116 */                             InterfaceGrafica.this.caminhoFiguras, 
/*      */                             
/* 3118 */                             ResourceBundle.getBundle(Idioma.getIdioma())
/* 3119 */                             .getString(
/* 3120 */                             "Erro_ao_apagar_o_registro_selecionado_do_historico"), 
/* 3121 */                             InterfaceGrafica.this.caminhoFiguras, 10, 10, 
/* 3122 */                             InterfaceGrafica.this, true, true);
/*      */                         }
/*      */                         
/*      */                       }
/* 3126 */                     });
/* 3127 */                     pop2.getBtnNo().addActionListener(new ActionListener()
/*      */                     {
/*      */ 
/*      */ 
/*      */ 
/*      */                       public void actionPerformed(ActionEvent e) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     });
/*      */ 
/*      */ 
/*      */ 
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */               }
/* 3151 */               else if ((ae.getSource() == InterfaceGrafica.this.painelHistorico.getBtnLimparTudo()) && 
/* 3152 */                 (InterfaceGrafica.this.painelHistorico.getTableModel().getRowCount() != 0))
/*      */               {
/* 3154 */                 final ListSelectionModel lsm = InterfaceGrafica.this.painelHistorico.getTabelaAlarmes().getSelectionModel();
/* 3155 */                 lsm.setSelectionMode(2);
/* 3156 */                 InterfaceGrafica.this.painelHistorico.getTabelaAlarmes().selectAll();
/* 3157 */                 PopUp pop = new PopUp(
/* 3158 */                   InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3159 */                   InterfaceGrafica.this.caminhoFiguras, 
/*      */                   
/* 3161 */                   ResourceBundle.getBundle(Idioma.getIdioma())
/* 3162 */                   .getString(
/* 3163 */                   "Deseja_apagar_todos_os_registros_do_historico"), 
/* 3164 */                   InterfaceGrafica.this.caminhoFiguras, 10, 10, InterfaceGrafica.this, false, 
/* 3165 */                   false);
/*      */                 
/* 3167 */                 pop.getBtnYes().addActionListener(new ActionListener()
/*      */                 {
/*      */                   public void actionPerformed(ActionEvent e) {
/* 3170 */                     if (InterfaceGrafica.this.controle.excluirTodosEventos()) {
/* 3171 */                       InterfaceGrafica.this.painelHistorico.limpaTabela();
/*      */                     } else {
/* 3173 */                       PopUp pop = new PopUp(
/* 3174 */                         InterfaceGrafica.this.caminhoFiguras + "PopUp.png", 
/* 3175 */                         InterfaceGrafica.this.caminhoFiguras, 
/* 3176 */                         ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 3177 */                         "Erro_ao_apagar_todos_os_registros_do_historico"), 
/* 3178 */                         InterfaceGrafica.this.caminhoFiguras, 10, 10, 
/* 3179 */                         InterfaceGrafica.this, true, true);
/* 3180 */                       lsm.setSelectionMode(0);
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/* 3185 */                 });
/* 3186 */                 pop.getBtnNo().addActionListener(new ActionListener() {
/*      */                   public void actionPerformed(ActionEvent e) {
/* 3188 */                     InterfaceGrafica.this.painelHistorico.getTabelaAlarmes().clearSelection();
/* 3189 */                     lsm
/* 3190 */                       .setSelectionMode(0);
/*      */                   }
/*      */                 });
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3200 */     public void mouseClicked(MouseEvent me) { if (InterfaceGrafica.this.monitor) {
/* 3201 */         InterfaceGrafica.this.painelMonitoramento.coletaDados();
/* 3202 */       } else if (InterfaceGrafica.this.graficos) {
/* 3203 */         InterfaceGrafica.this.painelGraficos.restartCharts();
/*      */       }
/* 3205 */       InterfaceGrafica.this.setVisible(true);
/* 3206 */       InterfaceGrafica.this.setState(0);
/*      */     }
/*      */     
/*      */ 
/*      */     public void mouseReleased(MouseEvent me) {}
/*      */     
/*      */ 
/*      */     public void mouseEntered(MouseEvent me) {}
/*      */     
/*      */ 
/*      */     public void mouseExited(MouseEvent me) {}
/*      */     
/*      */ 
/*      */     public void mousePressed(MouseEvent me) {}
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMensagens()
/*      */   {
/* 3225 */     this.controle.setMensagens(this.painelConfig.getPainelMensg()
/* 3226 */       .getCheckBoxSelected());
/* 3227 */     this.controle.salvaMensagens(this.painelConfig.getPainelMensg()
/* 3228 */       .getCheckBoxSelected());
/* 3229 */     this.energiaEmail = this.painelConfig.getPainelMensg()
/* 3230 */       .getCheckBoxSelected()[0][0];
/* 3231 */     this.energiaPop = this.painelConfig.getPainelMensg()
/* 3232 */       .getCheckBoxSelected()[0][1];
/* 3233 */     this.bateriaEmail = this.painelConfig.getPainelMensg()
/* 3234 */       .getCheckBoxSelected()[1][0];
/* 3235 */     this.bateriaPop = this.painelConfig.getPainelMensg()
/* 3236 */       .getCheckBoxSelected()[1][1];
/* 3237 */     this.cargaEmail = this.painelConfig.getPainelMensg()
/* 3238 */       .getCheckBoxSelected()[2][0];
/* 3239 */     this.cargaPop = this.painelConfig.getPainelMensg()
/* 3240 */       .getCheckBoxSelected()[2][1];
/* 3241 */     this.temperaturaEmail = this.painelConfig.getPainelMensg()
/* 3242 */       .getCheckBoxSelected()[3][0];
/* 3243 */     this.temperaturaPop = this.painelConfig.getPainelMensg()
/* 3244 */       .getCheckBoxSelected()[3][1];
/* 3245 */     this.bateriaUsoEmail = this.painelConfig.getPainelMensg()
/* 3246 */       .getCheckBoxSelected()[4][0];
/* 3247 */     this.bateriaUsoPop = this.painelConfig.getPainelMensg()
/* 3248 */       .getCheckBoxSelected()[4][1];
/* 3249 */     this.comEmail = this.painelConfig.getPainelMensg()
/* 3250 */       .getCheckBoxSelected()[5][0];
/*      */   }
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\InterfaceGrafica.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */