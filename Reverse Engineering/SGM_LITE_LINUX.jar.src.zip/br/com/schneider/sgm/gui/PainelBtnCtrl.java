/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelBtnCtrl
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 4826893105375689656L;
/*     */   private CardLayout card;
/*     */   private JPanel painelFundo;
/*     */   private JButton btnGeral;
/*     */   private JButton btnMensagens;
/*     */   private JButton btnUPS;
/*     */   private PainelUPS painelUPS;
/*     */   private PainelMensg painelMensg;
/*     */   private PainelGeral painelGeral;
/*     */   private PainelConfig painelConfig;
/*     */   private PainelSMTP painelSMTP;
/*     */   private PainelSNMP painelSNMP;
/*     */   private PainelAutoTeste painelAutoTeste;
/*     */   private JButton btnSNMP;
/*     */   private JButton btnSMTP;
/*     */   private String caminhoFiguras;
/*     */   private InterfaceGrafica interfaceGrafica;
/*     */   private boolean flagJanela;
/*     */   private JButton btnAutoTeste;
/*     */   
/*     */   public PainelBtnCtrl(String caminhoFiguras, InterfaceGrafica gui)
/*     */   {
/* 128 */     this.interfaceGrafica = gui;
/* 129 */     this.caminhoFiguras = caminhoFiguras;
/* 130 */     this.card = PainelConfig.getCard();
/* 131 */     this.painelFundo = PainelConfig.getPanelSlave();
/* 132 */     initComponents();
/* 133 */     addListeners();
/* 134 */     validarIdioma();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addListeners()
/*     */   {
/* 146 */     this.btnGeral.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 148 */         PainelBtnCtrl.this.card = PainelConfig.getCard();
/* 149 */         PainelBtnCtrl.this.painelFundo = PainelConfig.getPanelSlave();
/* 150 */         PainelBtnCtrl.this.card.show(PainelBtnCtrl.this.painelFundo, "painelGeral");
/* 151 */         PainelBtnCtrl.this.painelUpsChanged();
/* 152 */         PainelBtnCtrl.this.painelMensgChanged();
/* 153 */         PainelBtnCtrl.this.painelSNMPChanged();
/* 154 */         PainelBtnCtrl.this.painelSMTPChanged();
/* 155 */         PainelBtnCtrl.this.painelAutoTesteChanged();
/*     */       }
/* 157 */     });
/* 158 */     this.btnMensagens.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 160 */         PainelBtnCtrl.this.card = PainelConfig.getCard();
/* 161 */         PainelBtnCtrl.this.painelFundo = PainelConfig.getPanelSlave();
/* 162 */         PainelBtnCtrl.this.card.show(PainelBtnCtrl.this.painelFundo, "painelMensagens");
/* 163 */         PainelBtnCtrl.this.painelUpsChanged();
/* 164 */         PainelBtnCtrl.this.painelGeralChanged();
/* 165 */         PainelBtnCtrl.this.painelSNMPChanged();
/* 166 */         PainelBtnCtrl.this.painelSMTPChanged();
/* 167 */         PainelBtnCtrl.this.painelAutoTesteChanged();
/*     */       }
/* 169 */     });
/* 170 */     this.btnUPS.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 172 */         PainelBtnCtrl.this.card = PainelConfig.getCard();
/* 173 */         PainelBtnCtrl.this.painelFundo = PainelConfig.getPanelSlave();
/* 174 */         PainelBtnCtrl.this.card.show(PainelBtnCtrl.this.painelFundo, "painelUPS");
/* 175 */         PainelBtnCtrl.this.painelMensgChanged();
/* 176 */         PainelBtnCtrl.this.painelGeralChanged();
/* 177 */         PainelBtnCtrl.this.painelSNMPChanged();
/* 178 */         PainelBtnCtrl.this.painelSMTPChanged();
/* 179 */         PainelBtnCtrl.this.painelAutoTesteChanged();
/*     */       }
/* 181 */     });
/* 182 */     this.btnSMTP.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 184 */         PainelBtnCtrl.this.card = PainelConfig.getCard();
/* 185 */         PainelBtnCtrl.this.painelFundo = PainelConfig.getPanelSlave();
/* 186 */         PainelBtnCtrl.this.card.show(PainelBtnCtrl.this.painelFundo, "painelSMTP");
/* 187 */         PainelBtnCtrl.this.painelMensgChanged();
/* 188 */         PainelBtnCtrl.this.painelGeralChanged();
/* 189 */         PainelBtnCtrl.this.painelUpsChanged();
/* 190 */         PainelBtnCtrl.this.painelSNMPChanged();
/* 191 */         PainelBtnCtrl.this.painelAutoTesteChanged();
/*     */       }
/* 193 */     });
/* 194 */     this.btnSNMP.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 196 */         PainelBtnCtrl.this.card = PainelConfig.getCard();
/* 197 */         PainelBtnCtrl.this.painelFundo = PainelConfig.getPanelSlave();
/* 198 */         PainelBtnCtrl.this.card.show(PainelBtnCtrl.this.painelFundo, "painelSNMP");
/* 199 */         PainelBtnCtrl.this.painelMensgChanged();
/* 200 */         PainelBtnCtrl.this.painelGeralChanged();
/* 201 */         PainelBtnCtrl.this.painelUpsChanged();
/* 202 */         PainelBtnCtrl.this.painelSMTPChanged();
/* 203 */         PainelBtnCtrl.this.painelAutoTesteChanged();
/*     */       }
/*     */       
/* 206 */     });
/* 207 */     this.btnAutoTeste.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 209 */         PainelBtnCtrl.this.card = PainelConfig.getCard();
/* 210 */         PainelBtnCtrl.this.painelFundo = PainelConfig.getPanelSlave();
/* 211 */         PainelBtnCtrl.this.card.show(PainelBtnCtrl.this.painelFundo, "painelAutoTeste");
/* 212 */         PainelBtnCtrl.this.painelMensgChanged();
/* 213 */         PainelBtnCtrl.this.painelGeralChanged();
/* 214 */         PainelBtnCtrl.this.painelUpsChanged();
/* 215 */         PainelBtnCtrl.this.painelSMTPChanged();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configChanged()
/*     */   {
/* 228 */     if (this.painelUPS.getFlag())
/* 229 */       painelUpsChanged();
/* 230 */     if (this.painelMensg.getFlag())
/* 231 */       painelMensgChanged();
/* 232 */     if (this.painelGeral.getFlag())
/* 233 */       painelGeralChanged();
/* 234 */     if (this.painelSNMP.isFlag())
/* 235 */       painelSNMPChanged();
/* 236 */     if (this.painelSMTP.getFlag())
/* 237 */       painelSMTPChanged();
/* 238 */     if (this.painelAutoTeste.getFlag()) {
/* 239 */       painelAutoTesteChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConfigChanged()
/*     */   {
/* 249 */     if ((this.painelUPS.getFlag()) || 
/* 250 */       (this.painelMensg.getFlag()) || 
/* 251 */       (this.painelGeral.getFlag()) || (this.painelSNMP.isFlag()) || 
/* 252 */       (this.painelSMTP.getFlag())) {
/* 253 */       return true;
/*     */     }
/* 255 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void painelSMTPChanged()
/*     */   {
/* 263 */     if (this.painelSMTP.getFlag()) {
/* 264 */       this.card = PainelConfig.getCard();
/* 265 */       this.painelFundo = PainelConfig.getPanelSlave();
/* 266 */       this.card.show(this.painelFundo, "painelSMTP");
/* 267 */       PopUp pop = new PopUp(
/* 268 */         this.caminhoFiguras + "PopUp.png", 
/* 269 */         this.caminhoFiguras, 
/*     */         
/* 271 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 272 */         .getString(
/* 273 */         "Deseja_confirmar_as_modificacoes_na_configuracao_do_email"), 
/* 274 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, false);
/* 275 */       pop.getBtnYes().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 277 */           PainelBtnCtrl.this.painelSMTP.getBtnOk().doClick();
/*     */         }
/* 279 */       });
/* 280 */       pop.getBtnNo().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 282 */           PainelBtnCtrl.this.painelSMTP.getBtnCancel().doClick();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void painelUpsChanged()
/*     */   {
/* 293 */     if (this.painelUPS.getFlag()) {
/* 294 */       this.card = PainelConfig.getCard();
/* 295 */       this.painelFundo = PainelConfig.getPanelSlave();
/* 296 */       this.card.show(this.painelFundo, "painelUPS");
/* 297 */       PopUp pop = new PopUp(
/* 298 */         this.caminhoFiguras + "PopUp.png", 
/* 299 */         this.caminhoFiguras, 
/*     */         
/* 301 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 302 */         .getString(
/* 303 */         "Deseja_confirmar_as_modificacoes_na_configuracao_do_UPS"), 
/* 304 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, false);
/* 305 */       pop.getBtnYes().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 307 */           PainelBtnCtrl.this.painelUPS.getBtnOk().doClick();
/*     */         }
/* 309 */       });
/* 310 */       pop.getBtnNo().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 312 */           PainelBtnCtrl.this.painelUPS.getBtnCancel().doClick();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void painelAutoTesteChanged()
/*     */   {
/* 324 */     if (this.painelAutoTeste.getFlag()) {
/* 325 */       this.card = PainelConfig.getCard();
/* 326 */       this.painelFundo = PainelConfig.getPanelSlave();
/* 327 */       this.card.show(this.painelFundo, "painelAutoTeste");
/* 328 */       PopUp pop = new PopUp(
/* 329 */         this.caminhoFiguras + "PopUp.png", 
/* 330 */         this.caminhoFiguras, 
/*     */         
/* 332 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 333 */         .getString(
/* 334 */         "Deseja_confirmar_as_modificacoes_na_configuracao_de_auto_teste"), 
/* 335 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, false);
/* 336 */       pop.getBtnYes().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 338 */           PainelBtnCtrl.this.painelAutoTeste.getBtnOk().doClick();
/*     */         }
/* 340 */       });
/* 341 */       pop.getBtnNo().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 343 */           PainelBtnCtrl.this.painelAutoTeste.getBtnCancel().doClick();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void painelMensgChanged()
/*     */   {
/* 355 */     if (this.painelMensg.getFlag()) {
/* 356 */       this.card = PainelConfig.getCard();
/* 357 */       this.painelFundo = PainelConfig.getPanelSlave();
/* 358 */       this.card.show(this.painelFundo, "painelMensagens");
/* 359 */       PopUp pop = new PopUp(
/* 360 */         this.caminhoFiguras + "PopUp.png", 
/* 361 */         this.caminhoFiguras, 
/*     */         
/* 363 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 364 */         .getString(
/* 365 */         "Deseja_confirmar_as_modificacoes_na_configuracao_de_mensagens"), 
/* 366 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, false);
/* 367 */       pop.getBtnYes().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 369 */           PainelBtnCtrl.this.painelMensg.getBtnOk().doClick();
/*     */         }
/* 371 */       });
/* 372 */       pop.getBtnNo().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 374 */           PainelBtnCtrl.this.painelMensg.getBtnCancel().doClick();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void painelGeralChanged()
/*     */   {
/* 386 */     if (this.painelGeral.getFlag()) {
/* 387 */       this.card = PainelConfig.getCard();
/* 388 */       this.painelFundo = PainelConfig.getPanelSlave();
/* 389 */       this.card.show(this.painelFundo, "painelGeral");
/*     */       
/* 391 */       PopUp pop = new PopUp(
/* 392 */         this.caminhoFiguras + "PopUp.png", 
/* 393 */         this.caminhoFiguras, 
/*     */         
/* 395 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 396 */         .getString(
/* 397 */         "Deseja_confirmar_as_modificacoes_na_configuracao_geral"), 
/* 398 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, false);
/* 399 */       pop.getBtnYes().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 401 */           PainelBtnCtrl.this.painelGeral.getBtnOk().doClick();
/*     */         }
/* 403 */       });
/* 404 */       pop.getBtnNo().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 406 */           PainelBtnCtrl.this.painelGeral.getBtnCancel().doClick();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void painelSNMPChanged()
/*     */   {
/* 418 */     if (this.painelSNMP.isFlag()) {
/* 419 */       this.card = PainelConfig.getCard();
/* 420 */       this.painelFundo = PainelConfig.getPanelSlave();
/* 421 */       this.card.show(this.painelFundo, "painelSNMP");
/*     */       
/* 423 */       PopUp pop = new PopUp(
/* 424 */         this.caminhoFiguras + "PopUp.png", 
/* 425 */         this.caminhoFiguras, 
/*     */         
/* 427 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 428 */         .getString(
/* 429 */         "Deseja_confirmar_as_modificacoes_na_configuracao_do_snmp"), 
/* 430 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, false);
/* 431 */       pop.getBtnYes().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 433 */           PainelBtnCtrl.this.painelSNMP.getBtnOk().doClick();
/*     */         }
/* 435 */       });
/* 436 */       pop.getBtnNo().addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 438 */           PainelBtnCtrl.this.painelSNMP.getBtnCancel().doClick();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 448 */     this.btnGeral.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 449 */       .getString("GERAL"));
/* 450 */     this.btnMensagens.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 451 */       .getString("MENSAGENS"));
/* 452 */     this.btnUPS.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 453 */       "UPS"));
/* 454 */     this.btnSMTP.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 455 */       "E_MAIL"));
/* 456 */     this.btnSNMP.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 457 */       "SNMP"));
/* 458 */     this.btnAutoTeste.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 459 */       "AUTO_TESTE"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 466 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 467 */     Dimension d = new Dimension(100, 300);
/* 468 */     Font fonte = new Font("Trebuchet", 1, 12);
/*     */     
/* 470 */     this.btnGeral = new JButton();
/* 471 */     this.btnMensagens = new JButton();
/* 472 */     this.btnUPS = new JButton();
/* 473 */     this.btnSMTP = new JButton();
/* 474 */     this.btnSNMP = new JButton();
/* 475 */     this.btnAutoTeste = new JButton();
/*     */     
/*     */ 
/*     */ 
/* 479 */     setLayout(new GridBagLayout());
/* 480 */     setBackground(new Color(255, 255, 255));
/* 481 */     setMaximumSize(d);
/* 482 */     setMinimumSize(d);
/* 483 */     setPreferredSize(d);
/* 484 */     setOpaque(false);
/*     */     
/*     */ 
/*     */ 
/* 488 */     this.btnGeral.setFont(fonte);
/* 489 */     this.btnGeral.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 490 */       .getString("GERAL"));
/* 491 */     this.btnGeral.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 492 */       new Color(160, 160, 160)));
/*     */     
/* 494 */     this.btnGeral.setFocusPainted(false);
/* 495 */     this.btnGeral.setHorizontalTextPosition(0);
/* 496 */     this.btnGeral.setMaximumSize(new Dimension(90, 26));
/* 497 */     this.btnGeral.setMinimumSize(new Dimension(90, 26));
/* 498 */     this.btnGeral.setPreferredSize(new Dimension(90, 26));
/* 499 */     gridBagConstraints.gridx = 0;
/* 500 */     gridBagConstraints.gridy = 1;
/* 501 */     gridBagConstraints.fill = 1;
/* 502 */     gridBagConstraints.insets = new Insets(30, 0, 13, 0);
/* 503 */     add(this.btnGeral, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 507 */     this.btnMensagens.setFont(fonte);
/* 508 */     this.btnMensagens.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 509 */       .getString("MENSAGENS"));
/* 510 */     this.btnMensagens.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 511 */       new Color(160, 160, 160)));
/* 512 */     this.btnMensagens.setFocusPainted(false);
/* 513 */     this.btnMensagens.setHorizontalTextPosition(0);
/* 514 */     this.btnMensagens.setMaximumSize(new Dimension(90, 26));
/* 515 */     this.btnMensagens.setMinimumSize(new Dimension(90, 26));
/* 516 */     this.btnMensagens.setPreferredSize(new Dimension(90, 26));
/* 517 */     gridBagConstraints.gridx = 0;
/* 518 */     gridBagConstraints.gridy = 3;
/* 519 */     gridBagConstraints.fill = 1;
/* 520 */     gridBagConstraints.insets = new Insets(0, 0, 13, 0);
/* 521 */     add(this.btnMensagens, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 525 */     this.btnUPS.setFont(fonte);
/* 526 */     this.btnUPS.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 527 */       "UPS"));
/* 528 */     this.btnUPS.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(
/* 529 */       160, 160, 160)));
/* 530 */     this.btnUPS.setFocusPainted(false);
/* 531 */     this.btnUPS.setHorizontalTextPosition(0);
/* 532 */     this.btnUPS.setMaximumSize(new Dimension(90, 26));
/* 533 */     this.btnUPS.setMinimumSize(new Dimension(90, 26));
/* 534 */     this.btnUPS.setPreferredSize(new Dimension(90, 26));
/* 535 */     gridBagConstraints.gridx = 0;
/* 536 */     gridBagConstraints.gridy = 5;
/* 537 */     gridBagConstraints.fill = 1;
/* 538 */     gridBagConstraints.insets = new Insets(0, 0, 13, 0);
/* 539 */     add(this.btnUPS, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 544 */     this.btnSMTP.setFont(fonte);
/* 545 */     this.btnSMTP.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 546 */       "SMTP"));
/* 547 */     this.btnSMTP.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 548 */       new Color(160, 160, 160)));
/*     */     
/* 550 */     this.btnSMTP.setFocusPainted(false);
/* 551 */     this.btnSMTP.setHorizontalTextPosition(0);
/* 552 */     this.btnSMTP.setMaximumSize(new Dimension(90, 26));
/* 553 */     this.btnSMTP.setMinimumSize(new Dimension(90, 26));
/* 554 */     this.btnSMTP.setPreferredSize(new Dimension(90, 26));
/* 555 */     gridBagConstraints.gridx = 0;
/* 556 */     gridBagConstraints.gridy = 7;
/* 557 */     gridBagConstraints.fill = 1;
/* 558 */     gridBagConstraints.insets = new Insets(0, 0, 13, 0);
/* 559 */     add(this.btnSMTP, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 563 */     this.btnSNMP.setFont(fonte);
/* 564 */     this.btnSNMP.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 565 */       "SNMP"));
/* 566 */     this.btnSNMP.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 567 */       new Color(160, 160, 160)));
/* 568 */     this.btnSNMP.setFocusPainted(false);
/* 569 */     this.btnSNMP.setHorizontalTextPosition(0);
/* 570 */     this.btnSNMP.setMaximumSize(new Dimension(90, 26));
/* 571 */     this.btnSNMP.setMinimumSize(new Dimension(90, 26));
/* 572 */     this.btnSNMP.setPreferredSize(new Dimension(90, 26));
/* 573 */     gridBagConstraints.gridx = 0;
/* 574 */     gridBagConstraints.gridy = 9;
/* 575 */     gridBagConstraints.fill = 1;
/* 576 */     gridBagConstraints.insets = new Insets(0, 0, 13, 0);
/* 577 */     add(this.btnSNMP, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JButton getBtnGeral()
/*     */   {
/* 604 */     return this.btnGeral;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnMensagens()
/*     */   {
/* 611 */     return this.btnMensagens;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnSMTP()
/*     */   {
/* 618 */     return this.btnSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnSNMP()
/*     */   {
/* 625 */     return this.btnSNMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnUPS()
/*     */   {
/* 632 */     return this.btnUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCaminhoFiguras()
/*     */   {
/* 639 */     return this.caminhoFiguras;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CardLayout getCard()
/*     */   {
/* 646 */     return this.card;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFlagJanela()
/*     */   {
/* 653 */     return this.flagJanela;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InterfaceGrafica getInterfaceGrafica()
/*     */   {
/* 660 */     return this.interfaceGrafica;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelConfig getPainelConfig()
/*     */   {
/* 667 */     return this.painelConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JPanel getPainelFundo()
/*     */   {
/* 674 */     return this.painelFundo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelGeral getPainelGeral()
/*     */   {
/* 681 */     return this.painelGeral;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelMensg getPainelMensg()
/*     */   {
/* 688 */     return this.painelMensg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelSMTP getPainelSMTP()
/*     */   {
/* 695 */     return this.painelSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelSNMP getPainelSNMP()
/*     */   {
/* 702 */     return this.painelSNMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelUPS getPainelUPS()
/*     */   {
/* 709 */     return this.painelUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnGeral(JButton btnGeral)
/*     */   {
/* 722 */     this.btnGeral = btnGeral;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnMensagens(JButton btnMensagens)
/*     */   {
/* 730 */     this.btnMensagens = btnMensagens;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnSMTP(JButton btnSMTP)
/*     */   {
/* 738 */     this.btnSMTP = btnSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnSNMP(JButton btnSNMP)
/*     */   {
/* 746 */     this.btnSNMP = btnSNMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnUPS(JButton btnUPS)
/*     */   {
/* 754 */     this.btnUPS = btnUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCaminhoFiguras(String caminhoFiguras)
/*     */   {
/* 762 */     this.caminhoFiguras = caminhoFiguras;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCard(CardLayout card)
/*     */   {
/* 770 */     this.card = card;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlagJanela(boolean flagJanela)
/*     */   {
/* 778 */     this.flagJanela = flagJanela;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInterfaceGrafica(InterfaceGrafica interfaceGrafica)
/*     */   {
/* 786 */     this.interfaceGrafica = interfaceGrafica;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelConfig(PainelConfig painelConfig)
/*     */   {
/* 794 */     this.painelConfig = painelConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelFundo(JPanel painelFundo)
/*     */   {
/* 802 */     this.painelFundo = painelFundo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelAutoTeste(PainelAutoTeste painelAutoTeste)
/*     */   {
/* 810 */     this.painelAutoTeste = painelAutoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelGeral(PainelGeral painelGeral)
/*     */   {
/* 818 */     this.painelGeral = painelGeral;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelMensg(PainelMensg painelMensg)
/*     */   {
/* 826 */     this.painelMensg = painelMensg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelSMTP(PainelSMTP painelSMTP)
/*     */   {
/* 834 */     this.painelSMTP = painelSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelSNMP(PainelSNMP painelSNMP)
/*     */   {
/* 842 */     this.painelSNMP = painelSNMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPainelUPS(PainelUPS painelUPS)
/*     */   {
/* 850 */     this.painelUPS = painelUPS;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelBtnCtrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */