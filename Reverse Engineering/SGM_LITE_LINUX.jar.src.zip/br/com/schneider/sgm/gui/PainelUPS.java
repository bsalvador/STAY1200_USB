/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.SoftBevelBorder;
/*     */ import javax.swing.event.CaretEvent;
/*     */ import javax.swing.event.CaretListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelUPS
/*     */   extends JPanel
/*     */ {
/*     */   private JButton btnCancel;
/*     */   private JButton btnOk;
/*     */   private ButtonGroup buttonGroup;
/*     */   private JComboBox comboBoxSerial;
/*     */   private JLabel labelAmperes;
/*     */   private JLabel labelBateria;
/*     */   private JLabel labelComunicacao;
/*     */   private JPanel panelFamilia;
/*     */   private JRadioButton radioRhino;
/*     */   private JRadioButton radioSolis;
/*     */   private JRadioButton radioStay;
/*     */   private JTextField textFieldExpanBat;
/*     */   private int expansorBateria;
/*     */   private String familia;
/*     */   private int tipoUps;
/* 125 */   private final int solis = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */   private final int rhino = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */   private final int stay = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean flag;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object itemCombo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JLabel labelNomeUPS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JTextField nomeUPS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String caminhoFiguras;
/*     */   
/*     */ 
/*     */ 
/*     */   private InterfaceGrafica interfaceGrafica;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PainelUPS(String caminhoFiguras, InterfaceGrafica interfaceGrafica)
/*     */   {
/* 173 */     initComponents();
/* 174 */     this.tipoUps = 1;
/* 175 */     addListeners();
/* 176 */     this.flag = false;
/* 177 */     this.caminhoFiguras = caminhoFiguras;
/* 178 */     this.interfaceGrafica = interfaceGrafica;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addListeners()
/*     */   {
/* 190 */     this.textFieldExpanBat.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 192 */         PainelUPS.this.flag = true;
/*     */       }
/*     */       
/* 195 */     });
/* 196 */     this.nomeUPS.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 198 */         PainelUPS.this.flag = true;
/*     */       }
/*     */       
/* 201 */     });
/* 202 */     this.radioStay.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 204 */         PainelUPS.this.flag = true;
/*     */       }
/*     */       
/* 207 */     });
/* 208 */     this.radioSolis.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 210 */         PainelUPS.this.flag = true;
/*     */       }
/* 212 */     });
/* 213 */     this.comboBoxSerial.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 215 */         PainelUPS.this.flag = true;
/*     */       }
/*     */       
/* 218 */     });
/* 219 */     this.btnCancel.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 221 */         if (PainelUPS.this.tipoUps == 1) {
/* 222 */           PainelUPS.this.radioSolis.setSelected(true);
/*     */         } else {
/* 224 */           PainelUPS.this.radioRhino.setSelected(true);
/*     */         }
/* 226 */         PainelUPS.this.textFieldExpanBat.setText(new Integer(PainelUPS.this.expansorBateria)
/* 227 */           .toString());
/* 228 */         PainelUPS.this.comboBoxSerial.setSelectedItem(PainelUPS.this.itemCombo);
/* 229 */         PainelUPS.this.flag = false;
/*     */       }
/*     */       
/* 232 */     });
/* 233 */     this.btnOk.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 235 */         PainelUPS.this.flag = false;
/* 236 */         PainelUPS.this.expansorBateria = PainelUPS.this.getExpansorBateria();
/* 237 */         if (PainelUPS.this.radioSolis.isSelected()) {
/* 238 */           PainelUPS.this.tipoUps = 1;
/*     */         } else
/* 240 */           PainelUPS.this.tipoUps = 2;
/* 241 */         PainelUPS.this.itemCombo = PainelUPS.this.comboBoxSerial.getSelectedItem();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTipoUps()
/*     */   {
/* 257 */     if (this.radioSolis.isSelected()) {
/* 258 */       this.tipoUps = 1;
/* 259 */     } else if (this.radioRhino.isSelected()) {
/* 260 */       this.tipoUps = 2;
/*     */     } else {
/* 262 */       this.tipoUps = 3;
/*     */     }
/* 264 */     return this.tipoUps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTipoUps2()
/*     */   {
/* 277 */     if (this.radioSolis.isSelected()) {
/* 278 */       this.tipoUps = 1;
/* 279 */       return "solis"; }
/* 280 */     if (this.radioRhino.isSelected()) {
/* 281 */       this.tipoUps = 2;
/* 282 */       return "rhino";
/*     */     }
/* 284 */     this.tipoUps = 3;
/* 285 */     return "stay";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPorta()
/*     */   {
/* 299 */     return (String)this.comboBoxSerial.getSelectedItem();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getExpansorBateria()
/*     */   {
/*     */     try
/*     */     {
/* 311 */       this.expansorBateria = new Integer(this.textFieldExpanBat.getText())
/* 312 */         .intValue();
/* 313 */       return this.expansorBateria;
/*     */     } catch (NumberFormatException e) {}
/* 315 */     return this.expansorBateria;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isExpansorBateriaValido()
/*     */   {
/*     */     PopUp pop;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 328 */       this.expansorBateria = new Integer(this.textFieldExpanBat.getText())
/* 329 */         .intValue();
/* 330 */       return true;
/*     */     } catch (NumberFormatException e) {
/* 332 */       pop = new PopUp(
/* 333 */         this.caminhoFiguras + "PopUp.png", 
/* 334 */         this.caminhoFiguras, 
/*     */         
/* 336 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 337 */         .getString(
/* 338 */         "Valor_invalido_para_o_expansor_de_bateria__entre_com_valor_valido"), 
/* 339 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, true, true); }
/* 340 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 350 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 351 */       "OK"));
/* 352 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 353 */       .getString("CANCELAR"));
/* 354 */     this.familia = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 355 */       "FAMILIA_UPS");
/* 356 */     this.panelFamilia.setBorder(BorderFactory.createTitledBorder(
/* 357 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 170)), 
/* 358 */       this.familia));
/* 359 */     this.radioSolis.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 360 */       .getString("SOLIS"));
/* 361 */     this.radioRhino.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 362 */       .getString("RHINO"));
/* 363 */     this.radioStay.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 364 */       .getString("STAY"));
/* 365 */     this.labelComunicacao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 366 */       .getString("PORTA_DE_COMUNICACAO"));
/* 367 */     this.labelBateria.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 368 */       .getString("EXPANSOR_DE_BATERIA"));
/* 369 */     this.labelAmperes.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 370 */       .getString("AMPERES__HORA"));
/* 371 */     this.labelNomeUPS.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 372 */       .getString("NOME_DO_UPS"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 382 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 383 */     Font fonte12 = new Font("Trebuchet", 0, 12);
/* 384 */     Font fonte12N = new Font("Trebuchet", 1, 12);
/*     */     
/* 386 */     this.buttonGroup = new ButtonGroup();
/* 387 */     this.panelFamilia = new JPanel();
/* 388 */     this.radioSolis = new JRadioButton();
/* 389 */     this.radioRhino = new JRadioButton();
/* 390 */     this.radioStay = new JRadioButton();
/* 391 */     this.labelBateria = new JLabel();
/* 392 */     this.textFieldExpanBat = new JTextField();
/* 393 */     this.labelAmperes = new JLabel();
/* 394 */     this.labelComunicacao = new JLabel();
/* 395 */     this.comboBoxSerial = new JComboBox();
/* 396 */     this.btnOk = new JButton();
/* 397 */     this.btnCancel = new JButton();
/* 398 */     this.familia = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 399 */       "FAMILIA_UPS");
/* 400 */     this.labelNomeUPS = new JLabel();
/* 401 */     this.nomeUPS = new JTextField();
/*     */     
/*     */ 
/*     */ 
/* 405 */     this.buttonGroup.add(this.radioRhino);
/* 406 */     this.buttonGroup.add(this.radioSolis);
/* 407 */     this.buttonGroup.add(this.radioStay);
/*     */     
/*     */ 
/*     */ 
/* 411 */     setLayout(new GridBagLayout());
/* 412 */     setMaximumSize(new Dimension(384, 335));
/* 413 */     setMinimumSize(new Dimension(384, 335));
/* 414 */     setOpaque(false);
/* 415 */     setPreferredSize(new Dimension(384, 335));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 420 */     this.panelFamilia.setLayout(new FlowLayout(1, 10, 5));
/* 421 */     this.panelFamilia.setBorder(BorderFactory.createTitledBorder(
/* 422 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 170)), 
/* 423 */       this.familia));
/* 424 */     this.panelFamilia.setMaximumSize(new Dimension(350, 50));
/* 425 */     this.panelFamilia.setMinimumSize(new Dimension(350, 50));
/* 426 */     this.panelFamilia.setPreferredSize(new Dimension(350, 50));
/* 427 */     this.panelFamilia.setOpaque(false);
/* 428 */     gridBagConstraints.gridx = 0;
/* 429 */     gridBagConstraints.gridy = 0;
/* 430 */     gridBagConstraints.gridwidth = 6;
/* 431 */     gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/* 432 */     add(this.panelFamilia, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 436 */     this.radioSolis.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 437 */       .getString("SOLIS"));
/* 438 */     this.radioSolis.setSelected(true);
/* 439 */     this.radioSolis.setFont(fonte12N);
/* 440 */     this.radioSolis.setOpaque(false);
/* 441 */     this.radioSolis.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 442 */     this.radioSolis.setFocusPainted(false);
/* 443 */     this.radioSolis.setMargin(new Insets(0, 0, 0, 0));
/* 444 */     this.panelFamilia.add(this.radioSolis);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 459 */     this.radioStay.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 460 */       .getString("STAY"));
/* 461 */     this.radioStay.setFont(fonte12N);
/* 462 */     this.radioStay.setOpaque(false);
/* 463 */     this.radioStay.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 464 */     this.radioStay.setFocusPainted(false);
/* 465 */     this.radioStay.setMargin(new Insets(0, 0, 0, 0));
/* 466 */     this.panelFamilia.add(this.radioStay);
/*     */     
/*     */ 
/*     */ 
/* 470 */     this.labelComunicacao.setFont(fonte12N);
/* 471 */     this.labelComunicacao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 472 */       .getString("PORTA_DE_COMUNICACAO"));
/* 473 */     gridBagConstraints.gridx = 0;
/* 474 */     gridBagConstraints.gridy = 2;
/* 475 */     gridBagConstraints.gridwidth = 3;
/* 476 */     gridBagConstraints.fill = 2;
/* 477 */     gridBagConstraints.anchor = 17;
/* 478 */     gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/* 479 */     add(this.labelComunicacao, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 483 */     this.labelBateria.setFont(fonte12N);
/* 484 */     this.labelBateria.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 485 */       .getString("EXPANSOR_DE_BATERIA"));
/* 486 */     gridBagConstraints.gridx = 0;
/* 487 */     gridBagConstraints.gridy = 6;
/* 488 */     gridBagConstraints.gridwidth = 2;
/* 489 */     gridBagConstraints.fill = 2;
/* 490 */     gridBagConstraints.anchor = 17;
/* 491 */     gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/* 492 */     add(this.labelBateria, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 496 */     this.textFieldExpanBat.setHorizontalAlignment(4);
/* 497 */     this.textFieldExpanBat.setText("0");
/* 498 */     this.textFieldExpanBat
/* 499 */       .setBorder(new SoftBevelBorder(1, new Color(
/* 500 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 501 */     this.textFieldExpanBat.setFont(fonte12);
/* 502 */     gridBagConstraints = new GridBagConstraints();
/* 503 */     gridBagConstraints.gridx = 3;
/* 504 */     gridBagConstraints.gridy = 6;
/* 505 */     gridBagConstraints.gridwidth = 1;
/* 506 */     gridBagConstraints.fill = 2;
/* 507 */     gridBagConstraints.anchor = 13;
/* 508 */     gridBagConstraints.insets = new Insets(0, 5, 10, 0);
/* 509 */     add(this.textFieldExpanBat, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 513 */     this.labelNomeUPS.setFont(fonte12N);
/* 514 */     this.labelNomeUPS.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 515 */       .getString("NOME_DO_UPS"));
/* 516 */     gridBagConstraints.gridx = 0;
/* 517 */     gridBagConstraints.gridy = 8;
/* 518 */     gridBagConstraints.gridwidth = 3;
/* 519 */     gridBagConstraints.fill = 2;
/* 520 */     gridBagConstraints.anchor = 17;
/* 521 */     gridBagConstraints.insets = new Insets(0, 0, 80, 0);
/* 522 */     add(this.labelNomeUPS, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 526 */     this.nomeUPS.setHorizontalAlignment(4);
/* 527 */     this.nomeUPS.setBorder(new SoftBevelBorder(1, new Color(
/* 528 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 529 */     this.nomeUPS.setFont(fonte12);
/* 530 */     gridBagConstraints = new GridBagConstraints();
/* 531 */     gridBagConstraints.gridx = 3;
/* 532 */     gridBagConstraints.gridy = 8;
/* 533 */     gridBagConstraints.gridwidth = 1;
/* 534 */     gridBagConstraints.fill = 2;
/* 535 */     gridBagConstraints.anchor = 13;
/* 536 */     gridBagConstraints.insets = new Insets(0, 5, 80, 0);
/* 537 */     add(this.nomeUPS, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 541 */     this.labelAmperes.setFont(fonte12);
/* 542 */     this.labelAmperes.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 543 */       .getString("AMPERES__HORA"));
/* 544 */     this.labelAmperes.setVerticalAlignment(1);
/* 545 */     gridBagConstraints.fill = 0;
/* 546 */     gridBagConstraints.gridx = 4;
/* 547 */     gridBagConstraints.gridy = 6;
/* 548 */     gridBagConstraints.gridwidth = 1;
/* 549 */     gridBagConstraints.anchor = 17;
/* 550 */     gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/* 551 */     add(this.labelAmperes, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 555 */     this.comboBoxSerial.setFont(fonte12);
/* 556 */     this.comboBoxSerial.setModel(new DefaultComboBoxModel());
/* 557 */     this.comboBoxSerial.setOpaque(false);
/* 558 */     gridBagConstraints.gridwidth = 1;
/* 559 */     gridBagConstraints.gridx = 3;
/* 560 */     gridBagConstraints.gridy = 2;
/* 561 */     gridBagConstraints.fill = 2;
/* 562 */     gridBagConstraints.anchor = 17;
/* 563 */     gridBagConstraints.insets = new Insets(0, 5, 10, 0);
/* 564 */     add(this.comboBoxSerial, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 568 */     this.btnOk.setText("OK");
/* 569 */     this.btnOk.setFont(fonte12N);
/* 570 */     this.btnOk.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(
/* 571 */       160, 160, 160)));
/* 572 */     this.btnOk.setFocusPainted(false);
/* 573 */     this.btnOk.setHorizontalTextPosition(0);
/* 574 */     this.btnOk.setMaximumSize(new Dimension(101, 30));
/* 575 */     this.btnOk.setMinimumSize(new Dimension(101, 30));
/* 576 */     this.btnOk.setPreferredSize(new Dimension(101, 30));
/* 577 */     gridBagConstraints.gridx = 1;
/* 578 */     gridBagConstraints.gridy = 10;
/* 579 */     gridBagConstraints.fill = 0;
/* 580 */     gridBagConstraints.anchor = 13;
/* 581 */     gridBagConstraints.gridwidth = 2;
/* 582 */     gridBagConstraints.insets = new Insets(10, 0, 10, 10);
/* 583 */     add(this.btnOk, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 587 */     this.btnCancel.setText("CANCELAR");
/* 588 */     this.btnCancel.setFont(fonte12N);
/* 589 */     this.btnCancel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 590 */       new Color(160, 160, 160)));
/* 591 */     this.btnCancel.setFocusPainted(false);
/* 592 */     this.btnCancel.setMaximumSize(new Dimension(101, 30));
/* 593 */     this.btnCancel.setMinimumSize(new Dimension(101, 30));
/* 594 */     this.btnCancel.setPreferredSize(new Dimension(101, 30));
/* 595 */     gridBagConstraints.gridwidth = 2;
/* 596 */     gridBagConstraints.gridx = 3;
/* 597 */     gridBagConstraints.gridy = 10;
/* 598 */     gridBagConstraints.fill = 0;
/* 599 */     gridBagConstraints.anchor = 17;
/* 600 */     gridBagConstraints.insets = new Insets(10, 0, 10, 46);
/* 601 */     add(this.btnCancel, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JButton getBtnCancel()
/*     */   {
/* 610 */     return this.btnCancel;
/*     */   }
/*     */   
/*     */   public JButton getBtnOk() {
/* 614 */     return this.btnOk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFamilia()
/*     */   {
/* 621 */     return this.familia;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getItemCombo()
/*     */   {
/* 628 */     return this.itemCombo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelComunicacao()
/*     */   {
/* 635 */     return this.labelComunicacao;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelNomeUPS()
/*     */   {
/* 642 */     return this.labelNomeUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getNomeUPS()
/*     */   {
/* 649 */     return this.nomeUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRhino()
/*     */   {
/* 656 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSolis()
/*     */   {
/* 663 */     return 1;
/*     */   }
/*     */   
/*     */   public ButtonGroup getButtonGroup() {
/* 667 */     return this.buttonGroup;
/*     */   }
/*     */   
/*     */   public JComboBox getComboBoxSerial() {
/* 671 */     return this.comboBoxSerial;
/*     */   }
/*     */   
/*     */   public JLabel getLabelAmperes() {
/* 675 */     return this.labelAmperes;
/*     */   }
/*     */   
/*     */   public JLabel getLabelBateria() {
/* 679 */     return this.labelBateria;
/*     */   }
/*     */   
/*     */   public JLabel getlabelComunicacao() {
/* 683 */     return this.labelComunicacao;
/*     */   }
/*     */   
/*     */   public JPanel getPanelFamilia() {
/* 687 */     return this.panelFamilia;
/*     */   }
/*     */   
/*     */   public JRadioButton getRadioRhino() {
/* 691 */     return this.radioRhino;
/*     */   }
/*     */   
/*     */   public JRadioButton getRadioSolis() {
/* 695 */     return this.radioSolis;
/*     */   }
/*     */   
/*     */   public JRadioButton getRadioStay() {
/* 699 */     return this.radioStay;
/*     */   }
/*     */   
/*     */   public JTextField getTextFieldExpanBat() {
/* 703 */     return this.textFieldExpanBat;
/*     */   }
/*     */   
/*     */   public boolean getFlag() {
/* 707 */     return this.flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnCancel(JButton btnCancel)
/*     */   {
/* 718 */     this.btnCancel = btnCancel;
/*     */   }
/*     */   
/*     */   public void setBtnOk(JButton btnOk) {
/* 722 */     this.btnOk = btnOk;
/*     */   }
/*     */   
/*     */   public void setButtonGroup(ButtonGroup buttonGroup) {
/* 726 */     this.buttonGroup = buttonGroup;
/*     */   }
/*     */   
/*     */   public void setComboBoxSerial(JComboBox comboBoxSerial) {
/* 730 */     this.comboBoxSerial = comboBoxSerial;
/*     */   }
/*     */   
/*     */   public void setLabelAmperes(JLabel labelAmperes) {
/* 734 */     this.labelAmperes = labelAmperes;
/*     */   }
/*     */   
/*     */   public void setLabelBateria(JLabel labelBateria) {
/* 738 */     this.labelBateria = labelBateria;
/*     */   }
/*     */   
/*     */   public void setlabelComunicacao(JLabel labelComunicacao) {
/* 742 */     this.labelComunicacao = labelComunicacao;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExpansorBateria(int expansorBateria)
/*     */   {
/* 750 */     this.expansorBateria = expansorBateria;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFamilia(String familia)
/*     */   {
/* 758 */     this.familia = familia;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItemCombo(Object itemCombo)
/*     */   {
/* 766 */     this.itemCombo = itemCombo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelComunicacao(JLabel labelComunicacao)
/*     */   {
/* 774 */     this.labelComunicacao = labelComunicacao;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelNomeUPS(JLabel labelNomeUPS)
/*     */   {
/* 782 */     this.labelNomeUPS = labelNomeUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNomeUPS(JTextField nomeUPS)
/*     */   {
/* 790 */     this.nomeUPS = nomeUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTipoUps(int tipoUps)
/*     */   {
/* 798 */     this.tipoUps = tipoUps;
/*     */   }
/*     */   
/*     */   public void setPanelFamilia(JPanel panelFamilia) {
/* 802 */     this.panelFamilia = panelFamilia;
/*     */   }
/*     */   
/*     */   public void setRadioRhino(JRadioButton radioRhino) {
/* 806 */     this.radioRhino = radioRhino;
/*     */   }
/*     */   
/*     */   public void setRadioSolis(JRadioButton radioSolis) {
/* 810 */     this.radioSolis = radioSolis;
/*     */   }
/*     */   
/*     */   public void setTextFieldExpanBat(JTextField textFieldExpanBat) {
/* 814 */     this.textFieldExpanBat = textFieldExpanBat;
/*     */   }
/*     */   
/*     */   public void setFlag(boolean flag) {
/* 818 */     this.flag = flag;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelUPS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */