/*      */ package br.com.schneider.sgm.gui;
/*      */ 
/*      */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTextArea;
/*      */ import javax.swing.JTextPane;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PopUpValores
/*      */   extends JFrame
/*      */ {
/*      */   private PainelDec painel;
/*      */   private JButton botaoOk;
/*   52 */   private short posJanX = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   57 */   private short posJanY = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private InterfaceGrafica pai;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean flag;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private double[] consumo;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private double valor;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Pop pop;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PopUpValores(String caminhoFiguras, InterfaceGrafica pai, double[] cons, double val)
/*      */   {
/*   94 */     super("Valores do consumo anual");
/*   95 */     if (!flag) {
/*   96 */       this.consumo = cons;
/*   97 */       this.valor = val;
/*   98 */       this.pai = pai;
/*   99 */       setIconImage(new ImageIcon(caminhoFiguras + "IconeSGM.png")
/*  100 */         .getImage());
/*  101 */       this.painel = new PainelDec(caminhoFiguras + "Tabela2.png", 10, 10);
/*  102 */       this.painel.setLayout(new BorderLayout());
/*  103 */       this.painel.setPreferredSize(new Dimension(400, 145));
/*  104 */       getContentPane().setLayout(new BorderLayout());
/*  105 */       add(this.painel, "Center");
/*  106 */       Icon icone2 = new ImageIcon(caminhoFiguras + "Tabela1.png");
/*  107 */       Preenche2 preenche1 = new Preenche2(icone2);
/*  108 */       add(preenche1, "North");
/*  109 */       this.pop = new Pop();
/*  110 */       this.painel.add(this.pop, "Center");
/*      */       
/*  112 */       JTextPane texto = new JTextPane();
/*  113 */       JTextArea textoInt = new JTextArea("");
/*  114 */       textoInt.setFont(new Font("Trebuchet", 1, 12));
/*  115 */       texto.insertComponent(textoInt);
/*  116 */       texto.setOpaque(false);
/*  117 */       texto.setEnabled(false);
/*  118 */       texto.setDisabledTextColor(Color.BLACK);
/*  119 */       textoInt.setOpaque(false);
/*  120 */       textoInt.setEnabled(false);
/*  121 */       textoInt.setDisabledTextColor(Color.BLACK);
/*  122 */       this.botaoOk = new JButton(ResourceBundle.getBundle(Idioma.getIdioma())
/*  123 */         .getString("Ok"));
/*  124 */       this.botaoOk.addActionListener(new ActionListener() {
/*      */         public void actionPerformed(ActionEvent ae) {
/*  126 */           PopUpValores.this.pai.setXPop(PopUpValores.this.pai
/*  127 */             .getXPop() - 10);
/*  128 */           PopUpValores.this.pai.setYPop(PopUpValores.this.pai
/*  129 */             .getYPop() - 10);
/*  130 */           PopUpValores.flag = false;
/*  131 */           PopUpValores.this.dispose();
/*      */         }
/*  133 */       });
/*  134 */       JPanel p = new JPanel();
/*  135 */       Dimension d = new Dimension(90, 24);
/*  136 */       p.setPreferredSize(new Dimension(90, 29));
/*  137 */       p.setBackground(new Color(250, 250, 250));
/*  138 */       this.botaoOk.setMaximumSize(d);
/*  139 */       this.botaoOk.setPreferredSize(d);
/*  140 */       p.add(this.botaoOk);
/*  141 */       this.painel.add(p, "South");
/*  142 */       setResizable(false);
/*  143 */       setSize(500, 200);
/*  144 */       setUndecorated(true);
/*  145 */       setVisible(true);
/*  146 */       setAlwaysOnTop(true);
/*  147 */       setLocation(this.pai.getXPop(), this.pai
/*  148 */         .getYPop());
/*  149 */       this.posJanX = ((short)this.pai.getXPop());
/*  150 */       this.posJanY = ((short)this.pai.getYPop());
/*  151 */       this.pai.setXPop(this.pai.getXPop() + 10);
/*  152 */       this.pai.setYPop(this.pai.getYPop() + 10);
/*      */       
/*  154 */       addMouseListener(
/*  155 */         new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent me) {
/*  157 */             PopUpValores.this.posJanX = ((short)(me.getX() - PopUpValores.this.posJanX));
/*  158 */             PopUpValores.this.posJanY = ((short)(me.getY() - PopUpValores.this.posJanY));
/*      */           }
/*      */           
/*      */           public void mouseReleased(MouseEvent me) {
/*  162 */             PopUpValores.this.posJanX = ((short)(me.getX() - PopUpValores.this.posJanX));
/*  163 */             PopUpValores.this.posJanY = ((short)(me.getY() - PopUpValores.this.posJanY));
/*  164 */             PopUpValores.this.setLocation(PopUpValores.this.posJanX, PopUpValores.this.posJanY);
/*      */           }
/*      */           
/*  167 */         });
/*  168 */       addWindowListener(new WindowAdapter() {
/*      */         public void windowClosing(WindowEvent we) {
/*  170 */           PopUpValores.this.pai.setXPop(PopUpValores.this.pai
/*  171 */             .getXPop() - 10);
/*  172 */           PopUpValores.this.pai.setYPop(PopUpValores.this.pai
/*  173 */             .getYPop() - 10);
/*  174 */           PopUpValores.flag = false;
/*      */         }
/*      */         
/*  177 */       });
/*  178 */       pai.setState(0);
/*  179 */       pai.setVisible(true);
/*  180 */       setConsumoAndValor();
/*  181 */       flag = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConsumoAndValor()
/*      */   {
/*  190 */     DecimalFormat formatador = new DecimalFormat("00.00");
/*      */     
/*  192 */     this.pop.getConsumoJaneiro().setText(formatador.format(this.consumo[0]));
/*  193 */     this.pop.getConsumoFevereiro().setText(formatador.format(this.consumo[1]));
/*  194 */     this.pop.getConsumoMarco().setText(formatador.format(this.consumo[2]));
/*  195 */     this.pop.getConsumoAbril().setText(formatador.format(this.consumo[3]));
/*  196 */     this.pop.getConsumoMaio().setText(formatador.format(this.consumo[4]));
/*  197 */     this.pop.getConsumoJunho().setText(formatador.format(this.consumo[5]));
/*  198 */     this.pop.getConsumoJulho().setText(formatador.format(this.consumo[6]));
/*  199 */     this.pop.getConsumoAgosto().setText(formatador.format(this.consumo[7]));
/*  200 */     this.pop.getConsumoSetembro().setText(formatador.format(this.consumo[8]));
/*  201 */     this.pop.getConsumoOutubro().setText(formatador.format(this.consumo[9]));
/*  202 */     this.pop.getConsumoNovembro().setText(formatador.format(this.consumo[10]));
/*  203 */     this.pop.getConsumoDezembro().setText(formatador.format(this.consumo[11]));
/*  204 */     this.pop.getConsumoMedia().setText(formatador.format(this.consumo[12]));
/*      */     
/*  206 */     this.pop.getValorJaneiro().setText(formatador.format(this.consumo[0] * this.valor));
/*  207 */     this.pop.getValorFevereiro().setText(formatador.format(this.consumo[1] * this.valor));
/*  208 */     this.pop.getValorMarco().setText(formatador.format(this.consumo[2] * this.valor));
/*  209 */     this.pop.getValorAbril().setText(formatador.format(this.consumo[3] * this.valor));
/*  210 */     this.pop.getValorMaio().setText(formatador.format(this.consumo[4] * this.valor));
/*  211 */     this.pop.getValorJunho().setText(formatador.format(this.consumo[5] * this.valor));
/*  212 */     this.pop.getValorJulho().setText(formatador.format(this.consumo[6] * this.valor));
/*  213 */     this.pop.getValorAgosto().setText(formatador.format(this.consumo[7] * this.valor));
/*  214 */     this.pop.getValorSetembro().setText(formatador.format(this.consumo[8] * this.valor));
/*  215 */     this.pop.getValorOutubro().setText(formatador.format(this.consumo[9] * this.valor));
/*  216 */     this.pop.getValorNovembro().setText(formatador.format(this.consumo[10] * this.valor));
/*  217 */     this.pop.getValorDezembro().setText(formatador.format(this.consumo[11] * this.valor));
/*  218 */     this.pop.getValorMedia().setText(formatador.format(this.consumo[12] * this.valor));
/*      */   }
/*      */   
/*      */   public JButton getBtnOk() {
/*  222 */     return this.botaoOk;
/*      */   }
/*      */   
/*      */   class Preenche2
/*      */     extends JPanel
/*      */   {
/*      */     ImageIcon imagemFundo;
/*      */     
/*      */     public Preenche2(Icon imagemFundo)
/*      */     {
/*  232 */       setPreferredSize(new Dimension(500, 18));
/*  233 */       this.imagemFundo = ((ImageIcon)imagemFundo);
/*      */     }
/*      */     
/*      */     public void paintComponent(Graphics g)
/*      */     {
/*  238 */       super.paintComponent(g);
/*  239 */       g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   class Pop
/*      */     extends JPanel
/*      */   {
/*      */     private JLabel abril;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel agosto;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumo1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumo2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoAbril;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoAgosto;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoDezembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoFevereiro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoJaneiro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoJulho;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoJunho;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoMaio;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoMarco;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoNovembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoOutubro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoSetembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel dezembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel fevereiro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel janeiro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel julho;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel junho;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel maio;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel marco;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel novembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel outubro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel setembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valor1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valor2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorAbril;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorAgosto;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorDezembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorFevereiro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorJaneiro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorJulho;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorJunho;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorMaio;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorMarco;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorNovembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorOutubro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorSetembro;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel valorMedia;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel consumoMedia;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private JLabel media;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Pop()
/*      */     {
/*  474 */       initComponents();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void initComponents()
/*      */     {
/*  484 */       this.consumoJulho = new JLabel();
/*  485 */       this.consumoAgosto = new JLabel();
/*  486 */       this.consumoSetembro = new JLabel();
/*  487 */       this.consumoOutubro = new JLabel();
/*  488 */       this.consumoNovembro = new JLabel();
/*  489 */       this.consumoDezembro = new JLabel();
/*  490 */       this.valorJulho = new JLabel();
/*  491 */       this.valorAgosto = new JLabel();
/*  492 */       this.valorSetembro = new JLabel();
/*  493 */       this.valorOutubro = new JLabel();
/*  494 */       this.valorNovembro = new JLabel();
/*  495 */       this.valorDezembro = new JLabel();
/*  496 */       this.janeiro = new JLabel();
/*  497 */       this.fevereiro = new JLabel();
/*  498 */       this.marco = new JLabel();
/*  499 */       this.abril = new JLabel();
/*  500 */       this.maio = new JLabel();
/*  501 */       this.junho = new JLabel();
/*  502 */       this.julho = new JLabel();
/*  503 */       this.agosto = new JLabel();
/*  504 */       this.setembro = new JLabel();
/*  505 */       this.outubro = new JLabel();
/*  506 */       this.novembro = new JLabel();
/*  507 */       this.dezembro = new JLabel();
/*  508 */       this.consumoJaneiro = new JLabel();
/*  509 */       this.consumoFevereiro = new JLabel();
/*  510 */       this.consumoMarco = new JLabel();
/*  511 */       this.consumoAbril = new JLabel();
/*  512 */       this.consumoMaio = new JLabel();
/*  513 */       this.consumoJunho = new JLabel();
/*  514 */       this.valorJaneiro = new JLabel();
/*  515 */       this.valorFevereiro = new JLabel();
/*  516 */       this.valorMarco = new JLabel();
/*  517 */       this.valorAbril = new JLabel();
/*  518 */       this.valorMaio = new JLabel();
/*  519 */       this.valorJunho = new JLabel();
/*  520 */       this.consumo1 = new JLabel();
/*  521 */       this.valor1 = new JLabel();
/*  522 */       this.consumo2 = new JLabel();
/*  523 */       this.valor2 = new JLabel();
/*      */       
/*  525 */       this.media = new JLabel();
/*  526 */       this.valorMedia = new JLabel();
/*  527 */       this.consumoMedia = new JLabel();
/*      */       
/*  529 */       setLayout(new GridBagLayout());
/*      */       
/*  531 */       setMaximumSize(new Dimension(400, 135));
/*  532 */       setMinimumSize(new Dimension(400, 135));
/*  533 */       setOpaque(false);
/*  534 */       setPreferredSize(new Dimension(400, 135));
/*  535 */       this.consumoJulho.setText("0");
/*  536 */       GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  537 */       gridBagConstraints.gridx = 8;
/*  538 */       gridBagConstraints.gridy = 2;
/*  539 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  540 */       add(this.consumoJulho, gridBagConstraints);
/*      */       
/*  542 */       this.consumoAgosto.setText("0");
/*  543 */       gridBagConstraints = new GridBagConstraints();
/*  544 */       gridBagConstraints.gridx = 8;
/*  545 */       gridBagConstraints.gridy = 4;
/*  546 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  547 */       add(this.consumoAgosto, gridBagConstraints);
/*      */       
/*  549 */       this.consumoSetembro.setText("0");
/*  550 */       gridBagConstraints = new GridBagConstraints();
/*  551 */       gridBagConstraints.gridx = 8;
/*  552 */       gridBagConstraints.gridy = 6;
/*  553 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  554 */       add(this.consumoSetembro, gridBagConstraints);
/*      */       
/*  556 */       this.consumoOutubro.setText("0");
/*  557 */       gridBagConstraints = new GridBagConstraints();
/*  558 */       gridBagConstraints.gridx = 8;
/*  559 */       gridBagConstraints.gridy = 8;
/*  560 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  561 */       add(this.consumoOutubro, gridBagConstraints);
/*      */       
/*  563 */       this.consumoNovembro.setText("0");
/*  564 */       gridBagConstraints = new GridBagConstraints();
/*  565 */       gridBagConstraints.gridx = 8;
/*  566 */       gridBagConstraints.gridy = 10;
/*  567 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  568 */       add(this.consumoNovembro, gridBagConstraints);
/*      */       
/*  570 */       this.consumoDezembro.setText("0");
/*  571 */       gridBagConstraints = new GridBagConstraints();
/*  572 */       gridBagConstraints.gridx = 8;
/*  573 */       gridBagConstraints.gridy = 12;
/*  574 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  575 */       add(this.consumoDezembro, gridBagConstraints);
/*      */       
/*  577 */       this.consumoMedia.setText("0");
/*  578 */       gridBagConstraints = new GridBagConstraints();
/*  579 */       gridBagConstraints.gridx = 8;
/*  580 */       gridBagConstraints.gridy = 14;
/*  581 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  582 */       add(this.consumoMedia, gridBagConstraints);
/*      */       
/*  584 */       this.valorJulho.setText("0");
/*  585 */       gridBagConstraints = new GridBagConstraints();
/*  586 */       gridBagConstraints.gridx = 10;
/*  587 */       gridBagConstraints.gridy = 2;
/*  588 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  589 */       add(this.valorJulho, gridBagConstraints);
/*      */       
/*  591 */       this.valorAgosto.setText("0");
/*  592 */       gridBagConstraints = new GridBagConstraints();
/*  593 */       gridBagConstraints.gridx = 10;
/*  594 */       gridBagConstraints.gridy = 4;
/*  595 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  596 */       add(this.valorAgosto, gridBagConstraints);
/*      */       
/*  598 */       this.valorSetembro.setText("0");
/*  599 */       gridBagConstraints = new GridBagConstraints();
/*  600 */       gridBagConstraints.gridx = 10;
/*  601 */       gridBagConstraints.gridy = 6;
/*  602 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  603 */       add(this.valorSetembro, gridBagConstraints);
/*      */       
/*  605 */       this.valorOutubro.setText("0");
/*  606 */       gridBagConstraints = new GridBagConstraints();
/*  607 */       gridBagConstraints.gridx = 10;
/*  608 */       gridBagConstraints.gridy = 8;
/*  609 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  610 */       add(this.valorOutubro, gridBagConstraints);
/*      */       
/*  612 */       this.valorNovembro.setText("0");
/*  613 */       gridBagConstraints = new GridBagConstraints();
/*  614 */       gridBagConstraints.gridx = 10;
/*  615 */       gridBagConstraints.gridy = 10;
/*  616 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  617 */       add(this.valorNovembro, gridBagConstraints);
/*      */       
/*  619 */       this.valorDezembro.setText("0");
/*  620 */       gridBagConstraints = new GridBagConstraints();
/*  621 */       gridBagConstraints.gridx = 10;
/*  622 */       gridBagConstraints.gridy = 12;
/*  623 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  624 */       add(this.valorDezembro, gridBagConstraints);
/*      */       
/*  626 */       this.valorMedia.setText("0");
/*  627 */       gridBagConstraints = new GridBagConstraints();
/*  628 */       gridBagConstraints.gridx = 10;
/*  629 */       gridBagConstraints.gridy = 14;
/*  630 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  631 */       add(this.valorMedia, gridBagConstraints);
/*      */       
/*  633 */       this.janeiro.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  634 */         .getString("Janeiro"));
/*  635 */       gridBagConstraints = new GridBagConstraints();
/*  636 */       gridBagConstraints.gridx = 0;
/*  637 */       gridBagConstraints.gridy = 2;
/*  638 */       gridBagConstraints.fill = 1;
/*  639 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  640 */       add(this.janeiro, gridBagConstraints);
/*      */       
/*  642 */       this.fevereiro.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  643 */         .getString("Fevereiro"));
/*  644 */       gridBagConstraints = new GridBagConstraints();
/*  645 */       gridBagConstraints.gridx = 0;
/*  646 */       gridBagConstraints.gridy = 4;
/*  647 */       gridBagConstraints.fill = 1;
/*  648 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  649 */       add(this.fevereiro, gridBagConstraints);
/*      */       
/*  651 */       this.marco.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  652 */         .getString("Marco"));
/*  653 */       gridBagConstraints = new GridBagConstraints();
/*  654 */       gridBagConstraints.gridx = 0;
/*  655 */       gridBagConstraints.gridy = 6;
/*  656 */       gridBagConstraints.fill = 1;
/*  657 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  658 */       add(this.marco, gridBagConstraints);
/*      */       
/*  660 */       this.abril.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  661 */         .getString("Abril"));
/*  662 */       gridBagConstraints = new GridBagConstraints();
/*  663 */       gridBagConstraints.gridx = 0;
/*  664 */       gridBagConstraints.gridy = 8;
/*  665 */       gridBagConstraints.fill = 1;
/*  666 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  667 */       add(this.abril, gridBagConstraints);
/*      */       
/*  669 */       this.maio.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  670 */         .getString("Maio"));
/*  671 */       gridBagConstraints = new GridBagConstraints();
/*  672 */       gridBagConstraints.gridx = 0;
/*  673 */       gridBagConstraints.gridy = 10;
/*  674 */       gridBagConstraints.fill = 1;
/*  675 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  676 */       add(this.maio, gridBagConstraints);
/*      */       
/*  678 */       this.junho.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  679 */         .getString("Junho"));
/*  680 */       gridBagConstraints = new GridBagConstraints();
/*  681 */       gridBagConstraints.gridx = 0;
/*  682 */       gridBagConstraints.gridy = 12;
/*  683 */       gridBagConstraints.fill = 1;
/*  684 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  685 */       add(this.junho, gridBagConstraints);
/*      */       
/*  687 */       this.julho.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  688 */         .getString("Julho"));
/*  689 */       gridBagConstraints = new GridBagConstraints();
/*  690 */       gridBagConstraints.gridx = 6;
/*  691 */       gridBagConstraints.gridy = 2;
/*  692 */       gridBagConstraints.fill = 1;
/*  693 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  694 */       add(this.julho, gridBagConstraints);
/*      */       
/*  696 */       this.agosto.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  697 */         .getString("Agosto"));
/*  698 */       gridBagConstraints = new GridBagConstraints();
/*  699 */       gridBagConstraints.gridx = 6;
/*  700 */       gridBagConstraints.gridy = 4;
/*  701 */       gridBagConstraints.fill = 1;
/*  702 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  703 */       add(this.agosto, gridBagConstraints);
/*      */       
/*  705 */       this.setembro.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  706 */         .getString("Setembro"));
/*  707 */       gridBagConstraints = new GridBagConstraints();
/*  708 */       gridBagConstraints.gridx = 6;
/*  709 */       gridBagConstraints.gridy = 6;
/*  710 */       gridBagConstraints.fill = 1;
/*  711 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  712 */       add(this.setembro, gridBagConstraints);
/*      */       
/*  714 */       this.outubro.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  715 */         .getString("Outubro"));
/*  716 */       gridBagConstraints = new GridBagConstraints();
/*  717 */       gridBagConstraints.gridx = 6;
/*  718 */       gridBagConstraints.gridy = 8;
/*  719 */       gridBagConstraints.fill = 1;
/*  720 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  721 */       add(this.outubro, gridBagConstraints);
/*      */       
/*  723 */       this.novembro.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  724 */         .getString("Novembro"));
/*  725 */       gridBagConstraints = new GridBagConstraints();
/*  726 */       gridBagConstraints.gridx = 6;
/*  727 */       gridBagConstraints.gridy = 10;
/*  728 */       gridBagConstraints.fill = 1;
/*  729 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  730 */       add(this.novembro, gridBagConstraints);
/*      */       
/*  732 */       this.dezembro.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  733 */         .getString("Dezembro"));
/*  734 */       gridBagConstraints = new GridBagConstraints();
/*  735 */       gridBagConstraints.gridx = 6;
/*  736 */       gridBagConstraints.gridy = 12;
/*  737 */       gridBagConstraints.fill = 1;
/*  738 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  739 */       add(this.dezembro, gridBagConstraints);
/*      */       
/*  741 */       this.media.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  742 */         .getString("Media"));
/*  743 */       gridBagConstraints = new GridBagConstraints();
/*  744 */       gridBagConstraints.gridx = 6;
/*  745 */       gridBagConstraints.gridy = 14;
/*  746 */       gridBagConstraints.fill = 1;
/*  747 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  748 */       add(this.media, gridBagConstraints);
/*      */       
/*  750 */       this.consumoJaneiro.setText("0");
/*  751 */       gridBagConstraints = new GridBagConstraints();
/*  752 */       gridBagConstraints.gridx = 2;
/*  753 */       gridBagConstraints.gridy = 2;
/*  754 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  755 */       add(this.consumoJaneiro, gridBagConstraints);
/*      */       
/*  757 */       this.consumoFevereiro.setText("0");
/*  758 */       gridBagConstraints = new GridBagConstraints();
/*  759 */       gridBagConstraints.gridx = 2;
/*  760 */       gridBagConstraints.gridy = 4;
/*  761 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  762 */       add(this.consumoFevereiro, gridBagConstraints);
/*      */       
/*  764 */       this.consumoMarco.setText("0");
/*  765 */       gridBagConstraints = new GridBagConstraints();
/*  766 */       gridBagConstraints.gridx = 2;
/*  767 */       gridBagConstraints.gridy = 6;
/*  768 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  769 */       add(this.consumoMarco, gridBagConstraints);
/*      */       
/*  771 */       this.consumoAbril.setText("0");
/*  772 */       gridBagConstraints = new GridBagConstraints();
/*  773 */       gridBagConstraints.gridx = 2;
/*  774 */       gridBagConstraints.gridy = 8;
/*  775 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  776 */       add(this.consumoAbril, gridBagConstraints);
/*      */       
/*  778 */       this.consumoMaio.setText("0");
/*  779 */       gridBagConstraints = new GridBagConstraints();
/*  780 */       gridBagConstraints.gridx = 2;
/*  781 */       gridBagConstraints.gridy = 10;
/*  782 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  783 */       add(this.consumoMaio, gridBagConstraints);
/*      */       
/*  785 */       this.consumoJunho.setText("0");
/*  786 */       gridBagConstraints = new GridBagConstraints();
/*  787 */       gridBagConstraints.gridx = 2;
/*  788 */       gridBagConstraints.gridy = 12;
/*  789 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  790 */       add(this.consumoJunho, gridBagConstraints);
/*      */       
/*  792 */       this.valorJaneiro.setText("0");
/*  793 */       gridBagConstraints = new GridBagConstraints();
/*  794 */       gridBagConstraints.gridx = 4;
/*  795 */       gridBagConstraints.gridy = 2;
/*  796 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  797 */       add(this.valorJaneiro, gridBagConstraints);
/*      */       
/*  799 */       this.valorFevereiro.setText("0");
/*  800 */       gridBagConstraints = new GridBagConstraints();
/*  801 */       gridBagConstraints.gridx = 4;
/*  802 */       gridBagConstraints.gridy = 4;
/*  803 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  804 */       add(this.valorFevereiro, gridBagConstraints);
/*      */       
/*  806 */       this.valorMarco.setText("0");
/*  807 */       gridBagConstraints = new GridBagConstraints();
/*  808 */       gridBagConstraints.gridx = 4;
/*  809 */       gridBagConstraints.gridy = 6;
/*  810 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  811 */       add(this.valorMarco, gridBagConstraints);
/*      */       
/*  813 */       this.valorAbril.setText("0");
/*  814 */       gridBagConstraints = new GridBagConstraints();
/*  815 */       gridBagConstraints.gridx = 4;
/*  816 */       gridBagConstraints.gridy = 8;
/*  817 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  818 */       add(this.valorAbril, gridBagConstraints);
/*      */       
/*  820 */       this.valorMaio.setText("0");
/*  821 */       gridBagConstraints = new GridBagConstraints();
/*  822 */       gridBagConstraints.gridx = 4;
/*  823 */       gridBagConstraints.gridy = 10;
/*  824 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  825 */       add(this.valorMaio, gridBagConstraints);
/*      */       
/*  827 */       this.valorJunho.setText("0");
/*  828 */       gridBagConstraints = new GridBagConstraints();
/*  829 */       gridBagConstraints.gridx = 4;
/*  830 */       gridBagConstraints.gridy = 12;
/*  831 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  832 */       add(this.valorJunho, gridBagConstraints);
/*      */       
/*  834 */       this.consumo1.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  835 */         .getString("Consumo_KWh"));
/*  836 */       gridBagConstraints = new GridBagConstraints();
/*  837 */       gridBagConstraints.gridx = 2;
/*  838 */       gridBagConstraints.gridy = 0;
/*  839 */       gridBagConstraints.fill = 1;
/*  840 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  841 */       add(this.consumo1, gridBagConstraints);
/*      */       
/*  843 */       this.valor1.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  844 */         .getString("Valor_RS"));
/*  845 */       gridBagConstraints = new GridBagConstraints();
/*  846 */       gridBagConstraints.gridx = 4;
/*  847 */       gridBagConstraints.gridy = 0;
/*  848 */       gridBagConstraints.fill = 1;
/*  849 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  850 */       add(this.valor1, gridBagConstraints);
/*      */       
/*  852 */       this.consumo2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  853 */         .getString("Consumo_KWh"));
/*  854 */       gridBagConstraints = new GridBagConstraints();
/*  855 */       gridBagConstraints.gridx = 8;
/*  856 */       gridBagConstraints.gridy = 0;
/*  857 */       gridBagConstraints.fill = 1;
/*  858 */       gridBagConstraints.insets = new Insets(0, 0, 5, 10);
/*  859 */       add(this.consumo2, gridBagConstraints);
/*      */       
/*  861 */       this.valor2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  862 */         .getString("Valor_RS"));
/*  863 */       gridBagConstraints = new GridBagConstraints();
/*  864 */       gridBagConstraints.gridx = 10;
/*  865 */       gridBagConstraints.gridy = 0;
/*  866 */       gridBagConstraints.fill = 1;
/*  867 */       gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/*  868 */       add(this.valor2, gridBagConstraints);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public JLabel getAbril()
/*      */     {
/*  876 */       return this.abril;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getAgosto()
/*      */     {
/*  883 */       return this.agosto;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoMedia()
/*      */     {
/*  890 */       return this.consumoMedia;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getMedia()
/*      */     {
/*  897 */       return this.media;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorMedia()
/*      */     {
/*  904 */       return this.valorMedia;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumo1()
/*      */     {
/*  911 */       return this.consumo1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumo2()
/*      */     {
/*  918 */       return this.consumo2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoAbril()
/*      */     {
/*  925 */       return this.consumoAbril;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoAgosto()
/*      */     {
/*  932 */       return this.consumoAgosto;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoDezembro()
/*      */     {
/*  939 */       return this.consumoDezembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoFevereiro()
/*      */     {
/*  946 */       return this.consumoFevereiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoJaneiro()
/*      */     {
/*  953 */       return this.consumoJaneiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoJulho()
/*      */     {
/*  960 */       return this.consumoJulho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoJunho()
/*      */     {
/*  967 */       return this.consumoJunho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoMaio()
/*      */     {
/*  974 */       return this.consumoMaio;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoMarco()
/*      */     {
/*  981 */       return this.consumoMarco;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoNovembro()
/*      */     {
/*  988 */       return this.consumoNovembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoOutubro()
/*      */     {
/*  995 */       return this.consumoOutubro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getConsumoSetembro()
/*      */     {
/* 1002 */       return this.consumoSetembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getDezembro()
/*      */     {
/* 1009 */       return this.dezembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getFevereiro()
/*      */     {
/* 1016 */       return this.fevereiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getJaneiro()
/*      */     {
/* 1023 */       return this.janeiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getJulho()
/*      */     {
/* 1030 */       return this.julho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getJunho()
/*      */     {
/* 1037 */       return this.junho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getMaio()
/*      */     {
/* 1044 */       return this.maio;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getMarco()
/*      */     {
/* 1051 */       return this.marco;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getNovembro()
/*      */     {
/* 1058 */       return this.novembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getOutubro()
/*      */     {
/* 1065 */       return this.outubro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getSetembro()
/*      */     {
/* 1072 */       return this.setembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValor1()
/*      */     {
/* 1079 */       return this.valor1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValor2()
/*      */     {
/* 1086 */       return this.valor2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorAbril()
/*      */     {
/* 1093 */       return this.valorAbril;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorAgosto()
/*      */     {
/* 1100 */       return this.valorAgosto;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorDezembro()
/*      */     {
/* 1107 */       return this.valorDezembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorFevereiro()
/*      */     {
/* 1114 */       return this.valorFevereiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorJaneiro()
/*      */     {
/* 1121 */       return this.valorJaneiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorJulho()
/*      */     {
/* 1128 */       return this.valorJulho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorJunho()
/*      */     {
/* 1135 */       return this.valorJunho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorMaio()
/*      */     {
/* 1142 */       return this.valorMaio;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorMarco()
/*      */     {
/* 1149 */       return this.valorMarco;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorNovembro()
/*      */     {
/* 1156 */       return this.valorNovembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorOutubro()
/*      */     {
/* 1163 */       return this.valorOutubro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public JLabel getValorSetembro()
/*      */     {
/* 1170 */       return this.valorSetembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setAbril(JLabel abril)
/*      */     {
/* 1177 */       this.abril = abril;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setAgosto(JLabel agosto)
/*      */     {
/* 1184 */       this.agosto = agosto;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumo1(JLabel consumo1)
/*      */     {
/* 1191 */       this.consumo1 = consumo1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumo2(JLabel consumo2)
/*      */     {
/* 1198 */       this.consumo2 = consumo2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoMedia(JLabel consumoMedia)
/*      */     {
/* 1205 */       this.consumoMedia = consumoMedia;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setMedia(JLabel media)
/*      */     {
/* 1212 */       this.media = media;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorMedia(JLabel valorMedia)
/*      */     {
/* 1219 */       this.valorMedia = valorMedia;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoAbril(JLabel consumoAbril)
/*      */     {
/* 1226 */       this.consumoAbril = consumoAbril;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoAgosto(JLabel consumoAgosto)
/*      */     {
/* 1233 */       this.consumoAgosto = consumoAgosto;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoDezembro(JLabel consumoDezembro)
/*      */     {
/* 1240 */       this.consumoDezembro = consumoDezembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoFevereiro(JLabel consumoFevereiro)
/*      */     {
/* 1247 */       this.consumoFevereiro = consumoFevereiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoJaneiro(JLabel consumoJaneiro)
/*      */     {
/* 1254 */       this.consumoJaneiro = consumoJaneiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoJulho(JLabel consumoJulho)
/*      */     {
/* 1261 */       this.consumoJulho = consumoJulho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoJunho(JLabel consumoJunho)
/*      */     {
/* 1268 */       this.consumoJunho = consumoJunho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoMaio(JLabel consumoMaio)
/*      */     {
/* 1275 */       this.consumoMaio = consumoMaio;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoMarco(JLabel consumoMarco)
/*      */     {
/* 1282 */       this.consumoMarco = consumoMarco;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoNovembro(JLabel consumoNovembro)
/*      */     {
/* 1289 */       this.consumoNovembro = consumoNovembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoOutubro(JLabel consumoOutubro)
/*      */     {
/* 1296 */       this.consumoOutubro = consumoOutubro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setConsumoSetembro(JLabel consumoSetembro)
/*      */     {
/* 1303 */       this.consumoSetembro = consumoSetembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setDezembro(JLabel dezembro)
/*      */     {
/* 1310 */       this.dezembro = dezembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setFevereiro(JLabel fevereiro)
/*      */     {
/* 1317 */       this.fevereiro = fevereiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setJaneiro(JLabel janeiro)
/*      */     {
/* 1324 */       this.janeiro = janeiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setJulho(JLabel julho)
/*      */     {
/* 1331 */       this.julho = julho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setJunho(JLabel junho)
/*      */     {
/* 1338 */       this.junho = junho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setMaio(JLabel maio)
/*      */     {
/* 1345 */       this.maio = maio;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setMarco(JLabel marco)
/*      */     {
/* 1352 */       this.marco = marco;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setNovembro(JLabel novembro)
/*      */     {
/* 1359 */       this.novembro = novembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setOutubro(JLabel outubro)
/*      */     {
/* 1366 */       this.outubro = outubro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setSetembro(JLabel setembro)
/*      */     {
/* 1373 */       this.setembro = setembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValor1(JLabel valor1)
/*      */     {
/* 1380 */       this.valor1 = valor1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValor2(JLabel valor2)
/*      */     {
/* 1387 */       this.valor2 = valor2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorAbril(JLabel valorAbril)
/*      */     {
/* 1394 */       this.valorAbril = valorAbril;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorAgosto(JLabel valorAgosto)
/*      */     {
/* 1401 */       this.valorAgosto = valorAgosto;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorDezembro(JLabel valorDezembro)
/*      */     {
/* 1408 */       this.valorDezembro = valorDezembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorFevereiro(JLabel valorFevereiro)
/*      */     {
/* 1415 */       this.valorFevereiro = valorFevereiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorJaneiro(JLabel valorJaneiro)
/*      */     {
/* 1422 */       this.valorJaneiro = valorJaneiro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorJulho(JLabel valorJulho)
/*      */     {
/* 1429 */       this.valorJulho = valorJulho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorJunho(JLabel valorJunho)
/*      */     {
/* 1436 */       this.valorJunho = valorJunho;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorMaio(JLabel valorMaio)
/*      */     {
/* 1443 */       this.valorMaio = valorMaio;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorMarco(JLabel valorMarco)
/*      */     {
/* 1450 */       this.valorMarco = valorMarco;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorNovembro(JLabel valorNovembro)
/*      */     {
/* 1457 */       this.valorNovembro = valorNovembro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorOutubro(JLabel valorOutubro)
/*      */     {
/* 1464 */       this.valorOutubro = valorOutubro;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setValorSetembro(JLabel valorSetembro)
/*      */     {
/* 1471 */       this.valorSetembro = valorSetembro;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PopUpValores.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */