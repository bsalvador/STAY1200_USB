/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.SoftBevelBorder;
/*     */ import javax.swing.event.CaretEvent;
/*     */ import javax.swing.event.CaretListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelSMTP
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = -1800727996848387795L;
/*     */   private JButton btnCancel;
/*     */   private JButton btnOk;
/*     */   private JCheckBox cbAutenticacao;
/*     */   private JLabel labelDestinatario;
/*     */   private JLabel labelEndServidor;
/*     */   private JLabel labelPorta;
/*     */   private JLabel labelRemetente;
/*     */   private JLabel labelSMTP;
/*     */   private JLabel labelSenha;
/*     */   private JLabel labelUsuario;
/*     */   private JPasswordField pfSenha;
/*     */   private JTextField tfDestinatario;
/*     */   private JTextField tfEndServidor;
/*     */   private JTextField tfPorta;
/*     */   private JTextField tfRemetente;
/*     */   private JTextField tfUsuario;
/*     */   private JComboBox<String> cmbProvedores;
/*     */   private JLabel labelProvedor;
/*     */   private int antigaPorta;
/*     */   private boolean flag;
/*     */   private String provedorEscolhido;
/*     */   
/*     */   public PainelSMTP()
/*     */   {
/* 157 */     initComponents();
/* 158 */     validarIdioma();
/* 159 */     addListeners();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void habilitarCamposEmail(boolean value)
/*     */   {
/* 171 */     this.tfDestinatario.setEnabled(value);
/* 172 */     this.tfRemetente.setEnabled(value);
/* 173 */     this.tfPorta.setEnabled(value);
/* 174 */     this.tfEndServidor.setEnabled(value);
/* 175 */     cbAutenticacaoSelected(value);
/*     */     
/* 177 */     this.tfDestinatario.setEditable(value);
/* 178 */     this.tfRemetente.setEditable(value);
/* 179 */     this.tfPorta.setEditable(value);
/* 180 */     this.tfEndServidor.setEditable(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addListeners()
/*     */   {
/* 194 */     this.cbAutenticacao.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 196 */         PainelSMTP.this.cbAutenticacaoSelected(PainelSMTP.this.cbAutenticacao.isSelected());
/* 197 */         PainelSMTP.this.flag = true;
/*     */       }
/*     */       
/* 200 */     });
/* 201 */     this.tfUsuario.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 203 */         PainelSMTP.this.flag = true;
/*     */       }
/*     */       
/* 206 */     });
/* 207 */     this.tfRemetente.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 209 */         PainelSMTP.this.flag = true;
/*     */       }
/*     */       
/* 212 */     });
/* 213 */     this.tfPorta.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 215 */         PainelSMTP.this.flag = true;
/*     */       }
/*     */       
/* 218 */     });
/* 219 */     this.tfDestinatario.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 221 */         PainelSMTP.this.flag = true;
/*     */       }
/*     */       
/* 224 */     });
/* 225 */     this.tfEndServidor.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 227 */         PainelSMTP.this.flag = true;
/*     */       }
/*     */       
/* 230 */     });
/* 231 */     this.pfSenha.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 233 */         PainelSMTP.this.flag = true;
/*     */       }
/* 235 */     });
/* 236 */     this.btnCancel.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 238 */         PainelSMTP.this.flag = false;
/*     */       }
/* 240 */     });
/* 241 */     this.btnOk.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 243 */         PainelSMTP.this.flag = false;
/*     */       }
/*     */       
/* 246 */     });
/* 247 */     this.cmbProvedores.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*     */ 
/* 253 */         JComboBox cb = (JComboBox)e.getSource();
/* 254 */         String valorSelecionado = (String)cb.getSelectedItem();
/* 255 */         PainelSMTP.this.atualizarCamposEmail(valorSelecionado);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void atualizarCamposEmail(String valorSelecionado)
/*     */   {
/* 265 */     if (valorSelecionado.equals(this.provedorEscolhido)) {
/*     */       return;
/*     */     }
/*     */     
/*     */     String str;
/*     */     
/* 271 */     switch ((str = valorSelecionado).hashCode()) {case 2337004:  if (str.equals("LIVE")) {} break; case 67928702:  if (str.equals("GMAIL")) break; break; case 84201504:  if (str.equals("YAHOO")) {} break; case 1999208305:  if (!str.equals("CUSTOM")) {
/*     */         break label197;
/* 273 */         this.tfEndServidor.setText("smtp.gmail.com");
/* 274 */         alterarValorDefaultPorta();
/* 275 */         setProvedor(valorSelecionado);
/* 276 */         return;
/*     */         
/*     */ 
/* 279 */         this.tfEndServidor.setText("smtp.live.com");
/* 280 */         alterarValorDefaultPorta();
/* 281 */         setProvedor(valorSelecionado);
/* 282 */         return;
/*     */         
/*     */ 
/* 285 */         this.tfEndServidor.setText("smtp.mail.yahoo.com");
/* 286 */         alterarValorDefaultPorta();
/* 287 */         setProvedor(valorSelecionado);
/* 288 */         return;
/*     */       }
/*     */       else
/*     */       {
/* 292 */         habilitarCamposEmail(true);
/* 293 */         cbAutenticacaoSelected(false);
/* 294 */         this.cbAutenticacao.setSelected(false);
/* 295 */         setProvedor(valorSelecionado); }
/* 296 */       break;
/*     */     }
/*     */     label197:
/* 299 */     limparCamposEmail();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void alterarValorDefaultPorta()
/*     */   {
/* 310 */     boolean isPortaComZeroVaziaouNula = (this.tfPorta.getText() == null) || 
/* 311 */       (this.tfPorta.getText().equals("")) || 
/* 312 */       (this.tfPorta.getText().equals("0"));
/*     */     
/* 314 */     if (isPortaComZeroVaziaouNula) {
/* 315 */       this.tfPorta.setText("587");
/*     */     }
/*     */   }
/*     */   
/*     */   private void limparCamposEmail() {
/* 320 */     this.tfDestinatario.setText("");
/* 321 */     this.tfEndServidor.setText("");
/* 322 */     this.tfPorta.setText("");
/* 323 */     this.tfRemetente.setText("");
/* 324 */     this.pfSenha.setText("");
/* 325 */     this.tfUsuario.setText("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPortaValida()
/*     */   {
/*     */     try
/*     */     {
/* 337 */       this.antigaPorta = Integer.parseInt(this.tfPorta.getText());
/* 338 */       return true;
/*     */     } catch (NumberFormatException nfe) {
/* 340 */       this.tfPorta.setText(Integer.toString(this.antigaPorta)); }
/* 341 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPorta()
/*     */   {
/*     */     try
/*     */     {
/* 352 */       return Integer.parseInt(this.tfPorta.getText());
/*     */     } catch (NumberFormatException nfe) {}
/* 354 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cbAutenticacaoSelected(boolean b)
/*     */   {
/* 365 */     this.labelUsuario.setEnabled(b);
/* 366 */     this.labelSenha.setEnabled(b);
/* 367 */     this.tfUsuario.setEnabled(b);
/* 368 */     this.pfSenha.setEnabled(b);
/* 369 */     if (!b) {
/* 370 */       this.tfUsuario.setBackground(new Color(230, 230, 230));
/* 371 */       this.pfSenha.setBackground(new Color(230, 230, 230));
/*     */     } else {
/* 373 */       this.tfUsuario.setBackground(Color.WHITE);
/* 374 */       this.pfSenha.setBackground(Color.WHITE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getCamposSMTP()
/*     */   {
/* 385 */     String[] retorno = new String[6];
/* 386 */     retorno[0] = this.tfEndServidor.getText();
/* 387 */     retorno[1] = this.tfUsuario.getText();
/* 388 */     retorno[2] = this.pfSenha.getText();
/* 389 */     retorno[3] = this.tfRemetente.getText();
/* 390 */     retorno[4] = this.tfDestinatario.getText();
/* 391 */     retorno[5] = this.tfPorta.getText();
/* 392 */     return retorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 400 */     this.labelSenha.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 401 */       .getString("SENHA"));
/* 402 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 403 */       "OK"));
/* 404 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 405 */       .getString("CANCELAR"));
/* 406 */     this.labelEndServidor.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 407 */       .getString("ENDERECO_SERVIDOR"));
/* 408 */     this.labelUsuario.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 409 */       .getString("USUARIO"));
/* 410 */     this.labelSMTP.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 411 */       .getString("SMTP"));
/* 412 */     this.labelRemetente.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 413 */       .getString("REMETENTE"));
/* 414 */     this.labelDestinatario.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 415 */       .getString("DESTINATARIO"));
/* 416 */     this.labelPorta.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 417 */       .getString("PORTA"));
/* 418 */     this.labelProvedor.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 419 */       .getString("PROVEDOR"));
/* 420 */     this.cbAutenticacao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 421 */       .getString("AUTENTICACAO"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 430 */     Font fonte11 = new Font("Trebuchet", 0, 11);
/* 431 */     Font fonte12N = new Font("Trebuchet", 1, 12);
/*     */     
/* 433 */     this.labelSenha = new JLabel();
/* 434 */     this.pfSenha = new JPasswordField();
/* 435 */     this.btnOk = new JButton();
/* 436 */     this.btnCancel = new JButton();
/* 437 */     this.tfUsuario = new JTextField();
/* 438 */     this.tfEndServidor = new JTextField();
/* 439 */     this.labelEndServidor = new JLabel();
/* 440 */     this.labelUsuario = new JLabel();
/* 441 */     this.labelSMTP = new JLabel();
/* 442 */     this.labelProvedor = new JLabel();
/* 443 */     this.labelRemetente = new JLabel();
/* 444 */     this.tfRemetente = new JTextField();
/* 445 */     this.labelDestinatario = new JLabel();
/* 446 */     this.tfDestinatario = new JTextField();
/* 447 */     this.labelPorta = new JLabel();
/* 448 */     this.tfPorta = new JTextField();
/* 449 */     this.cbAutenticacao = new JCheckBox();
/*     */     
/* 451 */     setLayout(new GridBagLayout());
/*     */     
/* 453 */     setMaximumSize(new Dimension(384, 335));
/* 454 */     setMinimumSize(new Dimension(384, 335));
/* 455 */     setOpaque(false);
/* 456 */     setPreferredSize(new Dimension(384, 335));
/*     */     
/* 458 */     this.labelProvedor.setFont(fonte11);
/* 459 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 460 */     gridBagConstraints.gridx = 1;
/* 461 */     gridBagConstraints.gridy = 1;
/* 462 */     gridBagConstraints.gridwidth = 2;
/* 463 */     gridBagConstraints.fill = 2;
/* 464 */     gridBagConstraints.anchor = 17;
/* 465 */     gridBagConstraints.insets = new Insets(0, 20, -20, 0);
/* 466 */     add(this.labelProvedor, gridBagConstraints);
/*     */     
/* 468 */     this.labelSenha.setFont(fonte11);
/* 469 */     gridBagConstraints = new GridBagConstraints();
/* 470 */     gridBagConstraints.gridx = 0;
/* 471 */     gridBagConstraints.gridy = 6;
/* 472 */     gridBagConstraints.gridwidth = 2;
/* 473 */     gridBagConstraints.fill = 2;
/* 474 */     gridBagConstraints.anchor = 17;
/* 475 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 476 */     add(this.labelSenha, gridBagConstraints);
/*     */     
/* 478 */     this.pfSenha.setBorder(new SoftBevelBorder(1, new Color(
/* 479 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 480 */     this.pfSenha.setMaximumSize(new Dimension(100, 19));
/* 481 */     this.pfSenha.setMinimumSize(new Dimension(100, 19));
/* 482 */     this.pfSenha.setPreferredSize(new Dimension(100, 19));
/* 483 */     gridBagConstraints = new GridBagConstraints();
/* 484 */     gridBagConstraints.gridx = 2;
/* 485 */     gridBagConstraints.gridy = 6;
/* 486 */     gridBagConstraints.fill = 2;
/* 487 */     gridBagConstraints.anchor = 17;
/* 488 */     gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/* 489 */     add(this.pfSenha, gridBagConstraints);
/*     */     
/* 491 */     this.btnOk.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(
/* 492 */       160, 160, 160)));
/* 493 */     this.btnOk.setFocusPainted(false);
/* 494 */     this.btnOk.setHorizontalTextPosition(0);
/* 495 */     this.btnOk.setMaximumSize(new Dimension(101, 30));
/* 496 */     this.btnOk.setMinimumSize(new Dimension(101, 30));
/* 497 */     this.btnOk.setPreferredSize(new Dimension(101, 30));
/* 498 */     gridBagConstraints = new GridBagConstraints();
/* 499 */     gridBagConstraints.gridx = 1;
/* 500 */     gridBagConstraints.gridy = 16;
/* 501 */     gridBagConstraints.gridwidth = 2;
/* 502 */     gridBagConstraints.anchor = 13;
/* 503 */     gridBagConstraints.insets = new Insets(10, 0, 10, 24);
/* 504 */     add(this.btnOk, gridBagConstraints);
/*     */     
/* 506 */     this.btnCancel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 507 */       new Color(160, 160, 160)));
/* 508 */     this.btnCancel.setFocusPainted(false);
/* 509 */     this.btnCancel.setMaximumSize(new Dimension(101, 30));
/* 510 */     this.btnCancel.setMinimumSize(new Dimension(101, 30));
/* 511 */     this.btnCancel.setPreferredSize(new Dimension(101, 30));
/* 512 */     gridBagConstraints = new GridBagConstraints();
/* 513 */     gridBagConstraints.gridx = 3;
/* 514 */     gridBagConstraints.gridy = 16;
/* 515 */     gridBagConstraints.anchor = 17;
/* 516 */     gridBagConstraints.insets = new Insets(10, -14, 10, 46);
/* 517 */     add(this.btnCancel, gridBagConstraints);
/*     */     
/* 519 */     this.tfUsuario.setBorder(new SoftBevelBorder(1, new Color(
/* 520 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 521 */     this.tfUsuario.setMaximumSize(new Dimension(100, 19));
/* 522 */     this.tfUsuario.setMinimumSize(new Dimension(100, 19));
/* 523 */     this.tfUsuario.setPreferredSize(new Dimension(100, 19));
/* 524 */     gridBagConstraints = new GridBagConstraints();
/* 525 */     gridBagConstraints.gridx = 2;
/* 526 */     gridBagConstraints.gridy = 4;
/* 527 */     gridBagConstraints.gridwidth = 2;
/* 528 */     gridBagConstraints.fill = 2;
/* 529 */     gridBagConstraints.anchor = 17;
/* 530 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 531 */     add(this.tfUsuario, gridBagConstraints);
/*     */     
/* 533 */     this.tfEndServidor
/* 534 */       .setBorder(new SoftBevelBorder(1, new Color(
/* 535 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 536 */     this.tfEndServidor.setMinimumSize(new Dimension(100, 19));
/* 537 */     this.tfEndServidor.setPreferredSize(new Dimension(100, 19));
/* 538 */     gridBagConstraints = new GridBagConstraints();
/* 539 */     gridBagConstraints.gridx = 2;
/* 540 */     gridBagConstraints.gridy = 13;
/* 541 */     gridBagConstraints.gridwidth = 2;
/* 542 */     gridBagConstraints.fill = 2;
/* 543 */     gridBagConstraints.anchor = 17;
/* 544 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/*     */     
/* 546 */     add(this.tfEndServidor, gridBagConstraints);
/*     */     
/* 548 */     this.labelEndServidor.setFont(fonte11);
/* 549 */     gridBagConstraints = new GridBagConstraints();
/* 550 */     gridBagConstraints.gridx = 0;
/* 551 */     gridBagConstraints.gridy = 13;
/* 552 */     gridBagConstraints.gridwidth = 2;
/* 553 */     gridBagConstraints.fill = 2;
/* 554 */     gridBagConstraints.anchor = 17;
/* 555 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 556 */     add(this.labelEndServidor, gridBagConstraints);
/*     */     
/* 558 */     this.labelUsuario.setFont(fonte11);
/* 559 */     gridBagConstraints = new GridBagConstraints();
/* 560 */     gridBagConstraints.gridx = 0;
/* 561 */     gridBagConstraints.gridy = 4;
/* 562 */     gridBagConstraints.gridwidth = 2;
/* 563 */     gridBagConstraints.fill = 2;
/* 564 */     gridBagConstraints.anchor = 17;
/* 565 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 566 */     add(this.labelUsuario, gridBagConstraints);
/*     */     
/* 568 */     this.labelSMTP.setFont(fonte12N);
/* 569 */     this.labelSMTP.setMaximumSize(new Dimension(60, 15));
/* 570 */     this.labelSMTP.setMinimumSize(new Dimension(60, 15));
/* 571 */     this.labelSMTP.setPreferredSize(new Dimension(60, 15));
/* 572 */     gridBagConstraints = new GridBagConstraints();
/* 573 */     gridBagConstraints.gridx = 0;
/* 574 */     gridBagConstraints.gridy = 0;
/* 575 */     gridBagConstraints.gridwidth = 3;
/* 576 */     gridBagConstraints.fill = 2;
/* 577 */     gridBagConstraints.anchor = 13;
/* 578 */     gridBagConstraints.insets = new Insets(0, 20, 15, 0);
/* 579 */     add(this.labelSMTP, gridBagConstraints);
/*     */     
/* 581 */     this.labelRemetente.setFont(fonte11);
/* 582 */     gridBagConstraints = new GridBagConstraints();
/* 583 */     gridBagConstraints.gridx = 0;
/* 584 */     gridBagConstraints.gridy = 8;
/* 585 */     gridBagConstraints.gridwidth = 2;
/* 586 */     gridBagConstraints.fill = 2;
/* 587 */     gridBagConstraints.anchor = 17;
/* 588 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 589 */     add(this.labelRemetente, gridBagConstraints);
/*     */     
/* 591 */     this.tfRemetente
/* 592 */       .setBorder(new SoftBevelBorder(1, new Color(
/* 593 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 594 */     this.tfRemetente.setMaximumSize(new Dimension(100, 19));
/* 595 */     this.tfRemetente.setMinimumSize(new Dimension(100, 19));
/* 596 */     this.tfRemetente.setPreferredSize(new Dimension(100, 19));
/* 597 */     gridBagConstraints = new GridBagConstraints();
/* 598 */     gridBagConstraints.gridx = 2;
/* 599 */     gridBagConstraints.gridy = 8;
/* 600 */     gridBagConstraints.gridwidth = 2;
/* 601 */     gridBagConstraints.fill = 2;
/* 602 */     gridBagConstraints.anchor = 17;
/* 603 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 604 */     add(this.tfRemetente, gridBagConstraints);
/*     */     
/* 606 */     this.labelDestinatario.setFont(fonte11);
/* 607 */     gridBagConstraints = new GridBagConstraints();
/* 608 */     gridBagConstraints.gridx = 0;
/* 609 */     gridBagConstraints.gridy = 10;
/* 610 */     gridBagConstraints.gridwidth = 2;
/* 611 */     gridBagConstraints.fill = 2;
/* 612 */     gridBagConstraints.anchor = 17;
/* 613 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 614 */     add(this.labelDestinatario, gridBagConstraints);
/*     */     
/* 616 */     this.tfDestinatario
/* 617 */       .setBorder(new SoftBevelBorder(1, new Color(
/* 618 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 619 */     this.tfDestinatario.setMaximumSize(new Dimension(100, 19));
/* 620 */     this.tfDestinatario.setMinimumSize(new Dimension(100, 19));
/* 621 */     this.tfDestinatario.setPreferredSize(new Dimension(100, 19));
/* 622 */     gridBagConstraints = new GridBagConstraints();
/* 623 */     gridBagConstraints.gridx = 2;
/* 624 */     gridBagConstraints.gridy = 10;
/* 625 */     gridBagConstraints.gridwidth = 2;
/* 626 */     gridBagConstraints.fill = 2;
/* 627 */     gridBagConstraints.anchor = 17;
/* 628 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 629 */     add(this.tfDestinatario, gridBagConstraints);
/*     */     
/* 631 */     this.labelPorta.setFont(fonte11);
/* 632 */     gridBagConstraints = new GridBagConstraints();
/* 633 */     gridBagConstraints.gridx = 0;
/* 634 */     gridBagConstraints.gridy = 12;
/* 635 */     gridBagConstraints.gridwidth = 2;
/* 636 */     gridBagConstraints.fill = 2;
/* 637 */     gridBagConstraints.anchor = 17;
/* 638 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 639 */     add(this.labelPorta, gridBagConstraints);
/*     */     
/* 641 */     this.tfPorta.setBorder(new SoftBevelBorder(1, new Color(
/* 642 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 643 */     this.tfPorta.setMaximumSize(new Dimension(100, 19));
/* 644 */     this.tfPorta.setMinimumSize(new Dimension(100, 19));
/* 645 */     this.tfPorta.setPreferredSize(new Dimension(100, 19));
/* 646 */     gridBagConstraints = new GridBagConstraints();
/* 647 */     gridBagConstraints.gridx = 2;
/* 648 */     gridBagConstraints.gridy = 12;
/* 649 */     gridBagConstraints.fill = 2;
/* 650 */     gridBagConstraints.anchor = 17;
/* 651 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 652 */     add(this.tfPorta, gridBagConstraints);
/*     */     
/* 654 */     this.cbAutenticacao.setFont(fonte11);
/* 655 */     this.cbAutenticacao.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 656 */     this.cbAutenticacao.setFocusable(false);
/* 657 */     this.cbAutenticacao.setOpaque(false);
/* 658 */     this.cbAutenticacao.setMargin(new Insets(0, 0, 0, 0));
/* 659 */     gridBagConstraints = new GridBagConstraints();
/* 660 */     gridBagConstraints.gridx = 2;
/* 661 */     gridBagConstraints.gridy = 3;
/* 662 */     gridBagConstraints.fill = 1;
/* 663 */     gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/* 664 */     add(this.cbAutenticacao, gridBagConstraints);
/*     */     
/* 666 */     String[] provedores = { "LIVE", "GMAIL", "YAHOO", "CUSTOM" };
/* 667 */     this.cmbProvedores = new JComboBox(provedores);
/* 668 */     if (this.provedorEscolhido != null) {
/* 669 */       atualizarCamposEmail(this.provedorEscolhido);
/*     */     }
/*     */     
/* 672 */     gridBagConstraints = new GridBagConstraints();
/* 673 */     gridBagConstraints.gridx = 2;
/* 674 */     gridBagConstraints.gridy = 2;
/* 675 */     gridBagConstraints.gridwidth = 2;
/* 676 */     gridBagConstraints.fill = 2;
/* 677 */     gridBagConstraints.anchor = 17;
/* 678 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 679 */     add(this.cmbProvedores, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getAntigaPorta()
/*     */   {
/* 686 */     return this.antigaPorta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnCancel()
/*     */   {
/* 693 */     return this.btnCancel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnOk()
/*     */   {
/* 700 */     return this.btnOk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JCheckBox getCbAutenticacao()
/*     */   {
/* 707 */     return this.cbAutenticacao;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFlag()
/*     */   {
/* 714 */     return this.flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getFlag()
/*     */   {
/* 721 */     return this.flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelDestinatario()
/*     */   {
/* 728 */     return this.labelDestinatario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelEndServidor()
/*     */   {
/* 735 */     return this.labelEndServidor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelPorta()
/*     */   {
/* 742 */     return this.labelPorta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelRemetente()
/*     */   {
/* 749 */     return this.labelRemetente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelSenha()
/*     */   {
/* 756 */     return this.labelSenha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelSMTP()
/*     */   {
/* 763 */     return this.labelSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelUsuario()
/*     */   {
/* 770 */     return this.labelUsuario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JPasswordField getPfSenha()
/*     */   {
/* 777 */     return this.pfSenha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getTfDestinatario()
/*     */   {
/* 784 */     return this.tfDestinatario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getTfEndServidor()
/*     */   {
/* 791 */     return this.tfEndServidor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getTfPorta()
/*     */   {
/* 798 */     return this.tfPorta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getTfRemetente()
/*     */   {
/* 805 */     return this.tfRemetente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getTfUsuario()
/*     */   {
/* 812 */     return this.tfUsuario;
/*     */   }
/*     */   
/*     */   public String getProvedor() {
/* 816 */     return this.provedorEscolhido;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAntigaPorta(int antigaPorta)
/*     */   {
/* 824 */     this.antigaPorta = antigaPorta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnCancel(JButton btnCancel)
/*     */   {
/* 832 */     this.btnCancel = btnCancel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBtnOk(JButton btnOk)
/*     */   {
/* 840 */     this.btnOk = btnOk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCbAutenticacao(JCheckBox cbAutenticacao)
/*     */   {
/* 848 */     this.cbAutenticacao = cbAutenticacao;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlag(boolean flag)
/*     */   {
/* 856 */     this.flag = flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelDestinatario(JLabel labelDestinatario)
/*     */   {
/* 864 */     this.labelDestinatario = labelDestinatario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelEndServidor(JLabel labelEndServidor)
/*     */   {
/* 872 */     this.labelEndServidor = labelEndServidor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelPorta(JLabel labelPorta)
/*     */   {
/* 880 */     this.labelPorta = labelPorta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelRemetente(JLabel labelRemetente)
/*     */   {
/* 888 */     this.labelRemetente = labelRemetente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelSenha(JLabel labelSenha)
/*     */   {
/* 896 */     this.labelSenha = labelSenha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelSMTP(JLabel labelSMTP)
/*     */   {
/* 904 */     this.labelSMTP = labelSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelUsuario(JLabel labelUsuario)
/*     */   {
/* 912 */     this.labelUsuario = labelUsuario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPfSenha(JPasswordField pfSenha)
/*     */   {
/* 920 */     this.pfSenha = pfSenha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTfDestinatario(JTextField tfDestinatario)
/*     */   {
/* 928 */     this.tfDestinatario = tfDestinatario;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTfEndServidor(JTextField tfEndServidor)
/*     */   {
/* 936 */     this.tfEndServidor = tfEndServidor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTfPorta(JTextField tfPorta)
/*     */   {
/* 944 */     this.tfPorta = tfPorta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTfRemetente(JTextField tfRemetente)
/*     */   {
/* 952 */     this.tfRemetente = tfRemetente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTfUsuario(JTextField tfUsuario)
/*     */   {
/* 960 */     this.tfUsuario = tfUsuario;
/*     */   }
/*     */   
/*     */   public void setProvedor(String provedorEscolhido) {
/* 964 */     this.provedorEscolhido = provedorEscolhido;
/*     */   }
/*     */   
/*     */   public JComboBox<String> getCmbProvedores() {
/* 968 */     return this.cmbProvedores;
/*     */   }
/*     */   
/*     */   public void setCmbProvedores(JComboBox<String> cmbProvedores) {
/* 972 */     this.cmbProvedores = cmbProvedores;
/*     */   }
/*     */   
/*     */   private boolean isStrNulaOuVazia(String str) {
/* 976 */     return (str == null) || (str.equals(""));
/*     */   }
/*     */   
/*     */   private boolean isStrNulaOuVazia(char[] chars)
/*     */   {
/*     */     try {
/* 982 */       return (chars == null) || (chars.length == 0);
/*     */     } catch (Exception e) {}
/* 984 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelSMTP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */