/*      */ package br.com.schneider.sgm.gui;
/*      */ 
/*      */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FlowLayout;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class PainelBateria
/*      */   extends JPanel
/*      */ {
/*      */   private JLabel autonomia;
/*      */   private JLabel labelAutonomia;
/*      */   private JLabel labelBarraLimInferior;
/*      */   private JLabel labelBarraLimSuperior;
/*      */   private JLabel labelBarraMedio;
/*      */   private JLabel labelPercentual;
/*      */   private JLabel labelTensao;
/*      */   Barra4 panelBarraTensaoBat;
/*      */   private JLabel tensao;
/*      */   private DecimalFormat formatador;
/*      */   private String titulo;
/*      */   private ImageIcon imagemFundo;
/*      */   private JPanel enchimento3;
/*      */   
/*      */   public PainelBateria(String caminhoFiguras)
/*      */   {
/* 1411 */     initComponents();
/* 1412 */     this.imagemFundo = new ImageIcon(caminhoFiguras + "painelInferior.png");
/* 1413 */     this.formatador = new DecimalFormat("0.0");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void validarIdioma()
/*      */   {
/* 1420 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1421 */       "BATERIA");
/* 1422 */     this.enchimento3.setBorder(BorderFactory.createTitledBorder(
/* 1423 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 1424 */       0, 1, 
/* 1425 */       new Font("Trebuchet", 1, 12)));
/* 1426 */     this.labelTensao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1427 */       .getString("TENSAO"));
/* 1428 */     this.labelAutonomia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1429 */       .getString("AUTONOMIA"));
/* 1430 */     this.labelPercentual.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1431 */       .getString("PERCENTUAL"));
/*      */   }
/*      */   
/*      */ 
/*      */   public void paintComponent(Graphics g)
/*      */   {
/* 1437 */     super.paintComponent(g);
/* 1438 */     g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initComponents()
/*      */   {
/* 1448 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 1449 */     Dimension d = new Dimension(205, 135);
/* 1450 */     Font fonte11P = new Font("Trebuchet", 0, 11);
/* 1451 */     Font fonte11B = new Font("Trebuchet", 1, 11);
/* 1452 */     Font fonte12P = new Font("Trebuchet", 0, 12);
/* 1453 */     Font fonte12B = new Font("Trebuchet", 1, 12);
/* 1454 */     int local = 50;
/*      */     
/* 1456 */     this.labelPercentual = new JLabel();
/* 1457 */     this.labelTensao = new JLabel();
/* 1458 */     this.tensao = new JLabel();
/* 1459 */     this.labelAutonomia = new JLabel();
/* 1460 */     this.autonomia = new JLabel();
/* 1461 */     this.panelBarraTensaoBat = new Barra4();
/* 1462 */     this.labelBarraLimInferior = new JLabel();
/* 1463 */     this.labelBarraMedio = new JLabel();
/* 1464 */     this.labelBarraLimSuperior = new JLabel();
/* 1465 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1466 */       "BATERIA");
/*      */     
/* 1468 */     this.enchimento3 = new JPanel();
/* 1469 */     setLayout(new FlowLayout(1, 0, 3));
/* 1470 */     setOpaque(false);
/* 1471 */     add(this.enchimento3);
/*      */     
/* 1473 */     this.enchimento3.setLayout(new GridBagLayout());
/*      */     
/* 1475 */     this.enchimento3.setBorder(BorderFactory.createTitledBorder(
/* 1476 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 1477 */       0, 1, 
/* 1478 */       fonte12B));
/* 1479 */     this.enchimento3.setMaximumSize(d);
/* 1480 */     this.enchimento3.setMinimumSize(d);
/* 1481 */     this.enchimento3.setOpaque(false);
/* 1482 */     this.enchimento3.setPreferredSize(d);
/*      */     
/* 1484 */     this.labelPercentual.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1485 */       .getString("PERCENTUAL"));
/* 1486 */     this.labelPercentual.setFont(fonte12B);
/* 1487 */     gridBagConstraints.gridwidth = 5;
/* 1488 */     gridBagConstraints.anchor = 17;
/* 1489 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/* 1490 */     this.enchimento3.add(this.labelPercentual, gridBagConstraints);
/*      */     
/* 1492 */     this.labelTensao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1493 */       .getString("TENSAO"));
/* 1494 */     this.labelTensao.setFont(fonte11B);
/* 1495 */     gridBagConstraints.gridx = 0;
/* 1496 */     gridBagConstraints.gridy = 4;
/* 1497 */     gridBagConstraints.gridwidth = 2;
/* 1498 */     gridBagConstraints.anchor = 17;
/* 1499 */     gridBagConstraints.insets = new Insets(5, 0, 3, 0);
/* 1500 */     this.enchimento3.add(this.labelTensao, gridBagConstraints);
/*      */     
/* 1502 */     this.tensao.setFont(fonte11P);
/* 1503 */     this.tensao.setText("000.0V");
/* 1504 */     gridBagConstraints.gridx = 4;
/* 1505 */     gridBagConstraints.gridy = 4;
/* 1506 */     gridBagConstraints.anchor = 13;
/* 1507 */     gridBagConstraints.insets = new Insets(5, local, 3, 0);
/* 1508 */     this.enchimento3.add(this.tensao, gridBagConstraints);
/*      */     
/* 1510 */     this.labelAutonomia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1511 */       .getString("AUTONOMIA"));
/* 1512 */     this.labelAutonomia.setFont(fonte11B);
/* 1513 */     gridBagConstraints.gridx = 0;
/* 1514 */     gridBagConstraints.gridy = 6;
/* 1515 */     gridBagConstraints.gridwidth = 2;
/* 1516 */     gridBagConstraints.anchor = 17;
/* 1517 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/* 1518 */     this.enchimento3.add(this.labelAutonomia, gridBagConstraints);
/*      */     
/* 1520 */     this.autonomia.setFont(fonte11P);
/* 1521 */     this.autonomia.setText("00min");
/* 1522 */     gridBagConstraints.gridx = 4;
/* 1523 */     gridBagConstraints.gridy = 6;
/* 1524 */     gridBagConstraints.gridwidth = 1;
/* 1525 */     gridBagConstraints.anchor = 13;
/* 1526 */     gridBagConstraints.insets = new Insets(0, local, 0, 0);
/* 1527 */     this.enchimento3.add(this.autonomia, gridBagConstraints);
/*      */     
/* 1529 */     this.panelBarraTensaoBat.setMinimumSize(new Dimension(10, 20));
/* 1530 */     this.panelBarraTensaoBat.setPreferredSize(new Dimension(10, 20));
/* 1531 */     this.panelBarraTensaoBat.setRequestFocusEnabled(false);
/* 1532 */     gridBagConstraints.gridx = 0;
/* 1533 */     gridBagConstraints.gridy = 1;
/* 1534 */     gridBagConstraints.gridwidth = 6;
/* 1535 */     gridBagConstraints.fill = 1;
/* 1536 */     gridBagConstraints.insets = new Insets(0, 9, 0, 0);
/* 1537 */     this.enchimento3.add(this.panelBarraTensaoBat, gridBagConstraints);
/*      */     
/* 1539 */     this.labelBarraLimInferior.setFont(fonte11P);
/* 1540 */     this.labelBarraLimInferior.setText("0%");
/* 1541 */     gridBagConstraints = new GridBagConstraints();
/* 1542 */     gridBagConstraints.gridx = 0;
/* 1543 */     gridBagConstraints.gridy = 2;
/* 1544 */     gridBagConstraints.anchor = 17;
/* 1545 */     gridBagConstraints.insets = new Insets(0, 9, 0, 0);
/* 1546 */     this.enchimento3.add(this.labelBarraLimInferior, gridBagConstraints);
/*      */     
/* 1548 */     this.labelBarraMedio.setFont(fonte11P);
/* 1549 */     this.labelBarraMedio.setText("50%");
/* 1550 */     gridBagConstraints.gridx = 2;
/* 1551 */     gridBagConstraints.gridy = 2;
/* 1552 */     this.enchimento3.add(this.labelBarraMedio, gridBagConstraints);
/*      */     
/* 1554 */     this.labelBarraLimSuperior.setFont(fonte11P);
/* 1555 */     this.labelBarraLimSuperior.setText("100%");
/* 1556 */     gridBagConstraints.gridx = 4;
/* 1557 */     gridBagConstraints.gridy = 2;
/* 1558 */     gridBagConstraints.anchor = 13;
/* 1559 */     gridBagConstraints.insets = new Insets(0, 32, 0, 0);
/* 1560 */     this.enchimento3.add(this.labelBarraLimSuperior, gridBagConstraints);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutonomia(JLabel l)
/*      */   {
/* 1570 */     this.autonomia = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLabelAutonomia(JLabel l)
/*      */   {
/* 1576 */     this.labelAutonomia = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLabelBarraLimInferior(JLabel l)
/*      */   {
/* 1582 */     this.labelBarraLimInferior = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLabelBarraLimSuperior(JLabel l)
/*      */   {
/* 1588 */     this.labelBarraLimSuperior = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLabelBarraMedio(JLabel l)
/*      */   {
/* 1594 */     this.labelBarraMedio = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLabelPercentual(JLabel l)
/*      */   {
/* 1600 */     this.labelPercentual = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLabelTensao(JLabel l)
/*      */   {
/* 1606 */     this.labelTensao = l;
/*      */   }
/*      */   
/*      */   public void setTensao(JLabel l)
/*      */   {
/* 1611 */     this.tensao = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAutonomia(int i)
/*      */   {
/* 1617 */     this.autonomia.setText(i + "min");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTensao(float f)
/*      */   {
/* 1623 */     this.tensao.setText(this.formatador.format(f) + "V");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JLabel getAutonomia()
/*      */   {
/* 1634 */     return this.autonomia;
/*      */   }
/*      */   
/*      */   public JLabel getLabelAutonomia()
/*      */   {
/* 1639 */     return this.labelAutonomia;
/*      */   }
/*      */   
/*      */   public JLabel getLabelBarraLimInferior()
/*      */   {
/* 1644 */     return this.labelBarraLimInferior;
/*      */   }
/*      */   
/*      */   public JLabel getLabelBarraLimSuperior()
/*      */   {
/* 1649 */     return this.labelBarraLimSuperior;
/*      */   }
/*      */   
/*      */   public JLabel getLabelBarraMedio()
/*      */   {
/* 1654 */     return this.labelBarraMedio;
/*      */   }
/*      */   
/*      */   public JLabel getLabelPercentual()
/*      */   {
/* 1659 */     return this.labelPercentual;
/*      */   }
/*      */   
/*      */   public JLabel getLabelTensao()
/*      */   {
/* 1664 */     return this.labelTensao;
/*      */   }
/*      */   
/*      */   public JLabel getTensao()
/*      */   {
/* 1669 */     return this.tensao;
/*      */   }
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelBateria.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */