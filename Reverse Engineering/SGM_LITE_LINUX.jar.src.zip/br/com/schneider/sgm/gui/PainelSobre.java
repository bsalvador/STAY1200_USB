/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.border.SoftBevelBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelSobre
/*     */   extends JPanel
/*     */ {
/*     */   private JScrollPane scrollPane;
/*     */   private JTextPane textArea;
/*     */   private ImageIcon imagemFundo;
/*     */   private String version;
/*     */   private JLabel labelVersion;
/*     */   
/*     */   public PainelSobre(String caminhoImagem, String versao)
/*     */   {
/*  51 */     this.imagemFundo = new ImageIcon(caminhoImagem + "telaSobre.jpg");
/*  52 */     this.version = versao;
/*  53 */     this.labelVersion = new JLabel();
/*  54 */     validarIdioma();
/*  55 */     initComponents();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  65 */     Dimension d1 = new Dimension(513, 300);
/*  66 */     Dimension d2 = new Dimension(500, 100);
/*     */     
/*  68 */     this.scrollPane = new JScrollPane();
/*  69 */     this.textArea = new JTextPane();
/*     */     
/*  71 */     setLayout(new BorderLayout());
/*     */     
/*  73 */     setMaximumSize(d1);
/*  74 */     setMinimumSize(d1);
/*  75 */     setOpaque(false);
/*  76 */     setPreferredSize(d1);
/*     */     
/*  78 */     this.textArea.setFont(new Font("Trebuchet", 1, 14));
/*  79 */     this.textArea.setBorder(new SoftBevelBorder(1));
/*  80 */     this.textArea.setDisabledTextColor(new Color(0, 0, 0));
/*  81 */     this.textArea.setEnabled(false);
/*  82 */     this.textArea.setMaximumSize(d2);
/*  83 */     this.textArea.setMinimumSize(d2);
/*  84 */     this.textArea.setPreferredSize(d2);
/*  85 */     this.textArea.insertIcon(this.imagemFundo);
/*  86 */     this.textArea.insertComponent(this.labelVersion);
/*     */     
/*     */ 
/*  89 */     this.scrollPane.setMaximumSize(d1);
/*  90 */     this.scrollPane.setMinimumSize(d1);
/*  91 */     this.scrollPane.setPreferredSize(d1);
/*  92 */     this.scrollPane.setViewportView(this.textArea);
/*  93 */     add(this.scrollPane, "Center");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 104 */     this.labelVersion.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 105 */       .getString("VERSAO") + " " + this.version);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JScrollPane getScrollPane()
/*     */   {
/* 113 */     return this.scrollPane;
/*     */   }
/*     */   
/*     */   public JTextPane getTextArea() {
/* 117 */     return this.textArea;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setScrollPane(JScrollPane scrollPane)
/*     */   {
/* 123 */     this.scrollPane = scrollPane;
/*     */   }
/*     */   
/*     */   public void setTextArea(JTextPane textArea) {
/* 127 */     this.textArea = textArea;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelSobre.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */