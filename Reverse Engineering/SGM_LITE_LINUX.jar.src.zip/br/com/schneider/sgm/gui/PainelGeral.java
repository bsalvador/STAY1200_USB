/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.SoftBevelBorder;
/*     */ import javax.swing.event.CaretEvent;
/*     */ import javax.swing.event.CaretListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelGeral
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 7998800863231524765L;
/*     */   private JButton btnCancel;
/*     */   private JButton btnOk;
/*     */   private JButton btnProcura;
/*     */   private JComboBox comboBoxEvento;
/*     */   private JComboBox comboBoxIdioma;
/*     */   private JComboBox comboBoxSerial;
/*     */   private JLabel labelEvento;
/*     */   private JLabel labelScript;
/*     */   private JLabel labelAmperes;
/*     */   private JLabel labelBateria;
/*     */   private JLabel labelIdioma;
/*     */   private JLabel labelSerial;
/*     */   private JLabel labelTitulo;
/*     */   private JLabel labelLogging;
/*     */   private JTextField textFieldExpanBat;
/*     */   private JTextField tfScript;
/*     */   private String[] dados;
/*     */   private boolean flag;
/*     */   private JCheckBox cbShutdownRemoto;
/*     */   private JCheckBox cbVarLogging;
/*     */   private JLabel labelPortaShutdownRemoto;
/*     */   private JTextField tfPortaShutdownRemoto;
/*     */   private int portaAntiga;
/*     */   private boolean varLogging;
/*     */   
/*     */   public PainelGeral()
/*     */   {
/* 174 */     initComponents();
/* 175 */     String[] aux = { "", "", "", "", "" };
/* 176 */     this.dados = aux;
/* 177 */     this.flag = false;
/* 178 */     addListeners();
/* 179 */     this.tfPortaShutdownRemoto.setBackground(new Color(230, 230, 230));
/* 180 */     this.tfPortaShutdownRemoto.setEnabled(false);
/* 181 */     this.labelPortaShutdownRemoto.setEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addListeners()
/*     */   {
/* 194 */     this.comboBoxIdioma.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 196 */         PainelGeral.this.flag = true;
/*     */       }
/*     */       
/* 199 */     });
/* 200 */     this.comboBoxEvento.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 202 */         PainelGeral.this.flag = true;
/*     */       }
/*     */       
/* 205 */     });
/* 206 */     this.tfScript.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 208 */         PainelGeral.this.flag = true;
/*     */       }
/*     */       
/* 211 */     });
/* 212 */     this.tfPortaShutdownRemoto.addCaretListener(new CaretListener() {
/*     */       public void caretUpdate(CaretEvent ce) {
/* 214 */         PainelGeral.this.flag = true;
/*     */       }
/*     */       
/* 217 */     });
/* 218 */     this.cbShutdownRemoto.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 220 */         PainelGeral.this.flag = true;
/* 221 */         if (!PainelGeral.this.cbShutdownRemoto.isSelected())
/*     */         {
/* 223 */           PainelGeral.this.tfPortaShutdownRemoto.setBackground(new Color(230, 230, 230));
/* 224 */           PainelGeral.this.tfPortaShutdownRemoto.setEnabled(false);
/* 225 */           PainelGeral.this.labelPortaShutdownRemoto.setEnabled(false);
/*     */         } else {
/* 227 */           PainelGeral.this.tfPortaShutdownRemoto.setBackground(Color.WHITE);
/* 228 */           PainelGeral.this.tfPortaShutdownRemoto.setEnabled(true);
/* 229 */           PainelGeral.this.labelPortaShutdownRemoto.setEnabled(true);
/*     */         }
/*     */         
/*     */       }
/* 233 */     });
/* 234 */     this.cbVarLogging.addItemListener(new ItemListener()
/*     */     {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 237 */         PainelGeral.this.flag = true;
/* 238 */         if (!PainelGeral.this.cbVarLogging.isSelected()) {
/* 239 */           PainelGeral.this.varLogging = true;
/*     */         }
/*     */         else
/*     */         {
/* 243 */           PainelGeral.this.varLogging = false;
/*     */         }
/*     */         
/*     */       }
/* 247 */     });
/* 248 */     this.btnCancel.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 250 */         PainelGeral.this.comboBoxIdioma.setSelectedItem(PainelGeral.this.dados[0]);
/* 251 */         PainelGeral.this.comboBoxEvento.setSelectedItem(PainelGeral.this.dados[1]);
/* 252 */         PainelGeral.this.tfScript.setText(PainelGeral.this.dados[2]);
/* 253 */         PainelGeral.this.tfPortaShutdownRemoto.setText(Integer.toString(PainelGeral.this.portaAntiga));
/*     */         
/*     */ 
/* 256 */         PainelGeral.this.flag = false;
/*     */       }
/*     */       
/* 259 */     });
/* 260 */     this.btnOk.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 262 */         PainelGeral.this.flag = false;
/* 263 */         PainelGeral.this.dados[0] = PainelGeral.this.comboBoxIdioma.getSelectedItem().toString();
/* 264 */         PainelGeral.this.dados[1] = PainelGeral.this.comboBoxEvento.getSelectedItem().toString();
/* 265 */         PainelGeral.this.dados[2] = PainelGeral.this.tfScript.getText();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewEvento(String str)
/*     */   {
/* 275 */     this.comboBoxEvento.addItem(str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPortaValida()
/*     */   {
/*     */     try
/*     */     {
/* 284 */       int i = Integer.parseInt(this.tfPortaShutdownRemoto.getText());
/* 285 */       return true;
/*     */     } catch (NumberFormatException nfe) {
/* 287 */       this.tfPortaShutdownRemoto.setText(Integer.toString(this.portaAntiga)); }
/* 288 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPorta()
/*     */   {
/*     */     try
/*     */     {
/* 298 */       int i = Integer.parseInt(this.tfPortaShutdownRemoto.getText());
/* 299 */       this.portaAntiga = i;
/* 300 */       return this.portaAntiga;
/*     */     } catch (NumberFormatException nfe) {
/* 302 */       this.tfPortaShutdownRemoto.setText(Integer.toString(this.portaAntiga)); }
/* 303 */     return this.portaAntiga;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getEventoScript()
/*     */   {
/* 316 */     this.dados[1] = ((String)this.comboBoxEvento.getSelectedItem());
/* 317 */     this.dados[2] = this.tfScript.getText();
/* 318 */     String[] str = { this.dados[1], this.dados[2] };
/* 319 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdioma()
/*     */   {
/* 327 */     this.dados[0] = ((String)this.comboBoxIdioma.getSelectedItem());
/* 328 */     return this.dados[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 335 */     this.labelTitulo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 336 */       .getString("CONFIGURACOES_GERAIS"));
/* 337 */     this.labelIdioma.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 338 */       .getString("IDIOMA"));
/* 339 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 340 */       "OK"));
/* 341 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 342 */       .getString("CANCELAR"));
/* 343 */     this.labelEvento.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 344 */       .getString("EVENTO"));
/* 345 */     this.labelScript.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 346 */       .getString("SCRIPT"));
/* 347 */     this.cbVarLogging.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 348 */       .getString("VARLOG"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 355 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 356 */     Font fonte12 = new Font("Trebuchet", 0, 12);
/* 357 */     Font fonte12N = new Font("Trebuchet", 1, 12);
/* 358 */     Font fonte11N = new Font("Trebuchet", 1, 11);
/* 359 */     Font fonte11 = new Font("Trebuchet", 0, 11);
/*     */     
/* 361 */     this.labelTitulo = new JLabel();
/* 362 */     this.labelSerial = new JLabel();
/* 363 */     this.comboBoxSerial = new JComboBox();
/* 364 */     this.labelIdioma = new JLabel();
/* 365 */     this.comboBoxIdioma = new JComboBox();
/* 366 */     this.labelBateria = new JLabel();
/* 367 */     this.textFieldExpanBat = new JTextField();
/* 368 */     this.labelAmperes = new JLabel();
/* 369 */     this.btnOk = new JButton();
/* 370 */     this.btnProcura = new JButton();
/* 371 */     this.btnCancel = new JButton();
/* 372 */     this.cbShutdownRemoto = new JCheckBox();
/* 373 */     this.labelPortaShutdownRemoto = new JLabel();
/* 374 */     this.tfPortaShutdownRemoto = new JTextField();
/* 375 */     this.tfScript = new JTextField();
/* 376 */     this.labelEvento = new JLabel();
/* 377 */     this.labelScript = new JLabel();
/* 378 */     this.comboBoxEvento = new JComboBox();
/*     */     
/* 380 */     this.cbVarLogging = new JCheckBox();
/* 381 */     this.labelLogging = new JLabel();
/*     */     
/*     */ 
/* 384 */     setLayout(new GridBagLayout());
/* 385 */     setBackground(new Color(255, 255, 255));
/* 386 */     setMaximumSize(new Dimension(384, 335));
/* 387 */     setMinimumSize(new Dimension(384, 335));
/* 388 */     setOpaque(false);
/* 389 */     setPreferredSize(new Dimension(384, 335));
/*     */     
/*     */ 
/* 392 */     this.labelTitulo.setFont(fonte12N);
/* 393 */     this.labelTitulo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 394 */       .getString("CONFIGURACOES_GERAIS"));
/* 395 */     gridBagConstraints.gridwidth = 4;
/* 396 */     gridBagConstraints.fill = 2;
/* 397 */     gridBagConstraints.anchor = 17;
/* 398 */     gridBagConstraints.insets = new Insets(30, 20, 5, 0);
/* 399 */     add(this.labelTitulo, gridBagConstraints);
/*     */     
/*     */ 
/* 402 */     this.labelIdioma.setFont(fonte11);
/* 403 */     this.labelIdioma.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 404 */       .getString("IDIOMA"));
/* 405 */     gridBagConstraints.gridx = 0;
/* 406 */     gridBagConstraints.gridy = 4;
/* 407 */     gridBagConstraints.gridwidth = 2;
/* 408 */     gridBagConstraints.fill = 2;
/* 409 */     gridBagConstraints.anchor = 17;
/* 410 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 411 */     add(this.labelIdioma, gridBagConstraints);
/*     */     
/*     */ 
/* 414 */     this.comboBoxIdioma.setFont(fonte12);
/* 415 */     this.comboBoxIdioma.setModel(new DefaultComboBoxModel(new String[] {
/* 416 */       "PORTUGUÊS", "ENGLISH" }));
/* 417 */     this.comboBoxIdioma.setOpaque(false);
/* 418 */     gridBagConstraints.gridx = 2;
/* 419 */     gridBagConstraints.gridy = 4;
/* 420 */     gridBagConstraints.gridwidth = 1;
/* 421 */     gridBagConstraints.fill = 2;
/* 422 */     gridBagConstraints.anchor = 17;
/* 423 */     gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/* 424 */     add(this.comboBoxIdioma, gridBagConstraints);
/*     */     
/*     */ 
/* 427 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 428 */       "OK"));
/* 429 */     this.btnOk.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(
/* 430 */       160, 160, 160)));
/* 431 */     this.btnOk.setFocusPainted(false);
/* 432 */     this.btnOk.setHorizontalTextPosition(0);
/* 433 */     this.btnOk.setMaximumSize(new Dimension(101, 30));
/* 434 */     this.btnOk.setMinimumSize(new Dimension(101, 30));
/* 435 */     this.btnOk.setPreferredSize(new Dimension(101, 30));
/* 436 */     gridBagConstraints.gridx = 2;
/* 437 */     gridBagConstraints.gridy = 25;
/* 438 */     gridBagConstraints.gridwidth = 1;
/* 439 */     gridBagConstraints.fill = 1;
/* 440 */     gridBagConstraints.anchor = 13;
/* 441 */     gridBagConstraints.insets = new Insets(70, 0, 20, 10);
/* 442 */     add(this.btnOk, gridBagConstraints);
/*     */     
/*     */ 
/* 445 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 446 */       .getString("CANCELAR"));
/* 447 */     this.btnCancel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 448 */       new Color(160, 160, 160)));
/* 449 */     this.btnCancel.setFocusPainted(false);
/* 450 */     this.btnCancel.setMaximumSize(new Dimension(101, 30));
/* 451 */     this.btnCancel.setMinimumSize(new Dimension(101, 30));
/* 452 */     this.btnCancel.setPreferredSize(new Dimension(101, 30));
/* 453 */     gridBagConstraints.gridx = 3;
/* 454 */     gridBagConstraints.gridy = 25;
/* 455 */     gridBagConstraints.gridwidth = 1;
/* 456 */     gridBagConstraints.fill = 1;
/* 457 */     gridBagConstraints.anchor = 17;
/* 458 */     gridBagConstraints.insets = new Insets(70, 0, 20, 46);
/* 459 */     add(this.btnCancel, gridBagConstraints);
/*     */     
/*     */ 
/* 462 */     this.tfScript.setBorder(new SoftBevelBorder(1, new Color(
/* 463 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 464 */     this.tfScript.setMinimumSize(new Dimension(100, 19));
/* 465 */     this.tfScript.setPreferredSize(new Dimension(100, 19));
/* 466 */     this.tfScript.setFont(fonte12);
/* 467 */     gridBagConstraints.gridx = 2;
/* 468 */     gridBagConstraints.gridy = 10;
/* 469 */     gridBagConstraints.gridwidth = 1;
/* 470 */     gridBagConstraints.fill = 2;
/* 471 */     gridBagConstraints.anchor = 10;
/* 472 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 473 */     add(this.tfScript, gridBagConstraints);
/*     */     
/*     */ 
/* 476 */     this.btnProcura.setText(" . . . ");
/* 477 */     this.btnProcura.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 478 */       new Color(160, 160, 160)));
/* 479 */     this.btnProcura.setMinimumSize(new Dimension(50, 19));
/* 480 */     this.btnProcura.setPreferredSize(new Dimension(50, 19));
/* 481 */     this.btnProcura.setFocusPainted(false);
/* 482 */     this.btnProcura.setFont(new Font("Trebuchet", 1, 16));
/* 483 */     gridBagConstraints.gridx = 3;
/* 484 */     gridBagConstraints.gridy = 10;
/* 485 */     gridBagConstraints.gridwidth = 1;
/* 486 */     gridBagConstraints.fill = 0;
/* 487 */     gridBagConstraints.anchor = 17;
/* 488 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 489 */     add(this.btnProcura, gridBagConstraints);
/*     */     
/*     */ 
/* 492 */     this.labelEvento.setFont(fonte11);
/* 493 */     this.labelEvento.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 494 */       .getString("EVENTO"));
/* 495 */     gridBagConstraints.gridx = 0;
/* 496 */     gridBagConstraints.gridy = 8;
/* 497 */     gridBagConstraints.gridwidth = 2;
/* 498 */     gridBagConstraints.fill = 2;
/* 499 */     gridBagConstraints.anchor = 10;
/* 500 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 501 */     add(this.labelEvento, gridBagConstraints);
/*     */     
/*     */ 
/* 504 */     this.cbShutdownRemoto.setFont(fonte11);
/* 505 */     this.cbShutdownRemoto.setText("SHUTDOWN REMOTO");
/* 506 */     this.cbShutdownRemoto.setOpaque(false);
/* 507 */     this.cbShutdownRemoto.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 508 */     this.cbShutdownRemoto.setFocusPainted(false);
/* 509 */     this.cbShutdownRemoto.setMargin(new Insets(0, 0, 0, 0));
/* 510 */     gridBagConstraints.gridx = 0;
/* 511 */     gridBagConstraints.gridy = 12;
/* 512 */     gridBagConstraints.gridwidth = 3;
/* 513 */     gridBagConstraints.fill = 2;
/* 514 */     gridBagConstraints.anchor = 10;
/* 515 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 516 */     add(this.cbShutdownRemoto, gridBagConstraints);
/*     */     
/*     */ 
/* 519 */     this.cbVarLogging.setFont(fonte11);
/* 520 */     this.cbVarLogging.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString("VARLOG"));
/* 521 */     this.cbVarLogging.setOpaque(false);
/* 522 */     this.cbVarLogging.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 523 */     this.cbVarLogging.setFocusPainted(false);
/* 524 */     this.cbVarLogging.setMargin(new Insets(0, 0, 0, 0));
/* 525 */     gridBagConstraints.gridx = 0;
/* 526 */     gridBagConstraints.gridy = 14;
/* 527 */     gridBagConstraints.gridwidth = 3;
/* 528 */     gridBagConstraints.fill = 2;
/* 529 */     gridBagConstraints.anchor = 10;
/* 530 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 531 */     add(this.cbVarLogging, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 535 */     this.labelScript.setFont(fonte11);
/* 536 */     this.labelScript.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 537 */       .getString("SCRIPT"));
/* 538 */     gridBagConstraints.gridx = 0;
/* 539 */     gridBagConstraints.gridy = 10;
/* 540 */     gridBagConstraints.gridwidth = 2;
/* 541 */     gridBagConstraints.fill = 2;
/* 542 */     gridBagConstraints.anchor = 10;
/* 543 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 544 */     add(this.labelScript, gridBagConstraints);
/*     */     
/*     */ 
/* 547 */     this.labelPortaShutdownRemoto.setFont(fonte11);
/* 548 */     this.labelPortaShutdownRemoto.setText("PORTA :");
/* 549 */     gridBagConstraints.gridx = 0;
/* 550 */     gridBagConstraints.gridy = 16;
/* 551 */     gridBagConstraints.gridwidth = 2;
/* 552 */     gridBagConstraints.fill = 2;
/* 553 */     gridBagConstraints.anchor = 10;
/* 554 */     gridBagConstraints.insets = new Insets(0, 20, 5, 0);
/* 555 */     add(this.labelPortaShutdownRemoto, gridBagConstraints);
/*     */     
/*     */ 
/* 558 */     this.tfPortaShutdownRemoto.setBorder(new SoftBevelBorder(
/* 559 */       1, new Color(204, 204, 204), new Color(204, 
/* 560 */       204, 204), null, null));
/* 561 */     this.tfPortaShutdownRemoto.setMinimumSize(new Dimension(100, 19));
/* 562 */     this.tfPortaShutdownRemoto.setPreferredSize(new Dimension(100, 19));
/* 563 */     this.tfPortaShutdownRemoto.setFont(fonte12);
/* 564 */     gridBagConstraints.gridx = 2;
/* 565 */     gridBagConstraints.gridy = 16;
/* 566 */     gridBagConstraints.gridwidth = 1;
/* 567 */     gridBagConstraints.fill = 2;
/* 568 */     gridBagConstraints.anchor = 10;
/* 569 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 570 */     add(this.tfPortaShutdownRemoto, gridBagConstraints);
/*     */     
/*     */ 
/* 573 */     this.comboBoxEvento.setModel(new DefaultComboBoxModel());
/* 574 */     this.comboBoxEvento.setFont(fonte12);
/* 575 */     gridBagConstraints.gridx = 2;
/* 576 */     gridBagConstraints.gridy = 8;
/* 577 */     gridBagConstraints.gridwidth = 2;
/* 578 */     gridBagConstraints.fill = 2;
/* 579 */     gridBagConstraints.anchor = 10;
/* 580 */     gridBagConstraints.insets = new Insets(0, 0, 5, 25);
/* 581 */     add(this.comboBoxEvento, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */   public JButton getBtnCancel()
/*     */   {
/* 587 */     return this.btnCancel;
/*     */   }
/*     */   
/*     */   public JButton getBtnOk() {
/* 591 */     return this.btnOk;
/*     */   }
/*     */   
/*     */   public JButton getBtnProcura() {
/* 595 */     return this.btnProcura;
/*     */   }
/*     */   
/*     */   public JComboBox getComboBoxEvento() {
/* 599 */     return this.comboBoxEvento;
/*     */   }
/*     */   
/*     */   public JComboBox getComboBoxIdioma() {
/* 603 */     return this.comboBoxIdioma;
/*     */   }
/*     */   
/*     */   public JComboBox getComboBoxSerial() {
/* 607 */     return this.comboBoxSerial;
/*     */   }
/*     */   
/*     */   public JLabel getLabelAmperes() {
/* 611 */     return this.labelAmperes;
/*     */   }
/*     */   
/*     */   public JLabel getLabelBateria() {
/* 615 */     return this.labelBateria;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JCheckBox getCbVarLogging()
/*     */   {
/* 622 */     return this.cbVarLogging;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JCheckBox getCbShutdownRemoto()
/*     */   {
/* 630 */     return this.cbShutdownRemoto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getDados()
/*     */   {
/* 637 */     return this.dados;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getLabelPortaShutdownRemoto()
/*     */   {
/* 644 */     return this.labelPortaShutdownRemoto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPortaAntiga()
/*     */   {
/* 651 */     return this.portaAntiga;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getTfPortaShutdownRemoto()
/*     */   {
/* 658 */     return this.tfPortaShutdownRemoto;
/*     */   }
/*     */   
/*     */   public JLabel getLabelEvento() {
/* 662 */     return this.labelEvento;
/*     */   }
/*     */   
/*     */   public JLabel getLabelIdioma() {
/* 666 */     return this.labelIdioma;
/*     */   }
/*     */   
/*     */   public JLabel getLabelScript() {
/* 670 */     return this.labelScript;
/*     */   }
/*     */   
/*     */   public JLabel getLabelSerial() {
/* 674 */     return this.labelSerial;
/*     */   }
/*     */   
/*     */   public JLabel getLabelTitulo() {
/* 678 */     return this.labelTitulo;
/*     */   }
/*     */   
/*     */   public JTextField getTextFieldExpanBat() {
/* 682 */     return this.textFieldExpanBat;
/*     */   }
/*     */   
/*     */   public JTextField getTfScript() {
/* 686 */     return this.tfScript;
/*     */   }
/*     */   
/*     */   public boolean getFlag() {
/* 690 */     return this.flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFlag(boolean flag)
/*     */   {
/* 697 */     this.flag = flag;
/*     */   }
/*     */   
/*     */   public void setBtnCancel(JButton btnCancel) {
/* 701 */     this.btnCancel = btnCancel;
/*     */   }
/*     */   
/*     */   public void setBtnOk(JButton btnOk) {
/* 705 */     this.btnOk = btnOk;
/*     */   }
/*     */   
/*     */   public void setBtnProcura(JButton btn) {
/* 709 */     this.btnProcura = btn;
/*     */   }
/*     */   
/*     */   public void setComboBoxEvento(JComboBox comboBoxEvento) {
/* 713 */     this.comboBoxEvento = comboBoxEvento;
/*     */   }
/*     */   
/*     */   public void setComboBoxIdioma(JComboBox comboBoxIdioma) {
/* 717 */     this.comboBoxIdioma = comboBoxIdioma;
/*     */   }
/*     */   
/*     */   public void setComboBoxSerial(JComboBox comboBoxSerial) {
/* 721 */     this.comboBoxSerial = comboBoxSerial;
/*     */   }
/*     */   
/*     */   public void setLabelAmperes(JLabel labelAmperes) {
/* 725 */     this.labelAmperes = labelAmperes;
/*     */   }
/*     */   
/*     */   public void setLabelBateria(JLabel labelBateria) {
/* 729 */     this.labelBateria = labelBateria;
/*     */   }
/*     */   
/*     */   public void setLabelEvento(JLabel labelEvento) {
/* 733 */     this.labelEvento = labelEvento;
/*     */   }
/*     */   
/*     */   public void setLabelIdioma(JLabel labelIdioma) {
/* 737 */     this.labelIdioma = labelIdioma;
/*     */   }
/*     */   
/*     */   public void setLabelScript(JLabel labelScript) {
/* 741 */     this.labelScript = labelScript;
/*     */   }
/*     */   
/*     */   public void setLabelSerial(JLabel labelSerial) {
/* 745 */     this.labelSerial = labelSerial;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCbShutdownRemoto(JCheckBox cbShutdownRemoto)
/*     */   {
/* 752 */     this.cbShutdownRemoto = cbShutdownRemoto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDados(String[] dados)
/*     */   {
/* 759 */     this.dados = dados;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLabelPortaShutdownRemoto(JLabel labelPortaShutdownRemoto)
/*     */   {
/* 766 */     this.labelPortaShutdownRemoto = labelPortaShutdownRemoto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPortaAntiga(int portaAntiga)
/*     */   {
/* 773 */     this.portaAntiga = portaAntiga;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTfPortaShutdownRemoto(JTextField tfPortaShutdownRemoto)
/*     */   {
/* 780 */     this.tfPortaShutdownRemoto = tfPortaShutdownRemoto;
/*     */   }
/*     */   
/*     */   public void setLabelTitulo(JLabel labelTitulo) {
/* 784 */     this.labelTitulo = labelTitulo;
/*     */   }
/*     */   
/*     */   public void setTextFieldExpanBat(JTextField textFieldExpanBat) {
/* 788 */     this.textFieldExpanBat = textFieldExpanBat;
/*     */   }
/*     */   
/*     */   public void setTfScript(JTextField tfScript) {
/* 792 */     this.tfScript = tfScript;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelGeral.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */