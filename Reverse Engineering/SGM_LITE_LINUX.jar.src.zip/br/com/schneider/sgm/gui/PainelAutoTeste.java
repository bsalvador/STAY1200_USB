/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerListModel;
/*     */ import javax.swing.SpinnerModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelAutoTeste
/*     */   extends JPanel
/*     */ {
/*     */   public PainelAutoTeste()
/*     */   {
/* 103 */     initComponents();addListeners(); } private String[] hora = { "-1", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24" }; private String[] minuto = { "-1", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60" }; private JPanel panelPeriodo; private JPanel panelHoraTeste; private JButton btnOk; private JButton btnCancel; private int periodoAutoTeste; private int minutoTeste; private int horaTeste; private JLabel labelTitulo; private JLabel labelDoisPontos; private JSpinner spinnerMinutoTeste; private ButtonGroup periodoGroup; private JRadioButton radioMensal; private JRadioButton radioSemana; private JRadioButton radioDia; private JCheckBox chkHabilitaTeste; private DecimalFormat formatador = new DecimalFormat("00");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JSpinner spinnerHoraTeste;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean autoTesteEnabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean flag;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final long serialVersionUID = 4306578214258553153L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 135 */     this.labelTitulo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 136 */       .getString("CONFIGURACOES_AUTO_TESTE_BATERIA"));
/*     */     
/* 138 */     this.panelHoraTeste.setBorder(BorderFactory.createTitledBorder(
/* 139 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(120, 120, 
/* 140 */       120)), ResourceBundle.getBundle(Idioma.getIdioma())
/* 141 */       .getString("HORA_TESTE")));
/*     */     
/* 143 */     this.panelPeriodo.setBorder(BorderFactory.createTitledBorder(
/* 144 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(120, 120, 
/* 145 */       120)), ResourceBundle.getBundle(Idioma.getIdioma())
/* 146 */       .getString("PERIODO_TESTE")));
/*     */     
/* 148 */     this.chkHabilitaTeste.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 149 */       .getString("HABILITAR_TESTE"));
/*     */     
/* 151 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 152 */       .getString("CANCELAR"));
/*     */     
/* 154 */     this.radioDia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 155 */       .getString("DIARIO"));
/*     */     
/* 157 */     this.radioMensal.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 158 */       .getString("MENSAL"));
/*     */     
/* 160 */     this.radioSemana.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 161 */       .getString("SEMANAL"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addListeners()
/*     */   {
/* 171 */     this.spinnerHoraTeste.addChangeListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent e) {
/* 174 */         SpinnerModel modelo = PainelAutoTeste.this.spinnerHoraTeste.getModel();
/* 175 */         String aux = (String)modelo.getValue();
/* 176 */         Integer aux2 = new Integer(aux);
/* 177 */         int i = aux2.intValue();
/* 178 */         if (i == 24)
/* 179 */           modelo.setValue("00");
/* 180 */         if (i == -1)
/* 181 */           modelo.setValue("23");
/* 182 */         PainelAutoTeste.this.setFlag(true);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/* 187 */     });
/* 188 */     this.spinnerMinutoTeste.addChangeListener(new ChangeListener() {
/*     */       public void stateChanged(ChangeEvent e) {
/* 190 */         SpinnerModel modelo = PainelAutoTeste.this.spinnerMinutoTeste.getModel();
/* 191 */         String aux = (String)modelo.getValue();
/* 192 */         Integer aux2 = new Integer(aux);
/* 193 */         int i = aux2.intValue();
/* 194 */         if (i == 60)
/* 195 */           modelo.setValue("00");
/* 196 */         if (i == -1)
/* 197 */           modelo.setValue("59");
/* 198 */         PainelAutoTeste.this.setFlag(true);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 204 */     });
/* 205 */     this.radioMensal.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 207 */         PainelAutoTeste.this.setFlag(true);
/*     */       }
/*     */       
/*     */ 
/* 211 */     });
/* 212 */     this.radioSemana.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 214 */         PainelAutoTeste.this.setFlag(true);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/* 219 */     });
/* 220 */     this.radioDia.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 222 */         PainelAutoTeste.this.setFlag(true);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 228 */     });
/* 229 */     this.chkHabilitaTeste.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 231 */         PainelAutoTeste.this.setFlag(true);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 245 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 246 */     Dimension d = new Dimension(384, 335);
/* 247 */     Font fonte11 = new Font("Trebuchet", 0, 11);
/* 248 */     Font fonte12Negrito = new Font("Trebuchet", 1, 12);
/*     */     
/*     */ 
/* 251 */     setLayout(new GridBagLayout());
/* 252 */     setBackground(new Color(255, 255, 255));
/* 253 */     setMaximumSize(d);
/* 254 */     setMinimumSize(d);
/* 255 */     setOpaque(false);
/* 256 */     setPreferredSize(d);
/*     */     
/* 258 */     this.btnOk = new JButton();
/* 259 */     this.btnCancel = new JButton();
/* 260 */     this.spinnerMinutoTeste = new JSpinner();
/* 261 */     this.spinnerHoraTeste = new JSpinner();
/* 262 */     this.labelDoisPontos = new JLabel();
/* 263 */     this.labelTitulo = new JLabel();
/* 264 */     this.panelHoraTeste = new JPanel();
/* 265 */     this.panelPeriodo = new JPanel();
/* 266 */     this.chkHabilitaTeste = new JCheckBox();
/*     */     
/*     */ 
/* 269 */     this.radioDia = new JRadioButton();
/* 270 */     this.radioSemana = new JRadioButton();
/* 271 */     this.radioMensal = new JRadioButton();
/*     */     
/* 273 */     this.periodoGroup = new ButtonGroup();
/*     */     
/* 275 */     this.periodoGroup.add(this.radioDia);
/* 276 */     this.periodoGroup.add(this.radioSemana);
/* 277 */     this.periodoGroup.add(this.radioMensal);
/*     */     
/*     */ 
/*     */ 
/* 281 */     this.labelTitulo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 282 */       .getString("CONFIGURACOES_AUTO_TESTE_BATERIA"));
/* 283 */     this.labelTitulo.setFocusable(false);
/* 284 */     this.labelTitulo.setFont(fonte12Negrito);
/* 285 */     gridBagConstraints.gridwidth = 6;
/* 286 */     gridBagConstraints.gridx = 0;
/* 287 */     gridBagConstraints.gridy = 0;
/* 288 */     gridBagConstraints.fill = 2;
/* 289 */     gridBagConstraints.anchor = 17;
/* 290 */     gridBagConstraints.insets = new Insets(0, 40, 8, 0);
/* 291 */     add(this.labelTitulo, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 295 */     Dimension agendamento = new Dimension(330, 60);
/* 296 */     this.panelHoraTeste.setLayout(new GridBagLayout());
/* 297 */     this.panelHoraTeste.setBorder(BorderFactory.createTitledBorder(
/* 298 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(120, 120, 
/* 299 */       120)), ResourceBundle.getBundle(Idioma.getIdioma())
/* 300 */       .getString("HORA_TESTE")));
/* 301 */     this.panelHoraTeste.setMaximumSize(agendamento);
/* 302 */     this.panelHoraTeste.setMinimumSize(agendamento);
/* 303 */     this.panelHoraTeste.setPreferredSize(agendamento);
/* 304 */     this.panelHoraTeste.setOpaque(false);
/* 305 */     gridBagConstraints.gridwidth = 6;
/* 306 */     gridBagConstraints.gridx = 0;
/* 307 */     gridBagConstraints.gridy = 2;
/* 308 */     add(this.panelHoraTeste, gridBagConstraints);
/*     */     
/*     */ 
/* 311 */     this.panelPeriodo.setLayout(new GridBagLayout());
/* 312 */     this.panelPeriodo.setBorder(BorderFactory.createTitledBorder(
/* 313 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(120, 120, 
/* 314 */       120)), ResourceBundle.getBundle(Idioma.getIdioma())
/* 315 */       .getString("PERIODO_TESTE")));
/* 316 */     this.panelPeriodo.setMaximumSize(agendamento);
/* 317 */     this.panelPeriodo.setMinimumSize(agendamento);
/* 318 */     this.panelPeriodo.setPreferredSize(agendamento);
/* 319 */     this.panelPeriodo.setOpaque(false);
/* 320 */     gridBagConstraints.gridwidth = 6;
/* 321 */     gridBagConstraints.gridx = 0;
/* 322 */     gridBagConstraints.gridy = 4;
/* 323 */     add(this.panelPeriodo, gridBagConstraints);
/*     */     
/*     */ 
/* 326 */     this.chkHabilitaTeste.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 327 */       .getString("HABILITAR_TESTE"));
/* 328 */     this.chkHabilitaTeste.setFont(fonte11);
/* 329 */     this.chkHabilitaTeste.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 330 */     this.chkHabilitaTeste.setFocusable(false);
/* 331 */     this.chkHabilitaTeste.setOpaque(false);
/* 332 */     this.chkHabilitaTeste.setMargin(new Insets(0, 0, 0, 0));
/* 333 */     gridBagConstraints = new GridBagConstraints();
/* 334 */     gridBagConstraints.gridx = 1;
/* 335 */     gridBagConstraints.gridy = 6;
/* 336 */     gridBagConstraints.fill = 1;
/* 337 */     gridBagConstraints.insets = new Insets(0, 40, 0, 0);
/* 338 */     add(this.chkHabilitaTeste, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 342 */     this.btnOk.setFont(fonte12Negrito);
/* 343 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 344 */       "OK"));
/* 345 */     this.btnOk.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(
/* 346 */       160, 160, 160)));
/* 347 */     this.btnOk.setFocusPainted(false);
/* 348 */     this.btnOk.setMaximumSize(new Dimension(100, 30));
/* 349 */     this.btnOk.setMinimumSize(new Dimension(100, 30));
/* 350 */     this.btnOk.setPreferredSize(new Dimension(100, 30));
/* 351 */     gridBagConstraints.gridx = 1;
/* 352 */     gridBagConstraints.gridy = 30;
/* 353 */     gridBagConstraints.gridheight = 3;
/* 354 */     gridBagConstraints.gridwidth = 1;
/* 355 */     gridBagConstraints.fill = 0;
/* 356 */     gridBagConstraints.insets = new Insets(50, 30, 0, 0);
/* 357 */     add(this.btnOk, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 361 */     this.btnCancel.setFont(fonte12Negrito);
/* 362 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 363 */       .getString("CANCELAR"));
/* 364 */     this.btnCancel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 365 */       new Color(160, 160, 160)));
/* 366 */     this.btnCancel.setFocusPainted(false);
/* 367 */     this.btnCancel.setMaximumSize(new Dimension(100, 30));
/* 368 */     this.btnCancel.setMinimumSize(new Dimension(100, 30));
/* 369 */     this.btnCancel.setPreferredSize(new Dimension(100, 30));
/* 370 */     gridBagConstraints.gridx = 3;
/* 371 */     gridBagConstraints.gridy = 30;
/* 372 */     gridBagConstraints.gridheight = 3;
/* 373 */     gridBagConstraints.gridwidth = 1;
/* 374 */     gridBagConstraints.fill = 0;
/* 375 */     gridBagConstraints.insets = new Insets(50, 10, 0, 0);
/* 376 */     add(this.btnCancel, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 380 */     this.radioDia.setFont(fonte12Negrito);
/* 381 */     this.radioDia.setMaximumSize(new Dimension(100, 20));
/* 382 */     this.radioDia.setMinimumSize(new Dimension(100, 20));
/* 383 */     this.radioDia.setPreferredSize(new Dimension(100, 20));
/* 384 */     this.radioDia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 385 */       .getString("DIARIO"));
/*     */     
/* 387 */     this.radioDia.setOpaque(false);
/* 388 */     this.radioDia.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 389 */     this.radioDia.setFocusPainted(false);
/* 390 */     this.radioDia.setMargin(new Insets(0, 0, 0, 0));
/*     */     
/* 392 */     gridBagConstraints.fill = 0;
/* 393 */     gridBagConstraints.gridwidth = 1;
/* 394 */     gridBagConstraints.anchor = 10;
/* 395 */     gridBagConstraints.gridx = 1;
/* 396 */     gridBagConstraints.gridy = 2;
/* 397 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/* 398 */     this.panelPeriodo.add(this.radioDia, gridBagConstraints);
/*     */     
/*     */ 
/* 401 */     this.radioSemana.setFont(fonte12Negrito);
/* 402 */     this.radioSemana.setMaximumSize(new Dimension(100, 20));
/* 403 */     this.radioSemana.setMinimumSize(new Dimension(100, 20));
/* 404 */     this.radioSemana.setPreferredSize(new Dimension(100, 20));
/* 405 */     this.radioSemana.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 406 */       .getString("SEMANAL"));
/* 407 */     this.radioSemana.setOpaque(false);
/* 408 */     this.radioSemana.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 409 */     this.radioSemana.setFocusPainted(false);
/* 410 */     this.radioSemana.setMargin(new Insets(0, 0, 0, 0));
/*     */     
/* 412 */     gridBagConstraints.fill = 0;
/* 413 */     gridBagConstraints.gridwidth = 1;
/* 414 */     gridBagConstraints.anchor = 10;
/* 415 */     gridBagConstraints.gridx = 3;
/* 416 */     gridBagConstraints.gridy = 2;
/* 417 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/* 418 */     this.panelPeriodo.add(this.radioSemana, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 422 */     this.radioMensal.setFont(fonte12Negrito);
/* 423 */     this.radioMensal.setMaximumSize(new Dimension(100, 20));
/* 424 */     this.radioMensal.setMinimumSize(new Dimension(100, 20));
/* 425 */     this.radioMensal.setPreferredSize(new Dimension(100, 20));
/* 426 */     this.radioMensal.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 427 */       .getString("MENSAL"));
/*     */     
/* 429 */     this.radioMensal.setOpaque(false);
/* 430 */     this.radioMensal.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 431 */     this.radioMensal.setFocusPainted(false);
/* 432 */     this.radioMensal.setMargin(new Insets(0, 0, 0, 0));
/*     */     
/* 434 */     gridBagConstraints.fill = 0;
/* 435 */     gridBagConstraints.gridwidth = 1;
/* 436 */     gridBagConstraints.anchor = 10;
/* 437 */     gridBagConstraints.gridx = 5;
/* 438 */     gridBagConstraints.gridy = 2;
/* 439 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/* 440 */     this.panelPeriodo.add(this.radioMensal, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 445 */     this.spinnerHoraTeste.setFont(fonte12Negrito);
/* 446 */     this.spinnerHoraTeste.setMaximumSize(new Dimension(40, 20));
/* 447 */     this.spinnerHoraTeste.setMinimumSize(new Dimension(40, 20));
/* 448 */     this.spinnerHoraTeste.setPreferredSize(new Dimension(40, 20));
/* 449 */     gridBagConstraints.fill = 0;
/* 450 */     gridBagConstraints.gridwidth = 1;
/* 451 */     gridBagConstraints.anchor = 10;
/* 452 */     gridBagConstraints.gridx = 1;
/* 453 */     gridBagConstraints.gridy = 2;
/* 454 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/* 455 */     this.panelHoraTeste.add(this.spinnerHoraTeste, gridBagConstraints);
/* 456 */     SpinnerModel modeloHoraDesligar = new SpinnerListModel(
/* 457 */       Arrays.asList(this.hora));
/* 458 */     this.spinnerHoraTeste.setModel(modeloHoraDesligar);
/* 459 */     modeloHoraDesligar.setValue("18");
/*     */     
/*     */ 
/*     */ 
/* 463 */     this.labelDoisPontos.setFont(fonte12Negrito);
/* 464 */     this.labelDoisPontos.setText(":");
/* 465 */     gridBagConstraints.gridwidth = 1;
/* 466 */     gridBagConstraints.gridx = 2;
/* 467 */     gridBagConstraints.gridy = 2;
/* 468 */     gridBagConstraints.fill = 2;
/* 469 */     gridBagConstraints.insets = new Insets(5, 5, 5, 5);
/* 470 */     this.panelHoraTeste.add(this.labelDoisPontos, gridBagConstraints);
/*     */     
/*     */ 
/* 473 */     this.spinnerMinutoTeste.setFont(fonte12Negrito);
/* 474 */     this.spinnerMinutoTeste.setMaximumSize(new Dimension(40, 20));
/* 475 */     this.spinnerMinutoTeste.setMinimumSize(new Dimension(40, 20));
/* 476 */     this.spinnerMinutoTeste.setPreferredSize(new Dimension(40, 20));
/* 477 */     gridBagConstraints.fill = 0;
/* 478 */     gridBagConstraints.gridwidth = 1;
/* 479 */     gridBagConstraints.anchor = 10;
/* 480 */     gridBagConstraints.gridx = 3;
/* 481 */     gridBagConstraints.gridy = 2;
/* 482 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/* 483 */     this.panelHoraTeste.add(this.spinnerMinutoTeste, gridBagConstraints);
/* 484 */     SpinnerModel modeloMinutoDesligar = new SpinnerListModel(
/* 485 */       Arrays.asList(this.minuto));
/* 486 */     this.spinnerMinutoTeste.setModel(modeloMinutoDesligar);
/* 487 */     modeloMinutoDesligar.setValue("30");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateForm()
/*     */   {
/* 500 */     this.flag = false;
/*     */     
/* 502 */     if (this.radioDia.isSelected()) {
/* 503 */       setPeriodoAutoTeste(0);
/*     */     }
/* 505 */     else if (this.radioSemana.isSelected()) {
/* 506 */       setPeriodoAutoTeste(1);
/*     */     }
/* 508 */     else if (this.radioMensal.isSelected()) {
/* 509 */       setPeriodoAutoTeste(2);
/*     */     }
/* 511 */     setMinutoTeste(Integer.parseInt((String)this.spinnerMinutoTeste.getModel().getValue()));
/* 512 */     setHoraTeste(Integer.parseInt((String)this.spinnerHoraTeste.getModel().getValue()));
/* 513 */     setAutoTesteHabilitado(this.chkHabilitaTeste.isSelected());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnCancel()
/*     */   {
/* 520 */     return this.btnCancel;
/*     */   }
/*     */   
/*     */   public boolean getFlag() {
/* 524 */     return this.flag;
/*     */   }
/*     */   
/*     */   public JButton getBtnOk() {
/* 528 */     return this.btnOk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPeriodoAutoTeste()
/*     */   {
/* 537 */     return this.periodoAutoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHoraTeste()
/*     */   {
/* 546 */     return this.horaTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinutoTeste()
/*     */   {
/* 555 */     return this.minutoTeste;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAutoTesteHabilitado()
/*     */   {
/* 563 */     return this.autoTesteEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPeriodoAutoTeste(int periodo)
/*     */   {
/* 573 */     this.periodoAutoTeste = periodo;
/*     */     
/* 575 */     switch (periodo) {
/*     */     case 0: 
/* 577 */       this.radioDia.setSelected(true);
/* 578 */       break;
/*     */     case 1: 
/* 580 */       this.radioSemana.setSelected(true);
/* 581 */       break;
/*     */     case 2: 
/* 583 */       this.radioMensal.setSelected(true);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHoraTeste(int hora)
/*     */   {
/* 594 */     if ((hora >= 0) && (hora < 24))
/* 595 */       this.horaTeste = hora;
/* 596 */     this.spinnerHoraTeste.getModel().setValue(
/* 597 */       this.formatador.format(this.horaTeste));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinutoTeste(int minuto)
/*     */   {
/* 606 */     if ((minuto >= 0) && (minuto < 60)) {
/* 607 */       this.minutoTeste = minuto;
/*     */     }
/* 609 */     this.spinnerMinutoTeste.getModel().setValue(
/* 610 */       this.formatador.format(this.minutoTeste));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoTesteHabilitado(boolean tst)
/*     */   {
/* 618 */     this.autoTesteEnabled = tst;
/*     */     
/*     */ 
/* 621 */     this.chkHabilitaTeste.setSelected(this.autoTesteEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlag(boolean flag)
/*     */   {
/* 629 */     this.flag = flag;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelAutoTeste.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */