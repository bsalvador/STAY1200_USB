/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PopUpAlerta
/*     */   extends JFrame
/*     */ {
/*     */   private PainelDec painel;
/*     */   private JButton botaoOk;
/*  48 */   private short posJanX = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private short posJanY = 0;
/*     */   
/*     */ 
/*     */   private InterfaceGrafica pai;
/*     */   
/*     */   private String messageKey;
/*     */   
/*     */ 
/*     */   public String getMessageKey()
/*     */   {
/*  63 */     return this.messageKey;
/*     */   }
/*     */   
/*     */   public void setMessageKey(String messageKey) {
/*  67 */     this.messageKey = messageKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PopUpAlerta(String caminhoFundo, String caminhoBotao, String mensagem, String caminhoFigura, InterfaceGrafica pai, boolean alerta)
/*     */   {
/*  81 */     super(mensagem);
/*  82 */     this.pai = pai;
/*  83 */     setIconImage(new ImageIcon(caminhoBotao + "IconeSGM.png").getImage());
/*  84 */     this.painel = new PainelDec(caminhoFundo, 10, 10);
/*  85 */     this.painel.setLayout(new FlowLayout(1, 100, 10));
/*  86 */     this.painel.setPreferredSize(new Dimension(400, 134));
/*  87 */     getContentPane().setLayout(new BorderLayout());
/*  88 */     add(this.painel, "Center");
/*  89 */     Icon icone2 = new ImageIcon(caminhoBotao + "PopUpTitulo.png");
/*  90 */     Preenche3 preenche1 = new Preenche3(icone2);
/*  91 */     add(preenche1, "North");
/*     */     Icon icone;
/*     */     Icon icone;
/*  94 */     if (alerta) {
/*  95 */       icone = new ImageIcon(caminhoFigura + "okpopp.png");
/*     */     } else {
/*  97 */       icone = new ImageIcon(caminhoFigura + "okpop.png");
/*     */     }
/*  99 */     JTextPane texto = new JTextPane();
/* 100 */     JLabel rotulo = new JLabel(mensagem, icone, 0);
/* 101 */     texto.insertComponent(rotulo);
/* 102 */     texto.setOpaque(false);
/* 103 */     texto.setEnabled(false);
/* 104 */     texto.setDisabledTextColor(Color.BLACK);
/* 105 */     this.painel.add(texto);
/* 106 */     this.botaoOk = new JButton(ResourceBundle.getBundle(Idioma.getIdioma())
/* 107 */       .getString("Ok"));
/* 108 */     this.botaoOk.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent ae) {
/* 111 */         PopUpAlerta.this.pai.setXPop(PopUpAlerta.this.pai.getXPop() - 10);
/* 112 */         PopUpAlerta.this.pai
/* 113 */           .setYPop(PopUpAlerta.this.pai.getYPop() - 10);
/*     */         
/* 115 */         PopUpAlerta.this.pai.delPopupCache(PopUpAlerta.this.messageKey);
/* 116 */         PopUpAlerta.this.dispose();
/*     */       }
/*     */       
/* 119 */     });
/* 120 */     this.painel.add(this.botaoOk);
/* 121 */     setResizable(false);
/* 122 */     setSize(399, 149);
/* 123 */     setUndecorated(true);
/* 124 */     setVisible(true);
/* 125 */     setAlwaysOnTop(true);
/* 126 */     setLocation(this.pai.getXPop(), this.pai
/* 127 */       .getYPop());
/* 128 */     this.posJanX = ((short)this.pai.getXPop());
/* 129 */     this.posJanY = ((short)this.pai.getYPop());
/* 130 */     this.pai.setXPop(this.pai.getXPop() + 10);
/* 131 */     this.pai.setYPop(this.pai.getYPop() + 10);
/*     */     
/* 133 */     addMouseListener(
/* 134 */       new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent me) {
/* 136 */           PopUpAlerta.this.posJanX = ((short)(me.getX() - PopUpAlerta.this.posJanX));
/* 137 */           PopUpAlerta.this.posJanY = ((short)(me.getY() - PopUpAlerta.this.posJanY));
/*     */         }
/*     */         
/*     */         public void mouseReleased(MouseEvent me) {
/* 141 */           PopUpAlerta.this.posJanX = ((short)(me.getX() - PopUpAlerta.this.posJanX));
/* 142 */           PopUpAlerta.this.posJanY = ((short)(me.getY() - PopUpAlerta.this.posJanY));
/* 143 */           PopUpAlerta.this.setLocation(PopUpAlerta.this.posJanX, PopUpAlerta.this.posJanY);
/*     */         }
/*     */         
/* 146 */       });
/* 147 */     addWindowListener(new WindowAdapter()
/*     */     {
/*     */       public void windowClosing(WindowEvent we) {
/* 150 */         PopUpAlerta.this.pai.setXPop(PopUpAlerta.this.pai.getXPop() - 10);
/* 151 */         PopUpAlerta.this.pai
/* 152 */           .setYPop(PopUpAlerta.this.pai.getYPop() - 10);
/*     */       }
/*     */       
/*     */ 
/* 156 */     });
/* 157 */     pai.setState(0);
/* 158 */     pai.setVisible(true);
/*     */   }
/*     */   
/*     */   public JButton getBtnOk() {
/* 162 */     return this.botaoOk;
/*     */   }
/*     */   
/*     */   class Preenche3
/*     */     extends JPanel
/*     */   {
/*     */     ImageIcon imagemFundo;
/*     */     
/*     */     public Preenche3(Icon imagemFundo)
/*     */     {
/* 172 */       setPreferredSize(new Dimension(400, 18));
/* 173 */       this.imagemFundo = ((ImageIcon)imagemFundo);
/*     */     }
/*     */     
/*     */     public void paintComponent(Graphics g)
/*     */     {
/* 178 */       super.paintComponent(g);
/* 179 */       g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PopUpAlerta.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */