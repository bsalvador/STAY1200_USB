/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelCentral
/*     */   extends PainelDec
/*     */ {
/*     */   private static final long serialVersionUID = 469609036832263219L;
/*     */   private JPanel painelBarra;
/*     */   private JPanel painelCentral;
/*     */   private JPanel preenche1;
/*     */   private JPanel preenche2;
/*     */   private JLabel indicador;
/*     */   private Icon[] iconeIndicador;
/*     */   private String[] prompts;
/*     */   private InterfaceGrafica interfaceGrafica;
/*     */   
/*     */   public void validarIdioma()
/*     */   {
/*  79 */     this.prompts[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  80 */       "MONITORAMENTO_DO_SISTEMA");
/*  81 */     this.prompts[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  82 */       "GRAFICOS");
/*  83 */     this.prompts[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  84 */       "CONFIGURACOES_DO_SISTEMA");
/*  85 */     this.prompts[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  86 */       "EXECUCAO_DE_COMANDOS");
/*  87 */     this.prompts[4] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  88 */       "REGISTRO_DE_EVENTOS");
/*  89 */     this.prompts[5] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  90 */       "SOBRE");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PainelCentral(String caminhoImagens, InterfaceGrafica gui)
/*     */   {
/* 105 */     super(caminhoImagens + "Painel_funcional.png", 0, 0);
/*     */     
/* 107 */     this.interfaceGrafica = gui;
/* 108 */     this.painelBarra = new JPanel(new FlowLayout(0, 5, 0));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 113 */     this.painelBarra.setPreferredSize(new Dimension(515, 20));
/*     */     
/*     */ 
/* 116 */     this.painelBarra.setOpaque(false);
/* 117 */     this.prompts = new String[10];
/* 118 */     this.prompts[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 119 */       "MONITORAMENTO_DO_SISTEMA");
/* 120 */     this.prompts[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 121 */       "GRAFICOS");
/* 122 */     this.prompts[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 123 */       "CONFIGURACOES_DO_SISTEMA");
/* 124 */     this.prompts[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 125 */       "EXECUCAO_DE_COMANDOS");
/* 126 */     this.prompts[4] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 127 */       "REGISTRO_DE_EVENTOS");
/* 128 */     this.prompts[5] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 129 */       "SOBRE");
/* 130 */     this.iconeIndicador = new Icon[10];
/* 131 */     this.iconeIndicador[0] = new ImageIcon(caminhoImagens + "S1.png");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */     this.iconeIndicador[1] = new ImageIcon(caminhoImagens + "S2.png");
/* 138 */     this.iconeIndicador[2] = new ImageIcon(caminhoImagens + "S3.png");
/*     */     
/*     */ 
/*     */ 
/* 142 */     this.iconeIndicador[3] = new ImageIcon(caminhoImagens + "S4.png");
/*     */     
/*     */ 
/* 145 */     this.iconeIndicador[4] = new ImageIcon(caminhoImagens + "S5.png");
/*     */     
/*     */ 
/*     */ 
/* 149 */     this.iconeIndicador[5] = new ImageIcon(caminhoImagens + "S6.png");
/*     */     
/*     */ 
/*     */ 
/* 153 */     this.indicador = new JLabel(this.prompts[0], this.iconeIndicador[0], 
/* 154 */       2);
/* 155 */     this.indicador.setFont(new Font("Trebuchet", 1, 11));
/*     */     
/* 157 */     this.indicador.setForeground(Color.BLACK);
/* 158 */     this.indicador.setPreferredSize(new Dimension(250, 20));
/*     */     
/*     */ 
/*     */ 
/* 162 */     this.painelBarra.add(this.indicador);
/* 163 */     add(this.painelBarra, "North");
/*     */     
/* 165 */     this.preenche1 = new JPanel();
/* 166 */     this.preenche1.setPreferredSize(new Dimension(22, 335));
/*     */     
/*     */ 
/* 169 */     this.preenche1.setOpaque(false);
/* 170 */     add(this.preenche1, "East");
/*     */     
/* 172 */     this.preenche2 = new JPanel();
/* 173 */     this.preenche2.setPreferredSize(new Dimension(515, 19));
/*     */     
/*     */ 
/* 176 */     this.preenche2.setOpaque(false);
/* 177 */     add(this.preenche2, "South");
/*     */     
/* 179 */     this.painelCentral = new JPanel(new CardLayout());
/* 180 */     this.painelCentral.setPreferredSize(new Dimension(515, 335));
/* 181 */     this.painelCentral.setOpaque(false);
/* 182 */     add(this.painelCentral, "Center");
/*     */   }
/*     */   
/*     */   public JLabel getIndicador()
/*     */   {
/* 187 */     return this.indicador;
/*     */   }
/*     */   
/*     */   public String[] getPrompts() {
/* 191 */     return this.prompts;
/*     */   }
/*     */   
/*     */   public Icon[] getIconeIndicador() {
/* 195 */     return this.iconeIndicador;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mudaPrompt(int indiceIcone, int indicePrompt)
/*     */   {
/* 206 */     if (indicePrompt == 0)
/*     */     {
/* 208 */       this.interfaceGrafica.setFlagMonitor(true);
/* 209 */       this.interfaceGrafica.setFlagGrafico(false);
/*     */     }
/* 211 */     else if (indicePrompt == 1)
/*     */     {
/* 213 */       this.interfaceGrafica.setFlagMonitor(false);
/* 214 */       this.interfaceGrafica.setFlagGrafico(true);
/*     */     }
/*     */     else
/*     */     {
/* 218 */       this.interfaceGrafica.setFlagMonitor(false);
/* 219 */       this.interfaceGrafica.setFlagGrafico(false);
/*     */     }
/* 221 */     this.indicador.setText(this.prompts[indicePrompt]);
/* 222 */     this.indicador.setIcon(this.iconeIndicador[indiceIcone]);
/*     */   }
/*     */   
/*     */   public JPanel getPainelCentral()
/*     */   {
/* 227 */     return this.painelCentral;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelCentral.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */