/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PopUpConsumo
/*     */   extends JFrame
/*     */ {
/*     */   private PainelDec painel;
/*     */   private JButton btnOk;
/*     */   private JButton btnCancel;
/*     */   private JTextField tfValor;
/*  56 */   private short posJanX = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private short posJanY = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private InterfaceGrafica pai;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JLabel rotulo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JLabel unidadeMonetaria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean flag;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static double valorKW;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String caminhoFiguras;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PainelGraficos painelGraficos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PopUpConsumo(InterfaceGrafica pai, String caminhoFiguras, PainelGraficos painelGraficos, String valorKW)
/*     */   {
/* 107 */     super("Valor do KWh");
/* 108 */     if (!flag) {
/* 109 */       this.caminhoFiguras = caminhoFiguras;
/* 110 */       this.painelGraficos = painelGraficos;
/* 111 */       this.pai = pai;
/* 112 */       valorKW = Double.parseDouble(valorKW);
/* 113 */       setIconImage(new ImageIcon(caminhoFiguras + "IconeSGM.png")
/* 114 */         .getImage());
/* 115 */       this.painel = new PainelDec(caminhoFiguras + "PopUp.png", 10, 10);
/* 116 */       this.painel.setLayout(new FlowLayout(1, 25, 20));
/* 117 */       this.painel.setPreferredSize(new Dimension(400, 134));
/* 118 */       getContentPane().setLayout(new BorderLayout());
/* 119 */       add(this.painel, "Center");
/* 120 */       Icon icone2 = new ImageIcon(caminhoFiguras + "PopUpTitulo.png");
/* 121 */       Preenche3 preenche1 = new Preenche3(icone2);
/* 122 */       add(preenche1, "North");
/* 123 */       Icon icone = new ImageIcon(caminhoFiguras + "okpop.png");
/*     */       
/* 125 */       this.rotulo = new JLabel("\t" + 
/* 126 */         ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 127 */         "Insira_o_valor_do_KWh") + "\n\n\n", icone, 
/* 128 */         2);
/* 129 */       this.rotulo.setForeground(Color.BLACK);
/* 130 */       this.painel.add(this.rotulo);
/* 131 */       this.btnOk = new JButton(ResourceBundle.getBundle(Idioma.getIdioma())
/* 132 */         .getString("OK"));
/* 133 */       this.btnCancel = new JButton(
/* 134 */         ResourceBundle.getBundle(Idioma.getIdioma()).getString("CANCELAR"));
/* 135 */       this.btnOk.setPreferredSize(new Dimension(100, 25));
/* 136 */       this.btnCancel.setPreferredSize(new Dimension(100, 25));
/* 137 */       this.unidadeMonetaria = new JLabel(ResourceBundle.getBundle(
/* 138 */         Idioma.getIdioma()).getString("RS"));
/* 139 */       this.tfValor = new JTextField(3);
/* 140 */       this.tfValor.setText(valorKW);
/* 141 */       this.painel.add(this.unidadeMonetaria);
/* 142 */       this.painel.add(this.tfValor);
/* 143 */       this.painel.add(this.btnOk);
/* 144 */       this.painel.add(this.btnCancel);
/* 145 */       setResizable(false);
/* 146 */       setSize(399, 149);
/* 147 */       setUndecorated(true);
/* 148 */       setVisible(true);
/* 149 */       setAlwaysOnTop(true);
/* 150 */       setLocation(this.pai.getXPop(), this.pai.getYPop());
/* 151 */       this.posJanX = ((short)this.pai.getXPop());
/* 152 */       this.posJanY = ((short)this.pai.getYPop());
/* 153 */       this.pai.setXPop(this.pai.getXPop() + 10);
/* 154 */       this.pai.setYPop(this.pai.getYPop() + 10);
/* 155 */       addListeners();
/* 156 */       flag = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double getValor()
/*     */   {
/* 165 */     double aux = valorKW;
/*     */     try {
/* 167 */       if (this.tfValor.getText().length() > 15) {
/* 168 */         PopUp localPopUp1 = new PopUp(this.caminhoFiguras + "PopUp.png", 
/* 169 */           this.caminhoFiguras, 
/* 170 */           "Entre_com_um_numero_valido_para_o_valor_do_KWh", 
/* 171 */           this.caminhoFiguras, 10, 10, this.pai, false, true);
/*     */       } else {
/* 173 */         String temp = this.tfValor.getText().replace(',', '.');
/* 174 */         aux = Double.parseDouble(temp);
/*     */       }
/*     */     } catch (NumberFormatException nfe) {
/* 177 */       PopUp localPopUp2 = new PopUp(this.caminhoFiguras + "PopUp.png", this.caminhoFiguras, 
/* 178 */         "Entre_com_um_numero_valido_para_o_valor_do_KWh", 
/* 179 */         this.caminhoFiguras, 10, 10, this.pai, false, true);
/*     */     }
/* 181 */     return aux;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addListeners()
/*     */   {
/* 189 */     addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent me) {
/* 191 */         PopUpConsumo.this.posJanX = ((short)(me.getX() - PopUpConsumo.this.posJanX));
/* 192 */         PopUpConsumo.this.posJanY = ((short)(me.getY() - PopUpConsumo.this.posJanY));
/*     */       }
/*     */       
/*     */       public void mouseReleased(MouseEvent me) {
/* 196 */         PopUpConsumo.this.posJanX = ((short)(me.getX() - PopUpConsumo.this.posJanX));
/* 197 */         PopUpConsumo.this.posJanY = ((short)(me.getY() - PopUpConsumo.this.posJanY));
/* 198 */         PopUpConsumo.this.setLocation(PopUpConsumo.this.posJanX, PopUpConsumo.this.posJanY);
/*     */       }
/*     */       
/* 201 */     });
/* 202 */     addWindowListener(new WindowAdapter()
/*     */     {
/*     */       public void windowClosing(WindowEvent we) {
/* 205 */         PopUpConsumo.this.pai.setXPop(PopUpConsumo.this.pai.getXPop() - 10);
/* 206 */         PopUpConsumo.this.pai
/* 207 */           .setYPop(PopUpConsumo.this.pai.getYPop() - 10);
/* 208 */         PopUpConsumo.flag = false;
/*     */       }
/*     */       
/* 211 */     });
/* 212 */     this.btnOk.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent ae) {
/* 214 */         PopUpConsumo.valorKW = PopUpConsumo.this.getValor();
/* 215 */         PopUpConsumo.this.painelGraficos.setValorKW0(PopUpConsumo.valorKW);
/* 216 */         PopUpConsumo.this.painelGraficos.setValorKW1(PopUpConsumo.valorKW);
/* 217 */         PopUpConsumo.this.painelGraficos.setValorKW2(PopUpConsumo.valorKW);
/* 218 */         PopUpConsumo.this.painelGraficos.setValorGraficos(PopUpConsumo.valorKW);
/* 219 */         PopUpConsumo.this.pai
/* 220 */           .setXPop(PopUpConsumo.this.pai.getXPop() - 10);
/* 221 */         PopUpConsumo.this.pai
/* 222 */           .setYPop(PopUpConsumo.this.pai.getYPop() - 10);
/* 223 */         PopUpConsumo.this.dispose();
/* 224 */         PopUpConsumo.flag = false;
/*     */       }
/* 226 */     });
/* 227 */     this.btnCancel.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent ae) {
/* 230 */         PopUpConsumo.this.pai.setXPop(PopUpConsumo.this.pai.getXPop() - 10);
/* 231 */         PopUpConsumo.this.pai
/* 232 */           .setYPop(PopUpConsumo.this.pai.getYPop() - 10);
/* 233 */         PopUpConsumo.this.dispose();
/* 234 */         PopUpConsumo.flag = false;
/*     */       }
/*     */       
/* 237 */     });
/* 238 */     this.tfValor.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent ae) {
/* 240 */         PopUpConsumo.valorKW = PopUpConsumo.this.getValor();
/* 241 */         PopUpConsumo.this.painelGraficos.setValorKW0(PopUpConsumo.valorKW);
/* 242 */         PopUpConsumo.this.painelGraficos.setValorKW1(PopUpConsumo.valorKW);
/* 243 */         PopUpConsumo.this.painelGraficos.setValorKW2(PopUpConsumo.valorKW);
/* 244 */         PopUpConsumo.this.painelGraficos.setValorGraficos(PopUpConsumo.valorKW);
/* 245 */         PopUpConsumo.this.pai
/* 246 */           .setXPop(PopUpConsumo.this.pai.getXPop() - 10);
/* 247 */         PopUpConsumo.this.pai
/* 248 */           .setYPop(PopUpConsumo.this.pai.getYPop() - 10);
/* 249 */         PopUpConsumo.this.dispose();
/* 250 */         PopUpConsumo.flag = false;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   class Preenche3
/*     */     extends JPanel
/*     */   {
/*     */     ImageIcon imagemFundo;
/*     */     
/*     */     public Preenche3(Icon imagemFundo)
/*     */     {
/* 262 */       setPreferredSize(new Dimension(400, 18));
/* 263 */       this.imagemFundo = ((ImageIcon)imagemFundo);
/*     */     }
/*     */     
/*     */ 
/*     */     public void paintComponent(Graphics g)
/*     */     {
/* 269 */       super.paintComponent(g);
/* 270 */       g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isFlag()
/*     */   {
/* 283 */     return flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static double getValorKW()
/*     */   {
/* 290 */     return valorKW;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnCancel()
/*     */   {
/* 297 */     return this.btnCancel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JButton getBtnOk()
/*     */   {
/* 304 */     return this.btnOk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCaminhoFiguras()
/*     */   {
/* 311 */     return this.caminhoFiguras;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InterfaceGrafica getPai()
/*     */   {
/* 318 */     return this.pai;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PainelDec getPainel()
/*     */   {
/* 325 */     return this.painel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getPosJanX()
/*     */   {
/* 332 */     return this.posJanX;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getPosJanY()
/*     */   {
/* 339 */     return this.posJanY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getRotulo()
/*     */   {
/* 346 */     return this.rotulo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTextField getTfValor()
/*     */   {
/* 353 */     return this.tfValor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JLabel getUnidadeMonetaria()
/*     */   {
/* 360 */     return this.unidadeMonetaria;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setFlag(boolean flag)
/*     */   {
/* 370 */     flag = flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void setValorKW(double valorKW)
/*     */   {
/* 377 */     valorKW = valorKW;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBtnCancel(JButton btnCancel)
/*     */   {
/* 384 */     this.btnCancel = btnCancel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBtnOk(JButton btnOk)
/*     */   {
/* 391 */     this.btnOk = btnOk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCaminhoFiguras(String caminhoFiguras)
/*     */   {
/* 398 */     this.caminhoFiguras = caminhoFiguras;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPai(InterfaceGrafica pai)
/*     */   {
/* 405 */     this.pai = pai;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPainel(PainelDec painel)
/*     */   {
/* 412 */     this.painel = painel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPosJanX(short posJanX)
/*     */   {
/* 419 */     this.posJanX = posJanX;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPosJanY(short posJanY)
/*     */   {
/* 426 */     this.posJanY = posJanY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRotulo(JLabel rotulo)
/*     */   {
/* 433 */     this.rotulo = rotulo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTfValor(JTextField tfValor)
/*     */   {
/* 440 */     this.tfValor = tfValor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUnidadeMonetaria(JLabel unidadeMonetaria)
/*     */   {
/* 447 */     this.unidadeMonetaria = unidadeMonetaria;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PopUpConsumo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */