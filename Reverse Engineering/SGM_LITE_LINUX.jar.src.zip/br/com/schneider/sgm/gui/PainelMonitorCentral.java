/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelMonitorCentral
/*     */   extends JPanel
/*     */ {
/*     */   private JPanel panelCentral;
/*     */   private JPanel panelTemp;
/*     */   PainelEntrada painelEntrada;
/*     */   PainelSaida painelSaida;
/*     */   PainelPotencia painelPotencia;
/*     */   PainelBateria painelBateria;
/*     */   PainelTemperatura painelTemperatura;
/*     */   protected static boolean atualiza;
/*     */   
/*     */   public PainelMonitorCentral(String caminhoFiguras)
/*     */   {
/*  84 */     atualiza = true;
/*  85 */     initComponents();
/*     */     
/*  87 */     this.painelEntrada = new PainelEntrada(caminhoFiguras);
/*  88 */     this.painelSaida = new PainelSaida(caminhoFiguras);
/*  89 */     this.painelPotencia = new PainelPotencia(caminhoFiguras);
/*  90 */     this.painelBateria = new PainelBateria(caminhoFiguras);
/*  91 */     this.painelTemperatura = new PainelTemperatura(caminhoFiguras);
/*     */     
/*  93 */     this.panelCentral.add(this.painelEntrada);
/*  94 */     this.panelCentral.add(this.painelSaida);
/*  95 */     this.panelCentral.add(this.painelPotencia);
/*  96 */     this.panelCentral.add(this.painelBateria);
/*  97 */     this.panelTemp.add(this.painelTemperatura);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void coletaDados()
/*     */   {
/* 104 */     atualiza = true;
/*     */   }
/*     */   
/*     */   public void paraColetaDados() {
/* 108 */     atualiza = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 117 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 118 */     Dimension d1 = new Dimension(515, 310);
/* 119 */     Dimension d2 = new Dimension(65, 310);
/*     */     
/* 121 */     this.panelCentral = new JPanel(new FlowLayout(1, 5, 0));
/* 122 */     this.panelTemp = new JPanel(new FlowLayout(1, 5, 0));
/*     */     
/* 124 */     setLayout(new GridBagLayout());
/*     */     
/* 126 */     setOpaque(false);
/* 127 */     this.panelCentral.setMaximumSize(d1);
/* 128 */     this.panelCentral.setMinimumSize(d1);
/* 129 */     this.panelCentral.setOpaque(false);
/* 130 */     this.panelCentral.setPreferredSize(d1);
/* 131 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/* 132 */     add(this.panelCentral, gridBagConstraints);
/*     */     
/* 134 */     this.panelTemp.setMaximumSize(d2);
/* 135 */     this.panelTemp.setMinimumSize(d2);
/* 136 */     this.panelTemp.setOpaque(false);
/* 137 */     this.panelTemp.setPreferredSize(d2);
/* 138 */     gridBagConstraints.gridx = 1;
/* 139 */     gridBagConstraints.gridy = 0;
/* 140 */     gridBagConstraints.gridwidth = 5;
/* 141 */     gridBagConstraints.fill = 1;
/* 142 */     gridBagConstraints.insets = new Insets(0, 0, 0, 90);
/* 143 */     add(this.panelTemp, gridBagConstraints);
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelMonitorCentral.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */