/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.eventos.Evento;
/*     */ import br.com.schneider.sgm.historico.Historico;
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.border.SoftBevelBorder;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelHistorico
/*     */   extends JPanel
/*     */ {
/*     */   private JButton btnLimparSelecao;
/*     */   private JButton btnLimparTudo;
/*     */   private JPanel jPanel1;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTable tabelaAlarmes;
/*     */   private String[] tituloAlarmesCol;
/*     */   private String tituloAlarmes;
/*     */   private Object[][] dadosTabela1;
/*  48 */   private int selectedRow = -1;
/*     */   
/*     */ 
/*     */   private TableModel tableModel;
/*     */   
/*     */ 
/*     */   private String caminhoFiguras;
/*     */   
/*     */   private int linhaAtual;
/*     */   
/*     */   private InterfaceGrafica interfaceGrafica;
/*     */   
/*     */   private Historico historico;
/*     */   
/*     */   private boolean flagRetorno;
/*     */   
/*     */   private boolean painelAtivo;
/*     */   
/*     */   private DefaultTableModel tableEvento;
/*     */   
/*     */ 
/*     */   public PainelHistorico(String caminhoFiguras, InterfaceGrafica interfaceGrafica, Evento[] evts)
/*     */   {
/*  71 */     initComponents(evts.length);
/*  72 */     this.interfaceGrafica = interfaceGrafica;
/*  73 */     this.caminhoFiguras = caminhoFiguras;
/*  74 */     this.tableModel = this.tabelaAlarmes.getModel();
/*  75 */     inserirRegistros(evts, false);
/*  76 */     addListeners();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void inserirRegistros(Evento[] eventos, boolean novaLinha)
/*     */   {
/*     */     try
/*     */     {
/*  86 */       if (eventos != null) {
/*  87 */         for (int i = 0; i < eventos.length; i++)
/*     */         {
/*  89 */           if (eventos[i] != null)
/*     */           {
/*     */             try
/*     */             {
/*  93 */               evento = ResourceBundle.getBundle(Idioma.getIdioma()).getString(eventos[i].getTipo());
/*     */             } catch (MissingResourceException e) {
/*     */               String evento;
/*  96 */               continue;
/*     */             }
/*     */             String evento;
/*     */             String data;
/* 100 */             if (eventos[i].getDia() < 10)
/*     */             {
/* 102 */               data = "0" + Integer.toString(eventos[i].getDia());
/*     */             }
/*     */             else
/*     */             {
/* 106 */               data = Integer.toString(eventos[i].getDia());
/*     */             }
/* 108 */             if (eventos[i].getMes() < 10)
/*     */             {
/* 110 */               data = data + " / 0" + eventos[i].getMes();
/*     */             }
/*     */             else
/*     */             {
/* 114 */               data = data + " / " + eventos[i].getMes();
/*     */             }
/* 116 */             String data = data + " / " + eventos[i].getAno();
/*     */             String hora;
/* 118 */             String hora; if (eventos[i].getHora() < 10) {
/* 119 */               hora = "0" + Integer.toString(eventos[i].getHora());
/*     */             } else
/* 121 */               hora = Integer.toString(eventos[i].getHora());
/*     */             String minuto;
/* 123 */             String minuto; if (eventos[i].getMinuto() < 10) {
/* 124 */               minuto = "0" + Integer.toString(eventos[i].getMinuto());
/*     */             } else
/* 126 */               minuto = Integer.toString(eventos[i].getMinuto());
/*     */             String segundo;
/* 128 */             String segundo; if (eventos[i].getSegundo() < 10) {
/* 129 */               segundo = "0" + Integer.toString(eventos[i].getSegundo());
/*     */             } else {
/* 131 */               segundo = Integer.toString(eventos[i].getSegundo());
/*     */             }
/* 133 */             String horario = hora + " : " + minuto + " : " + segundo;
/* 134 */             addLine(evento, data, horario, novaLinha);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 140 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 150 */     this.btnLimparTudo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 151 */       .getString("LIMPAR_TUDO"));
/* 152 */     this.btnLimparSelecao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 153 */       .getString("LIMPAR_SELECAO"));
/* 154 */     this.tituloAlarmesCol[1] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 155 */       .getString("DATA");
/* 156 */     this.tituloAlarmesCol[2] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 157 */       .getString("HORARIO");
/* 158 */     this.tituloAlarmesCol[0] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 159 */       .getString("EVENTO_REGISTRADO");
/* 160 */     this.tituloAlarmes = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 161 */       "HISTORICO_DE_ALARMES");
/* 162 */     this.tabelaAlarmes.setBorder(new SoftBevelBorder(1));
/*     */     
/* 164 */     this.tabelaAlarmes.getColumnModel().getColumn(0).setHeaderValue(this.tituloAlarmesCol[0]);
/* 165 */     this.tabelaAlarmes.getColumnModel().getColumn(1).setHeaderValue(this.tituloAlarmesCol[1]);
/* 166 */     this.tabelaAlarmes.getColumnModel().getColumn(2).setHeaderValue(this.tituloAlarmesCol[2]);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getRow()
/*     */   {
/* 172 */     if (this.selectedRow >= 0)
/*     */     {
/*     */ 
/*     */ 
/* 176 */       return true;
/*     */     }
/*     */     
/* 179 */     return false;
/*     */   }
/*     */   
/*     */   private void addListeners()
/*     */   {
/* 184 */     this.tabelaAlarmes.setSelectionMode(0);
/* 185 */     ListSelectionModel rowSM = this.tabelaAlarmes.getSelectionModel();
/* 186 */     rowSM.addListSelectionListener(new ListSelectionListener() {
/*     */       public void valueChanged(ListSelectionEvent e) {
/* 188 */         if (e.getValueIsAdjusting()) {
/* 189 */           return;
/*     */         }
/* 191 */         ListSelectionModel lsm = (ListSelectionModel)e.getSource();
/* 192 */         if (!lsm.isSelectionEmpty())
/*     */         {
/*     */ 
/* 195 */           PainelHistorico.this.selectedRow = lsm.getMinSelectionIndex(); }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public boolean limpaTabela() {
/* 201 */     this.tableEvento.setRowCount(0);
/* 202 */     this.linhaAtual = 0;
/* 203 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addLine(String evento, String data, String horario, boolean novaLinha)
/*     */   {
/* 209 */     if (novaLinha) {
/* 210 */       String[] t = { "", "", "" };
/* 211 */       this.tableEvento.addRow(t);
/*     */     }
/* 213 */     this.tableModel.setValueAt(evento, this.linhaAtual, 0);
/* 214 */     this.tableModel.setValueAt(data, this.linhaAtual, 1);
/* 215 */     this.tableModel.setValueAt(horario, this.linhaAtual, 2);
/* 216 */     this.linhaAtual += 1;
/*     */   }
/*     */   
/*     */   private void initComponents(int numeroRegistros) {
/* 220 */     this.jPanel1 = new JPanel();
/* 221 */     this.btnLimparTudo = new JButton();
/* 222 */     this.btnLimparSelecao = new JButton();
/* 223 */     this.jScrollPane1 = new JScrollPane();
/* 224 */     this.tabelaAlarmes = new JTable();
/* 225 */     this.tituloAlarmes = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 226 */       "HISTORICO_DE_ALARMES");
/* 227 */     this.tituloAlarmesCol = new String[3];
/* 228 */     this.tituloAlarmesCol[0] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 229 */       .getString("EVENTO_REGISTRADO");
/* 230 */     this.tituloAlarmesCol[1] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 231 */       .getString("DATA");
/* 232 */     this.tituloAlarmesCol[2] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 233 */       .getString("HORARIO");
/* 234 */     this.dadosTabela1 = new Object[numeroRegistros][3];
/*     */     
/* 236 */     setLayout(new BorderLayout());
/*     */     
/* 238 */     setMaximumSize(new Dimension(515, 300));
/* 239 */     setMinimumSize(new Dimension(515, 300));
/* 240 */     setOpaque(false);
/* 241 */     setPreferredSize(new Dimension(515, 300));
/* 242 */     this.jPanel1.setLayout(new FlowLayout(2));
/*     */     
/* 244 */     this.jPanel1.setOpaque(false);
/*     */     
/* 246 */     this.btnLimparTudo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 247 */       .getString("LIMPAR_TUDO"));
/* 248 */     this.btnLimparTudo.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 249 */       new Color(160, 160, 160)));
/* 250 */     this.btnLimparTudo.setFocusPainted(false);
/* 251 */     this.btnLimparTudo.setMaximumSize(new Dimension(140, 31));
/* 252 */     this.btnLimparTudo.setMinimumSize(new Dimension(140, 31));
/* 253 */     this.btnLimparTudo.setPreferredSize(new Dimension(140, 31));
/* 254 */     this.jPanel1.add(this.btnLimparTudo);
/*     */     
/* 256 */     this.btnLimparSelecao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 257 */       .getString("LIMPAR_SELECAO"));
/* 258 */     this.btnLimparSelecao.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 259 */       new Color(160, 160, 160)));
/* 260 */     this.btnLimparSelecao.setFocusPainted(false);
/* 261 */     this.btnLimparSelecao.setMaximumSize(new Dimension(140, 31));
/* 262 */     this.btnLimparSelecao.setMinimumSize(new Dimension(140, 31));
/* 263 */     this.btnLimparSelecao.setPreferredSize(new Dimension(140, 31));
/* 264 */     this.jPanel1.add(this.btnLimparSelecao);
/*     */     
/* 266 */     add(this.jPanel1, "South");
/* 267 */     this.tabelaAlarmes.setBorder(new SoftBevelBorder(1));
/* 268 */     this.tableEvento = new DefaultTableModel(this.dadosTabela1, 
/* 269 */       this.tituloAlarmesCol)
/*     */       {
/* 270 */         boolean[] canEdit = new boolean[3];
/*     */         
/*     */         public boolean isCellEditable(int rowIndex, int columnIndex) {
/* 273 */           return this.canEdit[columnIndex];
/*     */         }
/* 275 */       };
/* 276 */       this.tabelaAlarmes.setModel(this.tableEvento);
/* 277 */       this.tabelaAlarmes.setGridColor(new Color(241, 241, 241));
/* 278 */       this.tabelaAlarmes.setRequestFocusEnabled(false);
/* 279 */       TableColumnModel tt = this.tabelaAlarmes.getColumnModel();
/* 280 */       TableColumn ttt = tt.getColumn(0);
/* 281 */       ttt.setPreferredWidth(250);
/* 282 */       this.jScrollPane1.setViewportView(this.tabelaAlarmes);
/* 283 */       this.jScrollPane1.setAutoscrolls(true);
/* 284 */       add(this.jScrollPane1, "Center");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public JButton getBtnLimparSelecao()
/*     */     {
/* 301 */       return this.btnLimparSelecao;
/*     */     }
/*     */     
/*     */     public JButton getBtnLimparTudo() {
/* 305 */       return this.btnLimparTudo;
/*     */     }
/*     */     
/*     */     public JPanel getJPanel1() {
/* 309 */       return this.jPanel1;
/*     */     }
/*     */     
/*     */     public JScrollPane getJScrollPane1() {
/* 313 */       return this.jScrollPane1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public JTable getTabelaAlarmes()
/*     */     {
/* 327 */       return this.tabelaAlarmes;
/*     */     }
/*     */     
/*     */     public String getTituloAlarmes() {
/* 331 */       return this.tituloAlarmes;
/*     */     }
/*     */     
/*     */     public String[] getTituloAlarmesCol() {
/* 335 */       return this.tituloAlarmesCol;
/*     */     }
/*     */     
/*     */     public void setBtnLimparSelecao(JButton btnLimparSelecao) {
/* 339 */       this.btnLimparSelecao = btnLimparSelecao;
/*     */     }
/*     */     
/*     */     public void setBtnLimparTudo(JButton btnLimparTudo) {
/* 343 */       this.btnLimparTudo = btnLimparTudo;
/*     */     }
/*     */     
/*     */     public void setJPanel1(JPanel panel1) {
/* 347 */       this.jPanel1 = panel1;
/*     */     }
/*     */     
/*     */     public void setJScrollPane1(JScrollPane scrollPane1) {
/* 351 */       this.jScrollPane1 = scrollPane1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setTabelaAlarmes(JTable tabelaAlarmes)
/*     */     {
/* 367 */       this.tabelaAlarmes = tabelaAlarmes;
/*     */     }
/*     */     
/*     */     public void setTituloAlarmes(String tituloAlarmes) {
/* 371 */       this.tituloAlarmes = tituloAlarmes;
/*     */     }
/*     */     
/*     */     public void setTituloAlarmesCol(String[] tituloAlarmesCol) {
/* 375 */       this.tituloAlarmesCol = tituloAlarmesCol;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getCaminhoFiguras()
/*     */     {
/* 382 */       return this.caminhoFiguras;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object[][] getDadosTabela1()
/*     */     {
/* 389 */       return this.dadosTabela1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isFlagRetorno()
/*     */     {
/* 396 */       return this.flagRetorno;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Historico getHistorico()
/*     */     {
/* 403 */       return this.historico;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public InterfaceGrafica getInterfaceGrafica()
/*     */     {
/* 410 */       return this.interfaceGrafica;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getLinhaAtual()
/*     */     {
/* 417 */       return this.linhaAtual;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isPainelAtivo()
/*     */     {
/* 424 */       return this.painelAtivo;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getSelectedRow()
/*     */     {
/* 431 */       return this.selectedRow;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public DefaultTableModel getTableEvento()
/*     */     {
/* 445 */       return this.tableEvento;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public TableModel getTableModel()
/*     */     {
/* 452 */       return this.tableModel;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setSelectedRow(int i)
/*     */     {
/* 466 */       this.selectedRow = i;
/* 467 */       this.linhaAtual = this.tableEvento.getRowCount();
/*     */     }
/*     */   }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelHistorico.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */