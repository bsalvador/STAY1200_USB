/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainelMensg
/*     */   extends JPanel
/*     */ {
/*     */   private JLabel labelMensagens;
/*     */   private JButton btnCancel;
/*     */   private JButton btnOk;
/*     */   private JCheckBox cbAquecimentoEmail;
/*     */   private JCheckBox cbAquecimentoPop;
/*     */   private JCheckBox cbBateriaUsoEmail;
/*     */   private JCheckBox cbBateriaUsoPop;
/*     */   private JCheckBox cbBateriaFracaEmail;
/*     */   private JCheckBox cbBateriaFracaPop;
/*     */   private JCheckBox cbEnergiaEmail;
/*     */   private JCheckBox cbEnergiaPop;
/*     */   private JCheckBox cbComunicaEmail;
/*     */   private JCheckBox cbComunicaPop;
/*     */   private JCheckBox cbSobrecargaEmail;
/*     */   private JCheckBox cbSobrecargaPop;
/*     */   private JLabel labelAquecimento;
/*     */   private JLabel labelBateriaUso;
/*     */   private JLabel labelBateriaFraca;
/*     */   private JLabel labelFaltaComunica;
/*     */   private JLabel labelFaltaComunica2;
/*     */   private JLabel labelEmail;
/*     */   private JLabel labelFaltaEnergia;
/*     */   private JLabel labelPop;
/*     */   private JLabel labelSobrecarga;
/*     */   private JLabel labelTitulo;
/*     */   private boolean[][] matrizCheckBox;
/*     */   private boolean flag;
/*     */   
/*     */   public PainelMensg()
/*     */   {
/* 188 */     boolean[][] aux = { new boolean[2], new boolean[2], 
/* 189 */       new boolean[2], new boolean[2], new boolean[2], 
/* 190 */       { false, true } };
/*     */     
/* 192 */     this.matrizCheckBox = aux;
/* 193 */     initComponents();
/* 194 */     addListeners();
/* 195 */     this.cbComunicaPop.setSelected(true);
/* 196 */     this.cbComunicaPop.setEnabled(false);
/* 197 */     this.flag = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addListeners()
/*     */   {
/* 205 */     this.cbAquecimentoEmail.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 207 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 210 */     });
/* 211 */     this.cbAquecimentoPop.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 213 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 216 */     });
/* 217 */     this.cbBateriaUsoEmail.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 219 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 222 */     });
/* 223 */     this.cbBateriaUsoPop.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 225 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 228 */     });
/* 229 */     this.cbBateriaFracaEmail.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 231 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 234 */     });
/* 235 */     this.cbBateriaFracaPop.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 237 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 240 */     });
/* 241 */     this.cbEnergiaEmail.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 243 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 246 */     });
/* 247 */     this.cbEnergiaPop.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 249 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 252 */     });
/* 253 */     this.cbComunicaEmail.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 255 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 258 */     });
/* 259 */     this.cbComunicaPop.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 261 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 264 */     });
/* 265 */     this.cbSobrecargaEmail.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 267 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 270 */     });
/* 271 */     this.cbSobrecargaPop.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent ie) {
/* 273 */         PainelMensg.this.flag = true;
/*     */       }
/*     */       
/* 276 */     });
/* 277 */     this.btnCancel.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 279 */         PainelMensg.this.cbEnergiaEmail.setSelected(PainelMensg.this.matrizCheckBox[0][0]);
/* 280 */         PainelMensg.this.cbEnergiaPop.setSelected(PainelMensg.this.matrizCheckBox[0][1]);
/* 281 */         PainelMensg.this.cbBateriaFracaEmail.setSelected(PainelMensg.this.matrizCheckBox[1][0]);
/* 282 */         PainelMensg.this.cbBateriaFracaPop.setSelected(PainelMensg.this.matrizCheckBox[1][1]);
/* 283 */         PainelMensg.this.cbSobrecargaEmail.setSelected(PainelMensg.this.matrizCheckBox[2][0]);
/* 284 */         PainelMensg.this.cbSobrecargaPop.setSelected(PainelMensg.this.matrizCheckBox[2][1]);
/* 285 */         PainelMensg.this.cbAquecimentoEmail.setSelected(PainelMensg.this.matrizCheckBox[3][0]);
/* 286 */         PainelMensg.this.cbAquecimentoPop.setSelected(PainelMensg.this.matrizCheckBox[3][1]);
/* 287 */         PainelMensg.this.cbBateriaUsoEmail.setSelected(PainelMensg.this.matrizCheckBox[4][0]);
/* 288 */         PainelMensg.this.cbBateriaUsoPop.setSelected(PainelMensg.this.matrizCheckBox[4][1]);
/* 289 */         PainelMensg.this.cbComunicaEmail.setSelected(PainelMensg.this.matrizCheckBox[5][0]);
/*     */         
/* 291 */         PainelMensg.this.flag = false;
/*     */       }
/*     */       
/* 294 */     });
/* 295 */     this.btnOk.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 297 */         PainelMensg.this.flag = false;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearEmail()
/*     */   {
/* 307 */     this.cbEnergiaEmail.setSelected(false);
/* 308 */     this.cbBateriaFracaEmail.setSelected(false);
/* 309 */     this.cbSobrecargaEmail.setSelected(false);
/* 310 */     this.cbAquecimentoEmail.setSelected(false);
/* 311 */     this.cbBateriaUsoEmail.setSelected(false);
/* 312 */     this.cbComunicaEmail.setSelected(false);
/* 313 */     this.flag = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean[][] getCheckBoxSelected()
/*     */   {
/* 320 */     this.matrizCheckBox[0][0] = this.cbEnergiaEmail.isSelected();
/* 321 */     this.matrizCheckBox[0][1] = this.cbEnergiaPop.isSelected();
/* 322 */     this.matrizCheckBox[1][0] = this.cbBateriaFracaEmail.isSelected();
/* 323 */     this.matrizCheckBox[1][1] = this.cbBateriaFracaPop.isSelected();
/* 324 */     this.matrizCheckBox[2][0] = this.cbSobrecargaEmail.isSelected();
/* 325 */     this.matrizCheckBox[2][1] = this.cbSobrecargaPop.isSelected();
/* 326 */     this.matrizCheckBox[3][0] = this.cbAquecimentoEmail.isSelected();
/* 327 */     this.matrizCheckBox[3][1] = this.cbAquecimentoPop.isSelected();
/* 328 */     this.matrizCheckBox[4][0] = this.cbBateriaUsoEmail.isSelected();
/* 329 */     this.matrizCheckBox[4][1] = this.cbBateriaUsoPop.isSelected();
/* 330 */     this.matrizCheckBox[5][0] = this.cbComunicaEmail.isSelected();
/* 331 */     this.matrizCheckBox[5][1] = 1;
/* 332 */     return this.matrizCheckBox;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 340 */     this.labelTitulo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 341 */       .getString("CONFIGURACOES_DE_ENVIOS_DE_MENSAGENS"));
/* 342 */     this.labelEmail.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 343 */       .getString("E_MAIL"));
/* 344 */     this.labelPop.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 345 */       .getString("POP_UP"));
/* 346 */     this.labelMensagens.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 347 */       .getString("MENSAGENS_DE_ALERTA"));
/* 348 */     this.labelFaltaEnergia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 349 */       .getString("FALTA__RETORNO_DE_ENERGIA"));
/* 350 */     this.labelBateriaFraca.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 351 */       .getString("BATERIA_FRACA__NORMAL"));
/* 352 */     this.labelFaltaComunica.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 353 */       .getString("INTERRUPCAO__ESTABELECIMENTO_DE"));
/* 354 */     this.labelFaltaComunica2.setText(
/* 355 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 356 */       "COMUNICACAO_ENTRE_O_PC_E_O_UPS"));
/* 357 */     this.labelSobrecarga.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 358 */       .getString("SOBRECARGA__CARGA_NORMALIZADA"));
/* 359 */     this.labelAquecimento.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 360 */       .getString("SUPERAQUECIMENTO__TEMPERATURA_NORMAL_DO_UPS"));
/* 361 */     this.labelBateriaUso.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 362 */       .getString("BATERIAS_EM_USO__FIM_DO_USO_DE_BATERIAS"));
/* 363 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 364 */       "OK"));
/* 365 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 366 */       .getString("CANCELAR"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 373 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 374 */     Dimension d = new Dimension(384, 335);
/* 375 */     Font fonte11 = new Font("Trebuchet", 0, 11);
/* 376 */     Font fonte12Negrito = new Font("Trebuchet", 1, 12);
/*     */     
/* 378 */     this.labelTitulo = new JLabel();
/* 379 */     this.labelEmail = new JLabel();
/* 380 */     this.labelPop = new JLabel();
/* 381 */     this.labelMensagens = new JLabel();
/* 382 */     this.cbEnergiaEmail = new JCheckBox();
/* 383 */     this.cbComunicaEmail = new JCheckBox();
/* 384 */     this.cbSobrecargaEmail = new JCheckBox();
/* 385 */     this.cbAquecimentoEmail = new JCheckBox();
/* 386 */     this.cbBateriaUsoEmail = new JCheckBox();
/* 387 */     this.cbBateriaFracaEmail = new JCheckBox();
/* 388 */     this.cbEnergiaPop = new JCheckBox();
/* 389 */     this.cbBateriaFracaPop = new JCheckBox();
/* 390 */     this.cbComunicaPop = new JCheckBox();
/* 391 */     this.cbSobrecargaPop = new JCheckBox();
/* 392 */     this.cbAquecimentoPop = new JCheckBox();
/* 393 */     this.cbBateriaUsoPop = new JCheckBox();
/* 394 */     this.labelFaltaEnergia = new JLabel();
/* 395 */     this.labelBateriaFraca = new JLabel();
/* 396 */     this.labelFaltaComunica = new JLabel();
/* 397 */     this.labelFaltaComunica2 = new JLabel();
/* 398 */     this.labelSobrecarga = new JLabel();
/* 399 */     this.labelAquecimento = new JLabel();
/* 400 */     this.labelBateriaUso = new JLabel();
/* 401 */     this.btnOk = new JButton();
/* 402 */     this.btnCancel = new JButton();
/*     */     
/*     */ 
/* 405 */     setLayout(new GridBagLayout());
/* 406 */     setBackground(new Color(255, 255, 255));
/* 407 */     setMaximumSize(d);
/* 408 */     setMinimumSize(d);
/* 409 */     setOpaque(false);
/* 410 */     setPreferredSize(d);
/*     */     
/*     */ 
/* 413 */     this.labelTitulo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 414 */       .getString("CONFIGURACOES_DE_ENVIOS_DE_MENSAGENS"));
/* 415 */     this.labelTitulo.setFocusable(false);
/* 416 */     this.labelTitulo.setFont(fonte12Negrito);
/* 417 */     gridBagConstraints.gridwidth = 6;
/* 418 */     gridBagConstraints.fill = 2;
/* 419 */     gridBagConstraints.anchor = 17;
/* 420 */     gridBagConstraints.insets = new Insets(0, 40, 8, 0);
/* 421 */     add(this.labelTitulo, gridBagConstraints);
/*     */     
/*     */ 
/* 424 */     this.labelEmail.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 425 */       .getString("E_MAIL"));
/* 426 */     this.labelEmail.setFocusable(false);
/* 427 */     this.labelEmail.setFont(fonte12Negrito);
/* 428 */     gridBagConstraints.gridwidth = 1;
/* 429 */     gridBagConstraints.gridx = 1;
/* 430 */     gridBagConstraints.gridy = 2;
/* 431 */     gridBagConstraints.fill = 2;
/* 432 */     gridBagConstraints.insets = new Insets(0, 0, 5, 2);
/* 433 */     add(this.labelEmail, gridBagConstraints);
/*     */     
/*     */ 
/* 436 */     this.labelPop.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 437 */       .getString("POP_UP"));
/* 438 */     this.labelPop.setFocusable(false);
/* 439 */     this.labelPop.setFont(fonte12Negrito);
/* 440 */     gridBagConstraints.gridwidth = 1;
/* 441 */     gridBagConstraints.gridx = 2;
/* 442 */     gridBagConstraints.gridy = 2;
/* 443 */     gridBagConstraints.fill = 2;
/* 444 */     gridBagConstraints.anchor = 17;
/* 445 */     gridBagConstraints.insets = new Insets(0, 0, 5, 1);
/* 446 */     add(this.labelPop, gridBagConstraints);
/*     */     
/*     */ 
/* 449 */     this.labelMensagens.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 450 */       .getString("MENSAGENS_DE_ALERTA"));
/* 451 */     this.labelMensagens.setFocusable(false);
/* 452 */     this.labelMensagens.setFont(fonte12Negrito);
/* 453 */     gridBagConstraints.gridx = 3;
/* 454 */     gridBagConstraints.gridy = 2;
/* 455 */     gridBagConstraints.fill = 0;
/* 456 */     gridBagConstraints.gridwidth = 4;
/* 457 */     gridBagConstraints.anchor = 17;
/* 458 */     gridBagConstraints.insets = new Insets(0, 0, 5, 0);
/* 459 */     add(this.labelMensagens, gridBagConstraints);
/*     */     
/*     */ 
/* 462 */     this.labelFaltaEnergia.setFont(fonte11);
/* 463 */     this.labelFaltaEnergia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 464 */       .getString("FALTA__RETORNO_DE_ENERGIA"));
/* 465 */     gridBagConstraints.fill = 0;
/* 466 */     gridBagConstraints.gridx = 3;
/* 467 */     gridBagConstraints.gridy = 4;
/* 468 */     gridBagConstraints.gridwidth = 3;
/* 469 */     gridBagConstraints.anchor = 17;
/* 470 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 471 */     add(this.labelFaltaEnergia, gridBagConstraints);
/*     */     
/*     */ 
/* 474 */     this.labelBateriaFraca.setFont(fonte11);
/* 475 */     this.labelBateriaFraca.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 476 */       .getString("BATERIA_FRACA__NORMAL"));
/* 477 */     gridBagConstraints.fill = 0;
/* 478 */     gridBagConstraints.gridx = 3;
/* 479 */     gridBagConstraints.gridy = 6;
/* 480 */     gridBagConstraints.gridwidth = 3;
/* 481 */     gridBagConstraints.anchor = 17;
/* 482 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 483 */     add(this.labelBateriaFraca, gridBagConstraints);
/*     */     
/*     */ 
/* 486 */     this.labelFaltaComunica.setFont(fonte11);
/* 487 */     this.labelFaltaComunica.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 488 */       .getString("INTERRUPCAO__ESTABELECIMENTO_DE"));
/* 489 */     gridBagConstraints.fill = 0;
/* 490 */     gridBagConstraints.gridx = 3;
/* 491 */     gridBagConstraints.gridy = 22;
/* 492 */     gridBagConstraints.gridwidth = 3;
/* 493 */     gridBagConstraints.anchor = 17;
/* 494 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 495 */     add(this.labelFaltaComunica, gridBagConstraints);
/*     */     
/*     */ 
/* 498 */     this.labelFaltaComunica2.setFont(fonte11);
/* 499 */     this.labelFaltaComunica2.setText(
/* 500 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 501 */       "COMUNICACAO_ENTRE_O_PC_E_O_UPS"));
/* 502 */     gridBagConstraints.fill = 0;
/* 503 */     gridBagConstraints.gridx = 3;
/* 504 */     gridBagConstraints.gridy = 24;
/* 505 */     gridBagConstraints.gridwidth = 3;
/* 506 */     gridBagConstraints.anchor = 17;
/* 507 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 508 */     add(this.labelFaltaComunica2, gridBagConstraints);
/*     */     
/*     */ 
/* 511 */     this.labelSobrecarga.setFont(fonte11);
/* 512 */     this.labelSobrecarga.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 513 */       .getString("SOBRECARGA__CARGA_NORMALIZADA"));
/* 514 */     gridBagConstraints.fill = 0;
/* 515 */     gridBagConstraints.gridx = 3;
/* 516 */     gridBagConstraints.gridy = 14;
/* 517 */     gridBagConstraints.gridwidth = 4;
/* 518 */     gridBagConstraints.anchor = 17;
/* 519 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 520 */     add(this.labelSobrecarga, gridBagConstraints);
/*     */     
/*     */ 
/* 523 */     this.labelAquecimento.setFont(fonte11);
/* 524 */     this.labelAquecimento.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 525 */       .getString("SUPERAQUECIMENTO__TEMPERATURA_NORMAL_DO_UPS"));
/* 526 */     gridBagConstraints.fill = 0;
/* 527 */     gridBagConstraints.gridx = 3;
/* 528 */     gridBagConstraints.gridy = 16;
/* 529 */     gridBagConstraints.gridwidth = 4;
/* 530 */     gridBagConstraints.anchor = 17;
/* 531 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 532 */     add(this.labelAquecimento, gridBagConstraints);
/*     */     
/*     */ 
/* 535 */     this.labelBateriaUso.setFont(fonte11);
/* 536 */     this.labelBateriaUso.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 537 */       .getString("BATERIAS_EM_USO__FIM_DO_USO_DE_BATERIAS"));
/* 538 */     gridBagConstraints.fill = 0;
/* 539 */     gridBagConstraints.gridx = 3;
/* 540 */     gridBagConstraints.gridy = 20;
/* 541 */     gridBagConstraints.gridwidth = 4;
/* 542 */     gridBagConstraints.anchor = 17;
/* 543 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 544 */     add(this.labelBateriaUso, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 549 */     this.cbEnergiaEmail.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 550 */     this.cbEnergiaEmail.setFocusPainted(false);
/* 551 */     this.cbEnergiaEmail.setMargin(new Insets(0, 0, 0, 0));
/* 552 */     this.cbEnergiaEmail.setOpaque(false);
/* 553 */     gridBagConstraints.fill = 0;
/* 554 */     gridBagConstraints.gridwidth = 1;
/* 555 */     gridBagConstraints.anchor = 10;
/* 556 */     gridBagConstraints.gridx = 1;
/* 557 */     gridBagConstraints.gridy = 4;
/* 558 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 559 */     add(this.cbEnergiaEmail, gridBagConstraints);
/*     */     
/*     */ 
/* 562 */     this.cbComunicaEmail.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 563 */     this.cbComunicaEmail.setFocusPainted(false);
/* 564 */     this.cbComunicaEmail.setMargin(new Insets(0, 0, 0, 0));
/* 565 */     gridBagConstraints.fill = 0;
/* 566 */     gridBagConstraints.gridwidth = 1;
/* 567 */     gridBagConstraints.anchor = 10;
/* 568 */     gridBagConstraints.gridx = 1;
/* 569 */     gridBagConstraints.gridy = 22;
/* 570 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 571 */     add(this.cbComunicaEmail, gridBagConstraints);
/*     */     
/*     */ 
/* 574 */     this.cbSobrecargaEmail
/* 575 */       .setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 576 */     this.cbSobrecargaEmail.setFocusPainted(false);
/* 577 */     this.cbSobrecargaEmail.setMargin(new Insets(0, 0, 0, 0));
/* 578 */     gridBagConstraints.fill = 0;
/* 579 */     gridBagConstraints.gridwidth = 1;
/* 580 */     gridBagConstraints.anchor = 10;
/* 581 */     gridBagConstraints.gridx = 1;
/* 582 */     gridBagConstraints.gridy = 14;
/* 583 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 584 */     add(this.cbSobrecargaEmail, gridBagConstraints);
/*     */     
/*     */ 
/* 587 */     this.cbAquecimentoEmail.setBorder(
/* 588 */       BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 589 */     this.cbAquecimentoEmail.setFocusPainted(false);
/* 590 */     this.cbAquecimentoEmail.setMargin(new Insets(0, 0, 0, 0));
/* 591 */     gridBagConstraints.fill = 0;
/* 592 */     gridBagConstraints.gridwidth = 1;
/* 593 */     gridBagConstraints.anchor = 10;
/* 594 */     gridBagConstraints.gridx = 1;
/* 595 */     gridBagConstraints.gridy = 16;
/* 596 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 597 */     add(this.cbAquecimentoEmail, gridBagConstraints);
/*     */     
/*     */ 
/* 600 */     this.cbBateriaUsoEmail
/* 601 */       .setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 602 */     this.cbBateriaUsoEmail.setFocusPainted(false);
/* 603 */     this.cbBateriaUsoEmail.setMargin(new Insets(0, 0, 0, 0));
/* 604 */     gridBagConstraints.fill = 0;
/* 605 */     gridBagConstraints.gridwidth = 1;
/* 606 */     gridBagConstraints.anchor = 10;
/* 607 */     gridBagConstraints.gridx = 1;
/* 608 */     gridBagConstraints.gridy = 20;
/* 609 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 610 */     add(this.cbBateriaUsoEmail, gridBagConstraints);
/*     */     
/*     */ 
/* 613 */     this.cbBateriaFracaEmail.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 
/* 614 */       0));
/* 615 */     this.cbBateriaFracaEmail.setFocusPainted(false);
/* 616 */     this.cbBateriaFracaEmail.setMargin(new Insets(0, 0, 0, 0));
/* 617 */     gridBagConstraints.fill = 0;
/* 618 */     gridBagConstraints.gridwidth = 1;
/* 619 */     gridBagConstraints.anchor = 10;
/* 620 */     gridBagConstraints.gridx = 1;
/* 621 */     gridBagConstraints.gridy = 6;
/* 622 */     gridBagConstraints.insets = new Insets(0, 0, 3, 0);
/* 623 */     add(this.cbBateriaFracaEmail, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 628 */     this.cbEnergiaPop.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 629 */     this.cbEnergiaPop.setFocusPainted(false);
/* 630 */     this.cbEnergiaPop.setMargin(new Insets(0, 0, 0, 0));
/* 631 */     gridBagConstraints.fill = 0;
/* 632 */     gridBagConstraints.gridwidth = 1;
/* 633 */     gridBagConstraints.gridx = 2;
/* 634 */     gridBagConstraints.gridy = 4;
/* 635 */     gridBagConstraints.anchor = 17;
/* 636 */     gridBagConstraints.insets = new Insets(0, 10, 3, 0);
/* 637 */     add(this.cbEnergiaPop, gridBagConstraints);
/*     */     
/*     */ 
/* 640 */     this.cbBateriaFracaPop
/* 641 */       .setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 642 */     this.cbBateriaFracaPop.setFocusPainted(false);
/* 643 */     this.cbBateriaFracaPop.setMargin(new Insets(0, 0, 0, 0));
/* 644 */     gridBagConstraints.fill = 0;
/* 645 */     gridBagConstraints.gridwidth = 1;
/* 646 */     gridBagConstraints.gridx = 2;
/* 647 */     gridBagConstraints.gridy = 6;
/* 648 */     gridBagConstraints.anchor = 17;
/* 649 */     gridBagConstraints.insets = new Insets(0, 10, 3, 0);
/* 650 */     add(this.cbBateriaFracaPop, gridBagConstraints);
/*     */     
/*     */ 
/* 653 */     this.cbComunicaPop.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 654 */     this.cbComunicaPop.setFocusPainted(false);
/* 655 */     this.cbComunicaPop.setMargin(new Insets(0, 0, 0, 0));
/* 656 */     gridBagConstraints.fill = 0;
/* 657 */     gridBagConstraints.gridwidth = 1;
/* 658 */     gridBagConstraints.gridx = 2;
/* 659 */     gridBagConstraints.gridy = 22;
/* 660 */     gridBagConstraints.anchor = 17;
/* 661 */     gridBagConstraints.insets = new Insets(0, 10, 3, 0);
/* 662 */     add(this.cbComunicaPop, gridBagConstraints);
/*     */     
/*     */ 
/* 665 */     this.cbSobrecargaPop.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 666 */     this.cbSobrecargaPop.setFocusPainted(false);
/* 667 */     this.cbSobrecargaPop.setMargin(new Insets(0, 0, 0, 0));
/* 668 */     gridBagConstraints.fill = 0;
/* 669 */     gridBagConstraints.gridwidth = 1;
/* 670 */     gridBagConstraints.gridx = 2;
/* 671 */     gridBagConstraints.gridy = 14;
/* 672 */     gridBagConstraints.anchor = 17;
/* 673 */     gridBagConstraints.insets = new Insets(0, 10, 3, 0);
/* 674 */     add(this.cbSobrecargaPop, gridBagConstraints);
/*     */     
/*     */ 
/* 677 */     this.cbAquecimentoPop.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 678 */     this.cbAquecimentoPop.setFocusPainted(false);
/* 679 */     this.cbAquecimentoPop.setMargin(new Insets(0, 0, 0, 0));
/* 680 */     gridBagConstraints.fill = 0;
/* 681 */     gridBagConstraints.gridwidth = 1;
/* 682 */     gridBagConstraints.gridx = 2;
/* 683 */     gridBagConstraints.gridy = 16;
/* 684 */     gridBagConstraints.anchor = 17;
/* 685 */     gridBagConstraints.insets = new Insets(0, 10, 3, 0);
/* 686 */     add(this.cbAquecimentoPop, gridBagConstraints);
/*     */     
/*     */ 
/* 689 */     this.cbBateriaUsoPop.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 690 */     this.cbBateriaUsoPop.setFocusPainted(false);
/* 691 */     this.cbBateriaUsoPop.setMargin(new Insets(0, 0, 0, 0));
/* 692 */     gridBagConstraints.fill = 0;
/* 693 */     gridBagConstraints.gridwidth = 1;
/* 694 */     gridBagConstraints.gridx = 2;
/* 695 */     gridBagConstraints.gridy = 20;
/* 696 */     gridBagConstraints.anchor = 17;
/* 697 */     gridBagConstraints.insets = new Insets(0, 10, 3, 0);
/* 698 */     add(this.cbBateriaUsoPop, gridBagConstraints);
/*     */     
/*     */ 
/* 701 */     this.btnOk.setFont(fonte12Negrito);
/* 702 */     this.btnOk.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 703 */       "OK"));
/* 704 */     this.btnOk.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(
/* 705 */       160, 160, 160)));
/* 706 */     this.btnOk.setFocusPainted(false);
/* 707 */     this.btnOk.setMaximumSize(new Dimension(100, 30));
/* 708 */     this.btnOk.setMinimumSize(new Dimension(100, 30));
/* 709 */     this.btnOk.setPreferredSize(new Dimension(100, 30));
/* 710 */     gridBagConstraints.gridx = 4;
/* 711 */     gridBagConstraints.gridy = 28;
/* 712 */     gridBagConstraints.gridheight = 3;
/* 713 */     gridBagConstraints.gridwidth = 1;
/* 714 */     gridBagConstraints.fill = 0;
/* 715 */     gridBagConstraints.insets = new Insets(50, 30, 0, 0);
/* 716 */     add(this.btnOk, gridBagConstraints);
/*     */     
/*     */ 
/* 719 */     this.btnCancel.setFont(fonte12Negrito);
/* 720 */     this.btnCancel.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 721 */       .getString("CANCELAR"));
/* 722 */     this.btnCancel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 723 */       new Color(160, 160, 160)));
/* 724 */     this.btnCancel.setFocusPainted(false);
/* 725 */     this.btnCancel.setMaximumSize(new Dimension(100, 30));
/* 726 */     this.btnCancel.setMinimumSize(new Dimension(100, 30));
/* 727 */     this.btnCancel.setPreferredSize(new Dimension(100, 30));
/* 728 */     gridBagConstraints.gridx = 5;
/* 729 */     gridBagConstraints.gridy = 28;
/* 730 */     gridBagConstraints.gridheight = 3;
/* 731 */     gridBagConstraints.gridwidth = 1;
/* 732 */     gridBagConstraints.fill = 0;
/* 733 */     gridBagConstraints.insets = new Insets(50, 10, 0, 0);
/* 734 */     add(this.btnCancel, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JButton getBtnCancel()
/*     */   {
/* 742 */     return this.btnCancel;
/*     */   }
/*     */   
/*     */   public boolean getFlag() {
/* 746 */     return this.flag;
/*     */   }
/*     */   
/*     */   public JButton getBtnOk() {
/* 750 */     return this.btnOk;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbAquecimentoEmail() {
/* 754 */     return this.cbAquecimentoEmail;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbAquecimentoPop() {
/* 758 */     return this.cbAquecimentoPop;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbBateriaFracaEmail() {
/* 762 */     return this.cbBateriaFracaEmail;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbBateriaFracaPop() {
/* 766 */     return this.cbBateriaFracaPop;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbBateriaUsoEmail() {
/* 770 */     return this.cbBateriaUsoEmail;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbBateriaUsoPop() {
/* 774 */     return this.cbBateriaUsoPop;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbComunicaEmail() {
/* 778 */     return this.cbComunicaEmail;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbComunicaPop() {
/* 782 */     return this.cbComunicaPop;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbEnergiaEmail() {
/* 786 */     return this.cbEnergiaEmail;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbEnergiaPop() {
/* 790 */     return this.cbEnergiaPop;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbSobrecargaEmail() {
/* 794 */     return this.cbSobrecargaEmail;
/*     */   }
/*     */   
/*     */   public JCheckBox getCbSobrecargaPop() {
/* 798 */     return this.cbSobrecargaPop;
/*     */   }
/*     */   
/*     */   public JLabel getLabelAquecimento() {
/* 802 */     return this.labelAquecimento;
/*     */   }
/*     */   
/*     */   public JLabel getLabelBateriaFraca() {
/* 806 */     return this.labelBateriaFraca;
/*     */   }
/*     */   
/*     */   public JLabel getLabelBateriaUso() {
/* 810 */     return this.labelBateriaUso;
/*     */   }
/*     */   
/*     */   public JLabel getLabelEmail() {
/* 814 */     return this.labelEmail;
/*     */   }
/*     */   
/*     */   public JLabel getLabelFaltaComunica() {
/* 818 */     return this.labelFaltaComunica;
/*     */   }
/*     */   
/*     */   public JLabel getLabelFaltaComunica2() {
/* 822 */     return this.labelFaltaComunica2;
/*     */   }
/*     */   
/*     */   public JLabel getLabelFaltaEnergia() {
/* 826 */     return this.labelFaltaEnergia;
/*     */   }
/*     */   
/*     */   public JLabel getLabelMensagens() {
/* 830 */     return this.labelMensagens;
/*     */   }
/*     */   
/*     */   public JLabel getLabelPop() {
/* 834 */     return this.labelPop;
/*     */   }
/*     */   
/*     */   public JLabel getLabelSobrecarga() {
/* 838 */     return this.labelSobrecarga;
/*     */   }
/*     */   
/*     */   public JLabel getLabelTitulo() {
/* 842 */     return this.labelTitulo;
/*     */   }
/*     */   
/*     */   public boolean[][] getMatrizCheckBox() {
/* 846 */     return this.matrizCheckBox;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBtnCancel(JButton btnCancel)
/*     */   {
/* 853 */     this.btnCancel = btnCancel;
/*     */   }
/*     */   
/*     */   public void setFlag(boolean flag) {
/* 857 */     this.flag = flag;
/*     */   }
/*     */   
/*     */   public void setBtnOk(JButton btnOk) {
/* 861 */     this.btnOk = btnOk;
/*     */   }
/*     */   
/*     */   public void setCbAquecimentoEmail(JCheckBox cbAquecimentoEmail) {
/* 865 */     this.cbAquecimentoEmail = cbAquecimentoEmail;
/*     */   }
/*     */   
/*     */   public void setCbAquecimentoPop(JCheckBox cbAquecimentoPop) {
/* 869 */     this.cbAquecimentoPop = cbAquecimentoPop;
/*     */   }
/*     */   
/*     */   public void setCbBateriaFracaEmail(JCheckBox cbBateriaFracaEmail) {
/* 873 */     this.cbBateriaFracaEmail = cbBateriaFracaEmail;
/*     */   }
/*     */   
/*     */   public void setCbBateriaFracaPop(JCheckBox cbBateriaFracaPop) {
/* 877 */     this.cbBateriaFracaPop = cbBateriaFracaPop;
/*     */   }
/*     */   
/*     */   public void setCbBateriaUsoEmail(JCheckBox cbBateriaUsoEmail) {
/* 881 */     this.cbBateriaUsoEmail = cbBateriaUsoEmail;
/*     */   }
/*     */   
/*     */   public void setCbBateriaUsoPop(JCheckBox cbBateriaUsoPop) {
/* 885 */     this.cbBateriaUsoPop = cbBateriaUsoPop;
/*     */   }
/*     */   
/*     */   public void setCbComunicaEmail(JCheckBox cbComunicaEmail) {
/* 889 */     this.cbComunicaEmail = cbComunicaEmail;
/*     */   }
/*     */   
/*     */   public void setCbComunicaPop(JCheckBox cbComunicaPop) {
/* 893 */     this.cbComunicaPop = cbComunicaPop;
/*     */   }
/*     */   
/*     */   public void setCbEnergiaEmail(JCheckBox cbEnergiaEmail) {
/* 897 */     this.cbEnergiaEmail = cbEnergiaEmail;
/*     */   }
/*     */   
/*     */   public void setCbEnergiaPop(JCheckBox cbEnergiaPop) {
/* 901 */     this.cbEnergiaPop = cbEnergiaPop;
/*     */   }
/*     */   
/*     */   public void setCbSobrecargaEmail(JCheckBox cbSobrecargaEmail) {
/* 905 */     this.cbSobrecargaEmail = cbSobrecargaEmail;
/*     */   }
/*     */   
/*     */   public void setCbSobrecargaPop(JCheckBox cbSobrecargaPop) {
/* 909 */     this.cbSobrecargaPop = cbSobrecargaPop;
/*     */   }
/*     */   
/*     */   public void setLabelAquecimento(JLabel labelAquecimento) {
/* 913 */     this.labelAquecimento = labelAquecimento;
/*     */   }
/*     */   
/*     */   public void setLabelBateriaFraca(JLabel labelBateriaFraca) {
/* 917 */     this.labelBateriaFraca = labelBateriaFraca;
/*     */   }
/*     */   
/*     */   public void setLabelBateriaUso(JLabel labelBateriaUso) {
/* 921 */     this.labelBateriaUso = labelBateriaUso;
/*     */   }
/*     */   
/*     */   public void setLabelEmail(JLabel labelEmail) {
/* 925 */     this.labelEmail = labelEmail;
/*     */   }
/*     */   
/*     */   public void setLabelFaltaComunica(JLabel labelFaltaComunica) {
/* 929 */     this.labelFaltaComunica = labelFaltaComunica;
/*     */   }
/*     */   
/*     */   public void setLabelFaltaComunica2(JLabel labelFaltaComunica2) {
/* 933 */     this.labelFaltaComunica2 = labelFaltaComunica2;
/*     */   }
/*     */   
/*     */   public void setLabelFaltaEnergia(JLabel labelFaltaEnergia) {
/* 937 */     this.labelFaltaEnergia = labelFaltaEnergia;
/*     */   }
/*     */   
/*     */   public void setLabelMensagens(JLabel labelMensagens) {
/* 941 */     this.labelMensagens = labelMensagens;
/*     */   }
/*     */   
/*     */   public void setLabelPop(JLabel labelPop) {
/* 945 */     this.labelPop = labelPop;
/*     */   }
/*     */   
/*     */   public void setLabelSobrecarga(JLabel labelSobrecarga) {
/* 949 */     this.labelSobrecarga = labelSobrecarga;
/*     */   }
/*     */   
/*     */   public void setLabelTitulo(JLabel labelTitulo) {
/* 953 */     this.labelTitulo = labelTitulo;
/*     */   }
/*     */   
/*     */   public void setMatrizCheckBox(boolean[][] matrizCheckBox) {
/* 957 */     this.matrizCheckBox = matrizCheckBox;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelMensg.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */