/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PainelPotencia
/*     */   extends JPanel
/*     */ {
/*     */   private JLabel fPot;
/*     */   private JLabel labelBoost;
/*     */   private JLabel boost;
/*     */   private JLabel labelFPot;
/*     */   private JLabel labelPotAp;
/*     */   private JLabel labelPotReal;
/*     */   private JLabel potAp;
/*     */   private JLabel potReal;
/*     */   private DecimalFormat formatador;
/*     */   private DecimalFormat formatador2;
/*     */   private String titulo;
/*     */   private ImageIcon imagemFundo;
/*     */   private JPanel enchimento;
/*     */   
/*     */   public PainelPotencia(String caminhoImagem)
/*     */   {
/* 232 */     initComponents();
/* 233 */     this.imagemFundo = new ImageIcon(caminhoImagem + "painelInferior.png");
/* 234 */     this.formatador = new DecimalFormat("0.0");
/* 235 */     this.formatador2 = new DecimalFormat("0.00");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 247 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 248 */       "POTENCIA");
/* 249 */     this.enchimento.setBorder(BorderFactory.createTitledBorder(
/* 250 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 251 */       0, 1, 
/* 252 */       new Font("Trebuchet", 1, 12)));
/* 253 */     this.labelPotAp.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 254 */       .getString("POTENCIA_APARENTE"));
/* 255 */     this.labelPotReal.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 256 */       .getString("POTENCIA_REAL"));
/* 257 */     this.labelFPot.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 258 */       .getString("FATOR_DE_POTENCIA"));
/* 259 */     this.labelBoost.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 260 */       .getString("BOOST"));
/*     */   }
/*     */   
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/* 266 */     super.paintComponent(g);
/* 267 */     g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/* 277 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 278 */     Dimension d = new Dimension(205, 135);
/* 279 */     Font fonte = new Font("Trebuchet", 0, 11);
/* 280 */     Font fonte1 = new Font("Trebuchet", 1, 11);
/* 281 */     Font fonte12B = new Font("Trebuchet", 1, 12);
/* 282 */     Insets insets = new Insets(0, 0, 10, 0);
/* 283 */     Insets insets2 = new Insets(0, 20, 10, 0);
/*     */     
/* 285 */     this.labelBoost = new JLabel();
/*     */     
/* 287 */     this.boost = new JLabel();
/* 288 */     this.labelPotAp = new JLabel();
/* 289 */     this.potAp = new JLabel();
/* 290 */     this.labelPotReal = new JLabel();
/* 291 */     this.potReal = new JLabel();
/* 292 */     this.labelFPot = new JLabel();
/* 293 */     this.fPot = new JLabel();
/* 294 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 295 */       "POTENCIA");
/*     */     
/* 297 */     this.enchimento = new JPanel();
/* 298 */     setLayout(new FlowLayout(1, 0, 3));
/* 299 */     setOpaque(false);
/* 300 */     add(this.enchimento);
/*     */     
/*     */ 
/*     */ 
/* 304 */     this.enchimento.setLayout(new GridBagLayout());
/* 305 */     this.enchimento.setBorder(BorderFactory.createTitledBorder(
/* 306 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 307 */       0, 1, 
/* 308 */       fonte12B));
/* 309 */     this.enchimento.setMaximumSize(d);
/* 310 */     this.enchimento.setMinimumSize(d);
/* 311 */     this.enchimento.setOpaque(false);
/* 312 */     this.enchimento.setPreferredSize(d);
/*     */     
/*     */ 
/*     */ 
/* 316 */     this.labelPotAp.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 317 */       .getString("POTENCIA_APARENTE"));
/* 318 */     this.labelPotAp.setFont(fonte1);
/* 319 */     gridBagConstraints.gridwidth = 2;
/* 320 */     gridBagConstraints.anchor = 17;
/* 321 */     gridBagConstraints.insets = insets;
/* 322 */     this.enchimento.add(this.labelPotAp, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 326 */     this.potAp.setFont(fonte);
/* 327 */     this.potAp.setText("VA");
/* 328 */     gridBagConstraints.gridx = 2;
/* 329 */     gridBagConstraints.gridy = 0;
/* 330 */     gridBagConstraints.anchor = 13;
/* 331 */     gridBagConstraints.insets = insets2;
/* 332 */     this.enchimento.add(this.potAp, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 336 */     this.labelPotReal.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 337 */       .getString("POTENCIA_REAL"));
/* 338 */     this.labelPotReal.setFont(fonte1);
/* 339 */     gridBagConstraints.gridx = 0;
/* 340 */     gridBagConstraints.gridy = 2;
/* 341 */     gridBagConstraints.gridwidth = 2;
/* 342 */     gridBagConstraints.anchor = 17;
/* 343 */     gridBagConstraints.insets = insets;
/* 344 */     this.enchimento.add(this.labelPotReal, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 348 */     this.potReal.setFont(fonte);
/* 349 */     this.potReal.setText("000.0W");
/* 350 */     gridBagConstraints.gridx = 2;
/* 351 */     gridBagConstraints.gridy = 2;
/* 352 */     gridBagConstraints.anchor = 13;
/* 353 */     gridBagConstraints.insets = insets2;
/* 354 */     this.enchimento.add(this.potReal, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 358 */     this.labelFPot.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 359 */       .getString("FATOR_DE_POTENCIA"));
/* 360 */     this.labelFPot.setFont(fonte1);
/* 361 */     gridBagConstraints.gridx = 0;
/* 362 */     gridBagConstraints.gridy = 4;
/* 363 */     gridBagConstraints.gridwidth = 2;
/* 364 */     gridBagConstraints.anchor = 17;
/* 365 */     gridBagConstraints.insets = insets;
/* 366 */     this.enchimento.add(this.labelFPot, gridBagConstraints);
/*     */     
/*     */ 
/*     */ 
/* 370 */     this.fPot.setFont(fonte);
/* 371 */     this.fPot.setText("FP");
/* 372 */     gridBagConstraints.gridx = 2;
/* 373 */     gridBagConstraints.gridy = 4;
/* 374 */     gridBagConstraints.anchor = 13;
/* 375 */     gridBagConstraints.insets = insets2;
/* 376 */     this.enchimento.add(this.fPot, gridBagConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFPot(JLabel l)
/*     */   {
/* 387 */     this.fPot = l;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabelFPot(JLabel l)
/*     */   {
/* 393 */     this.labelFPot = l;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabelPotAp(JLabel l)
/*     */   {
/* 399 */     this.labelPotAp = l;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabelPotReal(JLabel l)
/*     */   {
/* 405 */     this.labelPotReal = l;
/*     */   }
/*     */   
/*     */   public void setPotAp(JLabel l)
/*     */   {
/* 410 */     this.potAp = l;
/*     */   }
/*     */   
/*     */   public void setPotReal(JLabel l)
/*     */   {
/* 415 */     this.potReal = l;
/*     */   }
/*     */   
/*     */   public void setBoost(JLabel boost) {
/* 419 */     this.boost = boost;
/*     */   }
/*     */   
/*     */   public void setLabelBoost(JLabel labelBoost) {
/* 423 */     this.labelBoost = labelBoost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFPot(float f)
/*     */   {
/* 432 */     this.fPot.setText(this.formatador2.format(f));
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPotAp(float f)
/*     */   {
/* 438 */     this.potAp.setText(this.formatador.format(f) + "VA");
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPotReal(float f)
/*     */   {
/* 444 */     this.potReal.setText(this.formatador.format(f) + "W");
/*     */   }
/*     */   
/*     */   public void setBoost(float f) {
/* 448 */     this.boost.setText(this.formatador.format(f));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JLabel getFPot()
/*     */   {
/* 459 */     return this.fPot;
/*     */   }
/*     */   
/*     */   public JLabel getLabelFPot()
/*     */   {
/* 464 */     return this.labelFPot;
/*     */   }
/*     */   
/*     */   public JLabel getLabelPotAp()
/*     */   {
/* 469 */     return this.labelPotAp;
/*     */   }
/*     */   
/*     */   public JLabel getLabelPotReal()
/*     */   {
/* 474 */     return this.labelPotReal;
/*     */   }
/*     */   
/*     */   public JLabel getPotAp()
/*     */   {
/* 479 */     return this.potAp;
/*     */   }
/*     */   
/*     */   public JLabel getPotReal()
/*     */   {
/* 484 */     return this.potReal;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelPotencia.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */