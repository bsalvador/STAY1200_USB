/*     */ package br.com.schneider.sgm.gui;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrataStatusAlertas
/*     */ {
/*     */   public static final byte PERMANECE = 0;
/*     */   
/*     */   public static final byte LIGA = 1;
/*     */   
/*     */   public static final byte DESLIGA = 2;
/*     */   
/*     */   private boolean carregandoBateria;
/*     */   
/*     */   private boolean carregandoBateriaAntes;
/*     */   
/*     */   private byte indicaCarregandoBateria;
/*     */   
/*     */   private boolean bateriaEmUso;
/*     */   
/*     */   private boolean bateriaEmUsoAntes;
/*     */   
/*     */   private byte indicaBateriaEmUso;
/*     */   
/*     */   private boolean falhaRede;
/*     */   
/*  27 */   private boolean falhaRedeAntes = true;
/*     */   
/*     */   private byte indicaFalhaRede;
/*     */   
/*     */   private boolean modoInversor;
/*     */   
/*     */   private boolean modoInversorAntes;
/*     */   
/*     */   private byte indicaModoInversor;
/*     */   
/*     */   private boolean bateriaBaixa;
/*     */   
/*     */   private boolean bateriaBaixaAntes;
/*     */   
/*     */   private byte indicaBateriaBaixa;
/*     */   
/*     */   private boolean bateriaCritica;
/*     */   
/*     */   private boolean bateriaCriticaAntes;
/*     */   
/*     */   private byte indicaBateriaCritica;
/*     */   
/*     */   private boolean temperaturaElevada;
/*     */   
/*     */   private boolean temperaturaElevadaAntes;
/*     */   
/*     */   private byte indicaTemperaturaElevada;
/*     */   private boolean superAquecimento;
/*     */   private boolean superAquecimentoAntes;
/*     */   private byte indicaSuperAquecimento;
/*     */   private boolean cargaElevada;
/*     */   private boolean cargaElevadaAntes;
/*     */   private byte indicaCargaElevada;
/*     */   private boolean sobrecarga;
/*     */   private boolean sobrecargaAntes;
/*     */   private byte indicaSobrecarga;
/*     */   private boolean modoBypass;
/*     */   private boolean modoBypassAntes;
/*     */   private byte indicaBypass;
/*     */   
/*     */   public void setCarregandoBateria(boolean carregandoBateria)
/*     */   {
/*  69 */     this.carregandoBateria = carregandoBateria;
/*     */   }
/*     */   
/*  72 */   public byte getIndicaCarregandoBateria() { return this.indicaCarregandoBateria; }
/*     */   
/*     */   public void setBateriaEmUso(boolean bateriaEmUso) {
/*  75 */     this.bateriaEmUso = bateriaEmUso;
/*     */   }
/*     */   
/*  78 */   public byte getIndicaBateriaEmUso() { return this.indicaBateriaEmUso; }
/*     */   
/*     */   public void setModoInversor(boolean modoInversor) {
/*  81 */     this.modoInversor = modoInversor;
/*     */   }
/*     */   
/*  84 */   public byte getIndicaModoInversor() { return this.indicaModoInversor; }
/*     */   
/*     */   public void setFalhaRede(boolean falhaRede) {
/*  87 */     this.falhaRede = (!falhaRede);
/*     */   }
/*     */   
/*  90 */   public byte getIndicaFalhaRede() { return this.indicaFalhaRede; }
/*     */   
/*     */   public void setBateriaBaixa(boolean bateriaBaixa) {
/*  93 */     this.bateriaBaixa = bateriaBaixa;
/*     */   }
/*     */   
/*  96 */   public byte getIndicaBateriaBaixa() { return this.indicaBateriaBaixa; }
/*     */   
/*     */   public void setBateriaCritica(boolean bateriaCritica) {
/*  99 */     this.bateriaCritica = bateriaCritica;
/*     */   }
/*     */   
/* 102 */   public boolean getBateriaCritica() { return this.bateriaCritica; }
/*     */   
/*     */   public byte getIndicaBateriaCritica() {
/* 105 */     return this.indicaBateriaCritica;
/*     */   }
/*     */   
/* 108 */   public void setTemperaturaElevada(boolean temperaturaElevada) { this.temperaturaElevada = temperaturaElevada; }
/*     */   
/*     */   public byte getIndicaTemperaturaElevada() {
/* 111 */     return this.indicaTemperaturaElevada;
/*     */   }
/*     */   
/* 114 */   public void setSuperAquecimento(boolean superAquecimento) { this.superAquecimento = superAquecimento; }
/*     */   
/*     */   public boolean getSuperAquecimento() {
/* 117 */     return this.superAquecimento;
/*     */   }
/*     */   
/* 120 */   public byte getIndicaSuperAquecimento() { return this.indicaSuperAquecimento; }
/*     */   
/*     */   public void setCargaElevada(boolean cargaElevada) {
/* 123 */     this.cargaElevada = cargaElevada;
/*     */   }
/*     */   
/* 126 */   public byte getIndicaCargaElevada() { return this.indicaCargaElevada; }
/*     */   
/*     */   public void setSobrecarga(boolean sobrecarga) {
/* 129 */     this.sobrecarga = sobrecarga;
/*     */   }
/*     */   
/* 132 */   public boolean getSobrecarga() { return this.sobrecarga; }
/*     */   
/*     */   public byte getIndicaSobrecarga() {
/* 135 */     return this.indicaSobrecarga;
/*     */   }
/*     */   
/*     */   public void setBypass(boolean sobrecarga) {
/* 139 */     this.modoBypass = sobrecarga;
/*     */   }
/*     */   
/* 142 */   public boolean getBypass() { return this.modoBypass; }
/*     */   
/*     */   public byte getIndicaBypass() {
/* 145 */     return this.indicaBypass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void processaStatusAlertas()
/*     */   {
/* 152 */     this.indicaCarregandoBateria = 0;
/*     */     
/* 154 */     if ((this.carregandoBateria) && (!this.carregandoBateriaAntes)) {
/* 155 */       this.indicaCarregandoBateria = 1;
/*     */     }
/* 157 */     if ((!this.carregandoBateria) && (this.carregandoBateriaAntes)) {
/* 158 */       this.indicaCarregandoBateria = 2;
/*     */     }
/* 160 */     this.carregandoBateriaAntes = this.carregandoBateria;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */     this.indicaBateriaEmUso = 0;
/*     */     
/* 168 */     if ((this.bateriaEmUso) && (!this.bateriaEmUsoAntes)) {
/* 169 */       this.indicaBateriaEmUso = 1;
/*     */     }
/* 171 */     if ((!this.bateriaEmUso) && (this.bateriaEmUsoAntes)) {
/* 172 */       this.indicaBateriaEmUso = 2;
/*     */     }
/* 174 */     this.bateriaEmUsoAntes = this.bateriaEmUso;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */     this.indicaFalhaRede = 0;
/*     */     
/* 182 */     if ((this.falhaRede) && (!this.falhaRedeAntes)) {
/* 183 */       this.indicaFalhaRede = 2;
/*     */     }
/* 185 */     if ((!this.falhaRede) && (this.falhaRedeAntes)) {
/* 186 */       this.indicaFalhaRede = 1;
/*     */     }
/* 188 */     this.falhaRedeAntes = this.falhaRede;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */     this.indicaModoInversor = 0;
/*     */     
/* 196 */     if ((this.modoInversor) && (!this.modoInversorAntes)) {
/* 197 */       this.indicaModoInversor = 1;
/*     */     }
/* 199 */     if ((!this.modoInversor) && (this.modoInversorAntes)) {
/* 200 */       this.indicaModoInversor = 2;
/*     */     }
/* 202 */     this.modoInversorAntes = this.modoInversor;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */     if ((this.bateriaBaixa) && (!this.bateriaBaixaAntes)) {
/* 209 */       this.indicaBateriaBaixa = 1;
/*     */     }
/* 211 */     if ((!this.bateriaBaixa) && (this.bateriaBaixaAntes)) {
/* 212 */       this.indicaBateriaBaixa = 2;
/*     */     }
/* 214 */     this.bateriaBaixaAntes = this.bateriaBaixa;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 220 */     this.indicaBateriaCritica = 0;
/*     */     
/* 222 */     if ((this.bateriaCritica) && (!this.bateriaCriticaAntes)) {
/* 223 */       this.indicaBateriaCritica = 1;
/*     */     }
/* 225 */     if ((!this.bateriaCritica) && (this.bateriaCriticaAntes)) {
/* 226 */       this.indicaBateriaCritica = 2;
/*     */     }
/* 228 */     this.bateriaCriticaAntes = this.bateriaCritica;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 234 */     if ((this.temperaturaElevada) && (!this.temperaturaElevadaAntes)) {
/* 235 */       this.indicaTemperaturaElevada = 1;
/*     */     }
/* 237 */     if ((!this.temperaturaElevada) && (this.temperaturaElevadaAntes)) {
/* 238 */       this.indicaTemperaturaElevada = 2;
/*     */     }
/* 240 */     this.temperaturaElevadaAntes = this.temperaturaElevada;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */     this.indicaSuperAquecimento = 0;
/*     */     
/* 248 */     if ((this.superAquecimento) && (!this.superAquecimentoAntes)) {
/* 249 */       this.indicaSuperAquecimento = 1;
/*     */     }
/* 251 */     if ((!this.superAquecimento) && (this.superAquecimentoAntes)) {
/* 252 */       this.indicaSuperAquecimento = 2;
/*     */     }
/* 254 */     this.superAquecimentoAntes = this.superAquecimento;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 260 */     if ((this.cargaElevada) && (!this.cargaElevadaAntes)) {
/* 261 */       this.indicaCargaElevada = 1;
/*     */     }
/* 263 */     if ((!this.cargaElevada) && (this.cargaElevadaAntes)) {
/* 264 */       this.indicaCargaElevada = 2;
/*     */     }
/* 266 */     this.cargaElevadaAntes = this.cargaElevada;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 272 */     this.indicaSobrecarga = 0;
/*     */     
/* 274 */     if ((this.sobrecarga) && (!this.sobrecargaAntes)) {
/* 275 */       this.indicaSobrecarga = 1;
/*     */     }
/* 277 */     if ((!this.sobrecarga) && (this.sobrecargaAntes)) {
/* 278 */       this.indicaSobrecarga = 2;
/*     */     }
/* 280 */     this.sobrecargaAntes = this.sobrecarga;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 286 */     this.indicaBypass = 0;
/*     */     
/* 288 */     if ((this.modoBypass) && (!this.modoBypassAntes)) {
/* 289 */       this.indicaBypass = 1;
/*     */     }
/* 291 */     if ((!this.modoBypass) && (this.modoBypassAntes)) {
/* 292 */       this.indicaBypass = 2;
/*     */     }
/* 294 */     this.modoBypassAntes = this.modoBypass;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\TrataStatusAlertas.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */