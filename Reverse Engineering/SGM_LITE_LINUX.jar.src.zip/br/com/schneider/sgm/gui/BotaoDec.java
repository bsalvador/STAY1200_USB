/*    */ package br.com.schneider.sgm.gui;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BotaoDec
/*    */   extends JButton
/*    */ {
/*    */   private static final long serialVersionUID = 7549335571910798101L;
/*    */   
/*    */   public BotaoDec(String caminhoNormal, String caminhoPressionado, int largura, int altura)
/*    */   {
/* 32 */     super(new ImageIcon(caminhoNormal));
/* 33 */     setPressedIcon(new ImageIcon(caminhoPressionado));
/* 34 */     setPreferredSize(new Dimension(largura, altura));
/* 35 */     setContentAreaFilled(false);
/* 36 */     setBorder(null);
/* 37 */     setFocusPainted(false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BotaoDec()
/*    */   {
/* 48 */     setContentAreaFilled(false);
/* 49 */     setBorder(null);
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\BotaoDec.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */