/*      */ package br.com.schneider.sgm.gui;
/*      */ 
/*      */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.util.Arrays;
/*      */ import java.util.Calendar;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JSpinner;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.SpinnerListModel;
/*      */ import javax.swing.SpinnerModel;
/*      */ import javax.swing.border.SoftBevelBorder;
/*      */ import javax.swing.event.CaretEvent;
/*      */ import javax.swing.event.CaretListener;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PainelComando
/*      */   extends JPanel
/*      */ {
/*      */   private static final long serialVersionUID = 6771109895796759698L;
/*      */   private JPanel panelAgendamento;
/*      */   private JPanel panelOpcoes;
/*      */   private JButton btnAgendar;
/*      */   private JButton btnAgendar2;
/*      */   private JButton btnShutdown;
/*      */   private JButton btnShutdownReligamento;
/*      */   private JCheckBox cbAutonomia;
/*      */   private JCheckBox cbDomingo;
/*      */   private JCheckBox cbSegunda;
/*      */   private JCheckBox cbTerca;
/*      */   private JCheckBox cbQuarta;
/*      */   private JCheckBox cbQuinta;
/*      */   private JCheckBox cbSexta;
/*      */   private JCheckBox cbSabado;
/*      */   private JCheckBox cbTodos;
/*      */   private JCheckBox cbTempoFalha;
/*      */   private JLabel labelAutonomia;
/*      */   private JLabel labelDesligar;
/*      */   private JLabel labelDoisPontosDesligar;
/*      */   private JLabel labelDoisPontosLigar;
/*      */   private JLabel labelLigar;
/*      */   private JLabel labelTempoFalha1;
/*      */   private JLabel labelTempoFalha2;
/*      */   private JSpinner spinnerHoraDesligar;
/*      */   private JSpinner spinnerHoraLigar;
/*      */   private JSpinner spinnerMinutoDesligar;
/*      */   private JSpinner spinnerMinutoLigar;
/*      */   private JTextField textFieldTempoFalha;
/*      */   private JTextField textFieldAutonomia;
/*      */   private JLabel labelAutonomia2;
/*      */   private final String[] minuto;
/*      */   private final String[] hora;
/*      */   private boolean[] auxCb;
/*      */   private int[] dados;
/*      */   private String agendamentoTitulo;
/*      */   private String opcoesTitulo;
/*      */   private boolean flag;
/*      */   private String caminhoFiguras;
/*      */   private InterfaceGrafica interfaceGrafica;
/*      */   private boolean flagTodos;
/*      */   
/*      */   public PainelComando(String caminhoFiguras, InterfaceGrafica gui)
/*      */   {
/*  265 */     String[] minuto = { "-1", "00", "01", "02", "03", "04", "05", "06", 
/*  266 */       "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", 
/*  267 */       "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", 
/*  268 */       "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", 
/*  269 */       "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", 
/*  270 */       "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", 
/*  271 */       "57", "58", "59", "60" };
/*  272 */     this.minuto = minuto;
/*      */     
/*  274 */     String[] hora = { "-1", "00", "01", "02", "03", "04", "05", "06", "07", 
/*  275 */       "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", 
/*  276 */       "18", "19", "20", "21", "22", "23", "24" };
/*  277 */     this.hora = hora;
/*      */     
/*  279 */     int[] aux = new int[2];
/*  280 */     this.dados = aux;
/*  281 */     this.auxCb = new boolean[2];
/*  282 */     this.auxCb[0] = false;
/*  283 */     this.auxCb[1] = false;
/*  284 */     this.caminhoFiguras = caminhoFiguras;
/*  285 */     this.interfaceGrafica = gui;
/*  286 */     initComponents();
/*  287 */     addListeners();
/*  288 */     disableTextFieldTempoFalha();
/*  289 */     disableTextFieldAutonomia();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setAllCB(boolean b)
/*      */   {
/*  300 */     if (!this.flagTodos) {
/*  301 */       this.cbDomingo.setSelected(b);
/*  302 */       this.cbSegunda.setSelected(b);
/*  303 */       this.cbTerca.setSelected(b);
/*  304 */       this.cbQuarta.setSelected(b);
/*  305 */       this.cbQuinta.setSelected(b);
/*  306 */       this.cbSexta.setSelected(b);
/*  307 */       this.cbSabado.setSelected(b);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void addListeners()
/*      */   {
/*  315 */     this.cbTodos.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  317 */         if (PainelComando.this.cbTodos.isSelected()) {
/*  318 */           PainelComando.this.setAllCB(true);
/*      */         } else
/*  320 */           PainelComando.this.setAllCB(false);
/*  321 */         PainelComando.this.flag = true;
/*  322 */         PainelComando.this.flagTodos = false;
/*      */       }
/*      */       
/*  325 */     });
/*  326 */     this.cbDomingo.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  328 */         PainelComando.this.flag = true;
/*  329 */         if ((!PainelComando.this.cbDomingo.isSelected()) && 
/*  330 */           (PainelComando.this.cbTodos.isSelected())) {
/*  331 */           PainelComando.this.flagTodos = true;
/*  332 */           PainelComando.this.cbTodos.setSelected(false);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  337 */     });
/*  338 */     this.cbSegunda.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  340 */         PainelComando.this.flag = true;
/*  341 */         if ((!PainelComando.this.cbSegunda.isSelected()) && 
/*  342 */           (PainelComando.this.cbTodos.isSelected())) {
/*  343 */           PainelComando.this.flagTodos = true;
/*  344 */           PainelComando.this.cbTodos.setSelected(false);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  349 */     });
/*  350 */     this.cbTerca.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  352 */         PainelComando.this.flag = true;
/*  353 */         if ((!PainelComando.this.cbTerca.isSelected()) && 
/*  354 */           (PainelComando.this.cbTodos.isSelected())) {
/*  355 */           PainelComando.this.flagTodos = true;
/*  356 */           PainelComando.this.cbTodos.setSelected(false);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  361 */     });
/*  362 */     this.cbQuarta.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  364 */         PainelComando.this.flag = true;
/*  365 */         if ((!PainelComando.this.cbQuarta.isSelected()) && 
/*  366 */           (PainelComando.this.cbTodos.isSelected())) {
/*  367 */           PainelComando.this.flagTodos = true;
/*  368 */           PainelComando.this.cbTodos.setSelected(false);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  373 */     });
/*  374 */     this.cbQuinta.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  376 */         PainelComando.this.flag = true;
/*  377 */         if ((!PainelComando.this.cbQuinta.isSelected()) && 
/*  378 */           (PainelComando.this.cbTodos.isSelected())) {
/*  379 */           PainelComando.this.flagTodos = true;
/*  380 */           PainelComando.this.cbTodos.setSelected(false);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  385 */     });
/*  386 */     this.cbSexta.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  388 */         PainelComando.this.flag = true;
/*  389 */         if ((!PainelComando.this.cbSexta.isSelected()) && 
/*  390 */           (PainelComando.this.cbTodos.isSelected())) {
/*  391 */           PainelComando.this.flagTodos = true;
/*  392 */           PainelComando.this.cbTodos.setSelected(false);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  397 */     });
/*  398 */     this.cbSabado.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  400 */         PainelComando.this.flag = true;
/*  401 */         if ((!PainelComando.this.cbSabado.isSelected()) && 
/*  402 */           (PainelComando.this.cbTodos.isSelected())) {
/*  403 */           PainelComando.this.flagTodos = true;
/*  404 */           PainelComando.this.cbTodos.setSelected(false);
/*      */         }
/*      */         
/*      */       }
/*  408 */     });
/*  409 */     this.spinnerMinutoLigar.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent e) {
/*  411 */         SpinnerModel modelo = PainelComando.this.spinnerMinutoLigar.getModel();
/*  412 */         String aux = (String)modelo.getValue();
/*  413 */         Integer aux2 = new Integer(aux);
/*  414 */         int i = aux2.intValue();
/*  415 */         if (i == 60) {
/*  416 */           modelo.setValue("00");
/*      */         }
/*  418 */         if (i == -1)
/*  419 */           modelo.setValue("59");
/*  420 */         PainelComando.this.flag = true;
/*      */       }
/*      */       
/*  423 */     });
/*  424 */     this.spinnerMinutoDesligar.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent e) {
/*  426 */         SpinnerModel modelo = PainelComando.this.spinnerMinutoDesligar.getModel();
/*  427 */         String aux = (String)modelo.getValue();
/*  428 */         Integer aux2 = new Integer(aux);
/*  429 */         int i = aux2.intValue();
/*  430 */         if (i == 60)
/*  431 */           modelo.setValue("00");
/*  432 */         if (i == -1)
/*  433 */           modelo.setValue("59");
/*  434 */         PainelComando.this.flag = true;
/*      */       }
/*      */       
/*  437 */     });
/*  438 */     this.spinnerHoraDesligar.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent e) {
/*  440 */         SpinnerModel modelo = PainelComando.this.spinnerHoraDesligar.getModel();
/*  441 */         String aux = (String)modelo.getValue();
/*  442 */         Integer aux2 = new Integer(aux);
/*  443 */         int i = aux2.intValue();
/*  444 */         if (i == 24)
/*  445 */           modelo.setValue("00");
/*  446 */         if (i == -1)
/*  447 */           modelo.setValue("23");
/*  448 */         PainelComando.this.flag = true;
/*      */       }
/*      */       
/*  451 */     });
/*  452 */     this.spinnerHoraLigar.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent e) {
/*  454 */         SpinnerModel modelo = PainelComando.this.spinnerHoraLigar.getModel();
/*  455 */         String aux = (String)modelo.getValue();
/*  456 */         Integer aux2 = new Integer(aux);
/*  457 */         int i = aux2.intValue();
/*  458 */         if (i == 24)
/*  459 */           modelo.setValue("00");
/*  460 */         if (i == -1)
/*  461 */           modelo.setValue("23");
/*  462 */         PainelComando.this.flag = true;
/*      */       }
/*      */       
/*  465 */     });
/*  466 */     this.btnAgendar.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent e) {
/*  468 */         Calendar calendar = Calendar.getInstance();
/*  469 */         calendar.setLenient(true);
/*  470 */         Calendar compare = Calendar.getInstance();
/*      */         
/*  472 */         compare.set(calendar.get(1), calendar
/*  473 */           .get(2), calendar
/*  474 */           .get(5), PainelComando.this.getHoraDesligar(), 
/*  475 */           PainelComando.this.getMinutoDesligar());
/*      */         
/*  477 */         calendar.add(12, 5);
/*      */         
/*  479 */         int result = calendar.compareTo(compare);
/*  480 */         if (result <= 0)
/*      */         {
/*      */ 
/*  483 */           PainelComando.this.flag = false;
/*      */         }
/*      */       }
/*  486 */     });
/*  487 */     this.btnAgendar2.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent e) {
/*  489 */         PainelComando.this.flag = false;
/*      */       }
/*      */       
/*  492 */     });
/*  493 */     this.textFieldAutonomia.addCaretListener(new CaretListener() {
/*      */       public void caretUpdate(CaretEvent e) {
/*  495 */         if (PainelComando.this.cbAutonomia.isSelected()) {
/*  496 */           PainelComando.this.flag = true;
/*      */         }
/*      */       }
/*  499 */     });
/*  500 */     this.textFieldTempoFalha.addCaretListener(new CaretListener() {
/*      */       public void caretUpdate(CaretEvent e) {
/*  502 */         if (PainelComando.this.cbTempoFalha.isSelected()) {
/*  503 */           PainelComando.this.flag = true;
/*      */         }
/*      */       }
/*  506 */     });
/*  507 */     this.cbTempoFalha.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  509 */         if (!PainelComando.this.cbTempoFalha.isSelected()) {
/*  510 */           PainelComando.this.disableTextFieldTempoFalha();
/*      */         } else
/*  512 */           PainelComando.this.enableTextFieldTempoFalha();
/*  513 */         PainelComando.this.flag = true;
/*      */       }
/*      */       
/*  516 */     });
/*  517 */     this.cbAutonomia.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent ie) {
/*  519 */         if (!PainelComando.this.cbAutonomia.isSelected()) {
/*  520 */           PainelComando.this.disableTextFieldAutonomia();
/*      */         } else
/*  522 */           PainelComando.this.enableTextFieldAutonomia();
/*  523 */         PainelComando.this.flag = true;
/*      */       }
/*      */       
/*  526 */     });
/*  527 */     this.btnAgendar.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  529 */         PainelComando.this.flag = false;
/*      */       }
/*      */       
/*  532 */     });
/*  533 */     this.btnAgendar2.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent ae) {
/*  535 */         PainelComando.this.flag = false;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPainelComandoChanged()
/*      */   {
/*  546 */     if (this.flag) {
/*  547 */       return true;
/*      */     }
/*  549 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void painelComandosChanged()
/*      */   {
/*  556 */     PopUp pop = new PopUp(
/*  557 */       this.caminhoFiguras + "PopUp.png", 
/*  558 */       this.caminhoFiguras, 
/*  559 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  560 */       "Deseja_confirmar_as_modificacoes_nos_comandos_do_UPS"), 
/*  561 */       this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, false);
/*  562 */     pop.getBtnYes().addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent e) {
/*  564 */         PainelComando.this.getBtnAgendar().doClick();
/*  565 */         PainelComando.this.getBtnAgendar2().doClick();
/*      */       }
/*  567 */     });
/*  568 */     pop.getBtnNo().addActionListener(new ActionListener()
/*      */     {
/*      */       public void actionPerformed(ActionEvent e) {
/*  571 */         PainelComando.this.flag = false;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void disableTextFieldTempoFalha()
/*      */   {
/*  580 */     this.textFieldTempoFalha.setBackground(new Color(230, 230, 230));
/*  581 */     this.textFieldTempoFalha.setEnabled(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void enableTextFieldTempoFalha()
/*      */   {
/*  588 */     this.textFieldTempoFalha.setBackground(Color.WHITE);
/*  589 */     this.textFieldTempoFalha.setEnabled(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void disableTextFieldAutonomia()
/*      */   {
/*  596 */     this.textFieldAutonomia.setBackground(new Color(230, 230, 230));
/*  597 */     this.textFieldAutonomia.setEnabled(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void enableTextFieldAutonomia()
/*      */   {
/*  604 */     this.textFieldAutonomia.setBackground(Color.WHITE);
/*  605 */     this.textFieldAutonomia.setEnabled(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void validarIdioma()
/*      */   {
/*  612 */     this.agendamentoTitulo = ResourceBundle.getBundle(Idioma.getIdioma())
/*  613 */       .getString("AGENDAMENTO");
/*  614 */     this.opcoesTitulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  615 */       "OPCOES_DE_SHUTDOWN");
/*  616 */     this.cbDomingo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  617 */       .getString("DOMINGO"));
/*  618 */     this.cbSegunda.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  619 */       .getString("SEGUNDA"));
/*  620 */     this.cbTerca.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  621 */       "TERCA"));
/*  622 */     this.cbQuarta.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  623 */       .getString("QUARTA"));
/*  624 */     this.cbQuinta.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  625 */       .getString("QUINTA"));
/*  626 */     this.cbSexta.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  627 */       "SEXTA"));
/*  628 */     this.cbSabado.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  629 */       .getString("SABADO"));
/*  630 */     this.cbTodos.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  631 */       "TODOS"));
/*  632 */     this.labelLigar.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  633 */       .getString("HORA_DE_LIGAR"));
/*  634 */     this.labelDesligar.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  635 */       .getString("HORA_DE_DESLIGAR"));
/*  636 */     this.labelAutonomia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  637 */       .getString("SHUTDOWN"));
/*  638 */     this.labelAutonomia2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  639 */       .getString("min_ANTES_DO_FIM_DE_AUTONOMIA_DA_BATERIA"));
/*  640 */     this.labelTempoFalha1.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  641 */       .getString("SHUTDOWN_APOS"));
/*  642 */     this.labelTempoFalha2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  643 */       .getString("min_DE_FALHA_NA_REDE_ELETRICA"));
/*  644 */     this.btnAgendar.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  645 */       .getString("AGENDAR"));
/*  646 */     this.btnAgendar2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  647 */       .getString("AGENDAR"));
/*  648 */     this.btnShutdown.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  649 */       .getString("SHUTDOWN_IMEDIATO"));
/*  650 */     this.btnShutdownReligamento.setText(ResourceBundle.getBundle(
/*  651 */       Idioma.getIdioma()).getString("SHUTDOWN_COM_RELIGAMENTO"));
/*  652 */     this.panelAgendamento.setBorder(BorderFactory.createTitledBorder(
/*  653 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 
/*  654 */       170)), this.agendamentoTitulo));
/*  655 */     this.panelOpcoes.setBorder(BorderFactory.createTitledBorder(
/*  656 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 170)), 
/*  657 */       this.opcoesTitulo));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void initComponents()
/*      */   {
/*  664 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  665 */     Font fonte12N = new Font("Trebuchet", 1, 12);
/*  666 */     Font fonte12 = new Font("Trebuchet", 0, 12);
/*      */     
/*  668 */     this.panelAgendamento = new JPanel();
/*  669 */     this.cbDomingo = new JCheckBox();
/*  670 */     this.cbSegunda = new JCheckBox();
/*  671 */     this.cbTerca = new JCheckBox();
/*  672 */     this.cbQuarta = new JCheckBox();
/*  673 */     this.cbQuinta = new JCheckBox();
/*  674 */     this.cbSexta = new JCheckBox();
/*  675 */     this.cbSabado = new JCheckBox();
/*  676 */     this.labelLigar = new JLabel();
/*  677 */     this.labelDesligar = new JLabel();
/*  678 */     this.spinnerHoraLigar = new JSpinner();
/*  679 */     this.spinnerMinutoLigar = new JSpinner();
/*  680 */     this.spinnerHoraDesligar = new JSpinner();
/*  681 */     this.spinnerMinutoDesligar = new JSpinner();
/*  682 */     this.labelDoisPontosDesligar = new JLabel();
/*  683 */     this.labelDoisPontosLigar = new JLabel();
/*  684 */     this.cbTodos = new JCheckBox();
/*  685 */     this.btnAgendar = new JButton();
/*  686 */     this.btnShutdown = new JButton();
/*  687 */     this.btnShutdownReligamento = new JButton();
/*  688 */     this.panelOpcoes = new JPanel();
/*  689 */     this.cbAutonomia = new JCheckBox();
/*  690 */     this.labelAutonomia = new JLabel();
/*  691 */     this.labelAutonomia2 = new JLabel();
/*  692 */     this.cbTempoFalha = new JCheckBox();
/*  693 */     this.labelTempoFalha1 = new JLabel();
/*  694 */     this.labelTempoFalha2 = new JLabel();
/*      */     
/*  696 */     this.textFieldTempoFalha = new JTextField();
/*  697 */     this.textFieldAutonomia = new JTextField();
/*  698 */     this.agendamentoTitulo = ResourceBundle.getBundle(Idioma.getIdioma())
/*  699 */       .getString("AGENDAMENTO");
/*  700 */     this.opcoesTitulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  701 */       "OPCOES_DE_SHUTDOWN");
/*  702 */     this.btnAgendar2 = new JButton();
/*      */     
/*      */ 
/*      */ 
/*  706 */     setLayout(new GridBagLayout());
/*  707 */     setMaximumSize(new Dimension(515, 315));
/*  708 */     setMinimumSize(new Dimension(515, 315));
/*  709 */     setOpaque(false);
/*  710 */     setPreferredSize(new Dimension(515, 315));
/*      */     
/*      */ 
/*  713 */     Dimension agendamento = new Dimension(515, 150);
/*  714 */     this.panelAgendamento.setLayout(new GridBagLayout());
/*  715 */     this.panelAgendamento.setBorder(BorderFactory.createTitledBorder(
/*  716 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 
/*  717 */       170)), this.agendamentoTitulo));
/*  718 */     this.panelAgendamento.setMaximumSize(agendamento);
/*  719 */     this.panelAgendamento.setMinimumSize(agendamento);
/*  720 */     this.panelAgendamento.setPreferredSize(agendamento);
/*  721 */     this.panelAgendamento.setOpaque(false);
/*  722 */     gridBagConstraints.gridwidth = 2;
/*  723 */     add(this.panelAgendamento, gridBagConstraints);
/*      */     
/*      */ 
/*  726 */     this.panelOpcoes.setLayout(new GridBagLayout());
/*  727 */     this.panelOpcoes.setBorder(BorderFactory.createTitledBorder(
/*  728 */       BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(170, 170, 170)), 
/*  729 */       this.opcoesTitulo));
/*  730 */     this.panelOpcoes.setMaximumSize(new Dimension(515, 120));
/*  731 */     this.panelOpcoes.setMinimumSize(new Dimension(515, 120));
/*  732 */     this.panelOpcoes.setOpaque(false);
/*  733 */     this.panelOpcoes.setPreferredSize(new Dimension(515, 120));
/*  734 */     gridBagConstraints.gridx = 0;
/*  735 */     gridBagConstraints.gridy = 1;
/*  736 */     gridBagConstraints.gridwidth = 2;
/*  737 */     add(this.panelOpcoes, gridBagConstraints);
/*      */     
/*      */ 
/*  740 */     this.cbDomingo.setFont(fonte12N);
/*  741 */     this.cbDomingo.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  742 */       .getString("DOMINGO"));
/*  743 */     this.cbDomingo.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  744 */     this.cbDomingo.setContentAreaFilled(false);
/*  745 */     this.cbDomingo.setFocusPainted(false);
/*  746 */     this.cbDomingo.setMargin(new Insets(0, 0, 0, 0));
/*  747 */     gridBagConstraints.gridwidth = 1;
/*  748 */     gridBagConstraints.gridx = 2;
/*  749 */     gridBagConstraints.gridy = 1;
/*  750 */     gridBagConstraints.fill = 2;
/*  751 */     gridBagConstraints.insets = new Insets(0, 30, 2, 0);
/*  752 */     this.panelAgendamento.add(this.cbDomingo, gridBagConstraints);
/*      */     
/*      */ 
/*  755 */     this.cbSegunda.setFont(fonte12N);
/*  756 */     this.cbSegunda.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  757 */       .getString("SEGUNDA"));
/*  758 */     this.cbSegunda.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  759 */     this.cbSegunda.setContentAreaFilled(false);
/*  760 */     this.cbSegunda.setFocusPainted(false);
/*  761 */     this.cbSegunda.setMargin(new Insets(0, 0, 0, 0));
/*  762 */     gridBagConstraints.gridx = 4;
/*  763 */     gridBagConstraints.gridy = 1;
/*  764 */     gridBagConstraints.fill = 2;
/*  765 */     gridBagConstraints.insets = new Insets(0, 10, 2, 0);
/*  766 */     this.panelAgendamento.add(this.cbSegunda, gridBagConstraints);
/*      */     
/*      */ 
/*  769 */     this.cbTerca.setFont(fonte12N);
/*  770 */     this.cbTerca.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  771 */       "TERCA"));
/*  772 */     this.cbTerca.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  773 */     this.cbTerca.setContentAreaFilled(false);
/*  774 */     this.cbTerca.setFocusPainted(false);
/*  775 */     this.cbTerca.setMargin(new Insets(0, 0, 0, 0));
/*  776 */     gridBagConstraints.gridx = 6;
/*  777 */     gridBagConstraints.gridy = 1;
/*  778 */     gridBagConstraints.fill = 2;
/*  779 */     gridBagConstraints.insets = new Insets(0, 10, 2, 0);
/*  780 */     this.panelAgendamento.add(this.cbTerca, gridBagConstraints);
/*      */     
/*      */ 
/*  783 */     this.cbQuarta.setFont(fonte12N);
/*  784 */     this.cbQuarta.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  785 */       .getString("QUARTA"));
/*  786 */     this.cbQuarta.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  787 */     this.cbQuarta.setContentAreaFilled(false);
/*  788 */     this.cbQuarta.setFocusPainted(false);
/*  789 */     this.cbQuarta.setMargin(new Insets(0, 0, 0, 0));
/*  790 */     gridBagConstraints.gridx = 0;
/*  791 */     gridBagConstraints.gridy = 3;
/*  792 */     gridBagConstraints.fill = 2;
/*  793 */     gridBagConstraints.insets = new Insets(0, 10, 10, 0);
/*  794 */     this.panelAgendamento.add(this.cbQuarta, gridBagConstraints);
/*      */     
/*      */ 
/*  797 */     this.cbQuinta.setFont(fonte12N);
/*  798 */     this.cbQuinta.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  799 */       .getString("QUINTA"));
/*  800 */     this.cbQuinta.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  801 */     this.cbQuinta.setContentAreaFilled(false);
/*  802 */     this.cbQuinta.setFocusPainted(false);
/*  803 */     this.cbQuinta.setMargin(new Insets(0, 0, 0, 0));
/*  804 */     gridBagConstraints.gridx = 2;
/*  805 */     gridBagConstraints.gridy = 3;
/*  806 */     gridBagConstraints.fill = 2;
/*  807 */     gridBagConstraints.insets = new Insets(0, 30, 10, 0);
/*  808 */     this.panelAgendamento.add(this.cbQuinta, gridBagConstraints);
/*      */     
/*      */ 
/*  811 */     this.cbSexta.setFont(fonte12N);
/*  812 */     this.cbSexta.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  813 */       "SEXTA"));
/*  814 */     this.cbSexta.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  815 */     this.cbSexta.setContentAreaFilled(false);
/*  816 */     this.cbSexta.setFocusPainted(false);
/*  817 */     this.cbSexta.setMargin(new Insets(0, 0, 0, 0));
/*  818 */     gridBagConstraints.gridx = 4;
/*  819 */     gridBagConstraints.gridy = 3;
/*  820 */     gridBagConstraints.fill = 2;
/*  821 */     gridBagConstraints.insets = new Insets(0, 10, 10, 0);
/*  822 */     this.panelAgendamento.add(this.cbSexta, gridBagConstraints);
/*      */     
/*      */ 
/*  825 */     this.cbSabado.setFont(fonte12N);
/*  826 */     this.cbSabado.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  827 */       .getString("SABADO"));
/*  828 */     this.cbSabado.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  829 */     this.cbSabado.setContentAreaFilled(false);
/*  830 */     this.cbSabado.setFocusPainted(false);
/*  831 */     this.cbSabado.setMargin(new Insets(0, 0, 0, 0));
/*  832 */     gridBagConstraints.gridx = 6;
/*  833 */     gridBagConstraints.gridy = 3;
/*  834 */     gridBagConstraints.fill = 2;
/*  835 */     gridBagConstraints.insets = new Insets(0, 10, 10, 0);
/*  836 */     this.panelAgendamento.add(this.cbSabado, gridBagConstraints);
/*      */     
/*      */ 
/*  839 */     this.cbTodos.setFont(fonte12N);
/*  840 */     this.cbTodos.setText(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  841 */       "TODOS"));
/*  842 */     this.cbTodos.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/*  843 */     this.cbTodos.setContentAreaFilled(false);
/*  844 */     this.cbTodos.setFocusPainted(false);
/*  845 */     this.cbTodos.setMargin(new Insets(0, 0, 0, 0));
/*  846 */     gridBagConstraints.gridx = 0;
/*  847 */     gridBagConstraints.gridy = 1;
/*  848 */     gridBagConstraints.fill = 2;
/*  849 */     gridBagConstraints.insets = new Insets(0, 10, 2, 0);
/*  850 */     this.panelAgendamento.add(this.cbTodos, gridBagConstraints);
/*      */     
/*      */ 
/*  853 */     this.labelLigar.setFont(fonte12N);
/*  854 */     this.labelLigar.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  855 */       .getString("HORA_DE_LIGAR"));
/*  856 */     gridBagConstraints.gridx = 0;
/*  857 */     gridBagConstraints.gridy = 4;
/*  858 */     gridBagConstraints.gridwidth = 3;
/*  859 */     gridBagConstraints.fill = 2;
/*  860 */     gridBagConstraints.insets = new Insets(0, 80, 0, 0);
/*  861 */     this.panelAgendamento.add(this.labelLigar, gridBagConstraints);
/*      */     
/*      */ 
/*  864 */     this.labelDesligar.setFont(fonte12N);
/*  865 */     this.labelDesligar.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  866 */       .getString("HORA_DE_DESLIGAR"));
/*  867 */     gridBagConstraints.gridx = 0;
/*  868 */     gridBagConstraints.gridy = 6;
/*  869 */     gridBagConstraints.gridwidth = 3;
/*  870 */     gridBagConstraints.fill = 2;
/*  871 */     gridBagConstraints.insets = new Insets(5, 80, 0, 0);
/*  872 */     this.panelAgendamento.add(this.labelDesligar, gridBagConstraints);
/*      */     
/*      */ 
/*  875 */     this.labelDoisPontosDesligar.setFont(fonte12N);
/*  876 */     this.labelDoisPontosDesligar.setText(":");
/*  877 */     gridBagConstraints.gridwidth = 1;
/*  878 */     gridBagConstraints.gridx = 5;
/*  879 */     gridBagConstraints.gridy = 6;
/*  880 */     gridBagConstraints.fill = 2;
/*  881 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/*  882 */     this.panelAgendamento.add(this.labelDoisPontosDesligar, gridBagConstraints);
/*      */     
/*      */ 
/*  885 */     this.labelDoisPontosLigar.setFont(fonte12N);
/*  886 */     this.labelDoisPontosLigar.setText(":");
/*  887 */     gridBagConstraints.gridx = 5;
/*  888 */     gridBagConstraints.gridy = 4;
/*  889 */     gridBagConstraints.gridwidth = 0;
/*  890 */     gridBagConstraints.fill = 2;
/*  891 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/*  892 */     this.panelAgendamento.add(this.labelDoisPontosLigar, gridBagConstraints);
/*      */     
/*      */ 
/*  895 */     this.labelAutonomia.setFont(fonte12);
/*  896 */     this.labelAutonomia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  897 */       .getString("SHUTDOWN"));
/*  898 */     gridBagConstraints.gridx = 1;
/*  899 */     gridBagConstraints.gridy = 0;
/*  900 */     gridBagConstraints.gridwidth = 1;
/*  901 */     gridBagConstraints.fill = 2;
/*  902 */     gridBagConstraints.anchor = 11;
/*  903 */     this.panelOpcoes.add(this.labelAutonomia, gridBagConstraints);
/*      */     
/*      */ 
/*  906 */     this.labelAutonomia2.setFont(fonte12);
/*  907 */     this.labelAutonomia2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  908 */       .getString("min_ANTES_DO_FIM_DE_AUTONOMIA_DA_BATERIA"));
/*  909 */     gridBagConstraints.insets = new Insets(0, 0, 0, 60);
/*  910 */     gridBagConstraints.gridx = 3;
/*  911 */     gridBagConstraints.gridy = 0;
/*  912 */     gridBagConstraints.gridwidth = 4;
/*  913 */     gridBagConstraints.fill = 0;
/*  914 */     gridBagConstraints.anchor = 11;
/*  915 */     this.panelOpcoes.add(this.labelAutonomia2, gridBagConstraints);
/*      */     
/*      */ 
/*  918 */     this.labelTempoFalha1.setFont(fonte12);
/*  919 */     this.labelTempoFalha1.setFont(new Font("Dialog", 0, 12));
/*  920 */     this.labelTempoFalha1.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  921 */       .getString("SHUTDOWN_APOS"));
/*  922 */     gridBagConstraints.gridx = 1;
/*  923 */     gridBagConstraints.gridy = 2;
/*  924 */     gridBagConstraints.gridwidth = 1;
/*  925 */     gridBagConstraints.fill = 0;
/*  926 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/*  927 */     gridBagConstraints.anchor = 11;
/*  928 */     this.panelOpcoes.add(this.labelTempoFalha1, gridBagConstraints);
/*      */     
/*      */ 
/*  931 */     this.textFieldAutonomia
/*  932 */       .setBorder(new SoftBevelBorder(1, new Color(
/*  933 */       204, 204, 204), new Color(204, 204, 204), null, null));
/*  934 */     this.textFieldAutonomia.setMaximumSize(new Dimension(40, 19));
/*  935 */     this.textFieldAutonomia.setMinimumSize(new Dimension(40, 19));
/*  936 */     this.textFieldAutonomia.setPreferredSize(new Dimension(40, 19));
/*  937 */     gridBagConstraints.gridx = 2;
/*  938 */     gridBagConstraints.gridy = 0;
/*  939 */     gridBagConstraints.fill = 0;
/*  940 */     gridBagConstraints.anchor = 18;
/*  941 */     gridBagConstraints.insets = new Insets(0, 5, 0, 0);
/*  942 */     this.panelOpcoes.add(this.textFieldAutonomia, gridBagConstraints);
/*      */     
/*      */ 
/*  945 */     this.labelTempoFalha2.setFont(fonte12);
/*  946 */     this.labelTempoFalha2.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/*  947 */       .getString("min_DE_FALHA_NA_REDE_ELETRICA"));
/*  948 */     this.labelTempoFalha2.setText("min DE FALHA NA REDE ELÉTRICA");
/*  949 */     gridBagConstraints.fill = 0;
/*  950 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/*  951 */     gridBagConstraints.gridx = 3;
/*  952 */     gridBagConstraints.gridy = 2;
/*  953 */     gridBagConstraints.gridwidth = 3;
/*  954 */     gridBagConstraints.anchor = 18;
/*  955 */     this.panelOpcoes.add(this.labelTempoFalha2, gridBagConstraints);
/*      */     
/*      */ 
/*  958 */     this.spinnerHoraLigar.setFont(fonte12N);
/*  959 */     this.spinnerHoraLigar.setMaximumSize(new Dimension(40, 20));
/*  960 */     this.spinnerHoraLigar.setMinimumSize(new Dimension(40, 20));
/*  961 */     this.spinnerHoraLigar.setPreferredSize(new Dimension(40, 20));
/*  962 */     gridBagConstraints.fill = 0;
/*  963 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/*  964 */     gridBagConstraints.gridwidth = 1;
/*  965 */     gridBagConstraints.anchor = 10;
/*  966 */     gridBagConstraints.gridx = 4;
/*  967 */     gridBagConstraints.gridy = 4;
/*  968 */     this.panelAgendamento.add(this.spinnerHoraLigar, gridBagConstraints);
/*  969 */     SpinnerModel modeloHoraLigar = new SpinnerListModel(Arrays.asList(this.hora));
/*  970 */     this.spinnerHoraLigar.setModel(modeloHoraLigar);
/*  971 */     modeloHoraLigar.setValue("07");
/*      */     
/*      */ 
/*  974 */     this.spinnerMinutoLigar.setFont(fonte12N);
/*  975 */     this.spinnerMinutoLigar.setMaximumSize(new Dimension(40, 20));
/*  976 */     this.spinnerMinutoLigar.setMinimumSize(new Dimension(40, 20));
/*  977 */     this.spinnerMinutoLigar.setPreferredSize(new Dimension(40, 20));
/*  978 */     gridBagConstraints.fill = 0;
/*  979 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/*  980 */     gridBagConstraints.gridwidth = 1;
/*  981 */     gridBagConstraints.anchor = 10;
/*  982 */     gridBagConstraints.gridx = 6;
/*  983 */     gridBagConstraints.gridy = 4;
/*  984 */     this.panelAgendamento.add(this.spinnerMinutoLigar, gridBagConstraints);
/*  985 */     SpinnerModel modeloMinutoLigar = new SpinnerListModel(
/*  986 */       Arrays.asList(this.minuto));
/*  987 */     this.spinnerMinutoLigar.setModel(modeloMinutoLigar);
/*  988 */     modeloMinutoLigar.setValue("30");
/*      */     
/*      */ 
/*  991 */     this.spinnerHoraDesligar.setFont(fonte12N);
/*  992 */     this.spinnerHoraDesligar.setMaximumSize(new Dimension(40, 20));
/*  993 */     this.spinnerHoraDesligar.setMinimumSize(new Dimension(40, 20));
/*  994 */     this.spinnerHoraDesligar.setPreferredSize(new Dimension(40, 20));
/*  995 */     gridBagConstraints.fill = 0;
/*  996 */     gridBagConstraints.gridwidth = 1;
/*  997 */     gridBagConstraints.anchor = 10;
/*  998 */     gridBagConstraints.gridx = 4;
/*  999 */     gridBagConstraints.gridy = 6;
/* 1000 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/* 1001 */     this.panelAgendamento.add(this.spinnerHoraDesligar, gridBagConstraints);
/* 1002 */     SpinnerModel modeloHoraDesligar = new SpinnerListModel(
/* 1003 */       Arrays.asList(this.hora));
/* 1004 */     this.spinnerHoraDesligar.setModel(modeloHoraDesligar);
/* 1005 */     modeloHoraDesligar.setValue("18");
/*      */     
/*      */ 
/* 1008 */     this.spinnerMinutoDesligar.setFont(fonte12N);
/* 1009 */     this.spinnerMinutoDesligar.setMaximumSize(new Dimension(40, 20));
/* 1010 */     this.spinnerMinutoDesligar.setMinimumSize(new Dimension(40, 20));
/* 1011 */     this.spinnerMinutoDesligar.setPreferredSize(new Dimension(40, 20));
/* 1012 */     gridBagConstraints.fill = 0;
/* 1013 */     gridBagConstraints.gridwidth = 1;
/* 1014 */     gridBagConstraints.anchor = 10;
/* 1015 */     gridBagConstraints.gridx = 6;
/* 1016 */     gridBagConstraints.gridy = 6;
/* 1017 */     gridBagConstraints.insets = new Insets(5, 0, 0, 0);
/* 1018 */     this.panelAgendamento.add(this.spinnerMinutoDesligar, gridBagConstraints);
/* 1019 */     SpinnerModel modeloMinutoDesligar = new SpinnerListModel(
/* 1020 */       Arrays.asList(this.minuto));
/* 1021 */     this.spinnerMinutoDesligar.setModel(modeloMinutoDesligar);
/* 1022 */     modeloMinutoDesligar.setValue("30");
/*      */     
/*      */ 
/* 1025 */     this.btnAgendar.setFont(fonte12N);
/* 1026 */     this.btnAgendar.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1027 */       .getString("AGENDAR"));
/* 1028 */     this.btnAgendar.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 1029 */       new Color(160, 160, 160)));
/* 1030 */     this.btnAgendar.setFocusPainted(false);
/* 1031 */     this.btnAgendar.setMaximumSize(new Dimension(99, 25));
/* 1032 */     this.btnAgendar.setMinimumSize(new Dimension(99, 25));
/* 1033 */     this.btnAgendar.setPreferredSize(new Dimension(99, 25));
/* 1034 */     gridBagConstraints.fill = 0;
/* 1035 */     gridBagConstraints.anchor = 10;
/* 1036 */     gridBagConstraints.gridx = 2;
/* 1037 */     gridBagConstraints.gridy = 8;
/* 1038 */     gridBagConstraints.gridwidth = 4;
/* 1039 */     gridBagConstraints.insets = new Insets(5, 13, 0, 27);
/* 1040 */     this.panelAgendamento.add(this.btnAgendar, gridBagConstraints);
/*      */     
/*      */ 
/* 1043 */     this.btnShutdown.setFont(fonte12N);
/* 1044 */     this.btnShutdown.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1045 */       .getString("SHUTDOWN_IMEDIATO"));
/* 1046 */     this.btnShutdown.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 1047 */       new Color(160, 160, 160)));
/* 1048 */     this.btnShutdown.setFocusPainted(false);
/* 1049 */     this.btnShutdown.setMaximumSize(new Dimension(150, 25));
/* 1050 */     this.btnShutdown.setMinimumSize(new Dimension(150, 25));
/* 1051 */     this.btnShutdown.setPreferredSize(new Dimension(150, 25));
/* 1052 */     gridBagConstraints.fill = 0;
/* 1053 */     gridBagConstraints.gridwidth = 1;
/* 1054 */     gridBagConstraints.anchor = 10;
/* 1055 */     gridBagConstraints.gridx = 0;
/* 1056 */     gridBagConstraints.gridy = 3;
/* 1057 */     gridBagConstraints.insets = new Insets(10, 88, 0, 0);
/* 1058 */     add(this.btnShutdown, gridBagConstraints);
/*      */     
/*      */ 
/* 1061 */     this.btnShutdownReligamento.setFont(fonte12N);
/* 1062 */     this.btnShutdownReligamento.setText(ResourceBundle.getBundle(
/* 1063 */       Idioma.getIdioma()).getString("SHUTDOWN_COM_RELIGAMENTO"));
/* 1064 */     this.btnShutdownReligamento.setBorder(BorderFactory.createMatteBorder(1, 1, 
/* 1065 */       1, 1, new Color(160, 160, 160)));
/* 1066 */     this.btnShutdownReligamento.setFocusPainted(false);
/* 1067 */     Dimension d = new Dimension(210, 25);
/* 1068 */     this.btnShutdownReligamento.setMaximumSize(d);
/* 1069 */     this.btnShutdownReligamento.setMinimumSize(d);
/* 1070 */     this.btnShutdownReligamento.setPreferredSize(d);
/* 1071 */     gridBagConstraints.fill = 0;
/* 1072 */     gridBagConstraints.gridwidth = 1;
/* 1073 */     gridBagConstraints.anchor = 17;
/* 1074 */     gridBagConstraints.gridx = 1;
/* 1075 */     gridBagConstraints.gridy = 3;
/* 1076 */     gridBagConstraints.insets = new Insets(10, 10, 0, 0);
/* 1077 */     add(this.btnShutdownReligamento, gridBagConstraints);
/*      */     
/*      */ 
/* 1080 */     this.btnAgendar2.setFont(fonte12N);
/* 1081 */     this.btnAgendar2.setText("AGENDAR");
/* 1082 */     this.btnAgendar2.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, 
/* 1083 */       new Color(160, 160, 160)));
/* 1084 */     this.btnAgendar2.setFocusPainted(false);
/* 1085 */     this.btnAgendar2.setMaximumSize(new Dimension(99, 25));
/* 1086 */     this.btnAgendar2.setMinimumSize(new Dimension(99, 25));
/* 1087 */     this.btnAgendar2.setPreferredSize(new Dimension(99, 25));
/* 1088 */     gridBagConstraints.gridx = 1;
/* 1089 */     gridBagConstraints.gridy = 7;
/* 1090 */     gridBagConstraints.gridwidth = 3;
/* 1091 */     gridBagConstraints.anchor = 13;
/* 1092 */     gridBagConstraints.insets = new Insets(10, 141, 0, 10);
/* 1093 */     this.panelOpcoes.add(this.btnAgendar2, gridBagConstraints);
/*      */     
/*      */ 
/* 1096 */     this.cbAutonomia.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 1097 */     this.cbAutonomia.setMargin(new Insets(0, 0, 0, 0));
/* 1098 */     gridBagConstraints.fill = 0;
/* 1099 */     gridBagConstraints.gridwidth = 1;
/* 1100 */     gridBagConstraints.anchor = 10;
/* 1101 */     gridBagConstraints.gridx = 0;
/* 1102 */     gridBagConstraints.gridy = 0;
/* 1103 */     gridBagConstraints.insets = new Insets(0, 70, 10, 6);
/* 1104 */     this.panelOpcoes.add(this.cbAutonomia, gridBagConstraints);
/*      */     
/*      */ 
/* 1107 */     this.cbTempoFalha.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 1108 */     this.cbTempoFalha.setMargin(new Insets(0, 0, 0, 0));
/* 1109 */     gridBagConstraints.fill = 0;
/* 1110 */     gridBagConstraints.gridwidth = 1;
/* 1111 */     gridBagConstraints.anchor = 10;
/* 1112 */     gridBagConstraints.gridx = 0;
/* 1113 */     gridBagConstraints.gridy = 2;
/* 1114 */     gridBagConstraints.insets = new Insets(0, 70, 10, 6);
/* 1115 */     this.panelOpcoes.add(this.cbTempoFalha, gridBagConstraints);
/*      */     
/*      */ 
/* 1118 */     this.textFieldTempoFalha
/* 1119 */       .setBorder(new SoftBevelBorder(1, new Color(
/* 1120 */       204, 204, 204), new Color(204, 204, 204), null, null));
/* 1121 */     this.textFieldTempoFalha.setMaximumSize(new Dimension(40, 19));
/* 1122 */     this.textFieldTempoFalha.setMinimumSize(new Dimension(40, 19));
/* 1123 */     this.textFieldTempoFalha.setPreferredSize(new Dimension(40, 19));
/* 1124 */     gridBagConstraints.fill = 0;
/* 1125 */     gridBagConstraints.gridwidth = 1;
/* 1126 */     gridBagConstraints.gridx = 2;
/* 1127 */     gridBagConstraints.gridy = 2;
/* 1128 */     gridBagConstraints.anchor = 11;
/* 1129 */     gridBagConstraints.insets = new Insets(0, 5, 0, 5);
/* 1130 */     this.panelOpcoes.add(this.textFieldTempoFalha, gridBagConstraints);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTempoFalha()
/*      */   {
/*      */     try
/*      */     {
/* 1140 */       this.dados[1] = Integer.parseInt(this.textFieldTempoFalha.getText());
/* 1141 */       return this.dados[1];
/*      */     } catch (NumberFormatException nfe) {
/* 1143 */       PopUp pop = new PopUp(
/* 1144 */         this.caminhoFiguras + "PopUp.png", 
/* 1145 */         this.caminhoFiguras, 
/*      */         
/* 1147 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 1148 */         .getString(
/* 1149 */         "Modificacao_nao_confirmada__Entre_com_um_valor_valido"), 
/* 1150 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, true);
/* 1151 */       this.textFieldTempoFalha.setText(Integer.toString(this.dados[1]));
/*      */     }
/* 1153 */     return this.dados[1];
/*      */   }
/*      */   
/*      */   public boolean isTempoFalhaValido() {
/*      */     try {
/* 1158 */       this.dados[1] = Integer.parseInt(this.textFieldTempoFalha.getText());
/* 1159 */       return true;
/*      */     } catch (NumberFormatException nfe) {
/* 1161 */       this.textFieldTempoFalha.setText(Integer.toString(this.dados[1])); }
/* 1162 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isTempoAutonomiaValido()
/*      */   {
/*      */     try {
/* 1168 */       this.dados[0] = new Integer(this.textFieldAutonomia.getText()).intValue();
/* 1169 */       return true;
/*      */     } catch (NumberFormatException nfe) {
/* 1171 */       this.textFieldAutonomia.setText(Integer.toString(this.dados[0])); }
/* 1172 */     return false;
/*      */   }
/*      */   
/*      */   public int getTempoAutonomia()
/*      */   {
/*      */     try {
/* 1178 */       this.dados[0] = new Integer(this.textFieldAutonomia.getText()).intValue();
/* 1179 */       return this.dados[0];
/*      */     } catch (NumberFormatException nfe) {
/* 1181 */       PopUp pop = new PopUp(
/* 1182 */         this.caminhoFiguras + "PopUp.png", 
/* 1183 */         this.caminhoFiguras, 
/*      */         
/* 1185 */         ResourceBundle.getBundle(Idioma.getIdioma())
/* 1186 */         .getString(
/* 1187 */         "Modificacao_nao_confirmada__Entre_com_um_valor_valido"), 
/* 1188 */         this.caminhoFiguras, 10, 10, this.interfaceGrafica, false, true);
/* 1189 */       this.textFieldAutonomia.setText(Integer.toString(this.dados[0]));
/*      */     }
/* 1191 */     return this.dados[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean[] getDiasSemana()
/*      */   {
/* 1200 */     boolean[] semana = new boolean[7];
/* 1201 */     if (this.cbTodos.isSelected()) {
/* 1202 */       boolean[] aux = { true, true, true, true, true, true, true };
/* 1203 */       semana = aux;
/*      */     } else {
/* 1205 */       if (this.cbDomingo.isSelected()) {
/* 1206 */         semana[0] = true;
/*      */       }
/* 1208 */       if (this.cbSegunda.isSelected()) {
/* 1209 */         semana[1] = true;
/*      */       }
/* 1211 */       if (this.cbTerca.isSelected()) {
/* 1212 */         semana[2] = true;
/*      */       }
/* 1214 */       if (this.cbQuarta.isSelected()) {
/* 1215 */         semana[3] = true;
/*      */       }
/* 1217 */       if (this.cbQuinta.isSelected()) {
/* 1218 */         semana[4] = true;
/*      */       }
/* 1220 */       if (this.cbSexta.isSelected()) {
/* 1221 */         semana[5] = true;
/*      */       }
/* 1223 */       if (this.cbSabado.isSelected()) {
/* 1224 */         semana[6] = true;
/*      */       }
/*      */     }
/*      */     
/* 1228 */     return semana;
/*      */   }
/*      */   
/*      */   public int getHoraDesligar()
/*      */   {
/* 1233 */     SpinnerModel modelo = this.spinnerHoraDesligar.getModel();
/* 1234 */     return Integer.parseInt((String)modelo.getValue());
/*      */   }
/*      */   
/*      */   public int getMinutoDesligar()
/*      */   {
/* 1239 */     SpinnerModel modelo = this.spinnerMinutoDesligar.getModel();
/* 1240 */     return Integer.parseInt((String)modelo.getValue());
/*      */   }
/*      */   
/*      */   public int getHoraLigar()
/*      */   {
/* 1245 */     SpinnerModel modelo = this.spinnerHoraLigar.getModel();
/* 1246 */     return Integer.parseInt((String)modelo.getValue());
/*      */   }
/*      */   
/*      */   public JButton getBtnAgendar2() {
/* 1250 */     return this.btnAgendar2;
/*      */   }
/*      */   
/*      */   public int getMinutoLigar()
/*      */   {
/* 1255 */     SpinnerModel modelo = this.spinnerMinutoLigar.getModel();
/* 1256 */     return Integer.parseInt((String)modelo.getValue());
/*      */   }
/*      */   
/*      */   public JButton getBtnAgendar() {
/* 1260 */     return this.btnAgendar;
/*      */   }
/*      */   
/*      */   public JButton getBtnShutdown() {
/* 1264 */     return this.btnShutdown;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbAutonomia() {
/* 1268 */     return this.cbAutonomia;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbDomingo() {
/* 1272 */     return this.cbDomingo;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbQuarta() {
/* 1276 */     return this.cbQuarta;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbQuinta() {
/* 1280 */     return this.cbQuinta;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbSabado() {
/* 1284 */     return this.cbSabado;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbSegunda() {
/* 1288 */     return this.cbSegunda;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbSexta() {
/* 1292 */     return this.cbSexta;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbTempoFalha() {
/* 1296 */     return this.cbTempoFalha;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbTerca() {
/* 1300 */     return this.cbTerca;
/*      */   }
/*      */   
/*      */   public JCheckBox getCbTodos() {
/* 1304 */     return this.cbTodos;
/*      */   }
/*      */   
/*      */   public JLabel getLabelAutonomia() {
/* 1308 */     return this.labelAutonomia;
/*      */   }
/*      */   
/*      */   public JLabel getLabelDesligar() {
/* 1312 */     return this.labelDesligar;
/*      */   }
/*      */   
/*      */   public JLabel getLabelDoisPontosDesligar() {
/* 1316 */     return this.labelDoisPontosDesligar;
/*      */   }
/*      */   
/*      */   public JLabel getLabelDoisPontosLigar() {
/* 1320 */     return this.labelDoisPontosLigar;
/*      */   }
/*      */   
/*      */   public JLabel getLabelLigar() {
/* 1324 */     return this.labelLigar;
/*      */   }
/*      */   
/*      */   public JLabel getLabelTempoFalha1() {
/* 1328 */     return this.labelTempoFalha1;
/*      */   }
/*      */   
/*      */   public JLabel getLabelTempoFalha2() {
/* 1332 */     return this.labelTempoFalha2;
/*      */   }
/*      */   
/*      */   public JPanel getPanelAgendamento() {
/* 1336 */     return this.panelAgendamento;
/*      */   }
/*      */   
/*      */   public JPanel getPanelOpcoes() {
/* 1340 */     return this.panelOpcoes;
/*      */   }
/*      */   
/*      */   public JSpinner getSpinnerHoraDesligar() {
/* 1344 */     return this.spinnerHoraDesligar;
/*      */   }
/*      */   
/*      */   public JSpinner getSpinnerHoraLigar() {
/* 1348 */     return this.spinnerHoraLigar;
/*      */   }
/*      */   
/*      */   public JSpinner getSpinnerMinutoDesligar() {
/* 1352 */     return this.spinnerMinutoDesligar;
/*      */   }
/*      */   
/*      */   public JSpinner getSpinnerMinutoLigar() {
/* 1356 */     return this.spinnerMinutoLigar;
/*      */   }
/*      */   
/*      */   public JTextField getTextFieldTempoFalha() {
/* 1360 */     return this.textFieldTempoFalha;
/*      */   }
/*      */   
/*      */   public JTextField getTextFieldAutonomia() {
/* 1364 */     return this.textFieldAutonomia;
/*      */   }
/*      */   
/*      */   public JButton getBtnShutdownReligamento() {
/* 1368 */     return this.btnShutdownReligamento;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBtnAgendar(JButton btnAgendar)
/*      */   {
/* 1375 */     this.btnAgendar = btnAgendar;
/*      */   }
/*      */   
/*      */   public void setBtnShutdownReligamento(JButton b) {
/* 1379 */     this.btnShutdownReligamento = b;
/*      */   }
/*      */   
/*      */   public void setBtnAgendar2(JButton btnAgendar2) {
/* 1383 */     this.btnAgendar2 = btnAgendar2;
/*      */   }
/*      */   
/*      */   public void setBtnShutdown(JButton btnShutdown) {
/* 1387 */     this.btnShutdown = btnShutdown;
/*      */   }
/*      */   
/*      */   public void setCbAutonomia(JCheckBox cbAutonomia) {
/* 1391 */     this.cbAutonomia = cbAutonomia;
/*      */   }
/*      */   
/*      */   public void setCbDomingo(JCheckBox cbDomingo) {
/* 1395 */     this.cbDomingo = cbDomingo;
/*      */   }
/*      */   
/*      */   public void setCbQuarta(JCheckBox cbQuarta) {
/* 1399 */     this.cbQuarta = cbQuarta;
/*      */   }
/*      */   
/*      */   public void setCbQuinta(JCheckBox cbQuinta) {
/* 1403 */     this.cbQuinta = cbQuinta;
/*      */   }
/*      */   
/*      */   public void setCbSabado(JCheckBox cbSabado) {
/* 1407 */     this.cbSabado = cbSabado;
/*      */   }
/*      */   
/*      */   public void setCbSegunda(JCheckBox cbSegunda) {
/* 1411 */     this.cbSegunda = cbSegunda;
/*      */   }
/*      */   
/*      */   public void setCbSexta(JCheckBox cbSexta) {
/* 1415 */     this.cbSexta = cbSexta;
/*      */   }
/*      */   
/*      */   public void setCbTempoFalha(JCheckBox cbTempoFalha) {
/* 1419 */     this.cbTempoFalha = cbTempoFalha;
/*      */   }
/*      */   
/*      */   public void setCbTerca(JCheckBox cbTerca) {
/* 1423 */     this.cbTerca = cbTerca;
/*      */   }
/*      */   
/*      */   public void setCbTodos(JCheckBox cbTodos) {
/* 1427 */     this.cbTodos = cbTodos;
/*      */   }
/*      */   
/*      */   public void setLabelAutonomia(JLabel labelAutonomia) {
/* 1431 */     this.labelAutonomia = labelAutonomia;
/*      */   }
/*      */   
/*      */   public void setLabelDesligar(JLabel labelDesligar) {
/* 1435 */     this.labelDesligar = labelDesligar;
/*      */   }
/*      */   
/*      */   public void setLabelDoisPontosDesligar(JLabel labelDoisPontosDesligar) {
/* 1439 */     this.labelDoisPontosDesligar = labelDoisPontosDesligar;
/*      */   }
/*      */   
/*      */   public void setLabelDoisPontosLigar(JLabel labelDoisPontosLigar) {
/* 1443 */     this.labelDoisPontosLigar = labelDoisPontosLigar;
/*      */   }
/*      */   
/*      */   public void setLabelLigar(JLabel labelLigar) {
/* 1447 */     this.labelLigar = labelLigar;
/*      */   }
/*      */   
/*      */   public void setLabelTempoFalha1(JLabel labelTempoFalha1) {
/* 1451 */     this.labelTempoFalha1 = labelTempoFalha1;
/*      */   }
/*      */   
/*      */   public void setLabelTempoFalha2(JLabel labelTempoFalha2) {
/* 1455 */     this.labelTempoFalha2 = labelTempoFalha2;
/*      */   }
/*      */   
/*      */   public void setPanelAgendamento(JPanel panelAgendamento) {
/* 1459 */     this.panelAgendamento = panelAgendamento;
/*      */   }
/*      */   
/*      */   public void setPanelOpcoes(JPanel panelOpcoes) {
/* 1463 */     this.panelOpcoes = panelOpcoes;
/*      */   }
/*      */   
/*      */   public void setSpinnerHoraDesligar(JSpinner spinnerHoraDesligar) {
/* 1467 */     this.spinnerHoraDesligar = spinnerHoraDesligar;
/*      */   }
/*      */   
/*      */   public void setSpinnerHoraLigar(JSpinner spinnerHoraLigar) {
/* 1471 */     this.spinnerHoraLigar = spinnerHoraLigar;
/*      */   }
/*      */   
/*      */   public void setSpinnerMinutoDesligar(JSpinner spinnerMinutoDesligar) {
/* 1475 */     this.spinnerMinutoDesligar = spinnerMinutoDesligar;
/*      */   }
/*      */   
/*      */   public void setSpinnerMinutoLigar(JSpinner spinnerMinutoLigar) {
/* 1479 */     this.spinnerMinutoLigar = spinnerMinutoLigar;
/*      */   }
/*      */   
/*      */   public void setTextFieldTempoFalha(JTextField textFieldTempoFalha) {
/* 1483 */     this.textFieldTempoFalha = textFieldTempoFalha;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFlag()
/*      */   {
/* 1490 */     return this.flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFlag(boolean flag)
/*      */   {
/* 1497 */     this.flag = flag;
/*      */   }
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelComando.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */