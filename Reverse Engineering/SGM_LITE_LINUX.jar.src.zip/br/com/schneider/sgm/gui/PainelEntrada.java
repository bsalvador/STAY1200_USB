/*      */ package br.com.schneider.sgm.gui;
/*      */ 
/*      */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FlowLayout;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class PainelEntrada
/*      */   extends JPanel
/*      */ {
/*      */   private JLabel corrente;
/*      */   private JLabel entrada;
/*      */   private float barraLimSuperior;
/*      */   private float barraLimInferior;
/*      */   private JLabel frequencia;
/*      */   private JLabel labelCorrente;
/*      */   private JLabel labelEntrada;
/*      */   private JLabel labelFrequencia;
/*      */   private JLabel labelTensao;
/*      */   Barra1 panelBarraTensao;
/*      */   private DecimalFormat formatador;
/*      */   private String titulo;
/*      */   private ImageIcon imagemFundo;
/*      */   private JPanel enchimento2;
/*      */   
/*      */   public PainelEntrada(String caminhoFiguras)
/*      */   {
/* 1015 */     initComponents();
/* 1016 */     this.imagemFundo = new ImageIcon(caminhoFiguras + "painelSuperior.png");
/* 1017 */     this.formatador = new DecimalFormat("0.0");
/* 1018 */     validarIdioma();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void paintComponent(Graphics g)
/*      */   {
/* 1028 */     super.paintComponent(g);
/* 1029 */     g.drawImage(this.imagemFundo.getImage(), 0, 0, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBarraLimSuperior(float limite)
/*      */   {
/* 1042 */     this.barraLimSuperior = limite;
/* 1043 */     this.panelBarraTensao.setLimSuperior(this.barraLimSuperior);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBarraLimInferior(float limite)
/*      */   {
/* 1053 */     this.barraLimInferior = limite;
/* 1054 */     this.panelBarraTensao.setLimInferior(this.barraLimInferior);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getBarraLimInferior()
/*      */   {
/* 1063 */     return this.barraLimInferior;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getBarraLimSuperior()
/*      */   {
/* 1072 */     return this.barraLimSuperior;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void validarIdioma()
/*      */   {
/* 1079 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1080 */       "ENTRADA");
/* 1081 */     this.enchimento2.setBorder(BorderFactory.createTitledBorder(
/* 1082 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 1083 */       0, 
/* 1084 */       0, new Font("Trebuchet", 1, 12)));
/* 1085 */     this.labelEntrada.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1086 */       .getString("ENTRADA_NOMINAL"));
/* 1087 */     this.labelTensao.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1088 */       .getString("TENSAO_EFICAZ"));
/* 1089 */     this.labelCorrente.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1090 */       .getString("CORRENTE"));
/* 1091 */     this.labelFrequencia.setText(ResourceBundle.getBundle(Idioma.getIdioma())
/* 1092 */       .getString("FREQUENCIA"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initComponents()
/*      */   {
/* 1102 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*      */     
/* 1104 */     Dimension d = new Dimension(205, 170);
/* 1105 */     Font fonte11B = new Font("Trebuchet", 1, 11);
/* 1106 */     Font fonte11P = new Font("Trebuchet", 0, 11);
/* 1107 */     Font fonte12B = new Font("Trebuchet", 1, 12);
/* 1108 */     Font fonte12P = new Font("Trebuchet", 0, 12);
/* 1109 */     Insets insets = new Insets(0, 32, 15, 0);
/*      */     
/* 1111 */     this.labelEntrada = new JLabel();
/* 1112 */     this.entrada = new JLabel();
/* 1113 */     this.panelBarraTensao = new Barra1();
/* 1114 */     this.labelTensao = new JLabel();
/* 1115 */     this.labelCorrente = new JLabel();
/* 1116 */     this.corrente = new JLabel();
/* 1117 */     this.labelFrequencia = new JLabel();
/* 1118 */     this.frequencia = new JLabel();
/* 1119 */     this.barraLimSuperior = 150.0F;
/* 1120 */     this.barraLimInferior = 90.0F;
/* 1121 */     this.panelBarraTensao.setLimSuperior(this.barraLimSuperior);
/* 1122 */     this.panelBarraTensao.setLimInferior(this.barraLimInferior);
/* 1123 */     this.titulo = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 1124 */       "ENTRADA");
/*      */     
/* 1126 */     this.enchimento2 = new JPanel();
/* 1127 */     setLayout(new FlowLayout(1, 0, 3));
/* 1128 */     setOpaque(false);
/* 1129 */     add(this.enchimento2);
/*      */     
/* 1131 */     this.enchimento2.setLayout(new GridBagLayout());
/*      */     
/* 1133 */     this.enchimento2.setBorder(BorderFactory.createTitledBorder(
/* 1134 */       BorderFactory.createEmptyBorder(5, 5, 5, 5), "  " + this.titulo, 
/* 1135 */       0, 
/* 1136 */       0, fonte12B));
/* 1137 */     this.enchimento2.setMaximumSize(d);
/* 1138 */     this.enchimento2.setMinimumSize(d);
/* 1139 */     this.enchimento2.setOpaque(false);
/* 1140 */     this.enchimento2.setPreferredSize(d);
/*      */     
/* 1142 */     this.labelEntrada.setFont(fonte12B);
/* 1143 */     gridBagConstraints.gridwidth = 5;
/* 1144 */     gridBagConstraints.anchor = 17;
/* 1145 */     gridBagConstraints.insets = new Insets(10, 0, 10, 0);
/* 1146 */     this.enchimento2.add(this.labelEntrada, gridBagConstraints);
/*      */     
/* 1148 */     this.entrada.setFont(fonte12P);
/* 1149 */     this.entrada.setText("110V");
/* 1150 */     gridBagConstraints.gridx = 3;
/* 1151 */     gridBagConstraints.gridy = 0;
/* 1152 */     gridBagConstraints.anchor = 14;
/* 1153 */     gridBagConstraints.insets = insets;
/* 1154 */     this.enchimento2.add(this.entrada, gridBagConstraints);
/*      */     
/* 1156 */     this.labelTensao.setFont(fonte11B);
/* 1157 */     gridBagConstraints.gridx = 0;
/* 1158 */     gridBagConstraints.gridy = 2;
/* 1159 */     gridBagConstraints.gridwidth = 4;
/* 1160 */     gridBagConstraints.anchor = 17;
/* 1161 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/* 1162 */     this.enchimento2.add(this.labelTensao, gridBagConstraints);
/*      */     
/* 1164 */     this.panelBarraTensao.setMinimumSize(new Dimension(10, 45));
/* 1165 */     this.panelBarraTensao.setPreferredSize(new Dimension(10, 45));
/* 1166 */     this.panelBarraTensao.setRequestFocusEnabled(false);
/* 1167 */     gridBagConstraints.gridx = 0;
/* 1168 */     gridBagConstraints.gridy = 5;
/* 1169 */     gridBagConstraints.gridwidth = 5;
/* 1170 */     gridBagConstraints.fill = 2;
/* 1171 */     gridBagConstraints.insets = new Insets(0, 10, 0, 0);
/* 1172 */     this.enchimento2.add(this.panelBarraTensao, gridBagConstraints);
/*      */     
/* 1174 */     this.labelCorrente.setFont(fonte11B);
/* 1175 */     gridBagConstraints.gridx = 0;
/* 1176 */     gridBagConstraints.gridy = 6;
/* 1177 */     gridBagConstraints.gridwidth = 2;
/* 1178 */     gridBagConstraints.anchor = 17;
/* 1179 */     gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/* 1180 */     this.enchimento2.add(this.labelCorrente, gridBagConstraints);
/*      */     
/* 1182 */     this.corrente.setFont(fonte11P);
/* 1183 */     this.corrente.setText("A");
/* 1184 */     gridBagConstraints.gridx = 3;
/* 1185 */     gridBagConstraints.gridy = 6;
/* 1186 */     gridBagConstraints.fill = 0;
/* 1187 */     gridBagConstraints.anchor = 13;
/* 1188 */     gridBagConstraints.insets = insets;
/* 1189 */     this.enchimento2.add(this.corrente, gridBagConstraints);
/*      */     
/* 1191 */     this.labelFrequencia.setFont(fonte11B);
/* 1192 */     gridBagConstraints.gridx = 0;
/* 1193 */     gridBagConstraints.gridy = 7;
/* 1194 */     gridBagConstraints.gridwidth = 2;
/* 1195 */     gridBagConstraints.anchor = 17;
/* 1196 */     gridBagConstraints.insets = new Insets(0, 0, 15, 0);
/* 1197 */     this.enchimento2.add(this.labelFrequencia, gridBagConstraints);
/*      */     
/* 1199 */     this.frequencia.setFont(fonte11P);
/* 1200 */     this.frequencia.setText("0.00Hz");
/* 1201 */     gridBagConstraints.gridx = 3;
/* 1202 */     gridBagConstraints.gridy = 7;
/* 1203 */     gridBagConstraints.anchor = 13;
/* 1204 */     gridBagConstraints.insets = insets;
/* 1205 */     this.enchimento2.add(this.frequencia, gridBagConstraints);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLabelCorrente(JLabel l)
/*      */   {
/* 1215 */     this.labelCorrente = l;
/*      */   }
/*      */   
/*      */   public void setLabelEntrada(JLabel l)
/*      */   {
/* 1220 */     this.labelEntrada = l;
/*      */   }
/*      */   
/*      */   public void setLabelFrequencia(JLabel l)
/*      */   {
/* 1225 */     this.labelFrequencia = l;
/*      */   }
/*      */   
/*      */   public void setCorrente(JLabel l)
/*      */   {
/* 1230 */     this.corrente = l;
/*      */   }
/*      */   
/*      */   public void setEntrada(JLabel l)
/*      */   {
/* 1235 */     this.entrada = l;
/*      */   }
/*      */   
/*      */   public void setFrequencia(JLabel l)
/*      */   {
/* 1240 */     this.frequencia = l;
/*      */   }
/*      */   
/*      */   public void setLabelTensao(JLabel l)
/*      */   {
/* 1245 */     this.labelTensao = l;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCorrente(float f)
/*      */   {
/* 1251 */     this.corrente.setText(this.formatador.format(f) + "A");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setEntrada(boolean i)
/*      */   {
/* 1257 */     this.entrada.setText((i ? "220" : "110") + "V");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setEntrada(int i)
/*      */   {
/* 1263 */     this.entrada.setText(i + "V");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFrequencia(float f)
/*      */   {
/* 1269 */     this.frequencia.setText(this.formatador.format(f) + "Hz");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JLabel getLabelCorrente()
/*      */   {
/* 1280 */     return this.labelCorrente;
/*      */   }
/*      */   
/*      */   public JLabel getLabelEntrada()
/*      */   {
/* 1285 */     return this.labelEntrada;
/*      */   }
/*      */   
/*      */   public JLabel getLabelFrequencia()
/*      */   {
/* 1290 */     return this.labelFrequencia;
/*      */   }
/*      */   
/*      */   public JLabel getCorrente()
/*      */   {
/* 1295 */     return this.corrente;
/*      */   }
/*      */   
/*      */   public JLabel getEntrada()
/*      */   {
/* 1300 */     return this.entrada;
/*      */   }
/*      */   
/*      */   public JLabel getFrequencia()
/*      */   {
/* 1305 */     return this.frequencia;
/*      */   }
/*      */   
/*      */   public JLabel getLabelTensao()
/*      */   {
/* 1310 */     return this.labelTensao;
/*      */   }
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\gui\PainelEntrada.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */