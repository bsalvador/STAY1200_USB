/*     */ package br.com.schneider.sgm.persistencia;
/*     */ 
/*     */ import br.com.schneider.sgm.config.InstanciaSGM;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import sun.misc.BASE64Decoder;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Persistencia
/*     */ {
/*     */   public static final int SOLIS_M11 = 171;
/*     */   public static final int SOLIS_M15 = 175;
/*     */   public static final int SOLIS_M14 = 174;
/*     */   public static final int SOLIS_M13 = 173;
/*     */   public static final int SOLISDC_M15 = 207;
/*     */   public static final int CABECALHO_RHINO = 194;
/*     */   public static final int PS800 = 185;
/*     */   private InstanciaSGM sgmConf;
/*     */   private boolean primeiraExec;
/*     */   private boolean flagPersistencia;
/*     */   
/*     */   public Persistencia()
/*     */   {
/*  62 */     File config = new File("config.sgm");
/*     */     
/*  64 */     this.primeiraExec = (!config.exists());
/*     */     
/*  66 */     if (!this.primeiraExec)
/*     */     {
/*     */       try {
/*  69 */         ObjectInputStream input = new ObjectInputStream(
/*  70 */           new FileInputStream(config));
/*  71 */         this.sgmConf = ((InstanciaSGM)input.readObject());
/*  72 */         input.close();
/*  73 */         config = null;
/*     */       }
/*     */       catch (Exception e) {
/*  76 */         this.sgmConf = new InstanciaSGM();
/*  77 */         this.sgmConf.setIdioma("PORTUGUES");
/*  78 */         System.err.println(e.getMessage());
/*  79 */         e.printStackTrace();
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  86 */       this.sgmConf = new InstanciaSGM();
/*  87 */       this.sgmConf.setIdioma("PORTUGUES");
/*     */       
/*  89 */       this.sgmConf.setCaminhoArquivoXMLEVENTOS(config.getAbsolutePath());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Persistencia(String caminho)
/*     */   {
/*  97 */     File config = new File(File.separator + caminho + File.separator + "config.sgm");
/*     */     
/*  99 */     this.primeiraExec = (!config.exists());
/*     */     
/* 101 */     if (!this.primeiraExec)
/*     */     {
/*     */       try {
/* 104 */         ObjectInputStream input = new ObjectInputStream(
/* 105 */           new FileInputStream(config));
/* 106 */         this.sgmConf = ((InstanciaSGM)input.readObject());
/* 107 */         input.close();
/* 108 */         config = null;
/*     */       }
/*     */       catch (Exception e) {
/* 111 */         this.sgmConf = new InstanciaSGM();
/* 112 */         this.sgmConf.setIdioma("PORTUGUES");
/* 113 */         System.err.println(e.getMessage());
/* 114 */         e.printStackTrace();
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 121 */       this.sgmConf = new InstanciaSGM();
/* 122 */       this.sgmConf.setIdioma("PORTUGUES");
/* 123 */       this.sgmConf.setCaminhoArquivoXMLEVENTOS(caminho);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void salvaConf()
/*     */   {
/*     */     try
/*     */     {
/* 134 */       ObjectOutputStream output = new ObjectOutputStream(
/* 135 */         new FileOutputStream(new File(getCaminhoArquivoXMLEVENTOS() + "config.sgm")));
/* 136 */       output.writeObject(this.sgmConf);
/* 137 */       output.flush();
/* 138 */       output.close();
/*     */     } catch (Exception e) {
/* 140 */       System.err.println(e.getMessage());
/* 141 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrimeiraExec()
/*     */   {
/* 158 */     return this.primeiraExec;
/*     */   }
/*     */   
/*     */   public int getAutonoMinima() {
/* 162 */     return this.sgmConf.getAutonoMinima();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 167 */   public boolean getFlagPersistencia() { return this.flagPersistencia; }
/*     */   
/*     */   public String[] getDestinatarios() {
/* 170 */     if (this.sgmConf.getDestinatarios() == null) {
/* 171 */       String[] str = { "" };
/*     */       
/* 173 */       return str;
/*     */     }
/* 175 */     return this.sgmConf.getDestinatarios();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InstanciaSGM getSgmConf()
/*     */   {
/* 183 */     return this.sgmConf;
/*     */   }
/*     */   
/*     */   public String getEnderecoSMTP() {
/* 187 */     return this.sgmConf.getEnderecoSMTP();
/*     */   }
/*     */   
/*     */   public int getPortaSMTP() {
/* 191 */     return this.sgmConf.getPortaSMTP();
/*     */   }
/*     */   
/*     */   public int getEvento() {
/* 195 */     return this.sgmConf.getEvento();
/*     */   }
/*     */   
/*     */   public int getExpansorBateria() {
/* 199 */     return this.sgmConf.getExpansorBateria();
/*     */   }
/*     */   
/*     */   public int getFamilia() {
/* 203 */     return this.sgmConf.getFamilia();
/*     */   }
/*     */   
/*     */   public boolean isFlagAutentic() {
/* 207 */     return this.sgmConf.isFlagAutentic();
/*     */   }
/*     */   
/*     */   public boolean isFlagShutFalhaEletrica() {
/* 211 */     return this.sgmConf.isFlagShutFalhaEletrica();
/*     */   }
/*     */   
/*     */   public boolean isFlagShutFimAut() {
/* 215 */     return this.sgmConf.isFlagShutFimAut();
/*     */   }
/*     */   
/*     */   public Object getIdioma() {
/* 219 */     return this.sgmConf.getIdioma();
/*     */   }
/*     */   
/*     */   public boolean[][] getMensagens() {
/* 223 */     return this.sgmConf.getMensagens();
/*     */   }
/*     */   
/*     */   public String getPorta() {
/* 227 */     return this.sgmConf.getPorta();
/*     */   }
/*     */   
/*     */   public String getRemetente() {
/* 231 */     return this.sgmConf.getRemetente();
/*     */   }
/*     */   
/*     */   public String getScript() {
/* 235 */     return this.sgmConf.getScript();
/*     */   }
/*     */   
/*     */   public String getSenha() {
/*     */     try {
/* 240 */       return new String(new BASE64Decoder().decodeBuffer(this.sgmConf.getSenha()), "UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 243 */       e.printStackTrace();
/*     */     }
/*     */     catch (IOException e) {
/* 246 */       e.printStackTrace();
/*     */     }
/* 248 */     return null;
/*     */   }
/*     */   
/*     */   public int getTempoFalhaEletrica() {
/* 252 */     return this.sgmConf.getTempoFalhaEletrica();
/*     */   }
/*     */   
/*     */   public String getUsuario() {
/* 256 */     return this.sgmConf.getUsuario();
/*     */   }
/*     */   
/*     */   public int getModeloUPS() {
/* 260 */     return this.sgmConf.getModeloUPS();
/*     */   }
/*     */   
/*     */   public int getPortaRemota() {
/* 264 */     return this.sgmConf.getPortaRemota();
/*     */   }
/*     */   
/*     */   public boolean isModoRemoto() {
/* 268 */     return this.sgmConf.isModoRemoto();
/*     */   }
/*     */   
/*     */   public double getValorKW() {
/* 272 */     return this.sgmConf.getValorKW();
/*     */   }
/*     */   
/*     */   public String getModeloUPSString() {
/* 276 */     switch (getModeloUPS())
/*     */     {
/*     */     case 194: 
/* 279 */       return "RHINO";
/*     */     case 207: 
/* 281 */       return "SOLISDC 15";
/*     */     case 173: 
/* 283 */       return "SOLIS 13";
/*     */     case 174: 
/* 285 */       return "SOLIS 14";
/*     */     case 175: 
/* 287 */       return "SOLIS 15";
/*     */     case 171: 
/* 289 */       return "SOLIS 11";
/*     */     case 185: 
/* 291 */       return "PS 800";
/*     */     }
/* 293 */     return "Desconhecido";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getComunidadeEscrita()
/*     */   {
/* 302 */     return this.sgmConf.getComunidadeEscrita();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getComunidadeLeitura()
/*     */   {
/* 309 */     return this.sgmConf.getComunidadeLeitura();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEnderecoGerente()
/*     */   {
/* 316 */     return this.sgmConf.getEnderecoGerente();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNomeUPS()
/*     */   {
/* 323 */     return this.sgmConf.getNomeUPS();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPortaEnvio()
/*     */   {
/* 330 */     return this.sgmConf.getPortaEnvio();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPortaPedidos()
/*     */   {
/* 337 */     return this.sgmConf.getPortaPedidos();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getProtocoloTransporte()
/*     */   {
/* 344 */     return this.sgmConf.getProtocoloTransporte();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getVSNMP()
/*     */   {
/* 351 */     return this.sgmConf.getVSNMP();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUPSServerPort()
/*     */   {
/* 360 */     return this.sgmConf.getUPSServerPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getUPSServerClients()
/*     */   {
/* 368 */     return this.sgmConf.getUPSServerClients();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUPSServerEnabled()
/*     */   {
/* 377 */     return this.sgmConf.isUPSServerEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPeriodoTeste()
/*     */   {
/* 387 */     return this.sgmConf.getPeriodoTeste();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getHoraTeste()
/*     */   {
/* 394 */     return this.sgmConf.getHoraTeste();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMinutoTeste()
/*     */   {
/* 401 */     return this.sgmConf.getMinutoTeste();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAutoTesteEnabled()
/*     */   {
/* 409 */     return this.sgmConf.getAutoTesteEnabled();
/*     */   }
/*     */   
/*     */   public boolean getModoLogging() {
/* 413 */     return this.sgmConf.getModoLogging();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCaminhoArquivoXMLEVENTOS()
/*     */   {
/* 421 */     return this.sgmConf.getCaminhoArquivoXMLEVENTOS();
/*     */   }
/*     */   
/*     */   public String getProvedorEscolhido()
/*     */   {
/* 426 */     return this.sgmConf.getProvedorEscolhido() == null ? "" : this.sgmConf.getProvedorEscolhido();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAutonoMinima(int autonoMinima)
/*     */   {
/* 433 */     this.sgmConf.setAutonoMinima(autonoMinima);
/*     */   }
/*     */   
/*     */   public void setDestinatarios(String[] destinatarios) {
/* 437 */     this.sgmConf.setDestinatarios(destinatarios);
/*     */   }
/*     */   
/*     */   public void setEnderecoSMTP(String enderecoSMTP) {
/* 441 */     this.sgmConf.setEnderecoSMTP(enderecoSMTP);
/*     */   }
/*     */   
/*     */   public void setPortaSMTP(int portaSMTP) {
/* 445 */     this.sgmConf.setPortaSMTP(portaSMTP);
/*     */   }
/*     */   
/*     */   public void setEvento(int evento) {
/* 449 */     this.sgmConf.setEvento(evento);
/*     */   }
/*     */   
/*     */   public void setExpansorBateria(int expansorBateria) {
/* 453 */     this.sgmConf.setExpansorBateria(expansorBateria);
/*     */   }
/*     */   
/*     */   public void setFamilia(int familia) {
/* 457 */     this.sgmConf.setFamilia(familia);
/*     */   }
/*     */   
/*     */   public void setFlagAutentic(boolean flagAutentic) {
/* 461 */     this.sgmConf.setFlagAutentic(flagAutentic);
/*     */   }
/*     */   
/*     */   public void setFlagShutFalhaEletrica(boolean flagShutFalhaEletrica) {
/* 465 */     this.sgmConf.setFlagShutFalhaEletrica(flagShutFalhaEletrica);
/*     */   }
/*     */   
/*     */   public void setFlagShutFimAut(boolean flagShutFimAut) {
/* 469 */     this.sgmConf.setFlagShutFimAut(flagShutFimAut);
/*     */   }
/*     */   
/*     */   public void setIdioma(String idioma) {
/* 473 */     this.sgmConf.setIdioma(idioma);
/*     */   }
/*     */   
/*     */   public void setMensagens(boolean[][] mensagens) {
/* 477 */     this.sgmConf.setMensagens(mensagens);
/*     */   }
/*     */   
/*     */   public void setPorta(String porta) {
/* 481 */     this.sgmConf.setPorta(porta);
/*     */   }
/*     */   
/*     */   public void setRemetente(String remetente) {
/* 485 */     this.sgmConf.setRemetente(remetente);
/*     */   }
/*     */   
/*     */   public void setScript(String script) {
/* 489 */     this.sgmConf.setScript(script);
/*     */   }
/*     */   
/*     */   public void setSenha(String senha) {
/* 493 */     this.sgmConf.setSenha(new BASE64Encoder().encode(senha.getBytes()));
/*     */   }
/*     */   
/*     */   public void setTempoFalhaEletrica(int tempoFalhaEletrica) {
/* 497 */     this.sgmConf.setTempoFalhaEletrica(tempoFalhaEletrica);
/*     */   }
/*     */   
/*     */   public void setUsuario(String usuario) {
/* 501 */     this.sgmConf.setUsuario(usuario);
/*     */   }
/*     */   
/*     */   public void setModeloUPS(int modeloUPS) {
/* 505 */     this.sgmConf.setModeloUPS(modeloUPS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComunidadeEscrita(String comunidadeEscrita)
/*     */   {
/* 513 */     this.sgmConf.setComunidadeEscrita(comunidadeEscrita);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComunidadeLeitura(String comunidadeLeitura)
/*     */   {
/* 521 */     this.sgmConf.setComunidadeLeitura(comunidadeLeitura);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnderecoGerente(String enderecoGerente)
/*     */   {
/* 529 */     this.sgmConf.setEnderecoGerente(enderecoGerente);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIdioma(Object idioma)
/*     */   {
/* 537 */     this.sgmConf.setIdioma(idioma);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNomeUPS(String nomeUPS)
/*     */   {
/* 545 */     this.sgmConf.setNomeUPS(nomeUPS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPortaEnvio(int portaEnvio)
/*     */   {
/* 553 */     this.sgmConf.setPortaEnvio(portaEnvio);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPortaPedidos(int portaPedidos)
/*     */   {
/* 561 */     this.sgmConf.setPortaPedidos(portaPedidos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProtocoloTransporte(int protocoloTransporte)
/*     */   {
/* 569 */     this.sgmConf.setProtocoloTransporte(protocoloTransporte);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVSNMP(int vsnmp)
/*     */   {
/* 577 */     this.sgmConf.setVSNMP(vsnmp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModoRemoto(boolean modoRemoto)
/*     */   {
/* 585 */     this.sgmConf.setModoRemoto(modoRemoto);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPortaRemota(int portaRemota)
/*     */   {
/* 593 */     this.sgmConf.setPortaRemota(portaRemota);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrimeiraExec(boolean primeiraExec)
/*     */   {
/* 601 */     this.primeiraExec = primeiraExec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSgmConf(InstanciaSGM sgmConf)
/*     */   {
/* 609 */     this.sgmConf = sgmConf;
/*     */   }
/*     */   
/*     */   public void setValorKw(double valor) {
/* 613 */     this.sgmConf.setValorKW(valor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getUPSServerPort(int port)
/*     */   {
/* 621 */     this.sgmConf.setUPSServerPort(port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUPSServerClients(Object a)
/*     */   {
/* 629 */     this.sgmConf.setUPSServerClients(a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUPSServerEnabled(boolean b)
/*     */   {
/* 638 */     this.sgmConf.setUPSServerEnabled(b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPeriodoAutoTeste(int periodo)
/*     */   {
/* 647 */     this.sgmConf.setPeriodoAutoTeste(periodo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHoraTeste(int horaTeste)
/*     */   {
/* 654 */     this.sgmConf.setHoraTeste(horaTeste);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMinutoTeste(int minutoTeste)
/*     */   {
/* 661 */     this.sgmConf.setMinutoTeste(minutoTeste);
/*     */   }
/*     */   
/*     */   public void setAutoTeste(boolean enable) {
/* 665 */     this.sgmConf.setAutoTeste(enable);
/*     */   }
/*     */   
/*     */   public void setModoLogging(boolean enable) {
/* 669 */     this.sgmConf.setModoLogging(enable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCaminhoArquivoXMLEVENTOS(String caminhoArquivoXML)
/*     */   {
/* 677 */     this.sgmConf.setCaminhoArquivoXMLEVENTOS(caminhoArquivoXML);
/*     */   }
/*     */   
/*     */   public void setProvedorEscolhido(String provedorEscolhido)
/*     */   {
/* 682 */     this.sgmConf.setProvedorEscolhido(provedorEscolhido);
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\persistencia\Persistencia.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */