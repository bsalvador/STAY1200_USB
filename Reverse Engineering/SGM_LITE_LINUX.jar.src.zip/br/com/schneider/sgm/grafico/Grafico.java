/*    */ package br.com.schneider.sgm.grafico;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Color;
/*    */ import javax.swing.JPanel;
/*    */ import org.jfree.chart.ChartPanel;
/*    */ import org.jfree.chart.JFreeChart;
/*    */ import org.jfree.chart.axis.DateAxis;
/*    */ import org.jfree.chart.axis.NumberAxis;
/*    */ import org.jfree.chart.plot.XYPlot;
/*    */ import org.jfree.chart.renderer.StandardXYItemRenderer;
/*    */ import org.jfree.chart.renderer.XYItemRenderer;
/*    */ import org.jfree.data.time.Millisecond;
/*    */ import org.jfree.data.time.TimeSeries;
/*    */ import org.jfree.data.time.TimeSeriesCollection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Grafico
/*    */   extends JPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private TimeSeries valores;
/*    */   private TimeSeries free;
/*    */   protected static final int maxCont = 1800;
/*    */   
/*    */   public Grafico()
/*    */   {
/* 52 */     super(new BorderLayout());
/* 53 */     this.valores = new TimeSeries("", Millisecond.class);
/* 54 */     this.valores.setHistoryCount(10000);
/* 55 */     this.free = new TimeSeries("", Millisecond.class);
/* 56 */     this.free.setHistoryCount(10000);
/* 57 */     TimeSeriesCollection dataset = new TimeSeriesCollection();
/* 58 */     dataset.addSeries(this.free);
/* 59 */     dataset.addSeries(this.valores);
/* 60 */     DateAxis domain = new DateAxis("Tempo");
/* 61 */     NumberAxis range = new NumberAxis("");
/* 62 */     XYPlot xyplot = new XYPlot(dataset, domain, range, 
/* 63 */       new StandardXYItemRenderer());
/* 64 */     xyplot.setBackgroundPaint(Color.white);
/* 65 */     XYItemRenderer renderer = xyplot.getRenderer();
/* 66 */     renderer.setSeriesPaint(0, Color.red);
/* 67 */     renderer.setSeriesPaint(1, Color.black);
/* 68 */     domain.setAutoRange(true);
/* 69 */     domain.setLowerMargin(0.0D);
/* 70 */     domain.setUpperMargin(0.0D);
/* 71 */     domain.setTickLabelsVisible(true);
/* 72 */     range.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
/* 73 */     JFreeChart chart = new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, 
/* 74 */       xyplot, true);
/* 75 */     ChartPanel chartPanel = new ChartPanel(chart);
/* 76 */     add(chartPanel);
/*    */   }
/*    */   
/*    */ 
/*    */   private void addTotalObservation(double y)
/*    */   {
/* 82 */     this.valores.add(new Millisecond(), y);
/*    */   }
/*    */   
/*    */   private void addFreeObservation(double y)
/*    */   {
/* 87 */     this.free.add(new Millisecond(), y);
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\Grafico.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */