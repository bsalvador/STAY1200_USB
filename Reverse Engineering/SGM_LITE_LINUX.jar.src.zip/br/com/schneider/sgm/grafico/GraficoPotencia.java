/*     */ package br.com.schneider.sgm.grafico;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.util.ResourceBundle;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.DateAxis;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.StandardXYItemRenderer;
/*     */ import org.jfree.chart.renderer.XYItemRenderer;
/*     */ import org.jfree.data.SeriesException;
/*     */ import org.jfree.data.time.Second;
/*     */ import org.jfree.data.time.TimeSeries;
/*     */ import org.jfree.data.time.TimeSeriesCollection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraficoPotencia
/*     */   extends Grafico
/*     */ {
/*     */   private static final long serialVersionUID = 5799104728367333912L;
/*     */   private TimeSeries valores;
/*     */   private TimeSeries free;
/*     */   private String[] graficoID;
/*     */   private String tempo;
/*     */   private boolean flag;
/*     */   private DateAxis domain;
/*     */   private NumberAxis range;
/*     */   private JFreeChart chart;
/*     */   private int cont;
/*     */   
/*     */   public GraficoPotencia()
/*     */   {
/*  84 */     this.flag = false;
/*  85 */     this.graficoID = new String[3];
/*  86 */     this.graficoID[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString("POTENCIA");
/*  87 */     this.graficoID[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString("PotenciaReal");
/*  88 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString("PotenciaAparente");
/*  89 */     this.tempo = ResourceBundle.getBundle(Idioma.getIdioma()).getString("Tempo");
/*  90 */     this.valores = new TimeSeries(this.graficoID[1], Second.class);
/*  91 */     this.valores.setHistoryCount(10000);
/*  92 */     this.free = new TimeSeries(this.graficoID[2], Second.class);
/*  93 */     this.free.setHistoryCount(10000);
/*  94 */     TimeSeriesCollection dataset = new TimeSeriesCollection();
/*  95 */     dataset.addSeries(this.free);
/*  96 */     dataset.addSeries(this.valores);
/*  97 */     this.domain = new DateAxis(this.tempo);
/*  98 */     this.range = new NumberAxis(this.graficoID[0]);
/*  99 */     XYPlot xyplot = new XYPlot(dataset, this.domain, this.range, new StandardXYItemRenderer());
/* 100 */     xyplot.setBackgroundPaint(Color.white);
/* 101 */     XYItemRenderer renderer = xyplot.getRenderer();
/* 102 */     renderer.setSeriesPaint(0, Color.red);
/* 103 */     renderer.setSeriesPaint(1, Color.black);
/* 104 */     this.domain.setAutoRange(true);
/* 105 */     this.domain.setLowerMargin(0.0D);
/* 106 */     this.domain.setUpperMargin(0.0D);
/* 107 */     this.domain.setTickLabelsVisible(true);
/* 108 */     this.range.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
/* 109 */     this.chart = new JFreeChart(this.graficoID[0], 
/* 110 */       JFreeChart.DEFAULT_TITLE_FONT, xyplot, true);
/* 111 */     this.chart.setBackgroundPaint(new Color(230, 230, 230));
/* 112 */     ChartPanel chartPanel = new ChartPanel(this.chart, false, true, true, false, true);
/* 113 */     add(chartPanel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 122 */     this.domain.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString("Tempo"));
/* 123 */     this.range.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString("Potencia"));
/* 124 */     this.chart.setTitle(ResourceBundle.getBundle(Idioma.getIdioma()).getString("POTENCIA"));
/* 125 */     this.free.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString("PotenciaReal"));
/* 126 */     this.valores.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString("PotenciaAparente"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopChart()
/*     */   {
/* 135 */     this.cont = 0;
/* 136 */     this.free.clear();
/* 137 */     this.valores.clear();
/* 138 */     this.flag = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void restartChart()
/*     */   {
/* 147 */     this.flag = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(double potReal, double potAp)
/*     */   {
/* 161 */     if (!this.flag)
/*     */     {
/* 163 */       this.cont += 1;
/* 164 */       addFreeObservation(potReal);
/* 165 */       addTotalObservation(potAp);
/* 166 */       if (this.cont == 1800)
/*     */       {
/* 168 */         this.free.clear();
/* 169 */         this.valores.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTotalObservation(Second d, double y)
/*     */   {
/*     */     try
/*     */     {
/* 187 */       if (!this.flag)
/*     */       {
/* 189 */         this.valores.add(d, y);
/*     */       }
/*     */     }
/*     */     catch (SeriesException localSeriesException) {}catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTotalObservation(double y)
/*     */   {
/* 208 */     addTotalObservation(new Second(), y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addFreeObservation(double y)
/*     */   {
/*     */     try
/*     */     {
/* 222 */       if (!this.flag) {
/* 223 */         this.free.add(new Second(), y);
/*     */       }
/*     */     }
/*     */     catch (SeriesException localSeriesException) {}catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\GraficoPotencia.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */