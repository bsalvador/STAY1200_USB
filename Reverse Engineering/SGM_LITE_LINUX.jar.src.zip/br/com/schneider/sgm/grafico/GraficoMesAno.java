/*     */ package br.com.schneider.sgm.grafico;
/*     */ 
/*     */ import br.com.schneider.sgm.config.PathConfig;
/*     */ import br.com.schneider.sgm.historico.HistoricoConsumo;
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.awt.GradientPaint;
/*     */ import java.util.ResourceBundle;
/*     */ import org.jfree.chart.ChartFactory;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.Legend;
/*     */ import org.jfree.chart.axis.CategoryAxis;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.plot.CategoryPlot;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.renderer.BarRenderer;
/*     */ import org.jfree.data.DefaultCategoryDataset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraficoMesAno
/*     */   extends Grafico
/*     */ {
/*     */   private static final long serialVersionUID = 8978898621505921552L;
/*     */   ChartPanel chartPanel;
/*     */   DefaultCategoryDataset dataset;
/*     */   private String[] meses;
/*     */   private String[] graficoID;
/*     */   private int cont;
/*     */   private NumberAxis rangeAxis;
/*     */   private JFreeChart chart;
/*     */   private double valorKW;
/*     */   private String ano;
/*     */   
/*     */   public GraficoMesAno(double valor)
/*     */   {
/*  87 */     this.valorKW = valor;
/*  88 */     this.meses = new String[13];
/*  89 */     this.meses[0] = ResourceBundle.getBundle(Idioma.getIdioma())
/*  90 */       .getString("Jan");
/*  91 */     this.meses[1] = ResourceBundle.getBundle(Idioma.getIdioma())
/*  92 */       .getString("Fev");
/*  93 */     this.meses[2] = ResourceBundle.getBundle(Idioma.getIdioma())
/*  94 */       .getString("Mar");
/*  95 */     this.meses[3] = ResourceBundle.getBundle(Idioma.getIdioma())
/*  96 */       .getString("Abr");
/*  97 */     this.meses[4] = ResourceBundle.getBundle(Idioma.getIdioma())
/*  98 */       .getString("Mai");
/*  99 */     this.meses[5] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 100 */       .getString("Jun");
/* 101 */     this.meses[6] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 102 */       .getString("Jul");
/* 103 */     this.meses[7] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 104 */       .getString("Ago");
/* 105 */     this.meses[8] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 106 */       .getString("Set");
/* 107 */     this.meses[9] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 108 */       .getString("Out");
/* 109 */     this.meses[10] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 110 */       "Nov");
/* 111 */     this.meses[11] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 112 */       "Dez");
/* 113 */     this.meses[12] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 114 */       "Med");
/* 115 */     this.graficoID = new String[5];
/* 116 */     this.graficoID[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 117 */       "CONSUMO_ANUAL");
/* 118 */     this.graficoID[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 119 */       "Tempo");
/* 120 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 121 */       "Consumo");
/* 122 */     this.graficoID[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 123 */       "media");
/* 124 */     this.graficoID[4] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 125 */       "Consumo");
/* 126 */     this.dataset = new DefaultCategoryDataset();
/* 127 */     this.dataset.addValue(0.0D, this.graficoID[3], this.meses[12]);
/* 128 */     for (int i = 0; i < 12; i++) {
/* 129 */       this.dataset.addValue(0.0D, "valor (R$)", this.meses[i]);
/* 130 */       this.dataset.addValue(0.0D, this.graficoID[4], this.meses[i]);
/*     */     }
/* 132 */     this.chart = ChartFactory.createBarChart(this.graficoID[0], 
/*     */     
/* 134 */       this.graficoID[1], 
/* 135 */       null, 
/* 136 */       this.dataset, 
/* 137 */       PlotOrientation.HORIZONTAL, true, 
/* 138 */       true, 
/* 139 */       false);
/*     */     
/* 141 */     Legend leg = this.chart.getLegend();
/* 142 */     leg.setAnchor(2);
/* 143 */     CategoryPlot plot = this.chart.getCategoryPlot();
/* 144 */     this.rangeAxis = ((NumberAxis)plot.getRangeAxis());
/* 145 */     this.rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
/* 146 */     BarRenderer renderer = (BarRenderer)plot.getRenderer();
/* 147 */     renderer.setDrawBarOutline(true);
/* 148 */     GradientPaint gp0 = new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 
/* 149 */       0.0F, Color.lightGray);
/* 150 */     GradientPaint gp1 = new GradientPaint(0.0F, 0.0F, Color.green, 0.0F, 
/* 151 */       0.0F, Color.lightGray);
/* 152 */     GradientPaint gp2 = new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 
/* 153 */       0.0F, Color.lightGray);
/* 154 */     renderer.setSeriesPaint(0, gp0);
/* 155 */     renderer.setSeriesPaint(1, gp1);
/* 156 */     renderer.setSeriesPaint(2, gp2);
/* 157 */     this.chart.setBackgroundPaint(new Color(230, 230, 230));
/* 158 */     ChartPanel chartPanel = new ChartPanel(this.chart, false, true, true, false, 
/* 159 */       true);
/* 160 */     add(chartPanel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double[] passaValores()
/*     */   {
/* 170 */     double[] d = new double[13];
/* 171 */     for (int i = 0; i < 11; i++) {
/* 172 */       d[i] = this.dataset.getValue(this.graficoID[2], this.meses[i]).doubleValue();
/*     */     }
/* 174 */     if (this.dataset.getValue(this.graficoID[3], this.meses[12]).equals(new Double(NaN.0D))) {
/* 175 */       d[12] = 0.0D;
/*     */     } else
/* 177 */       d[12] = this.dataset.getValue(this.graficoID[3], this.meses[12]).doubleValue();
/* 178 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 186 */     this.chart.setTitle(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 187 */       "CONSUMO_ANUAL"));
/* 188 */     this.chart.getCategoryPlot().getDomainAxis()
/* 189 */       .setLabel(
/* 190 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 191 */       "Tempo"));
/* 192 */     float[] aux = new float[12];
/* 193 */     for (int i = 0; i < 11; i++) {
/* 194 */       aux[i] = this.dataset.getValue(this.graficoID[2], this.meses[i]).floatValue();
/*     */     }
/* 196 */     this.dataset.clear();
/* 197 */     this.meses[0] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 198 */       .getString("Jan");
/* 199 */     this.meses[1] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 200 */       .getString("Fev");
/* 201 */     this.meses[2] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 202 */       .getString("Mar");
/* 203 */     this.meses[3] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 204 */       .getString("Abr");
/* 205 */     this.meses[4] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 206 */       .getString("Mai");
/* 207 */     this.meses[5] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 208 */       .getString("Jun");
/* 209 */     this.meses[6] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 210 */       .getString("Jul");
/* 211 */     this.meses[7] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 212 */       .getString("Ago");
/* 213 */     this.meses[8] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 214 */       .getString("Set");
/* 215 */     this.meses[9] = ResourceBundle.getBundle(Idioma.getIdioma())
/* 216 */       .getString("Out");
/* 217 */     this.meses[10] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 218 */       "Nov");
/* 219 */     this.meses[11] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 220 */       "Dez");
/* 221 */     this.meses[12] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 222 */       "Med");
/* 223 */     this.graficoID[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 224 */       "media");
/* 225 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 226 */       "Consumo");
/* 227 */     this.dataset.addValue(0.0D, this.graficoID[3], this.meses[12]);
/* 228 */     for (int i = 0; i < 12; i++) {
/* 229 */       this.dataset.addValue(aux[i] * this.valorKW, "valor (R$)", this.meses[i]);
/* 230 */       this.dataset.addValue(aux[i], this.graficoID[2], this.meses[i]);
/*     */     }
/* 232 */     media();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValorKW(double d)
/*     */   {
/* 242 */     this.valorKW = d;
/* 243 */     setValor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValor()
/*     */   {
/* 252 */     for (int i = 0; i < 11; i++) {
/* 253 */       float f = this.dataset.getValue(this.graficoID[2], this.meses[i]).floatValue();
/* 254 */       this.dataset.addValue(f * this.valorKW, "valor (R$)", this.meses[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(double d, int mes)
/*     */   {
/* 267 */     this.dataset.addValue(d, this.graficoID[4], this.meses[mes]);
/* 268 */     this.dataset.addValue(d * this.valorKW, "valor (R$)", this.meses[mes]);
/* 269 */     media();
/* 270 */     this.rangeAxis.setUpperMargin(0.2D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAno(String str)
/*     */   {
/* 280 */     this.ano = str;
/* 281 */     leXML();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAno()
/*     */   {
/* 290 */     String[] aux = this.ano.split("-");
/* 291 */     return Integer.parseInt(aux[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void leXML()
/*     */   {
/* 299 */     for (int i = 0; i < 12; i++)
/* 300 */       addValue(0.0D, i);
/* 301 */     HistoricoConsumo h = new HistoricoConsumo(PathConfig.getPathXML() + "consumo.xml");
/* 302 */     String[] data = { "01-", "02-", "03-", "04-", "05-", "06-", "07-", 
/* 303 */       "08-", "08-", "10-", "11-", "12-" };
/* 304 */     for (int j = 0; j < 12; j++) {
/* 305 */       int tmp141_140 = j; String[] tmp141_139 = data;tmp141_139[tmp141_140] = (tmp141_139[tmp141_140] + this.ano);
/*     */     }
/* 307 */     for (int i = 0; i < 12; i++)
/*     */     {
/* 309 */       if (h.getConsumoMensal(data[i]) != null) {
/* 310 */         addValue(Double.parseDouble(h.getConsumoMensal(data[i])), i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double media()
/*     */   {
/* 320 */     double aux = 0.0D;
/* 321 */     int cont = 0;
/* 322 */     for (int i = 0; i < 11; i++) {
/* 323 */       if (this.dataset.getValue(this.graficoID[2], this.meses[i]).doubleValue() != 0.0D) {
/* 324 */         cont++;
/* 325 */         aux += this.dataset.getValue(this.graficoID[2], this.meses[i]).doubleValue();
/*     */       }
/*     */     }
/* 328 */     aux /= cont;
/* 329 */     this.dataset.addValue(aux, this.graficoID[3], this.meses[12]);
/* 330 */     return aux;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultCategoryDataset getDataSet()
/*     */   {
/* 339 */     return this.dataset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void btnDireitaClick()
/*     */   {
/* 349 */     this.dataset.addValue(5.0D, this.graficoID[4], this.meses[(this.cont++)]);
/* 350 */     if (this.cont < 0)
/* 351 */       this.cont = 0;
/* 352 */     if (this.cont > 11) {
/* 353 */       this.cont = 11;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void btnEsquerdaClick()
/*     */   {
/* 363 */     this.dataset.addValue(0.0D, this.graficoID[4], this.meses[(this.cont--)]);
/* 364 */     if (this.cont < 0)
/* 365 */       this.cont = 0;
/* 366 */     if (this.cont > 11) {
/* 367 */       this.cont = 11;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultCategoryDataset createDataset()
/*     */   {
/* 377 */     this.dataset = new DefaultCategoryDataset();
/* 378 */     this.dataset.addValue(3.0D, this.graficoID[4], this.meses[12]);
/* 379 */     for (int i = 0; i < 12; i++)
/* 380 */       this.dataset.addValue(0.0D, this.graficoID[4], this.meses[i]);
/* 381 */     return this.dataset;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\GraficoMesAno.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */