/*     */ package br.com.schneider.sgm.grafico;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.util.ResourceBundle;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.DateAxis;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.StandardXYItemRenderer;
/*     */ import org.jfree.chart.renderer.XYItemRenderer;
/*     */ import org.jfree.data.SeriesException;
/*     */ import org.jfree.data.time.Second;
/*     */ import org.jfree.data.time.TimeSeries;
/*     */ import org.jfree.data.time.TimeSeriesCollection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraficoCorrente
/*     */   extends Grafico
/*     */ {
/*     */   private static final long serialVersionUID = 3051385519766054338L;
/*     */   private TimeSeries valores;
/*     */   private TimeSeries free;
/*     */   private String[] graficoID;
/*     */   private String tempo;
/*     */   private boolean flag;
/*     */   private DateAxis domain;
/*     */   private NumberAxis range;
/*     */   private JFreeChart chart;
/*     */   private int cont;
/*     */   
/*     */   public GraficoCorrente()
/*     */   {
/*  83 */     this.flag = false;
/*  84 */     this.graficoID = new String[4];
/*  85 */     this.graficoID[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  86 */       "entrada");
/*  87 */     this.graficoID[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  88 */       "saida");
/*  89 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  90 */       "Corrente_A");
/*  91 */     this.graficoID[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  92 */       "CORRENTE");
/*  93 */     this.tempo = ResourceBundle.getBundle(Idioma.getIdioma()).getString("Tempo");
/*  94 */     this.valores = new TimeSeries(this.graficoID[1], Second.class);
/*  95 */     this.valores.setHistoryCount(1000000000);
/*     */     
/*  97 */     this.free = new TimeSeries(this.graficoID[0], Second.class);
/*  98 */     this.free.setHistoryCount(1000000000);
/*  99 */     TimeSeriesCollection dataset = new TimeSeriesCollection();
/* 100 */     dataset.addSeries(this.free);
/* 101 */     dataset.addSeries(this.valores);
/* 102 */     this.domain = new DateAxis(this.tempo);
/* 103 */     this.range = new NumberAxis(this.graficoID[2]);
/* 104 */     XYPlot xyplot = new XYPlot(dataset, this.domain, this.range, 
/* 105 */       new StandardXYItemRenderer());
/* 106 */     xyplot.setBackgroundPaint(Color.white);
/* 107 */     XYItemRenderer renderer = xyplot.getRenderer();
/* 108 */     renderer.setSeriesPaint(0, Color.red);
/* 109 */     renderer.setSeriesPaint(1, Color.black);
/* 110 */     this.domain.setAutoRange(true);
/* 111 */     this.domain.setLowerMargin(0.0D);
/* 112 */     this.domain.setUpperMargin(0.0D);
/* 113 */     this.domain.setTickLabelsVisible(true);
/* 114 */     this.range.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
/* 115 */     this.chart = new JFreeChart(this.graficoID[3], JFreeChart.DEFAULT_TITLE_FONT, 
/* 116 */       xyplot, true);
/* 117 */     this.chart.setBackgroundPaint(new Color(230, 230, 230));
/* 118 */     ChartPanel chartPanel = new ChartPanel(this.chart, false, true, true, false, 
/* 119 */       true);
/* 120 */     add(chartPanel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 129 */     this.free.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 130 */       "entrada"));
/* 131 */     this.valores.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 132 */       "saida"));
/* 133 */     this.domain.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 134 */       "Tempo"));
/* 135 */     this.range.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 136 */       "Corrente_A"));
/* 137 */     this.chart.setTitle(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 138 */       "CORRENTE"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopChart()
/*     */   {
/* 146 */     this.cont = 0;
/* 147 */     this.free.clear();
/* 148 */     this.valores.clear();
/* 149 */     this.flag = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void restartChart()
/*     */   {
/* 157 */     this.flag = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(double entrada, double saida)
/*     */   {
/* 170 */     if (!this.flag) {
/* 171 */       this.cont += 1;
/* 172 */       addTotalObservation(saida);
/* 173 */       addFreeObservation(entrada);
/* 174 */       if (this.cont == 1800) {
/* 175 */         this.free.clear();
/* 176 */         this.valores.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTotalObservation(double y)
/*     */   {
/*     */     try
/*     */     {
/* 190 */       if (!this.flag) {
/* 191 */         this.valores.add(new Second(), y);
/*     */       }
/*     */     }
/*     */     catch (SeriesException localSeriesException) {}catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addFreeObservation(double y)
/*     */   {
/*     */     try
/*     */     {
/* 207 */       if (!this.flag) {
/* 208 */         this.free.add(new Second(), y);
/*     */       }
/*     */     }
/*     */     catch (SeriesException localSeriesException) {}catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\GraficoCorrente.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */