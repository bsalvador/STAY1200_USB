/*     */ package br.com.schneider.sgm.grafico;
/*     */ 
/*     */ import br.com.schneider.sgm.config.PathConfig;
/*     */ import br.com.schneider.sgm.historico.HistoricoConsumo;
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.awt.GradientPaint;
/*     */ import java.util.ResourceBundle;
/*     */ import org.jfree.chart.ChartFactory;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.Legend;
/*     */ import org.jfree.chart.axis.CategoryAxis;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
/*     */ import org.jfree.chart.plot.CategoryPlot;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.renderer.BarRenderer;
/*     */ import org.jfree.data.DefaultCategoryDataset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraficoSemanaMes
/*     */   extends Grafico
/*     */ {
/*     */   private static final long serialVersionUID = 336793293486203969L;
/*     */   private String[] semanas;
/*     */   private String mes;
/*     */   private DefaultCategoryDataset dataset;
/*     */   private String[] graficoID;
/*     */   private NumberAxis rangeAxis;
/*     */   private JFreeChart chart;
/*     */   private double valorKW;
/*     */   
/*     */   public GraficoSemanaMes(double valorKW)
/*     */   {
/*  78 */     this.valorKW = valorKW;
/*  79 */     this.semanas = new String[6];
/*  80 */     this.semanas[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  81 */       "sem_1");
/*  82 */     this.semanas[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  83 */       "sem_2");
/*  84 */     this.semanas[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  85 */       "sem_3");
/*  86 */     this.semanas[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  87 */       "sem_4");
/*  88 */     this.semanas[4] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  89 */       "sem_5");
/*  90 */     this.semanas[5] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  91 */       "media");
/*  92 */     this.graficoID = new String[4];
/*  93 */     this.graficoID[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  94 */       "CONSUMO_MENSAL");
/*  95 */     this.graficoID[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  96 */       "Tempo");
/*  97 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  98 */       "Consumo");
/*  99 */     this.graficoID[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 100 */       "media");
/* 101 */     this.dataset = new DefaultCategoryDataset();
/* 102 */     this.dataset.addValue(0.0D, this.graficoID[3], this.semanas[5]);
/* 103 */     for (int i = 0; i < 5; i++) {
/* 104 */       this.dataset.addValue(500.0D, "valor", this.semanas[i]);
/* 105 */       this.dataset.addValue(0.0D, this.graficoID[2], this.semanas[i]);
/*     */     }
/* 107 */     this.chart = ChartFactory.createBarChart(this.graficoID[0], 
/*     */     
/* 109 */       this.graficoID[1], 
/* 110 */       null, 
/* 111 */       this.dataset, 
/* 112 */       PlotOrientation.HORIZONTAL, true, 
/* 113 */       true, 
/* 114 */       false);
/*     */     
/* 116 */     Legend leg = this.chart.getLegend();
/* 117 */     leg.setAnchor(2);
/* 118 */     CategoryPlot plot = this.chart.getCategoryPlot();
/* 119 */     this.rangeAxis = ((NumberAxis)plot.getRangeAxis());
/* 120 */     this.rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
/* 121 */     BarRenderer renderer = (BarRenderer)plot.getRenderer();
/*     */     
/*     */ 
/*     */ 
/* 125 */     StandardCategoryItemLabelGenerator std = new StandardCategoryItemLabelGenerator();
/* 126 */     std.generateToolTip(this.dataset, 1, 1);
/* 127 */     renderer.setLabelGenerator(std);
/* 128 */     renderer.setItemLabelsVisible(true);
/* 129 */     renderer.setDrawBarOutline(false);
/* 130 */     renderer.setMaxBarWidth(1.0D);
/* 131 */     GradientPaint gp0 = new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 
/* 132 */       0.0F, Color.lightGray);
/* 133 */     GradientPaint gp1 = new GradientPaint(0.0F, 0.0F, Color.green, 0.0F, 
/* 134 */       0.0F, Color.lightGray);
/* 135 */     GradientPaint gp2 = new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 
/* 136 */       0.0F, Color.lightGray);
/* 137 */     renderer.setSeriesPaint(0, gp0);
/* 138 */     renderer.setSeriesPaint(1, gp1);
/* 139 */     renderer.setSeriesPaint(2, gp2);
/* 140 */     this.chart.setBackgroundPaint(new Color(230, 230, 230));
/* 141 */     ChartPanel chartPanel = new ChartPanel(this.chart, false, true, true, false, 
/* 142 */       true);
/* 143 */     add(chartPanel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValorKW(double d)
/*     */   {
/* 153 */     this.valorKW = d;
/* 154 */     setValor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValor()
/*     */   {
/* 163 */     for (int i = 0; i < 5; i++) {
/* 164 */       float f = this.dataset.getValue(this.graficoID[2], this.semanas[i]).floatValue();
/* 165 */       this.dataset.addValue(f * this.valorKW, "valor (R$)", this.semanas[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 174 */     this.chart.setTitle(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 175 */       "CONSUMO_MENSAL"));
/* 176 */     this.chart.getCategoryPlot().getDomainAxis()
/* 177 */       .setLabel(
/* 178 */       ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 179 */       "Tempo"));
/* 180 */     float[] aux = new float[5];
/* 181 */     for (int i = 0; i < 5; i++) {
/* 182 */       aux[i] = this.dataset.getValue(this.graficoID[2], this.semanas[i]).floatValue();
/*     */     }
/* 184 */     this.dataset.clear();
/* 185 */     this.semanas[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 186 */       "sem_1");
/* 187 */     this.semanas[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 188 */       "sem_2");
/* 189 */     this.semanas[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 190 */       "sem_3");
/* 191 */     this.semanas[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 192 */       "sem_4");
/* 193 */     this.semanas[4] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 194 */       "sem_5");
/* 195 */     this.semanas[5] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 196 */       "media");
/* 197 */     this.graficoID[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 198 */       "media");
/* 199 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 200 */       "Consumo");
/* 201 */     this.dataset.addValue(0.0D, this.graficoID[3], this.semanas[5]);
/* 202 */     for (int i = 0; i < 5; i++) {
/* 203 */       this.dataset.addValue(aux[i] * this.valorKW, "valor (R$)", this.semanas[i]);
/* 204 */       this.dataset.addValue(aux[i], this.graficoID[2], this.semanas[i]);
/*     */     }
/* 206 */     media();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double media()
/*     */   {
/* 215 */     double aux = 0.0D;
/* 216 */     int cont = 0;
/* 217 */     for (int i = 0; i < 5; i++) {
/* 218 */       if (this.dataset.getValue(this.graficoID[2], this.semanas[i]).doubleValue() != 0.0D) {
/* 219 */         cont++;
/* 220 */         aux += this.dataset.getValue(this.graficoID[2], this.semanas[i]).doubleValue();
/*     */       }
/*     */     }
/* 223 */     aux /= cont;
/* 224 */     this.dataset.addValue(aux, this.graficoID[3], this.semanas[5]);
/* 225 */     return aux;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMes(String str)
/*     */   {
/* 235 */     this.mes = str;
/* 236 */     leXML();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMes()
/*     */   {
/* 245 */     String[] aux = this.mes.split("-");
/* 246 */     return Integer.parseInt(aux[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void leXML()
/*     */   {
/* 255 */     for (int i = 0; i < 5; i++)
/* 256 */       addValue(0.0D, i);
/* 257 */     HistoricoConsumo h = new HistoricoConsumo(PathConfig.getPathXML() + "consumo.xml");
/* 258 */     String[] result = h.getConsumoSemanal(this.mes).split(", ");
/* 259 */     String[] valor = new String[5];
/*     */     
/* 261 */     for (int j = 0; j < result.length; j++)
/*     */     {
/*     */       try
/*     */       {
/* 265 */         for (int i = 0; i < result.length; i++)
/*     */         {
/*     */ 
/* 268 */           String[] aux = result[i].split("=");
/* 269 */           String[] aux0 = aux[0].split("-");
/* 270 */           valor[i] = aux[1];
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 276 */           int a = Integer.valueOf(aux0[2]).intValue();
/* 277 */           if (valor[i] != null) {
/* 278 */             addValue(
/* 279 */               Double.parseDouble(valor[i]), 
/* 280 */               a - 1);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(double d, int semana)
/*     */   {
/* 298 */     this.dataset.addValue(d, this.graficoID[2], this.semanas[semana]);
/* 299 */     this.dataset.addValue(d * this.valorKW, "valor (R$)", this.semanas[semana]);
/* 300 */     media();
/* 301 */     this.rangeAxis.setUpperMargin(0.2D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultCategoryDataset getDataSet()
/*     */   {
/* 310 */     return this.dataset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultCategoryDataset createDataset()
/*     */   {
/* 320 */     this.dataset = new DefaultCategoryDataset();
/* 321 */     this.dataset.addValue(3.0D, this.graficoID[2], this.semanas[12]);
/* 322 */     for (int i = 0; i < 5; i++)
/* 323 */       this.dataset.addValue(0.0D, this.graficoID[2], this.semanas[i]);
/* 324 */     return this.dataset;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\GraficoSemanaMes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */