/*     */ package br.com.schneider.sgm.grafico;
/*     */ 
/*     */ import br.com.schneider.sgm.config.PathConfig;
/*     */ import br.com.schneider.sgm.historico.HistoricoConsumo;
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.util.ResourceBundle;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.DateAxis;
/*     */ import org.jfree.chart.axis.DateTickUnit;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.StandardXYItemRenderer;
/*     */ import org.jfree.chart.renderer.XYItemRenderer;
/*     */ import org.jfree.data.time.Day;
/*     */ import org.jfree.data.time.TimeSeries;
/*     */ import org.jfree.data.time.TimeSeriesCollection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraficoDiaMes
/*     */   extends Grafico
/*     */ {
/*     */   private static final long serialVersionUID = 2506725394841029557L;
/*     */   private TimeSeries free;
/*     */   private TimeSeries valores;
/*     */   private String[] graficoID;
/*     */   private String tempo;
/*     */   private DateAxis domain;
/*     */   private NumberAxis range;
/*     */   private JFreeChart chart;
/*     */   private TimeSeriesCollection dataset;
/*     */   private double valorKW;
/*     */   private String mes;
/*     */   
/*     */   public GraficoDiaMes(double valor)
/*     */   {
/*  93 */     this.valorKW = valor;
/*  94 */     this.graficoID = new String[4];
/*  95 */     this.graficoID[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  96 */       "Consumo");
/*  97 */     this.graficoID[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  98 */       "CONSUMO_DIARIO");
/*  99 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString("valor");
/* 100 */     this.tempo = ResourceBundle.getBundle(Idioma.getIdioma()).getString("Tempo");
/* 101 */     this.valores = new TimeSeries(this.graficoID[2], Day.class);
/* 102 */     this.valores.setHistoryCount(1000000000);
/*     */     
/* 104 */     this.free = new TimeSeries(this.graficoID[0], Day.class);
/* 105 */     this.free.setHistoryCount(1000000000);
/*     */     
/* 107 */     this.dataset = new TimeSeriesCollection();
/* 108 */     this.dataset.addSeries(this.free);
/* 109 */     this.dataset.addSeries(this.valores);
/*     */     
/* 111 */     this.domain = new DateAxis(this.tempo);
/* 112 */     this.range = new NumberAxis();
/* 113 */     XYPlot xyplot = new XYPlot(this.dataset, this.domain, this.range, 
/* 114 */       new StandardXYItemRenderer());
/* 115 */     xyplot.setBackgroundPaint(Color.white);
/* 116 */     XYItemRenderer renderer = xyplot.getRenderer();
/* 117 */     renderer.setSeriesPaint(0, Color.red);
/* 118 */     renderer.setSeriesPaint(1, Color.black);
/* 119 */     this.domain.setTickUnit(new DateTickUnit(2, 2));
/* 120 */     this.domain.setAutoRange(true);
/* 121 */     this.domain.setLowerMargin(0.0D);
/* 122 */     this.domain.setUpperMargin(0.0D);
/* 123 */     this.domain.setTickLabelsVisible(true);
/*     */     
/* 125 */     this.range.setLowerMargin(0.0D);
/* 126 */     this.range.setUpperMargin(0.0D);
/* 127 */     this.range.setAutoRange(true);
/* 128 */     this.range.setTickLabelsVisible(true);
/* 129 */     this.range.setStandardTickUnits(NumberAxis.createStandardTickUnits());
/*     */     
/* 131 */     this.chart = new JFreeChart(this.graficoID[1], JFreeChart.DEFAULT_TITLE_FONT, 
/* 132 */       xyplot, true);
/* 133 */     this.chart.setBackgroundPaint(new Color(230, 230, 230));
/* 134 */     ChartPanel chartPanel = new ChartPanel(this.chart, false, true, true, false, 
/* 135 */       true);
/* 136 */     add(chartPanel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMes(String str)
/*     */   {
/* 146 */     this.mes = str;
/* 147 */     leXML();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMes()
/*     */   {
/* 156 */     String[] aux = this.mes.split("-");
/* 157 */     return Integer.parseInt(aux[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void leXML()
/*     */   {
/* 165 */     this.free.clear();
/* 166 */     this.valores.clear();
/* 167 */     HistoricoConsumo h = new HistoricoConsumo(PathConfig.getPathXML() + "consumo.xml");
/* 168 */     String[] resultado = h.getConsumoDiario(this.mes).split(", ");
/*     */     
/*     */     try
/*     */     {
/* 172 */       for (int i = 0; i < resultado.length; i++) {
/* 173 */         String[] valor = resultado[i].split("=");
/* 174 */         String[] dia = valor[0].split("-");
/* 175 */         addFreeObservation(new Day(Integer.parseInt(dia[2]), 
/* 176 */           Integer.parseInt(dia[1]), Integer.parseInt(dia[0])), 
/* 177 */           Double.parseDouble(valor[1]));
/* 178 */         addTotalObservation(new Day(Integer.parseInt(dia[2]), 
/* 179 */           Integer.parseInt(dia[1]), Integer.parseInt(dia[0])), 
/* 180 */           Double.parseDouble(valor[1]) * this.valorKW);
/*     */       }
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 192 */     this.free.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 193 */       "Consumo"));
/* 194 */     this.domain.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 195 */       "Tempo"));
/*     */     
/* 197 */     this.chart.setTitle(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 198 */       "CONSUMO_DIARIO"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addFreeObservation(Day d, double y)
/*     */   {
/* 211 */     this.free.add(d, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(double d)
/*     */   {
/* 221 */     addFreeObservation(d);
/* 222 */     addTotalObservation(d * this.valorKW);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValorKW(double d)
/*     */   {
/* 232 */     this.valorKW = d;
/* 233 */     this.free.clear();
/* 234 */     this.valores.clear();
/* 235 */     leXML();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTotalObservation(Day d, double y)
/*     */   {
/* 248 */     this.valores.add(d, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTotalObservation(double y)
/*     */   {
/* 258 */     this.valores.add(new Day(), y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addFreeObservation(double y)
/*     */   {
/* 268 */     this.free.add(new Day(), y);
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\GraficoDiaMes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */