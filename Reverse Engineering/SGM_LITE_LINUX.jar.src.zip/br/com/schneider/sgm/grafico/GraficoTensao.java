/*     */ package br.com.schneider.sgm.grafico;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.util.ResourceBundle;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.DateAxis;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.StandardXYItemRenderer;
/*     */ import org.jfree.chart.renderer.XYItemRenderer;
/*     */ import org.jfree.data.SeriesException;
/*     */ import org.jfree.data.time.Second;
/*     */ import org.jfree.data.time.TimeSeries;
/*     */ import org.jfree.data.time.TimeSeriesCollection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraficoTensao
/*     */   extends Grafico
/*     */ {
/*     */   private static final long serialVersionUID = 1939925865859888570L;
/*     */   private TimeSeriesCollection dataset;
/*     */   private TimeSeries valores;
/*     */   private TimeSeries free;
/*     */   private String[] graficoID;
/*     */   private String tempo;
/*     */   private boolean flag;
/*     */   private DateAxis domain;
/*     */   private NumberAxis range;
/*     */   private JFreeChart chart;
/*     */   private int cont;
/*     */   
/*     */   public GraficoTensao()
/*     */   {
/*  88 */     this.flag = false;
/*  89 */     this.graficoID = new String[4];
/*  90 */     this.graficoID[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  91 */       "entrada");
/*  92 */     this.graficoID[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  93 */       "saida");
/*  94 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  95 */       "Tensao_V");
/*  96 */     this.graficoID[3] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  97 */       "TENSAO");
/*  98 */     this.tempo = ResourceBundle.getBundle(Idioma.getIdioma()).getString("Tempo");
/*  99 */     this.valores = new TimeSeries(this.graficoID[1], Second.class);
/* 100 */     this.valores.setHistoryCount(1000000000);
/* 101 */     this.free = new TimeSeries(this.graficoID[0], Second.class);
/* 102 */     this.free.setHistoryCount(1000000000);
/* 103 */     this.dataset = new TimeSeriesCollection();
/* 104 */     this.dataset.addSeries(this.free);
/* 105 */     this.dataset.addSeries(this.valores);
/* 106 */     this.domain = new DateAxis(this.tempo);
/* 107 */     this.range = new NumberAxis(this.graficoID[2]);
/* 108 */     XYPlot xyplot = new XYPlot(this.dataset, this.domain, this.range, 
/* 109 */       new StandardXYItemRenderer());
/* 110 */     xyplot.setBackgroundPaint(Color.white);
/* 111 */     XYItemRenderer renderer = xyplot.getRenderer();
/* 112 */     renderer.setSeriesPaint(0, Color.red);
/* 113 */     renderer.setSeriesPaint(1, Color.black);
/* 114 */     this.domain.setAutoRange(true);
/* 115 */     this.domain.setLowerMargin(0.0D);
/* 116 */     this.domain.setUpperMargin(0.0D);
/* 117 */     this.domain.setTickLabelsVisible(true);
/* 118 */     this.range.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
/* 119 */     this.chart = new JFreeChart(this.graficoID[3], JFreeChart.DEFAULT_TITLE_FONT, 
/* 120 */       xyplot, true);
/* 121 */     this.chart.setBackgroundPaint(new Color(230, 230, 230));
/* 122 */     ChartPanel chartPanel = new ChartPanel(this.chart, false, true, true, false, 
/* 123 */       true);
/* 124 */     add(chartPanel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 132 */     this.free.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 133 */       "entrada"));
/* 134 */     this.valores.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 135 */       "saida"));
/* 136 */     this.domain.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 137 */       "Tempo"));
/* 138 */     this.range.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 139 */       "Tensao_V"));
/* 140 */     this.chart.setTitle(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 141 */       "TENSAO"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopChart()
/*     */   {
/* 149 */     this.free.clear();
/* 150 */     this.valores.clear();
/* 151 */     this.cont = 0;
/* 152 */     this.flag = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void restartChart()
/*     */   {
/* 160 */     this.flag = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(double entrada, double saida)
/*     */   {
/* 173 */     if (!this.flag) {
/* 174 */       this.cont += 1;
/* 175 */       addTotalObservation(saida);
/* 176 */       addFreeObservation(entrada);
/* 177 */       if (this.cont == 1800)
/*     */       {
/* 179 */         this.free.clear();
/* 180 */         this.valores.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTotalObservation(double y)
/*     */   {
/*     */     try
/*     */     {
/* 194 */       if (!this.flag) {
/* 195 */         this.valores.add(new Second(), y);
/*     */       }
/*     */     }
/*     */     catch (SeriesException localSeriesException) {}catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addFreeObservation(double y)
/*     */   {
/*     */     try
/*     */     {
/* 211 */       if (!this.flag) {
/* 212 */         this.free.add(new Second(), y);
/*     */       }
/*     */     }
/*     */     catch (SeriesException localSeriesException) {}catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\GraficoTensao.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */