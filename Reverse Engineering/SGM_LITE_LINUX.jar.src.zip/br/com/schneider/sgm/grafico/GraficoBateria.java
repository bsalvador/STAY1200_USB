/*     */ package br.com.schneider.sgm.grafico;
/*     */ 
/*     */ import br.com.schneider.sgm.internacionalizacao.Idioma;
/*     */ import java.awt.Color;
/*     */ import java.util.ResourceBundle;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.DateAxis;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.StandardXYItemRenderer;
/*     */ import org.jfree.chart.renderer.XYItemRenderer;
/*     */ import org.jfree.data.SeriesException;
/*     */ import org.jfree.data.time.Second;
/*     */ import org.jfree.data.time.TimeSeries;
/*     */ import org.jfree.data.time.TimeSeriesCollection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraficoBateria
/*     */   extends Grafico
/*     */ {
/*     */   private static final long serialVersionUID = 1006930403322845027L;
/*     */   private TimeSeries free;
/*     */   private String[] graficoID;
/*     */   private String tempo;
/*     */   private boolean flag;
/*     */   private DateAxis domain;
/*     */   private NumberAxis range;
/*     */   private JFreeChart chart;
/*     */   private int cont;
/*     */   
/*     */   public GraficoBateria()
/*     */   {
/*  81 */     this.flag = false;
/*  82 */     this.graficoID = new String[3];
/*  83 */     this.graficoID[0] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  84 */       "Tensao_V");
/*  85 */     this.graficoID[1] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  86 */       "BATERIA");
/*  87 */     this.graficoID[2] = ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/*  88 */       "Bateria");
/*  89 */     this.tempo = ResourceBundle.getBundle(Idioma.getIdioma()).getString("Tempo");
/*  90 */     this.free = new TimeSeries(this.graficoID[2], Second.class);
/*  91 */     this.free.setHistoryCount(10000);
/*  92 */     TimeSeriesCollection dataset = new TimeSeriesCollection();
/*  93 */     dataset.addSeries(this.free);
/*  94 */     this.domain = new DateAxis(this.tempo);
/*  95 */     this.range = new NumberAxis(this.graficoID[0]);
/*  96 */     XYPlot xyplot = new XYPlot(dataset, this.domain, this.range, 
/*  97 */       new StandardXYItemRenderer());
/*  98 */     xyplot.setBackgroundPaint(Color.white);
/*  99 */     XYItemRenderer renderer = xyplot.getRenderer();
/* 100 */     renderer.setSeriesPaint(0, Color.red);
/* 101 */     renderer.setSeriesPaint(1, Color.black);
/* 102 */     this.domain.setAutoRange(true);
/* 103 */     this.domain.setLowerMargin(0.0D);
/* 104 */     this.domain.setUpperMargin(0.0D);
/* 105 */     this.domain.setTickLabelsVisible(true);
/* 106 */     this.range.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
/* 107 */     this.chart = new JFreeChart(this.graficoID[1], JFreeChart.DEFAULT_TITLE_FONT, 
/* 108 */       xyplot, true);
/* 109 */     this.chart.setBackgroundPaint(new Color(230, 230, 230));
/* 110 */     ChartPanel chartPanel = new ChartPanel(this.chart, false, true, true, false, 
/* 111 */       true);
/* 112 */     add(chartPanel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validarIdioma()
/*     */   {
/* 121 */     this.domain.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 122 */       "Tempo"));
/* 123 */     this.range.setLabel(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 124 */       "Tensao_V"));
/* 125 */     this.chart.setTitle(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 126 */       "BATERIA"));
/* 127 */     this.free.setName(ResourceBundle.getBundle(Idioma.getIdioma()).getString(
/* 128 */       "Bateria"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopChart()
/*     */   {
/* 136 */     this.cont = 0;
/* 137 */     this.free.clear();
/* 138 */     this.flag = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void restartChart()
/*     */   {
/* 146 */     this.flag = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(double tensao)
/*     */   {
/* 157 */     if (!this.flag) {
/* 158 */       this.cont += 1;
/* 159 */       addFreeObservation(tensao);
/* 160 */       if (this.cont == 1800)
/*     */       {
/* 162 */         this.free.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addFreeObservation(double y)
/*     */   {
/*     */     try
/*     */     {
/* 176 */       if (!this.flag) {
/* 177 */         this.free.add(new Second(), y);
/*     */       }
/*     */     }
/*     */     catch (SeriesException localSeriesException) {}catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\grafico\GraficoBateria.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */