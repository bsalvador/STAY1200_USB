package br.com.schneider.sgm.ups;

import br.com.schneider.sgm.eventos.UPSListener;
import br.com.schneider.sgm.protocolo.ProtocoloUPS;

public abstract interface UPSDataObject
{
  public abstract int getAno();
  
  public abstract int getAutonomiaBateria();
  
  public abstract boolean isBateriaBaixa();
  
  public abstract boolean isBateriaCarregada();
  
  public abstract boolean isBateriaCritica();
  
  public abstract boolean isBateriaDescarregada();
  
  public abstract boolean isBypassAtivado();
  
  public abstract boolean isCargaElevada();
  
  public abstract boolean isCarregandoBateria();
  
  public abstract boolean isUsandoSomenteBateria();
  
  public abstract float getCorrenteEntrada();
  
  public abstract float getCorrenteSaida();
  
  public abstract int getDiaMes();
  
  public abstract int getDiaSemana();
  
  public abstract boolean[] getDiasSemanaProgramados();
  
  public abstract boolean isEntradaLigada();
  
  public abstract int getExpansorBateria();
  
  public abstract float getFatorPotenciaCarga();
  
  public abstract float getFrequenciaEntrada();
  
  public abstract float getFrequenciaSaida();
  
  public abstract int getHora();
  
  public abstract int getHoraDesligar();
  
  public abstract int getHoraLigar();
  
  public abstract float getLimiteInferiorTensaoEntrada();
  
  public abstract float getLimiteInferiorTensaoSaida();
  
  public abstract float getLimiteSuperiorTensaoEntrada();
  
  public abstract float getLimiteSuperiorTensaoSaida();
  
  public abstract int getMes();
  
  public abstract int getMinutoDesligar();
  
  public abstract int getMinutoLigar();
  
  public abstract int getMinutos();
  
  public abstract boolean isModoBateria();
  
  public abstract boolean isModoBypass();
  
  public abstract boolean isModoRede();
  
  public abstract UPSListener getOuvinteUPS();
  
  public abstract int getPercentualBateria();
  
  public abstract float getPotenciaAparente();
  
  public abstract float getPotenciaReal();
  
  public abstract ProtocoloUPS getProtocoloUPS();
  
  public abstract boolean isSaidaLigada();
  
  public abstract int getSegundos();
  
  public abstract boolean isSobrecarga();
  
  public abstract boolean isSuperAquecimento();
  
  public abstract boolean isTemperaturaElevada();
  
  public abstract float getTemperaturaUPS();
  
  public abstract float getTensaoBateria();
  
  public abstract float getTensaoBoost();
  
  public abstract float getTensaoEntrada();
  
  public abstract float getTensaoEntradaNominal();
  
  public abstract boolean isTensaoEntrada220();
  
  public abstract float getTensaoSaida();
  
  public abstract boolean isTensaoSaida220();
  
  public abstract float getTensaoSaidaNominal();
  
  public abstract float getBateriaTensaoNominal();
  
  public abstract int getPotenciaNominalVA();
  
  public abstract int getPotenciaNominalW();
  
  public abstract float getTemperaturaCritica();
  
  public abstract int getFatorPotenciaEquipamento();
  
  public abstract boolean isTesteExecutando();
  
  public abstract float getFrequenciaBypass();
  
  public abstract float getTensaoBypass();
  
  public abstract float getCorrenteBypass();
  
  public abstract float getPotenciaBypass();
  
  public abstract boolean isTemperaturaAvaliable();
}


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\ups\UPSDataObject.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */