/*     */ package br.com.schneider.sgm.ups;
/*     */ 
/*     */ import br.com.schneider.sgm.eventos.Evento;
/*     */ import br.com.schneider.sgm.eventos.ProtocoloListener;
/*     */ import br.com.schneider.sgm.eventos.UPSListener;
/*     */ import br.com.schneider.sgm.protocolo.ProtocoloUPS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUPS
/*     */   implements ProtocoloListener, UPSDataObject
/*     */ {
/*     */   protected int modelo;
/*  28 */   protected int fatorPotenciaEquipamento = 700;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  33 */   protected float temperaturaCritica = 55.0F;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   protected int potenciaNominalVA = 1000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  43 */   protected int potenciaNominalW = 800;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   protected float bateriaTensaoNominal = 24.0F;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float tensaoEntradaNominal;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float tensaoEntrada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float correnteEntrada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float frequenciaEntrada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean tensaoEntrada220;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float limiteSuperiorTensaoEntrada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float limiteInferiorTensaoEntrada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float tensaoSaidaNominal;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float tensaoSaida;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float correnteSaida;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float frequenciaSaida;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean tensaoSaida220;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float limiteSuperiorTensaoSaida;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float limiteInferiorTensaoSaida;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float potenciaAparente;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float potenciaReal;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float fatorPotenciaCarga;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float tensaoBoost;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float temperaturaUPS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int percentualBateria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float tensaoBateria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int autonomiaBateria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int expansorBateria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean carregandoBateria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean modoBateria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean usandoSomenteBateria;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean modoRede;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 189 */   protected boolean modoBypass = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean superAquecimento;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean temperaturaElevada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean bateriaBaixa;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean bateriaCritica;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean bateriaDescarregada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean bateriaCarregada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean sobrecarga;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean cargaElevada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int segundos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int minutos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int hora;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int diaSemana;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int diaMes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int mes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int ano;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean[] diasSemanaProgramados;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int minutoLigar;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int horaLigar;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int minutoDesligar;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int horaDesligar;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean saidaLigada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean entradaLigada;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 305 */   protected boolean bypassAtivado = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UPSListener ouvinteUPS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ProtocoloUPS protocoloUPS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Evento[] eventos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean ligaEntrada();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean desligaEntrada();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean ligaSaida();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean desligaSaida();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean ativaBypass();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean desativaBypass();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean iniciarAutoteste();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean finalizarAutoteste();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean shutdown();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean shutdownReligamento();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void downloadEventos();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean configuraRelogio(int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean configuraCalendario(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean configuraCalendarioRelogio(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean programaSemana(boolean[] paramArrayOfBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUPSListener(UPSListener ouvinteUPS)
/*     */   {
/* 441 */     this.ouvinteUPS = ouvinteUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean programa(boolean[] paramArrayOfBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setAno(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setAutonomiaBateria(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setBateriaBaixa(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setBateriaCarregada(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setBateriaCritica(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setUsandoSomenteBateria(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setBateriaDescarregada(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setBypassAtivado(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setCargaElevada(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setCarregandoBateria(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setCorrenteEntrada(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setCorrenteSaida(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setDiaMes(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setDiaSemana(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setDiasSemanaProgramados(boolean[] paramArrayOfBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setEntradaLigada(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setExpansorBateria(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setFatorPotenciaCarga(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setFrequenciaEntrada(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setFrequenciaSaida(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setHora(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setHoraDesligar(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setHoraLigar(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setLimiteInferiorTensaoEntrada(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setLimiteInferiorTensaoSaida(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setLimiteSuperiorTensaoEntrada(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setLimiteSuperiorTensaoSaida(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setMes(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setMinutoDesligar(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setMinutoLigar(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setMinutos(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setModoBateria(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setModoBypass(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setModoRede(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setPercentualBateria(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setPotenciaAparente(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setPotenciaReal(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setSaidaLigada(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setSegundos(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setSobrecarga(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setSuperAquecimento(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTemperaturaElevada(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTemperaturaUPS(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoBateria(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoBoost(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoEntrada(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoEntradaNominal(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoEntrada220(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoSaida(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoSaidaNominal(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTensaoSaida220(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setFatorPotenciaEquipamento(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setTemperaturaCritica(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setPotenciaNominalVA(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setPotenciaNominalW(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setBateriaTensaoNominal(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProtocoloUPS(ProtocoloUPS protocoloUPS)
/*     */   {
/* 814 */     this.protocoloUPS = protocoloUPS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 820 */   public int getAno() { return this.ano; }
/*     */   
/* 822 */   public int getAutonomiaBateria() { return this.autonomiaBateria; }
/*     */   
/* 824 */   public boolean isBateriaBaixa() { return this.bateriaBaixa; }
/*     */   
/* 826 */   public boolean isBateriaCarregada() { return this.bateriaCarregada; }
/*     */   
/* 828 */   public boolean isBateriaCritica() { return this.bateriaCritica; }
/*     */   
/* 830 */   public boolean isBateriaDescarregada() { return this.bateriaDescarregada; }
/*     */   
/* 832 */   public boolean isBypassAtivado() { return this.bypassAtivado; }
/*     */   
/* 834 */   public boolean isCargaElevada() { return this.cargaElevada; }
/*     */   
/* 836 */   public boolean isCarregandoBateria() { return this.carregandoBateria; }
/*     */   
/* 838 */   public boolean isUsandoSomenteBateria() { return this.usandoSomenteBateria; }
/*     */   
/* 840 */   public float getCorrenteEntrada() { return this.correnteEntrada; }
/*     */   
/* 842 */   public float getCorrenteSaida() { return this.correnteSaida; }
/*     */   
/* 844 */   public int getDiaMes() { return this.diaMes; }
/*     */   
/* 846 */   public int getDiaSemana() { return this.diaSemana; }
/*     */   
/* 848 */   public boolean[] getDiasSemanaProgramados() { return this.diasSemanaProgramados; }
/*     */   
/* 850 */   public boolean isEntradaLigada() { return this.entradaLigada; }
/*     */   
/* 852 */   public int getExpansorBateria() { return this.expansorBateria; }
/*     */   
/* 854 */   public float getFatorPotenciaCarga() { return this.fatorPotenciaCarga; }
/*     */   
/* 856 */   public float getFrequenciaEntrada() { return this.frequenciaEntrada; }
/*     */   
/* 858 */   public float getFrequenciaSaida() { return this.frequenciaSaida; }
/*     */   
/* 860 */   public int getHora() { return this.hora; }
/*     */   
/* 862 */   public int getHoraDesligar() { return this.horaDesligar; }
/*     */   
/* 864 */   public int getHoraLigar() { return this.horaLigar; }
/*     */   
/* 866 */   public float getLimiteInferiorTensaoEntrada() { return this.limiteInferiorTensaoEntrada; }
/*     */   
/* 868 */   public float getLimiteInferiorTensaoSaida() { return this.limiteInferiorTensaoSaida; }
/*     */   
/* 870 */   public float getLimiteSuperiorTensaoEntrada() { return this.limiteSuperiorTensaoEntrada; }
/*     */   
/* 872 */   public float getLimiteSuperiorTensaoSaida() { return this.limiteSuperiorTensaoSaida; }
/*     */   
/* 874 */   public int getMes() { return this.mes; }
/*     */   
/* 876 */   public int getMinutoDesligar() { return this.minutoDesligar; }
/*     */   
/* 878 */   public int getMinutoLigar() { return this.minutoLigar; }
/*     */   
/* 880 */   public int getMinutos() { return this.minutos; }
/*     */   
/* 882 */   public boolean isModoBateria() { return this.modoBateria; }
/*     */   
/* 884 */   public boolean isModoBypass() { return this.modoBypass; }
/*     */   
/* 886 */   public boolean isModoRede() { return this.modoRede; }
/*     */   
/* 888 */   public UPSListener getOuvinteUPS() { return this.ouvinteUPS; }
/*     */   
/* 890 */   public int getPercentualBateria() { return this.percentualBateria; }
/*     */   
/* 892 */   public float getPotenciaAparente() { return this.potenciaAparente; }
/*     */   
/* 894 */   public float getPotenciaReal() { return this.potenciaReal; }
/*     */   
/* 896 */   public ProtocoloUPS getProtocoloUPS() { return this.protocoloUPS; }
/*     */   
/* 898 */   public boolean isSaidaLigada() { return this.saidaLigada; }
/*     */   
/* 900 */   public int getSegundos() { return this.segundos; }
/*     */   
/* 902 */   public boolean isSobrecarga() { return this.sobrecarga; }
/*     */   
/* 904 */   public boolean isSuperAquecimento() { return this.superAquecimento; }
/*     */   
/* 906 */   public boolean isTemperaturaElevada() { return this.temperaturaElevada; }
/*     */   
/* 908 */   public float getTemperaturaUPS() { return this.temperaturaUPS; }
/*     */   
/* 910 */   public float getTensaoBateria() { return this.tensaoBateria; }
/*     */   
/* 912 */   public float getTensaoBoost() { return this.tensaoBoost; }
/*     */   
/* 914 */   public float getTensaoEntrada() { return this.tensaoEntrada; }
/*     */   
/* 916 */   public float getTensaoEntradaNominal() { return this.tensaoEntradaNominal; }
/*     */   
/* 918 */   public boolean isTensaoEntrada220() { return this.tensaoEntrada220; }
/*     */   
/* 920 */   public float getTensaoSaida() { return this.tensaoSaida; }
/*     */   
/* 922 */   public boolean isTensaoSaida220() { return this.tensaoSaida220; }
/*     */   
/* 924 */   public float getTensaoSaidaNominal() { return this.tensaoSaidaNominal; }
/*     */   
/* 926 */   public float getBateriaTensaoNominal() { return this.bateriaTensaoNominal; }
/*     */   
/* 928 */   public int getPotenciaNominalVA() { return this.potenciaNominalVA; }
/*     */   
/* 930 */   public int getPotenciaNominalW() { return this.potenciaNominalW; }
/*     */   
/* 932 */   public float getTemperaturaCritica() { return this.temperaturaCritica; }
/*     */   
/* 934 */   public int getFatorPotenciaEquipamento() { return this.fatorPotenciaEquipamento; }
/*     */   
/* 936 */   public boolean isTesteExecutando() { return false; }
/*     */   
/* 938 */   public float getFrequenciaBypass() { return 0.0F; }
/*     */   
/* 940 */   public float getTensaoBypass() { return 0.0F; }
/*     */   
/* 942 */   public float getCorrenteBypass() { return 0.0F; }
/*     */   
/* 944 */   public float getPotenciaBypass() { return 0.0F; }
/*     */   
/* 946 */   public boolean isTemperaturaAvaliable() { return true; }
/*     */   
/* 948 */   public boolean isAutoTesteBateriaAvaliable() { return false; }
/*     */   
/* 950 */   public int calculaEstadoBaterias(float bateriaInicial, float bateriaFinal, float Potencia, int tempo) { return 0; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evento[] getEventos()
/*     */   {
/* 958 */     if (this.eventos != null) {
/* 959 */       Evento[] temp = (Evento[])this.eventos.clone();
/* 960 */       this.eventos = null;
/*     */       
/* 962 */       return temp;
/*     */     }
/*     */     
/*     */ 
/* 966 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getCabecalhoPacote()
/*     */   {
/* 972 */     return this.protocoloUPS.cabecalhoPacote;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\ups\AbstractUPS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */