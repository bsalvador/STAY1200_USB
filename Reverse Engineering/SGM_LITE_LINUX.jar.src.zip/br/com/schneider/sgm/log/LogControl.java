/*     */ package br.com.schneider.sgm.log;
/*     */ 
/*     */ import br.com.schneider.sgm.config.PathConfig;
/*     */ import br.com.schneider.sgm.controle.Controle;
/*     */ import br.com.schneider.sgm.eventos.ControleListener;
/*     */ import br.com.schneider.sgm.eventos.Evento;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ import org.jdom.output.Format;
/*     */ import org.jdom.output.XMLOutputter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogControl
/*     */   implements ControleListener
/*     */ {
/*     */   private Controle control;
/*     */   private float corrMinSaida;
/*     */   private float corrMaxSaida;
/*     */   private float corrMedSaida;
/*     */   private float tenMinSaida;
/*     */   private float tenMaxSaida;
/*     */   private float tenMedSaida;
/*     */   private float tenMinEnt;
/*     */   private float tenMaxEnt;
/*     */   private float tenMedEnt;
/*     */   private int contPacotesDados;
/*     */   private static final int MAX_COUNTING = 300;
/*     */   private Evento[] eventos;
/*  47 */   private boolean enableLogging = false;
/*  48 */   private DecimalFormat formatador = new DecimalFormat("000.00");
/*  49 */   private static final String fileVin = PathConfig.getPathXML() + "varVINlog.xml";
/*  50 */   private static final String fileVout = PathConfig.getPathXML() + "varVOUTlog.xml";
/*  51 */   private static final String fileCout = PathConfig.getPathXML() + "varCOUTlog.xml";
/*     */   
/*     */   public LogControl(Controle cntr)
/*     */   {
/*  55 */     this.control = cntr;
/*  56 */     this.corrMinSaida = 0.0F;
/*  57 */     this.corrMaxSaida = 0.0F;
/*  58 */     this.corrMedSaida = 0.0F;
/*     */     
/*  60 */     this.tenMinSaida = 0.0F;
/*  61 */     this.tenMaxSaida = 0.0F;
/*  62 */     this.tenMedSaida = 0.0F;
/*     */     
/*  64 */     this.tenMinEnt = 0.0F;
/*  65 */     this.tenMaxEnt = 0.0F;
/*  66 */     this.tenMedEnt = 0.0F;
/*     */     
/*  68 */     this.contPacotesDados = 0;
/*  69 */     this.eventos = new Evento[3];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogEnabled(boolean en)
/*     */   {
/*  80 */     this.enableLogging = en;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notificaDados()
/*     */   {
/*  91 */     Calendar calendar = new GregorianCalendar();
/*     */     
/*     */ 
/*  94 */     if (this.contPacotesDados == 0)
/*     */     {
/*  96 */       this.corrMinSaida = this.control.getCorrenteSaida();
/*  97 */       this.tenMinSaida = this.control.getTensaoSaida();
/*  98 */       this.tenMinEnt = this.control.getTensaoEntrada();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 103 */     if (this.corrMinSaida > this.control.getCorrenteSaida()) {
/* 104 */       this.corrMinSaida = this.control.getCorrenteSaida();
/*     */     }
/* 106 */     if (this.tenMinSaida > this.control.getTensaoSaida()) {
/* 107 */       this.tenMinSaida = this.control.getTensaoSaida();
/*     */     }
/* 109 */     if (this.tenMinEnt > this.control.getTensaoEntrada()) {
/* 110 */       this.tenMinEnt = this.control.getTensaoEntrada();
/*     */     }
/*     */     
/* 113 */     if (this.corrMaxSaida < this.control.getCorrenteSaida()) {
/* 114 */       this.corrMaxSaida = this.control.getCorrenteSaida();
/*     */     }
/* 116 */     if (this.tenMaxSaida < this.control.getTensaoSaida()) {
/* 117 */       this.tenMaxSaida = this.control.getTensaoSaida();
/*     */     }
/* 119 */     if (this.tenMaxEnt < this.control.getTensaoEntrada()) {
/* 120 */       this.tenMaxEnt = this.control.getTensaoEntrada();
/*     */     }
/* 122 */     this.contPacotesDados += 1;
/*     */     
/*     */ 
/*     */ 
/* 126 */     if (this.contPacotesDados == 300)
/*     */     {
/*     */ 
/* 129 */       this.contPacotesDados = 0;
/* 130 */       if (this.enableLogging)
/*     */       {
/* 132 */         int dia = calendar.get(5);
/* 133 */         int hora = calendar.get(11);
/* 134 */         int minuto = calendar.get(12);
/* 135 */         int mes = calendar.get(2);
/* 136 */         int ano = calendar.get(1);
/*     */         
/* 138 */         this.eventos[0] = new Evento("VENT (V)", hora, minuto, 0, dia, mes, ano);
/* 139 */         inserirEvento(fileVin, this.eventos[0], this.formatador.format(this.tenMinEnt), this.formatador.format(this.tenMaxEnt));
/* 140 */         this.eventos[1] = new Evento("VOUT (V)", hora, minuto, 0, dia, mes, ano);
/* 141 */         inserirEvento(fileVout, this.eventos[1], this.formatador.format(this.tenMinSaida), this.formatador.format(this.tenMaxSaida));
/* 142 */         this.eventos[2] = new Evento("COUT (A)", hora, minuto, 0, dia, mes, ano);
/* 143 */         inserirEvento(fileCout, this.eventos[2], this.formatador.format(this.corrMinSaida), this.formatador.format(this.corrMaxSaida));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized boolean inserirEvento(String filename, Evento e, String min, String max)
/*     */   {
/* 161 */     SAXBuilder builder = new SAXBuilder();
/*     */     try {
/* 163 */       File f = new File(filename);
/* 164 */       Document doc = builder.build(f);
/*     */       
/*     */ 
/* 167 */       Element evt = new Element("amostra");
/*     */       
/*     */ 
/* 170 */       evt.setAttribute("min", min);
/* 171 */       evt.setAttribute("max", max);
/* 172 */       evt.setAttribute("data", e.getAno() + "-" + e.getMes() + "-" + e.getDia());
/* 173 */       evt.setAttribute("hora", e.getHora() + ":" + e.getMinuto() + ":" + e.getSegundo());
/* 174 */       evt.setText(e.getTipo());
/*     */       
/*     */ 
/* 177 */       doc.getRootElement().addContent(evt);
/*     */       
/*     */ 
/* 180 */       XMLOutputter serializer = new XMLOutputter();
/* 181 */       serializer.setFormat(Format.getPrettyFormat());
/*     */       
/*     */ 
/* 184 */       serializer.output(doc, new FileWriter(f));
/*     */       
/* 186 */       return true;
/*     */     }
/*     */     catch (JDOMException jdomx)
/*     */     {
/* 190 */       criaArquivo(filename);
/*     */ 
/*     */     }
/*     */     catch (IOException iox)
/*     */     {
/*     */ 
/* 196 */       criaArquivo(filename);
/*     */     }
/*     */     
/* 199 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void criaArquivo(String filename)
/*     */   {
/*     */     try
/*     */     {
/* 208 */       BufferedWriter out = new BufferedWriter(new FileWriter(filename));
/* 209 */       out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<varlog xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"varlog.xsd\">\n</varlog>");
/*     */       
/*     */ 
/* 212 */       out.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */   public void notificaBateriaBaixa() {}
/*     */   
/*     */   public void notificaBateriaNormal() {}
/*     */   
/*     */   public void notificaCargaElevada() {}
/*     */   
/*     */   public void notificaCargaNormal() {}
/*     */   
/*     */   public void notificaComunicacao() {}
/*     */   
/*     */   public void notificaFalhaCom() {}
/*     */   
/*     */   public void notificaFalhaRede() {}
/*     */   
/*     */   public void notificaNaoUsaBateria() {}
/*     */   
/*     */   public void notificaRetornoCom() {}
/*     */   
/*     */   public void notificaRetornoRede() {}
/*     */   
/*     */   public void notificaTemperaturaElevada() {}
/*     */   
/*     */   public void notificaTemperaturaNormal() {}
/*     */   
/*     */   public void notificaUsandoBateria() {}
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\log\LogControl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */