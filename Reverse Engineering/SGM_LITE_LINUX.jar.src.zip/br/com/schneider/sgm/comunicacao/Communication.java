package br.com.schneider.sgm.comunicacao;

import br.com.schneider.sgm.eventos.DriverListener;
import gnu.io.SerialPort;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;

public abstract interface Communication
{
  public abstract boolean open(String[] paramArrayOfString);
  
  public abstract boolean close();
  
  public abstract BufferedInputStream getEntrada();
  
  public abstract BufferedOutputStream getSaida();
  
  public abstract SerialPort getPortaSerial();
  
  public abstract boolean sendBytes(int[] paramArrayOfInt);
  
  public abstract boolean sendBytes(int[] paramArrayOfInt, int paramInt);
  
  public abstract int[] getBytes();
  
  public abstract String[] getPortas();
  
  public abstract int getIndicePortaAtual();
  
  public abstract boolean restart();
  
  public abstract String getNomePortaAtual();
  
  public abstract void addDriverListener(DriverListener paramDriverListener);
}


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\comunicacao\Communication.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */