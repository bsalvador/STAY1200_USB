package br.com.schneider.sgm.eventos;

public abstract interface BatTesteListener
{
  public static final int ESTADO_BATERIA_BOM = 0;
  public static final int ESTADO_BATERIA_OK = 1;
  public static final int ESTADO_BATERIA_RUIM = 2;
  public static final int FALHA_TIMEOUT = 1;
  public static final int FALHA_BATERIA_MUITO_BAIXA = 2;
  public static final int FALHA_COMUNICACAO = 3;
  
  public abstract void inicioTesteBateria();
  
  public abstract void fimTesteBateria(int paramInt);
  
  public abstract void testeBateriaAbortado(int paramInt);
  
  public abstract void testeBateriaIndisponivel();
}


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\eventos\BatTesteListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */