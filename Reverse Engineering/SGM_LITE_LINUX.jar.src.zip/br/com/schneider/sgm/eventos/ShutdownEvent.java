/*    */ package br.com.schneider.sgm.eventos;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.lang3.SystemUtils;
/*    */ 
/*    */ public class ShutdownEvent
/*    */ {
/*    */   public static boolean send(int time) throws IOException
/*    */   {
/* 10 */     String shutdownCommand = null;String t = time == 0 ? "now" : String.valueOf(time);
/*    */     
/* 12 */     if (SystemUtils.IS_OS_LINUX) {
/* 13 */       shutdownCommand = "shutdown -h " + t;
/* 14 */     } else if (SystemUtils.IS_OS_WINDOWS_XP) {
/* 15 */       shutdownCommand = "shutdown.exe -s -t " + t;
/* 16 */     } else if ((SystemUtils.IS_OS_WINDOWS_VISTA) || (SystemUtils.IS_OS_WINDOWS_7)) {
/* 17 */       shutdownCommand = "shutdown.exe -s -t " + t;
/* 18 */     } else if ((SystemUtils.IS_OS_WINDOWS_2000) || (SystemUtils.IS_OS_WINDOWS_2003) || (SystemUtils.IS_OS_WINDOWS_2008)) {
/* 19 */       shutdownCommand = "shutdown.exe -s -t " + t;
/* 20 */     } else if (SystemUtils.IS_OS_WINDOWS) {
/* 21 */       shutdownCommand = "shutdown.exe -s -t " + t;
/*    */     } else {
/* 23 */       return false;
/*    */     }
/* 25 */     Runtime.getRuntime().exec(shutdownCommand);
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\eventos\ShutdownEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */