/*    */ package br.com.schneider.sgm.eventos;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.mail.Authenticator;
/*    */ import javax.mail.Message;
/*    */ import javax.mail.Message.RecipientType;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.PasswordAuthentication;
/*    */ import javax.mail.Session;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ import javax.mail.internet.MimeMessage;
/*    */ 
/*    */ public class MailEvent
/*    */ {
/*    */   public static boolean send(boolean hasAuthentication, String username, final String password, String smtpServer, Integer smtpPort, String fromUser, String toUser, String mailSubject, String mailText)
/*    */   {
/* 17 */     Properties props = new Properties();
/* 18 */     props.put("mail.smtp.starttls.enable", "true");
/* 19 */     props.put("mail.smtp.host", smtpServer);
/* 20 */     props.put("mail.smtp.port", smtpPort.toString());
/*    */     
/* 22 */     Session session = null;
/* 23 */     if (hasAuthentication) {
/* 24 */       props.put("mail.smtp.auth", "true");
/* 25 */       session = Session.getInstance(props, 
/* 26 */         new Authenticator() {
/*    */           protected PasswordAuthentication getPasswordAuthentication() {
/* 28 */             return new PasswordAuthentication(MailEvent.this, password);
/*    */           }
/*    */         });
/*    */     }
/*    */     else {
/* 33 */       props.put("mail.smtp.auth", "false");
/* 34 */       session = Session.getInstance(props);
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 39 */       Message message = new MimeMessage(session);
/* 40 */       message.setFrom(new InternetAddress(fromUser));
/* 41 */       message.setRecipients(Message.RecipientType.TO, 
/* 42 */         InternetAddress.parse(toUser));
/* 43 */       message.setSubject(mailSubject);
/* 44 */       message.setText(mailText);
/*    */       
/* 46 */       javax.mail.Transport.send(message);
/*    */     }
/*    */     catch (MessagingException e) {
/* 49 */       e.printStackTrace();
/* 50 */       return false;
/*    */     }
/* 52 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\eventos\MailEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */