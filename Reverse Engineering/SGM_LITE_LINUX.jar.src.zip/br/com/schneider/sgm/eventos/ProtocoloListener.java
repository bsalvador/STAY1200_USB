package br.com.schneider.sgm.eventos;

public abstract interface ProtocoloListener
{
  public abstract void notifica();
}


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\eventos\ProtocoloListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */