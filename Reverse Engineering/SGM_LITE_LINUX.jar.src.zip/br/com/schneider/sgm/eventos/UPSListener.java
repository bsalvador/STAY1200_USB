package br.com.schneider.sgm.eventos;

public abstract interface UPSListener
{
  public abstract void notificaControle();
}


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\eventos\UPSListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */