package br.com.schneider.sgm.eventos;

public abstract interface ControleListener
{
  public static final int DADOS = 1;
  public static final int FALHA_COM = 2;
  public static final int RETORNO_COM = 3;
  public static final int FALHA_REDE = 4;
  public static final int RETORNO_REDE = 5;
  public static final int BATERIA_BAIXA = 6;
  public static final int BATERIA_NORMAL = 7;
  public static final int CARGA_ELEVADA = 8;
  public static final int CARGA_NORMAL = 9;
  public static final int TEMPERATURA_ELEVADA = 10;
  public static final int TEMPERATURA_NORMAL = 11;
  public static final int USO_BATERIAS = 12;
  public static final int FIM_USO_BATERIAS = 13;
  public static final int COMUNICACAO_OK = 14;
  
  public abstract void notificaDados();
  
  public abstract void notificaFalhaCom();
  
  public abstract void notificaRetornoCom();
  
  public abstract void notificaFalhaRede();
  
  public abstract void notificaRetornoRede();
  
  public abstract void notificaBateriaBaixa();
  
  public abstract void notificaBateriaNormal();
  
  public abstract void notificaCargaElevada();
  
  public abstract void notificaCargaNormal();
  
  public abstract void notificaTemperaturaElevada();
  
  public abstract void notificaTemperaturaNormal();
  
  public abstract void notificaUsandoBateria();
  
  public abstract void notificaNaoUsaBateria();
  
  public abstract void notificaComunicacao();
}


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\eventos\ControleListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */