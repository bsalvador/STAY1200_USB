/*     */ package br.com.schneider.sgm.eventos;
/*     */ 
/*     */ public class Evento
/*     */ {
/*     */   public static String[] listaAlarmes;
/*     */   public static final int SUBTENSAO_ENTRADA = 1;
/*     */   public static final int SOBRETENSAO_ENTRADA = 2;
/*     */   public static final int RETORNO_REDE_ELETRICA = 3;
/*     */   public static final int SOBRECARGA = 4;
/*     */   public static final int BATERIAS_DESCARREGADAS = 5;
/*     */   public static final int CHAVE_LIGADA = 6;
/*     */   public static final int CHAVE_DESLIGADA = 7;
/*     */   public static final int DESLIGAMENTO = 8;
/*     */   public static final int INICIALIZACAO = 9;
/*     */   public static final int DESLIGAMENTO_REMOTO = 10;
/*     */   public static final int SUPER_AQUECIMENTO = 11;
/*     */   public static final int DESLIGAMENTO_PROGAMADO = 12;
/*     */   public static final int ACIONAMENTO_PROGRAMADO = 13;
/*     */   public static final int SAIDA_SEM_CONSUMO = 14;
/*     */   public static final int BATERIA_BAIXO = 15;
/*     */   public static final int SAIDA_LIGADA = 16;
/*     */   public static final int BATERIAS_CARREGADAS = 17;
/*     */   public static final int SHUTDOWN = 18;
/*     */   public static final int FALHA_NA_COMUNICACAO = 19;
/*     */   public static final int RETORNO_DE_COMUNICACAO = 20;
/*     */   public static final int FALHA_NA_REDE = 21;
/*     */   public static final int FALHA_AUTO_TEST = 22;
/*     */   public static final int FALHA_INVERSOR = 23;
/*     */   public static final int ATIVA_BYPASS = 24;
/*     */   public static final int DESATIVA_BYPASS = 25;
/*     */   public static final int CARREGADOR_FALHO = 26;
/*     */   public static final int BATERIA_FALHA = 27;
/*     */   public static final int AUTO_DIAGNOSTICO_OK = 28;
/*     */   public static final int AUTO_TESTE_BAT_OK = 29;
/*     */   public static final int AUTO_TESTE_BAT_BOM = 30;
/*     */   public static final int AUTO_TESTE_BAT_RUIM = 31;
/*     */   private int hora;
/*     */   private int minuto;
/*     */   private int segundo;
/*     */   private int dia;
/*     */   private int mes;
/*     */   private int ano;
/*     */   private String tipo;
/*     */   
/*     */   public Evento(int tipo, int hora, int minuto, int segundo, int dia, int mes, int ano) {
/*  46 */     setTipo(tipo);
/*  47 */     this.hora = hora;
/*  48 */     this.minuto = minuto;
/*  49 */     this.segundo = segundo;
/*  50 */     this.dia = dia;
/*  51 */     this.mes = mes;
/*  52 */     this.ano = ano;
/*     */   }
/*     */   
/*     */   public Evento(String tipo, int hora, int minuto, int segundo, int dia, int mes, int ano)
/*     */   {
/*  57 */     this.tipo = tipo;
/*  58 */     this.hora = hora;
/*  59 */     this.minuto = minuto;
/*  60 */     this.segundo = segundo;
/*  61 */     this.dia = dia;
/*  62 */     this.mes = mes;
/*  63 */     this.ano = ano;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getDia()
/*     */   {
/*  69 */     return this.dia;
/*     */   }
/*     */   
/*     */   public void setDia(int dia) {
/*  73 */     this.dia = dia;
/*     */   }
/*     */   
/*     */   public int getHora() {
/*  77 */     return this.hora;
/*     */   }
/*     */   
/*     */   public void setHora(int hora) {
/*  81 */     this.hora = hora;
/*     */   }
/*     */   
/*     */   public int getMinuto() {
/*  85 */     return this.minuto;
/*     */   }
/*     */   
/*     */   public void setMinuto(int minuto) {
/*  89 */     this.minuto = minuto;
/*     */   }
/*     */   
/*     */   public String getTipo() {
/*  93 */     return this.tipo;
/*     */   }
/*     */   
/*     */   public void setTipo(int tipo)
/*     */   {
/*  98 */     if ((tipo > listaAlarmes.length) || (tipo <= 0)) {
/*  99 */       this.tipo = "ALARME_DESCONHECIDO";
/*     */     }
/*     */     else {
/* 102 */       this.tipo = listaAlarmes[(tipo - 1)];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getAno()
/*     */   {
/* 109 */     return this.ano;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAno(int ano)
/*     */   {
/* 116 */     this.ano = ano;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMes()
/*     */   {
/* 123 */     return this.mes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMes(int mes)
/*     */   {
/* 130 */     this.mes = mes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSegundo()
/*     */   {
/* 137 */     return this.segundo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSegundo(int segundo)
/*     */   {
/* 144 */     this.segundo = segundo;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\eventos\Evento.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */