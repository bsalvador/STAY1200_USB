/*    */ package br.com.schneider.sgm.internacionalizacao;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Idioma
/*    */ {
/*    */   public static ResourceBundle res;
/* 21 */   private static boolean b = true;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Idioma()
/*    */   {
/* 30 */     res = ResourceBundle.getBundle("Portugues");
/* 31 */     b = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void setIdiomaPortugues()
/*    */   {
/* 41 */     res = ResourceBundle.getBundle("Portugues");
/* 42 */     b = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void setIdiomaIngles()
/*    */   {
/* 52 */     res = ResourceBundle.getBundle("Ingles");
/* 53 */     b = false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static ResourceBundle getIdiomaRes()
/*    */   {
/* 63 */     return res;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getIdioma()
/*    */   {
/* 71 */     if (b) {
/* 72 */       return "Portugues";
/*    */     }
/* 74 */     return "Ingles";
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\internacionalizacao\Idioma.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */