/*     */ package br.com.schneider.sgm.historico;
/*     */ 
/*     */ import br.com.schneider.sgm.eventos.Evento;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ import org.jdom.output.XMLOutputter;
/*     */ 
/*     */ public class Historico
/*     */ {
/*     */   private String nomeDocumento;
/*     */   private Vector res;
/*     */   private String ano;
/*     */   private String mes;
/*     */   private String tipo;
/*     */   private String dia;
/*     */   private String hora;
/*     */   private String min;
/*     */   private String seg;
/*     */   private int tipoBusca;
/*     */   private boolean removeu;
/*     */   private Element oldChild;
/*     */   private int numeroRegistros;
/*     */   private static final int BUSCAR = 1;
/*     */   private static final int REMOVER = 2;
/*     */   private static final int DUMP = 3;
/*     */   private static final int NUMERO_MAXIMO_REGISTROS_A_VISUALIZAR = 999;
/*     */   
/*     */   public Historico(String nomeDocumento)
/*     */   {
/*  39 */     this.nomeDocumento = nomeDocumento;
/*  40 */     this.tipoBusca = 0;
/*  41 */     this.removeu = false;
/*     */   }
/*     */   
/*  44 */   public void setNomeDocumento(String nomeDocumento) { this.nomeDocumento = nomeDocumento; }
/*     */   
/*     */   public synchronized boolean inserirEvento(Evento e, int mes, int ano)
/*     */   {
/*  48 */     SAXBuilder builder = new SAXBuilder();
/*     */     try {
/*  50 */       File f = new File(this.nomeDocumento);
/*  51 */       Document doc = builder.build(f);
/*     */       
/*     */ 
/*  54 */       Element evt = new Element("evento");
/*     */       
/*  56 */       if (mes < 10)
/*  57 */         this.mes = "0"; else
/*  58 */         this.mes = "";
/*  59 */       this.mes += mes;
/*     */       
/*     */ 
/*  62 */       if (e.getDia() < 10)
/*  63 */         this.dia = "0"; else
/*  64 */         this.dia = "";
/*  65 */       this.dia += String.valueOf(e.getDia());
/*     */       
/*  67 */       if (e.getDia() < 10)
/*  68 */         this.dia = "0"; else
/*  69 */         this.dia = "";
/*  70 */       this.dia += e.getDia();
/*     */       
/*  72 */       if (e.getHora() < 10)
/*  73 */         this.hora = "0"; else
/*  74 */         this.hora = "";
/*  75 */       this.hora += e.getHora();
/*     */       
/*  77 */       if (e.getMinuto() < 10)
/*  78 */         this.min = "0"; else
/*  79 */         this.min = "";
/*  80 */       this.min += e.getMinuto();
/*     */       
/*  82 */       if (e.getSegundo() < 10)
/*  83 */         this.seg = "0"; else {
/*  84 */         this.seg = "";
/*     */       }
/*  86 */       this.seg += e.getSegundo();
/*     */       
/*  88 */       this.tipo = e.getTipo();
/*     */       
/*  90 */       evt.setAttribute("data", ano + "-" + this.mes + "-" + this.dia);
/*  91 */       evt.setAttribute("hora", this.hora + ":" + this.min + ":" + this.seg);
/*  92 */       evt.setText(this.tipo);
/*     */       
/*     */ 
/*  95 */       doc.getRootElement().addContent(evt);
/*     */       
/*     */ 
/*  98 */       XMLOutputter serializer = new XMLOutputter();
/*  99 */       serializer.setFormat(org.jdom.output.Format.getPrettyFormat());
/*     */       
/*     */ 
/* 102 */       serializer.output(doc, new FileWriter(f));
/*     */       
/* 104 */       return true;
/*     */     }
/*     */     catch (JDOMException jdomx)
/*     */     {
/* 108 */       criaArquivo();
/*     */ 
/*     */     }
/*     */     catch (IOException iox)
/*     */     {
/*     */ 
/* 114 */       criaArquivo();
/*     */     }
/*     */     
/* 117 */     return false;
/*     */   }
/*     */   
/*     */   public void criaArquivo() {
/*     */     try {
/* 122 */       BufferedWriter out = new BufferedWriter(new FileWriter(this.nomeDocumento));
/* 123 */       out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<eventos xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"eventos.xsd\">\n</eventos>");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */       out.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void buscaEventos(Object o, int depth)
/*     */   {
/* 139 */     if ((o instanceof Document)) {
/* 140 */       Document doc = (Document)o;
/* 141 */       List children = doc.getContent();
/* 142 */       Iterator iterator = children.iterator();
/* 143 */       while (iterator.hasNext()) {
/* 144 */         Object child = iterator.next();
/* 145 */         buscaEventos(child, depth + 1);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 150 */     else if ((o instanceof Element))
/*     */     {
/* 152 */       Element elem = (Element)o;
/*     */       
/* 154 */       if (elem.getName() == "evento")
/*     */       {
/* 156 */         String[] data = elem.getAttributeValue("data").split("-");
/* 157 */         switch (this.tipoBusca)
/*     */         {
/*     */ 
/*     */         case 1: 
/* 161 */           if ((data[0].equals(this.ano)) && 
/* 162 */             (data[1].equals(this.mes)))
/* 163 */             this.res.add(elem.getAttributeValue("data") + 
/* 164 */               "xxx" + elem.getAttributeValue("hora") + 
/* 165 */               "xxx" + elem.getValue());
/* 166 */           break;
/*     */         
/*     */ 
/*     */         case 3: 
/* 170 */           this.res.add(elem.getAttributeValue("data") + 
/* 171 */             "xxx" + elem.getAttributeValue("hora") + 
/* 172 */             "xxx" + elem.getValue());
/* 173 */           break;
/*     */         
/*     */         case 2: 
/* 176 */           if (!this.removeu)
/*     */           {
/* 178 */             String[] hora = elem.getAttributeValue("hora").split(":");
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */             if ((data[0].equals(this.ano)) && 
/* 188 */               (data[1].equals(this.mes)) && 
/* 189 */               (hora[0].equals(this.hora)) && 
/* 190 */               (hora[1].equals(this.min)) && 
/* 191 */               (elem.getValue().equalsIgnoreCase(this.tipo)))
/*     */             {
/* 193 */               this.removeu = true;
/*     */               
/* 195 */               this.oldChild = elem;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/*     */             return;
/*     */           }
/*     */           
/*     */           break;
/*     */         }
/*     */         
/*     */       }
/* 207 */       List children = elem.getContent();
/* 208 */       Iterator iterator = children.iterator();
/* 209 */       while (iterator.hasNext()) {
/* 210 */         Object child = iterator.next();
/* 211 */         buscaEventos(child, depth + 1);
/* 212 */         if (this.removeu)
/*     */         {
/*     */ 
/* 215 */           this.removeu = elem.removeContent(this.oldChild);
/* 216 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Evento[] getEventos()
/*     */   {
/* 225 */     SAXBuilder builder = new SAXBuilder();
/* 226 */     this.res = new Vector();
/*     */     try {
/* 228 */       Document doc = builder.build(new File(this.nomeDocumento));
/* 229 */       this.tipoBusca = 3;
/* 230 */       buscaEventos(doc, 0);
/*     */       
/* 232 */       if (this.res != null)
/*     */       {
/*     */ 
/* 235 */         int numeroRegistros = this.res.size();
/* 236 */         int excesso = 999 - numeroRegistros;
/* 237 */         int registroInicial; int registroInicial; if (excesso < 0) {
/* 238 */           registroInicial = Math.abs(excesso);
/*     */         } else {
/* 240 */           registroInicial = 0;
/*     */         }
/* 242 */         Evento[] eventos = new Evento[this.res.size()];
/*     */         
/*     */ 
/*     */ 
/* 246 */         for (int i = registroInicial; i < this.res.size(); i++)
/*     */         {
/* 248 */           String[] eventoS = ((String)this.res.get(i - registroInicial)).split("xxx");
/* 249 */           String[] data = eventoS[0].split("-");
/* 250 */           String[] hora = eventoS[1].split(":");
/* 251 */           eventos[i] = new Evento(
/* 252 */             eventoS[2], 
/* 253 */             Integer.parseInt(hora[0]), 
/* 254 */             Integer.parseInt(hora[1]), 
/* 255 */             Integer.parseInt(hora[2]), 
/* 256 */             Integer.parseInt(data[2]), 
/* 257 */             Integer.parseInt(data[1]), 
/* 258 */             Integer.parseInt(data[0]));
/*     */         }
/*     */         
/*     */ 
/* 262 */         return eventos;
/*     */       }
/*     */       
/* 265 */       return null;
/*     */     }
/*     */     catch (JDOMException localJDOMException) {}catch (IOException localIOException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 278 */     return null;
/*     */   }
/*     */   
/*     */   public Evento[] getEventos(int ano, int mes) {
/* 282 */     this.ano = String.valueOf(ano);
/* 283 */     if (mes < 10) {
/* 284 */       this.mes = "0";
/*     */     } else {
/* 286 */       this.mes = "";
/*     */     }
/* 288 */     this.mes += String.valueOf(mes);
/*     */     
/* 290 */     SAXBuilder builder = new SAXBuilder();
/* 291 */     this.res = new Vector();
/*     */     try {
/* 293 */       Document doc = builder.build(new File(this.nomeDocumento));
/* 294 */       this.tipoBusca = 1;
/* 295 */       buscaEventos(doc, 0);
/*     */       
/* 297 */       if (this.res != null)
/*     */       {
/* 299 */         Evento[] eventos = new Evento[this.res.size()];
/*     */         
/*     */ 
/*     */ 
/* 303 */         for (int i = 0; i < this.res.size(); i++)
/*     */         {
/* 305 */           String[] eventoS = ((String)this.res.get(i)).split("xxx");
/* 306 */           String[] data = eventoS[0].split("-");
/* 307 */           String[] hora = eventoS[1].split(":");
/* 308 */           eventos[i] = new Evento(
/* 309 */             eventoS[2], 
/* 310 */             Integer.parseInt(hora[0]), 
/* 311 */             Integer.parseInt(hora[1]), 
/* 312 */             Integer.parseInt(hora[2]), 
/* 313 */             Integer.parseInt(data[2]), 
/* 314 */             mes, 
/* 315 */             ano);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 320 */         return eventos;
/*     */       }
/*     */       
/* 323 */       return null;
/*     */     }
/*     */     catch (JDOMException localJDOMException) {}catch (IOException localIOException) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 336 */     return null;
/*     */   }
/*     */   
/*     */   public boolean removerEvento(Evento e, int mes, int ano)
/*     */   {
/*     */     try
/*     */     {
/* 343 */       this.ano = String.valueOf(ano);
/* 344 */       if (mes < 10)
/* 345 */         this.mes = "0"; else
/* 346 */         this.mes = "";
/* 347 */       this.mes += String.valueOf(mes);
/*     */       
/* 349 */       if (e.getDia() < 10)
/* 350 */         this.dia = "0"; else
/* 351 */         this.dia = "";
/* 352 */       this.dia += String.valueOf(e.getDia());
/*     */       
/* 354 */       if (e.getHora() < 10)
/* 355 */         this.hora = "0"; else
/* 356 */         this.hora = "";
/* 357 */       this.hora += String.valueOf(e.getHora());
/*     */       
/* 359 */       if (e.getMinuto() < 10)
/* 360 */         this.min = "0"; else
/* 361 */         this.min = "";
/* 362 */       this.min += String.valueOf(e.getMinuto());
/*     */       
/* 364 */       this.tipo = e.getTipo();
/*     */       
/* 366 */       SAXBuilder builder = new SAXBuilder();
/*     */       
/* 368 */       File f = new File(this.nomeDocumento);
/* 369 */       Document doc = builder.build(f);
/* 370 */       this.tipoBusca = 2;
/* 371 */       buscaEventos(doc, 0);
/* 372 */       if (this.removeu)
/*     */       {
/* 374 */         XMLOutputter serializer = new XMLOutputter();
/* 375 */         serializer.output(doc, new FileWriter(f));
/* 376 */         this.removeu = false;
/* 377 */         return true;
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (JDOMException localJDOMException) {}catch (IOException localIOException) {}catch (Exception evt)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 391 */       evt.printStackTrace();
/*     */     }
/*     */     
/* 394 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\historico\Historico.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */