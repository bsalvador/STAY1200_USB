/*     */ package br.com.schneider.sgm.historico;
/*     */ 
/*     */ import br.com.schneider.sgm.config.PathConfig;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ import org.jdom.output.Format;
/*     */ import org.jdom.output.XMLOutputter;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HistoricoConsumo
/*     */ {
/*  23 */   private final int CONSUMO_DIARIO = 1;
/*  24 */   private final int CONSUMO_SEMANAL = 2;
/*  25 */   private final int CONSUMO_MENSAL = 3;
/*  26 */   private final int CONSUMO_ANUAL = 4;
/*  27 */   private final int INSERIR_DIA = 5;
/*  28 */   private final int INSERIR_SEMANA = 6;
/*  29 */   private final int INSERIR_MES = 7;
/*  30 */   private final int INSERIR_ANO = 8;
/*  31 */   private final int BUSCAR_DIA = 9;
/*  32 */   private int tipoBusca = 1;
/*     */   
/*     */   private Vector res;
/*     */   
/*     */   private Hashtable hash;
/*     */   
/*     */   private GregorianCalendar data;
/*     */   private File arquivo;
/*     */   private Document doc;
/*     */   private int[] interI;
/*     */   private String ano;
/*     */   private String mes;
/*     */   
/*     */   public HistoricoConsumo(String nomeArquivo)
/*     */   {
/*  47 */     this.data = new GregorianCalendar();
/*  48 */     this.data.setTimeInMillis(System.currentTimeMillis());
/*  49 */     this.interI = new int[3];
/*     */     
/*  51 */     this.arquivo = new File(nomeArquivo);
/*  52 */     SAXBuilder builder = new SAXBuilder();
/*     */     try
/*     */     {
/*  55 */       this.doc = builder.build(this.arquivo);
/*     */     }
/*     */     catch (JDOMException e) {
/*  58 */       e.printStackTrace();
/*     */     }
/*     */     catch (IOException e) {
/*  61 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getSemana(int dia)
/*     */   {
/*  68 */     if (dia <= 7) return "1";
/*  69 */     if ((dia > 7) && (dia <= 14)) return "2";
/*  70 */     if ((dia > 14) && (dia <= 21)) return "3";
/*  71 */     if ((dia > 21) && (dia <= 27)) return "4";
/*  72 */     return "5";
/*     */   }
/*     */   
/*     */ 
/*     */   public String intToNomeDia(int dia)
/*     */   {
/*  78 */     switch (dia) {
/*     */     case 1: 
/*  80 */       return "domingo";
/*  81 */     case 2:  return "segunda";
/*  82 */     case 3:  return "terca";
/*  83 */     case 4:  return "quarta";
/*  84 */     case 5:  return "quinta";
/*  85 */     case 6:  return "sexta";
/*  86 */     case 7:  return "sabado";
/*     */     }
/*     */     
/*  89 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private void preparaElem()
/*     */   {
/*  95 */     if (this.ano == null)
/*     */     {
/*  97 */       this.week = new Element("semana");
/*  98 */       this.week.setAttribute("id", getSemana(this.interI[0]));
/*  99 */       this.week.addContent(this.newDay);
/*     */       
/* 101 */       this.month = new Element("mes");
/* 102 */       this.month.setAttribute("id", String.valueOf(this.interI[1]));
/* 103 */       this.month.addContent(this.week);
/*     */       
/* 105 */       this.year = new Element("ano");
/* 106 */       this.year.setAttribute("id", String.valueOf(this.interI[2]));
/* 107 */       this.year.addContent(this.month);
/*     */       
/* 109 */       this.tipoBusca = 8;
/*     */     }
/* 111 */     else if (this.mes == null)
/*     */     {
/* 113 */       this.week = new Element("semana");
/* 114 */       this.week.setAttribute("id", getSemana(this.interI[0]));
/* 115 */       this.week.addContent(this.newDay);
/*     */       
/* 117 */       this.month = new Element("mes");
/* 118 */       this.month.setAttribute("id", String.valueOf(this.interI[1]));
/* 119 */       this.month.addContent(this.week);
/*     */       
/* 121 */       this.tipoBusca = 7;
/*     */     }
/* 123 */     else if (this.semana == null)
/*     */     {
/* 125 */       this.week = new Element("semana");
/* 126 */       this.week.setAttribute("id", getSemana(this.interI[0]));
/* 127 */       this.week.addContent(this.newDay);
/*     */       
/* 129 */       this.tipoBusca = 6;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void criaDia(Element elem)
/*     */   {
/* 136 */     int diaAtual = 0;
/*     */     
/*     */ 
/* 139 */     List children = elem.getContent();
/* 140 */     Iterator iterator = children.iterator();
/* 141 */     while (iterator.hasNext())
/*     */     {
/* 143 */       Object child = iterator.next();
/* 144 */       if ((child instanceof Element))
/*     */       {
/* 146 */         Element dia = (Element)child;
/* 147 */         diaAtual = Integer.parseInt(dia.getAttributeValue("id"));
/* 148 */         if (diaAtual == this.interI[0])
/*     */         {
/* 150 */           dia.setText(this.newDay.getText());
/* 151 */           this.semana = elem.getAttributeValue("semana");
/* 152 */           this.inseriu = true;
/* 153 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 158 */     if (!this.inseriu)
/*     */     {
/* 160 */       elem.addContent(this.newDay);
/* 161 */       this.semana = elem.getAttributeValue("semana");
/* 162 */       this.inseriu = true;
/* 163 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean inserirDia(float valor)
/*     */   {
/* 169 */     this.interI[0] = this.data.get(5);
/* 170 */     this.interI[1] = (this.data.get(2) + 1);
/* 171 */     this.interI[2] = this.data.get(1);
/*     */     
/* 173 */     this.newDay = new Element("dia");
/* 174 */     this.newDay.setAttribute("id", String.valueOf(this.interI[0]));
/* 175 */     this.newDay.setAttribute("nome", intToNomeDia(this.data.get(7)));
/* 176 */     this.newDay.setAttribute("semana", getSemana(this.interI[0]));
/* 177 */     this.newDay.setText(String.valueOf(valor));
/*     */     
/* 179 */     this.tipoBusca = 5;
/* 180 */     this.ano = null;this.mes = null;this.semana = null;
/* 181 */     buscaConsumo(this.doc, 0, null);
/*     */     
/* 183 */     if (this.inseriu)
/*     */     {
/* 185 */       this.inseriu = false;
/*     */       
/* 187 */       XMLOutputter serializer = new XMLOutputter();
/* 188 */       serializer.setFormat(Format.getPrettyFormat());
/*     */       try {
/* 190 */         serializer.output(this.doc, new FileWriter(this.arquivo));
/* 191 */         return true;
/*     */ 
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 200 */       preparaElem();
/* 201 */       buscaConsumo(this.doc, 0, null);
/* 202 */       if (this.inseriu)
/*     */       {
/* 204 */         this.inseriu = false;
/*     */         
/*     */ 
/* 207 */         XMLOutputter serializer = new XMLOutputter();
/* 208 */         serializer.setFormat(Format.getPrettyFormat());
/*     */         try
/*     */         {
/* 211 */           serializer.output(this.doc, new FileWriter(this.arquivo));
/* 212 */           return true;
/*     */         }
/*     */         catch (IOException localIOException1) {}
/*     */       }
/*     */     }
/*     */     
/* 218 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private void buscaConsumo(Object o, int depth, String data)
/*     */   {
/* 224 */     if ((o instanceof Document))
/*     */     {
/* 226 */       Document doc = (Document)o;
/* 227 */       List children = doc.getContent();
/* 228 */       Iterator iterator = children.iterator();
/* 229 */       while (iterator.hasNext())
/*     */       {
/* 231 */         Object child = iterator.next();
/* 232 */         buscaConsumo(child, depth + 1, null);
/* 233 */         if (this.inseriu) {
/* 234 */           return;
/*     */         }
/*     */       }
/* 237 */     } else if ((o instanceof Element))
/*     */     {
/* 239 */       Element elem = (Element)o;
/*     */       
/* 241 */       if (elem.getName() == "consumo")
/*     */       {
/* 243 */         switch (this.tipoBusca)
/*     */         {
/*     */ 
/*     */         case 8: 
/* 247 */           elem.addContent(this.year);
/* 248 */           this.inseriu = true;
/* 249 */           return;
/*     */         }
/*     */         
/*     */         
/* 253 */         List children = elem.getContent();
/* 254 */         Iterator iterator = children.iterator();
/* 255 */         while (iterator.hasNext())
/*     */         {
/* 257 */           Object child = iterator.next();
/* 258 */           buscaConsumo(child, depth + 1, null);
/* 259 */           if (this.inseriu) {
/* 260 */             return;
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 266 */       else if (elem.getName() == "ano")
/*     */       {
/* 268 */         if (Integer.parseInt(elem.getAttributeValue("id")) == this.interI[2])
/*     */         {
/* 270 */           if (this.tipoBusca == 7)
/*     */           {
/* 272 */             elem.addContent(this.month);
/* 273 */             this.inseriu = true;
/* 274 */             return;
/*     */           }
/*     */           
/*     */ 
/* 278 */           this.ano = elem.getAttributeValue("id");
/* 279 */           List children = elem.getContent();
/* 280 */           Iterator iterator = children.iterator();
/* 281 */           while (iterator.hasNext())
/*     */           {
/* 283 */             Object child = iterator.next();
/* 284 */             buscaConsumo(child, depth + 1, this.ano);
/* 285 */             if (this.inseriu) {
/* 286 */               return;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 291 */       else if (elem.getName() == "mes")
/*     */       {
/* 293 */         switch (this.tipoBusca)
/*     */         {
/*     */ 
/*     */         case 6: 
/* 297 */           if (Integer.parseInt(elem.getAttributeValue("id")) == this.interI[1])
/*     */           {
/* 299 */             elem.addContent(this.week);
/* 300 */             this.inseriu = true;
/* 301 */             return;
/*     */           }
/*     */         
/*     */ 
/*     */ 
/*     */         case 4: 
/* 307 */           this.mes = elem.getAttributeValue("id");
/* 308 */           this.resF = 0.0F;
/* 309 */           List children = elem.getContent();
/* 310 */           Iterator iterator = children.iterator();
/* 311 */           while (iterator.hasNext()) {
/* 312 */             Object child = iterator.next();
/* 313 */             buscaConsumo(child, depth + 1, data + "-" + this.mes);
/*     */           } }
/* 315 */         if ((goto 969) && 
/*     */         
/*     */ 
/*     */ 
/* 319 */           (Integer.parseInt(elem.getAttributeValue("id")) == this.interI[1]))
/*     */         {
/* 321 */           this.mes = elem.getAttributeValue("id");
/* 322 */           List children = elem.getContent();
/* 323 */           Iterator iterator = children.iterator();
/* 324 */           while (iterator.hasNext())
/*     */           {
/* 326 */             Object child = iterator.next();
/* 327 */             buscaConsumo(child, depth + 1, data + "-" + this.mes);
/* 328 */             if (this.inseriu) {
/* 329 */               return;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 336 */       else if (elem.getName() == "semana")
/*     */       {
/* 338 */         if (this.tipoBusca == 5)
/*     */         {
/* 340 */           if (Integer.parseInt(elem.getAttributeValue("id")) == Integer.parseInt(this.newDay.getAttributeValue("semana")))
/*     */           {
/* 342 */             criaDia(elem);
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 348 */           List children = elem.getContent();
/* 349 */           Iterator iterator = children.iterator();
/* 350 */           while (iterator.hasNext())
/*     */           {
/* 352 */             Object child = iterator.next();
/* 353 */             buscaConsumo(child, depth + 1, data);
/*     */           }
/*     */         }
/*     */       }
/* 357 */       else if (elem.getName() == "dia")
/*     */       {
/* 359 */         switch (this.tipoBusca)
/*     */         {
/*     */ 
/*     */         case 1: 
/* 363 */           this.dia = elem.getAttributeValue("id");
/* 364 */           this.res.add(data + "-" + this.dia + "=" + elem.getValue());
/* 365 */           break;
/*     */         
/*     */ 
/*     */         case 2: 
/* 369 */           if (Integer.parseInt(this.semana) != Integer.parseInt(elem.getAttributeValue("semana"))) {
/* 370 */             this.semana = elem.getAttributeValue("semana");
/*     */           }
/* 372 */           this.resF += Float.parseFloat(elem.getValue());
/* 373 */           this.hash.put(data + "-" + this.semana, new Float(this.resF));
/* 374 */           break;
/*     */         
/*     */ 
/*     */         case 3: 
/* 378 */           this.resF += Float.parseFloat(elem.getValue());
/* 379 */           break;
/*     */         
/*     */ 
/*     */         case 4: 
/* 383 */           this.resF += Float.parseFloat(elem.getValue());
/* 384 */           this.hash.put(data, new Float(this.resF)); }
/*     */         
/*     */       } } }
/*     */   
/*     */   private String dia;
/*     */   private String semana;
/*     */   private float resF;
/*     */   private Element newDay;
/*     */   private Element year;
/*     */   private Element month;
/*     */   private Element week;
/*     */   private boolean inseriu;
/* 396 */   public String getConsumoDiario(String mesAno) { String[] inter = mesAno.split("-");
/* 397 */     this.interI[1] = Integer.parseInt(inter[0]);
/* 398 */     this.interI[2] = Integer.parseInt(inter[1]);
/*     */     
/* 400 */     this.tipoBusca = 1;
/*     */     
/* 402 */     this.res = new Vector();
/* 403 */     this.ano = null;
/* 404 */     this.mes = null;
/* 405 */     this.semana = null;
/*     */     
/* 407 */     buscaConsumo(this.doc, 0, null);
/*     */     
/* 409 */     if (this.res != null)
/*     */     {
/* 411 */       String resS = this.res.toString().substring(1, this.res.toString().length() - 1);
/* 412 */       this.res = null;
/* 413 */       return resS;
/*     */     }
/* 415 */     return null;
/*     */   }
/*     */   
/*     */   public String getConsumoSemanal(String mesAno)
/*     */   {
/* 420 */     String[] inter = mesAno.split("-");
/* 421 */     this.interI[1] = Integer.parseInt(inter[0]);
/* 422 */     this.interI[2] = Integer.parseInt(inter[1]);
/*     */     
/* 424 */     this.semana = "1";
/*     */     
/* 426 */     this.tipoBusca = 2;
/* 427 */     this.hash = new Hashtable();
/* 428 */     this.resF = 0.0F;
/*     */     
/* 430 */     buscaConsumo(this.doc, 0, null);
/*     */     
/* 432 */     if (this.hash != null)
/*     */     {
/* 434 */       String s = this.hash.toString().substring(1, this.hash.toString().length() - 1);
/* 435 */       this.hash = null;
/* 436 */       return s;
/*     */     }
/*     */     
/* 439 */     return null;
/*     */   }
/*     */   
/*     */   public String getConsumoMensal(String mesAno)
/*     */   {
/* 444 */     String[] inter = mesAno.split("-");
/* 445 */     this.interI[1] = Integer.parseInt(inter[0]);
/* 446 */     this.interI[2] = Integer.parseInt(inter[1]);
/*     */     
/* 448 */     this.tipoBusca = 3;
/* 449 */     this.resF = 0.0F;
/*     */     
/* 451 */     buscaConsumo(this.doc, 0, null);
/*     */     
/* 453 */     if (this.resF != 0.0F) {
/* 454 */       return String.valueOf(this.resF);
/*     */     }
/* 456 */     return null;
/*     */   }
/*     */   
/*     */   public String getConsumoAnual(String ano)
/*     */   {
/* 461 */     this.interI[2] = Integer.parseInt(ano);
/* 462 */     this.tipoBusca = 4;
/* 463 */     this.hash = new Hashtable();
/* 464 */     this.resF = 0.0F;
/*     */     
/* 466 */     buscaConsumo(this.doc, 0, null);
/* 467 */     if (this.hash != null)
/*     */     {
/* 469 */       String s = this.hash.toString().substring(1, this.hash.toString().length() - 1);
/* 470 */       this.hash = null;
/* 471 */       return s;
/*     */     }
/*     */     
/* 474 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 481 */     HistoricoConsumo his = new HistoricoConsumo(PathConfig.getPathXML() + "consumo.xml");
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\historico\HistoricoConsumo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */