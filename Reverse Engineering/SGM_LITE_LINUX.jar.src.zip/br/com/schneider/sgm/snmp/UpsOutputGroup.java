/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOAccess;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.DefaultMOMutableTableModel;
/*     */ import org.snmp4j.agent.mo.DefaultMOTable;
/*     */ import org.snmp4j.agent.mo.DefaultMOTableRow;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOMutableColumn;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.MOTableIndex;
/*     */ import org.snmp4j.agent.mo.MOTableRow;
/*     */ import org.snmp4j.agent.mo.MOTableSubIndex;
/*     */ import org.snmp4j.agent.mo.snmp.DisplayStringScalar;
/*     */ import org.snmp4j.agent.mo.snmp.EnumeratedScalar;
/*     */ import org.snmp4j.agent.request.RequestStatus;
/*     */ import org.snmp4j.agent.request.SubRequest;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.Variable;
/*     */ import org.snmp4j.smi.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpsOutputGroup
/*     */   implements MOGroup
/*     */ {
/*     */   private EnumeratedScalar upsOutputSource;
/*     */   private MOScalar upsOutputFrequency;
/*     */   private MOScalar upsOutputNumLines;
/*     */   private MOScalar upsSaidaLigada;
/*     */   private DisplayStringScalar upsOutputLigar;
/*     */   private UpsOutputEnumeratedScalar upsTipoConsumo;
/*     */   private UpsOutputDisplayStringScalar upsPeriodoConsumo;
/*     */   private DisplayStringScalar upsResultadoConsumo;
/*     */   public static final int colUpsOutputVoltage = 2;
/*     */   public static final int colUpsOutputCurrent = 3;
/*     */   public static final int colUpsOutputTruePower = 4;
/*     */   public static final int colUpsOutputPercentLoad = 5;
/*     */   public static final int colUpsOutputPoteciaAparente = 6;
/*     */   private static final int idxUpsOutputVoltage = 0;
/*     */   private static final int idxUpsOutputCurrent = 1;
/*     */   private static final int idxUpsOutputTruePower = 2;
/*     */   private static final int idxUpsOutputPercentLoad = 3;
/*     */   private static final int idxUpsOutputPotenciaAparente = 4;
/*  58 */   private static MOTableSubIndex[] upsOutputEntryIndexes = {
/*  59 */     new MOTableSubIndex(2, 0, Integer.MAX_VALUE) };
/*     */   
/*  61 */   private static MOTableIndex upsOutputEntryIndex = new MOTableIndex(upsOutputEntryIndexes, true);
/*     */   
/*     */   private DefaultMOTable upsOutputEntry;
/*     */   
/*     */   private DefaultMOMutableTableModel upsOutputEntryModel;
/*     */   private Integer32[] vr;
/*     */   private Integer32 outputNumLines;
/*     */   private Integer32 outputSource;
/*     */   
/*     */   public UpsOutputGroup(int numLinhas, int linhaUsada)
/*     */   {
/*  72 */     this.linhaUsada = new OID(String.valueOf(linhaUsada));
/*     */     
/*     */ 
/*  75 */     this.outputSource = new Integer32(2);
/*  76 */     this.upsOutputSource = new EnumeratedScalar(
/*  77 */       new OID("1.3.6.1.2.1.33.1.4.1.0"), 
/*  78 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  79 */       this.outputSource, 
/*  80 */       new int[] {
/*  81 */       1, 
/*  82 */       2, 
/*  83 */       3, 
/*  84 */       4, 
/*  85 */       5, 
/*  86 */       6, 
/*  87 */       7 });
/*     */     
/*     */ 
/*     */ 
/*  91 */     this.outputFrequency = new Integer32(0);
/*  92 */     this.upsOutputFrequency = new MOScalar(
/*  93 */       new OID("1.3.6.1.2.1.33.1.4.2.0"), 
/*  94 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  95 */       this.outputFrequency);
/*     */     
/*  97 */     this.saidaLigada = new Integer32(0);
/*  98 */     this.upsSaidaLigada = new MOScalar(
/*  99 */       new OID("1.3.6.1.2.1.33.1.4.9.0"), 
/* 100 */       MOAccessImpl.ACCESS_READ_ONLY, 
/* 101 */       this.saidaLigada);
/*     */     
/* 103 */     this.outputNumLines = new Integer32(numLinhas);
/* 104 */     this.upsOutputNumLines = new MOScalar(
/* 105 */       new OID("1.3.6.1.2.1.33.1.4.3.0"), 
/* 106 */       MOAccessImpl.ACCESS_READ_ONLY, 
/* 107 */       this.outputNumLines);
/*     */     
/*     */ 
/*     */ 
/* 111 */     this.vr = new Integer32[5];
/* 112 */     for (int i = 0; i < this.vr.length; i++) {
/* 113 */       this.vr[i] = new Integer32(0);
/*     */     }
/* 115 */     MOMutableColumn[] upsOutputEntryColumns = new MOMutableColumn[this.vr.length];
/* 116 */     upsOutputEntryColumns[0] = 
/* 117 */       new MOMutableColumn(
/* 118 */       2, 
/* 119 */       2, 
/* 120 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 123 */     upsOutputEntryColumns[1] = 
/* 124 */       new MOMutableColumn(
/* 125 */       3, 
/* 126 */       2, 
/* 127 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 130 */     upsOutputEntryColumns[2] = 
/* 131 */       new MOMutableColumn(
/* 132 */       4, 
/* 133 */       2, 
/* 134 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 137 */     upsOutputEntryColumns[3] = 
/* 138 */       new MOMutableColumn(
/* 139 */       5, 
/* 140 */       2, 
/* 141 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 144 */     upsOutputEntryColumns[4] = 
/* 145 */       new MOMutableColumn(
/* 146 */       6, 
/* 147 */       2, 
/* 148 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 151 */     this.upsOutputEntry = new DefaultMOTable(
/* 152 */       new OID("1.3.6.1.2.1.33.1.4.4.1"), 
/* 153 */       upsOutputEntryIndex, 
/* 154 */       upsOutputEntryColumns);
/*     */     
/*     */ 
/* 157 */     this.upsOutputEntryModel = new DefaultMOMutableTableModel();
/* 158 */     this.upsOutputEntry.setModel(this.upsOutputEntryModel);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 163 */     this.outputLigar = new OctetString("true");
/* 164 */     this.upsOutputLigar = new DisplayStringScalar(
/* 165 */       new OID("1.3.6.1.2.1.33.1.4.5.0"), 
/* 166 */       MOAccessImpl.ACCESS_READ_ONLY, 
/* 167 */       this.outputLigar);
/*     */     
/* 169 */     this.tipoConsumo = new Integer32(1);
/* 170 */     this.upsTipoConsumo = new UpsOutputEnumeratedScalar(
/* 171 */       new OID("1.3.6.1.2.1.33.1.4.6.0"), 
/* 172 */       MOAccessImpl.ACCESS_READ_WRITE, 
/* 173 */       this.tipoConsumo, 
/* 174 */       new int[] {
/* 175 */       1, 
/* 176 */       2, 
/* 177 */       3, 
/* 178 */       4 });
/*     */     
/*     */ 
/* 181 */     this.upsPeriodoConsumo = new UpsOutputDisplayStringScalar(
/* 182 */       new OID("1.3.6.1.2.1.33.1.4.7.0"), 
/* 183 */       MOAccessImpl.ACCESS_READ_WRITE, 
/* 184 */       new OctetString(""), 
/* 185 */       0, 
/* 186 */       32);
/*     */     
/* 188 */     this.resultadoConsumo = new OctetString("");
/* 189 */     this.upsResultadoConsumo = new DisplayStringScalar(
/* 190 */       new OID("1.3.6.1.2.1.33.1.4.8.0"), 
/* 191 */       MOAccessImpl.ACCESS_READ_ONLY, 
/* 192 */       this.resultadoConsumo);
/*     */   }
/*     */   
/*     */ 
/*     */   public class UpsOutputDisplayStringScalar
/*     */     extends DisplayStringScalar
/*     */   {
/* 199 */     public boolean atualizacao = false;
/*     */     
/*     */     public UpsOutputDisplayStringScalar(OID oid, MOAccess access, OctetString value, int minSize, int maxSize) {
/* 202 */       super(access, value, minSize, maxSize);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 207 */       RequestStatus status = request.getStatus();
/* 208 */       VariableBinding vb = request.getVariableBinding();
/* 209 */       request.setUndoValue(getValue());
/* 210 */       setValue(vb.getVariable());
/* 211 */       status.setPhaseComplete(true);
/* 212 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 216 */       RequestStatus status = request.getStatus();
/* 217 */       if ((request.getUndoValue() != null) && 
/* 218 */         ((request.getUndoValue() instanceof Variable))) {
/* 219 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 220 */         status.setErrorStatus(errorStatus);
/* 221 */         status.setPhaseComplete(true);
/* 222 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 225 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 230 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 234 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */   public void registerMOs(MOServer server, OctetString context) throws DuplicateRegistrationException
/*     */   {
/* 240 */     server.register(this.upsOutputSource, context);
/* 241 */     server.register(this.upsOutputFrequency, context);
/* 242 */     server.register(this.upsOutputNumLines, context);
/* 243 */     server.register(this.upsOutputEntry, context);
/*     */     
/*     */ 
/* 246 */     server.register(this.upsOutputLigar, context);
/* 247 */     server.register(this.upsTipoConsumo, context);
/* 248 */     server.register(this.upsPeriodoConsumo, context);
/* 249 */     server.register(this.upsResultadoConsumo, context);
/* 250 */     server.register(this.upsSaidaLigada, context);
/*     */   }
/*     */   
/*     */ 
/*     */   public void unregisterMOs(MOServer server, OctetString context)
/*     */   {
/* 256 */     server.unregister(this.upsOutputSource, context);
/* 257 */     server.unregister(this.upsOutputFrequency, context);
/* 258 */     server.unregister(this.upsOutputNumLines, context);
/* 259 */     server.unregister(this.upsOutputEntry, context);
/*     */     
/*     */ 
/* 262 */     server.unregister(this.upsOutputLigar, context);
/* 263 */     server.unregister(this.upsTipoConsumo, context);
/* 264 */     server.unregister(this.upsPeriodoConsumo, context);
/* 265 */     server.unregister(this.upsResultadoConsumo, context);
/* 266 */     server.unregister(this.upsSaidaLigada, context);
/*     */   }
/*     */   
/*     */ 
/*     */   private Integer32 outputFrequency;
/*     */   
/*     */   private Integer32 tipoConsumo;
/*     */   private Integer32 saidaLigada;
/*     */   private OctetString outputLigar;
/*     */   private OID linhaUsada;
/*     */   private OctetString resultadoConsumo;
/*     */   public void addUpsOutputEntry(int index, int outputVoltage, int outputCurrent, int outputTruePower, int outputPercentLoad, int outputPotenciaAparente)
/*     */   {
/* 279 */     this.linhaUsada.setValue(String.valueOf(index));
/* 280 */     this.vr[0].setValue(outputVoltage);
/* 281 */     this.vr[1].setValue(outputCurrent);
/* 282 */     this.vr[2].setValue(outputTruePower);
/* 283 */     this.vr[3].setValue(outputPercentLoad);
/* 284 */     this.vr[4].setValue(outputPotenciaAparente);
/*     */     
/* 286 */     DefaultMOTableRow row = new DefaultMOTableRow(new OID(String.valueOf(index)), this.vr);
/* 287 */     this.upsOutputEntryModel.addRow(row);
/*     */   }
/*     */   
/*     */ 
/*     */   public MOTableRow removeUpsOutputEntry(OID index)
/*     */   {
/* 293 */     return this.upsOutputEntryModel.removeRow(index);
/*     */   }
/*     */   
/*     */   public class UpsOutputEnumeratedScalar extends EnumeratedScalar
/*     */   {
/* 298 */     private boolean atualizacao = false;
/*     */     
/*     */     public UpsOutputEnumeratedScalar(OID arg0, MOAccess arg1, Integer32 arg2, int[] arg3) {
/* 301 */       super(arg1, arg2, arg3);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 306 */       RequestStatus status = request.getStatus();
/* 307 */       VariableBinding vb = request.getVariableBinding();
/* 308 */       request.setUndoValue(getValue());
/* 309 */       setValue(vb.getVariable());
/* 310 */       status.setPhaseComplete(true);
/* 311 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 315 */       RequestStatus status = request.getStatus();
/* 316 */       if ((request.getUndoValue() != null) && 
/* 317 */         ((request.getUndoValue() instanceof Variable))) {
/* 318 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 319 */         status.setErrorStatus(errorStatus);
/* 320 */         status.setPhaseComplete(true);
/* 321 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 324 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/* 328 */     public boolean getAtualizacao() { return this.atualizacao; }
/*     */     
/*     */     public void setAtualizacao(boolean valor)
/*     */     {
/* 332 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUpsOutputLigar(String vr)
/*     */   {
/* 340 */     this.outputLigar.setValue(vr);
/* 341 */     this.upsOutputLigar.setValue(this.outputLigar);
/*     */   }
/*     */   
/*     */   public String getUpsOutputLigar()
/*     */   {
/* 346 */     return this.upsOutputLigar.getValue().toString();
/*     */   }
/*     */   
/*     */   public UpsOutputEnumeratedScalar getUpsTipoHisConsumo()
/*     */   {
/* 351 */     return this.upsTipoConsumo;
/*     */   }
/*     */   
/*     */   public void setsUpsResultadoConsumo(String s)
/*     */   {
/* 356 */     this.resultadoConsumo.setValue(s);
/* 357 */     this.upsResultadoConsumo.setValue(this.resultadoConsumo);
/*     */   }
/*     */   
/*     */   public UpsOutputDisplayStringScalar getUpsPeriodoConsumo()
/*     */   {
/* 362 */     return this.upsPeriodoConsumo;
/*     */   }
/*     */   
/*     */   public Integer32 getUpsOutputFrequency() {
/* 366 */     return (Integer32)this.upsOutputFrequency.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsOutputFrequency(int upsOutputFrequency) {
/* 370 */     this.outputFrequency.setValue(upsOutputFrequency);
/* 371 */     this.upsOutputFrequency.setValue(this.outputFrequency);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsSaidaLigada() {
/* 375 */     return (Integer32)this.upsSaidaLigada.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsSaidaLigada(int upsSaidaLigada) {
/* 379 */     this.saidaLigada.setValue(upsSaidaLigada);
/* 380 */     this.upsSaidaLigada.setValue(this.saidaLigada);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsOutputNumLines() {
/* 384 */     return (Integer32)this.upsOutputNumLines.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsOutputNumLines(int upsOutputNumLines) {
/* 388 */     this.outputNumLines.setValue(upsOutputNumLines);
/* 389 */     this.upsOutputNumLines.setValue(this.outputNumLines);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsOutputSource()
/*     */   {
/* 394 */     return (Integer32)this.upsOutputSource.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsOutputSource(int upsOutputSource) {
/* 398 */     this.outputSource.setValue(upsOutputSource);
/* 399 */     this.upsOutputSource.setValue(this.outputSource);
/*     */   }
/*     */   
/*     */   public MOTableRow getUpsOutputRow(OID index)
/*     */   {
/* 404 */     return this.upsOutputEntryModel.getRow(index);
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsOutputGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */