/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOAccess;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.DefaultMOMutableTableModel;
/*     */ import org.snmp4j.agent.mo.DefaultMOTable;
/*     */ import org.snmp4j.agent.mo.DefaultMOTableRow;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOMutableColumn;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.MOTableIndex;
/*     */ import org.snmp4j.agent.mo.MOTableRow;
/*     */ import org.snmp4j.agent.mo.MOTableSubIndex;
/*     */ import org.snmp4j.agent.mo.snmp.DisplayStringScalar;
/*     */ import org.snmp4j.agent.mo.snmp.EnumeratedScalar;
/*     */ import org.snmp4j.agent.request.RequestStatus;
/*     */ import org.snmp4j.agent.request.SubRequest;
/*     */ import org.snmp4j.smi.Counter32;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.Variable;
/*     */ import org.snmp4j.smi.VariableBinding;
/*     */ 
/*     */ public class UpsInputGroup implements MOGroup
/*     */ {
/*     */   private MOScalar upsInputLineBads;
/*     */   private MOScalar upsInputNumLines;
/*     */   private UpsInputDisplayStringScalar upsInputLigar;
/*     */   public static final int colUpsInputFrequency = 2;
/*     */   public static final int colUpsInputVoltage = 3;
/*     */   public static final int colUpsInputCurrent = 4;
/*     */   public static final int colUpsInputTruePower = 5;
/*     */   public static final int colUpsInputPotenciaAparente = 6;
/*     */   private static final int idxUpsInputFrequency = 0;
/*     */   private static final int idxUpsInputVoltage = 1;
/*     */   private static final int idxUpsInputCurrent = 2;
/*     */   private static final int idxUpsInputTruePower = 3;
/*     */   private static final int idxUpsInputPotenciaAparente = 4;
/*  42 */   private static MOTableSubIndex[] upsInputEntryIndexes = {
/*  43 */     new MOTableSubIndex(2, 1, Integer.MAX_VALUE) };
/*     */   
/*  45 */   private static MOTableIndex upsInputEntryIndex = new MOTableIndex(upsInputEntryIndexes, true);
/*     */   
/*     */   private DefaultMOTable upsInputEntry;
/*     */   private DefaultMOMutableTableModel upsInputEntryModel;
/*     */   private OID linhaUsada;
/*     */   private Integer32[] vrTabela;
/*     */   private Counter32 inputLineBads;
/*     */   private OctetString inputLigar;
/*     */   
/*     */   public UpsInputGroup(String modeloUps, int numLinhas, int linhaUsada)
/*     */   {
/*  56 */     this.linhaUsada = new OID(String.valueOf(linhaUsada));
/*     */     
/*     */ 
/*  59 */     this.inputLineBads = new Counter32(0L);
/*  60 */     this.upsInputLineBads = new MOScalar(
/*  61 */       new OID("1.3.6.1.2.1.33.1.3.1.0"), 
/*  62 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  63 */       this.inputLineBads);
/*     */     
/*     */ 
/*  66 */     this.upsInputNumLines = new MOScalar(
/*  67 */       new OID("1.3.6.1.2.1.33.1.3.2.0"), 
/*  68 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  69 */       new Integer32(numLinhas));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     this.inputLigar = new OctetString("");
/*  75 */     this.upsInputLigar = 
/*  76 */       new UpsInputDisplayStringScalar(
/*  77 */       new OID("1.3.6.1.2.1.33.1.3.4.0"), 
/*  78 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  79 */       this.inputLigar, 0, 5);
/*     */     
/*     */ 
/*  82 */     this.vrTabela = new Integer32[5];
/*  83 */     for (int i = 0; i < this.vrTabela.length; i++) {
/*  84 */       this.vrTabela[i] = new Integer32();
/*     */     }
/*  86 */     MOMutableColumn[] upsInputEntryColumns = new MOMutableColumn[this.vrTabela.length];
/*  87 */     upsInputEntryColumns[0] = 
/*  88 */       new MOMutableColumn(
/*  89 */       2, 
/*  90 */       2, 
/*  91 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/*  94 */     upsInputEntryColumns[1] = 
/*  95 */       new MOMutableColumn(
/*  96 */       3, 
/*  97 */       2, 
/*  98 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 101 */     upsInputEntryColumns[2] = 
/* 102 */       new MOMutableColumn(
/* 103 */       4, 
/* 104 */       2, 
/* 105 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 108 */     upsInputEntryColumns[3] = 
/* 109 */       new MOMutableColumn(
/* 110 */       5, 
/* 111 */       2, 
/* 112 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/* 114 */     upsInputEntryColumns[4] = 
/* 115 */       new MOMutableColumn(
/* 116 */       6, 
/* 117 */       2, 
/* 118 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/* 121 */     this.upsInputEntry = new DefaultMOTable(
/* 122 */       new OID("1.3.6.1.2.1.33.1.3.3.1"), 
/* 123 */       upsInputEntryIndex, 
/* 124 */       upsInputEntryColumns);
/*     */     
/* 126 */     this.upsInputEntryModel = new DefaultMOMutableTableModel();
/* 127 */     this.upsInputEntry.setModel(this.upsInputEntryModel);
/*     */   }
/*     */   
/*     */   public void registerMOs(MOServer server, OctetString context) throws DuplicateRegistrationException {
/* 131 */     server.register(this.upsInputLineBads, context);
/* 132 */     server.register(this.upsInputNumLines, context);
/* 133 */     server.register(this.upsInputLigar, context);
/* 134 */     server.register(this.upsInputEntry, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context)
/*     */   {
/* 139 */     server.unregister(this.upsInputLineBads, context);
/* 140 */     server.unregister(this.upsInputNumLines, context);
/* 141 */     server.unregister(this.upsInputLigar, context);
/* 142 */     server.unregister(this.upsInputEntry, context);
/*     */   }
/*     */   
/*     */   public void incrementUpsInputLineBads()
/*     */   {
/* 147 */     this.inputLineBads.increment();
/* 148 */     this.upsInputLineBads.setValue(this.inputLineBads);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUpsInputEntry(int index, int inputFrequency, int inputVoltage, int inputCurrent, int inputTruePower, int inputPotenciaAparente)
/*     */   {
/* 159 */     this.linhaUsada.setValue(String.valueOf(index));
/* 160 */     this.vrTabela[0].setValue(inputFrequency);
/* 161 */     this.vrTabela[1].setValue(inputVoltage);
/* 162 */     this.vrTabela[2].setValue(inputCurrent);
/* 163 */     this.vrTabela[3].setValue(inputTruePower);
/* 164 */     this.vrTabela[4].setValue(inputPotenciaAparente);
/*     */     
/* 166 */     DefaultMOTableRow row = new DefaultMOTableRow(this.linhaUsada, this.vrTabela);
/* 167 */     this.upsInputEntryModel.addRow(row);
/*     */   }
/*     */   
/*     */   public MOTableRow removeUpsInputEntry(OID index)
/*     */   {
/* 172 */     return this.upsInputEntryModel.removeRow(index);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setUpsInputLigar(String vr)
/*     */   {
/* 178 */     this.inputLigar.setValue(vr);
/* 179 */     this.upsInputLigar.setValue(this.inputLigar);
/*     */   }
/*     */   
/*     */   public UpsInputDisplayStringScalar getUpsInputLigar()
/*     */   {
/* 184 */     return this.upsInputLigar;
/*     */   }
/*     */   
/*     */   public Counter32 getUpsInputLineBads() {
/* 188 */     return (Counter32)this.upsInputLineBads.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsInputLineBads(long valor)
/*     */   {
/* 193 */     this.upsInputLineBads.setValue(new Counter32(valor));
/*     */   }
/*     */   
/*     */   public Integer32 getUpsInputNumLines() {
/* 197 */     return (Integer32)this.upsInputNumLines.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsInputNumLines(Integer32 upsInputNumLines) {
/* 201 */     this.upsInputNumLines.setValue(upsInputNumLines);
/*     */   }
/*     */   
/*     */   public MOTableRow getUpsInputRow(int index)
/*     */   {
/* 206 */     this.linhaUsada.setValue(String.valueOf(index));
/* 207 */     return this.upsInputEntryModel.getRow(this.linhaUsada);
/*     */   }
/*     */   
/*     */   class UpsInputEnumeratedScalar extends EnumeratedScalar
/*     */   {
/* 212 */     private boolean atualizacao = false;
/*     */     
/*     */     public UpsInputEnumeratedScalar(OID arg0, MOAccess arg1, Integer32 arg2, int[] arg3) {
/* 215 */       super(arg1, arg2, arg3);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 220 */       RequestStatus status = request.getStatus();
/* 221 */       VariableBinding vb = request.getVariableBinding();
/* 222 */       request.setUndoValue(getValue());
/* 223 */       setValue(vb.getVariable());
/* 224 */       status.setPhaseComplete(true);
/* 225 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 229 */       RequestStatus status = request.getStatus();
/* 230 */       if ((request.getUndoValue() != null) && 
/* 231 */         ((request.getUndoValue() instanceof Variable))) {
/* 232 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 233 */         status.setErrorStatus(errorStatus);
/* 234 */         status.setPhaseComplete(true);
/* 235 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 238 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 243 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 247 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */   class UpsInputDisplayStringScalar
/*     */     extends DisplayStringScalar
/*     */   {
/* 254 */     public boolean atualizacao = false;
/*     */     
/*     */     public UpsInputDisplayStringScalar(OID oid, MOAccess access, OctetString value, int minSize, int maxSize) {
/* 257 */       super(access, value, minSize, maxSize);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 262 */       RequestStatus status = request.getStatus();
/* 263 */       VariableBinding vb = request.getVariableBinding();
/* 264 */       request.setUndoValue(getValue());
/* 265 */       setValue(vb.getVariable());
/* 266 */       status.setPhaseComplete(true);
/* 267 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 271 */       RequestStatus status = request.getStatus();
/* 272 */       if ((request.getUndoValue() != null) && 
/* 273 */         ((request.getUndoValue() instanceof Variable))) {
/* 274 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 275 */         status.setErrorStatus(errorStatus);
/* 276 */         status.setPhaseComplete(true);
/* 277 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 280 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 285 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 289 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsInputGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */