/*      */ package br.com.schneider.sgm.snmp;
/*      */ 
/*      */ import br.com.schneider.sgm.controle.Controle;
/*      */ import br.com.schneider.sgm.eventos.ControleListener;
/*      */ import br.com.schneider.sgm.eventos.Evento;
/*      */ import br.com.schneider.sgm.historico.HistoricoConsumo;
/*      */ import br.com.schneider.sgm.persistencia.Persistencia;
/*      */ import br.com.schneider.sgm.servico.NotificadorHisConsumo;
/*      */ import br.com.schneider.sgm.servico.NotificadorTrapOnBattery;
/*      */ import br.com.schneider.sgm.servico.NotificadorTraps;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.TimerTask;
/*      */ import org.snmp4j.agent.CommandProcessor;
/*      */ import org.snmp4j.agent.DuplicateRegistrationException;
/*      */ import org.snmp4j.agent.mo.snmp.SNMPv2MIB;
/*      */ import org.snmp4j.agent.mo.snmp.SnmpCommunityMIB;
/*      */ import org.snmp4j.agent.mo.snmp.SnmpNotificationMIB;
/*      */ import org.snmp4j.agent.mo.snmp.SnmpTargetMIB;
/*      */ import org.snmp4j.agent.mo.snmp.SysUpTime;
/*      */ import org.snmp4j.agent.mo.snmp.VacmMIB;
/*      */ import org.snmp4j.log.LogFactory;
/*      */ import org.snmp4j.security.USM;
/*      */ import org.snmp4j.smi.Gauge32;
/*      */ import org.snmp4j.smi.Integer32;
/*      */ import org.snmp4j.smi.OctetString;
/*      */ import org.snmp4j.smi.TimeTicks;
/*      */ import org.snmp4j.smi.Variable;
/*      */ import org.snmp4j.util.ThreadPool;
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AgenteSGM
/*      */   extends AgenteSNMP
/*      */   implements ControleListener, ActionListener
/*      */ {
/*      */   private javax.swing.Timer timerPerMIB;
/*      */   protected UpsIdentGroup grupoIdent;
/*      */   protected UpsBatteryGroup grupoBateria;
/*      */   protected UpsInputGroup grupoEntrada;
/*      */   protected UpsOutputGroup grupoSaida;
/*      */   protected UpsControlGroup grupoControle;
/*      */   protected UpsAlarmGroup grupoAlarme;
/*      */   protected UpsConfigGroup grupoConfig;
/*      */   protected UpsTestGroup grupoTeste;
/*      */   protected UpsBypassGroup grupoBypass;
/*      */   
/*      */   static
/*      */   {
/*   52 */     LogFactory.setLogFactory(new LogFactory());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   65 */   protected String modeloUPS = "";
/*      */   
/*      */   public Controle feeder;
/*      */   
/*      */   private float tensaoEntrada;
/*      */   
/*      */   private boolean[] alarmesUpsMIB;
/*      */   
/*      */   private Evento[] alarmesMicrosol;
/*      */   
/*      */   private TimeTicks horaAlarme;
/*      */   
/*      */   private java.util.Timer timerUpsTrapOnBattery;
/*      */   private java.util.Timer timerUpsTestElapsedTime;
/*      */   private boolean enviaTrap;
/*      */   private java.util.Timer timerUpsSecondsOnBattery;
/*      */   private int numSecondsOnBattery;
/*      */   private int numElapsedTime;
/*      */   private int delayShutdown;
/*      */   private int delayStartup;
/*      */   private int tipoShutdown;
/*      */   private boolean updateUpsSecondsOnBattery;
/*      */   private boolean atualizaUpsConfigLowBattTime;
/*      */   private boolean atualizaUpsTestElapsedTime;
/*      */   private boolean remove24;
/*      */   private boolean removeAlarme;
/*      */   private boolean removeControle;
/*      */   private boolean[] diasAgenda;
/*      */   private HistoricoConsumo hisConsumo;
/*      */   private boolean execPrim;
/*      */   
/*      */   public AgenteSGM(File bootCounterFile, File configFile, String address, Controle controle, HistoricoConsumo his)
/*      */     throws IOException
/*      */   {
/*   99 */     super(bootCounterFile, configFile, address);
/*      */     
/*      */ 
/*  102 */     this.agent.setThreadPool(ThreadPool.create("RequestPool", 4));
/*  103 */     this.feeder = controle;
/*      */     
/*  105 */     File bootCounter = new File("AgenteSGMBC.cfg");
/*  106 */     File config = new File("AgenteSGMConfig.cfg");
/*      */     
/*  108 */     if ((bootCounter.exists()) && (config.exists())) {
/*  109 */       this.execPrim = false;
/*      */     } else {
/*  111 */       this.execPrim = true;
/*      */     }
/*      */     
/*  114 */     initConfigGeralSNMP(
/*  115 */       this.feeder.getPortaPedidos(), 
/*  116 */       this.feeder.getComunidadeLeitura(), 
/*  117 */       this.feeder.getComunidadeEscrita());
/*      */     
/*      */ 
/*  120 */     initConfigTraps(
/*  121 */       this.feeder.getEnderecoGerente(), 
/*  122 */       this.feeder.getPortaEnvio(), 
/*  123 */       this.feeder.getVersaoSNMP(), 
/*  124 */       this.feeder.getProtocoloSNMP());
/*      */     
/*      */ 
/*      */ 
/*  128 */     this.tensaoEntrada = 0.0F;
/*  129 */     this.alarmesUpsMIB = new boolean[24];
/*  130 */     for (int i = 0; i < this.alarmesUpsMIB.length; i++)
/*  131 */       this.alarmesUpsMIB[i] = false;
/*  132 */     this.horaAlarme = new TimeTicks();
/*  133 */     this.timerUpsTrapOnBattery = new java.util.Timer();
/*  134 */     this.enviaTrap = false;
/*  135 */     this.timerUpsSecondsOnBattery = new java.util.Timer();
/*  136 */     this.timerUpsTestElapsedTime = new java.util.Timer();
/*  137 */     this.delayStartup = -1;
/*  138 */     this.delayShutdown = -1;
/*  139 */     this.numSecondsOnBattery = 0;
/*  140 */     this.updateUpsSecondsOnBattery = false;
/*  141 */     this.atualizaUpsConfigLowBattTime = true;
/*  142 */     this.remove24 = true;
/*  143 */     this.removeAlarme = true;
/*  144 */     this.removeControle = true;
/*  145 */     this.diasAgenda = new boolean[7];
/*  146 */     addShutdownHook();
/*  147 */     this.timerPerMIB = new javax.swing.Timer(1000, this);
/*  148 */     this.hisConsumo = his;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void addNotificationTargets(SnmpTargetMIB targetMIB, SnmpNotificationMIB notificationMIB)
/*      */   {
/*  154 */     targetMIB.addDefaultTDomains();
/*      */     
/*  156 */     notificationMIB.addNotifyEntry(new OctetString("default"), 
/*  157 */       new OctetString("notify"), 
/*  158 */       1, 
/*  159 */       3);
/*      */     
/*  161 */     if (this.execPrim) {
/*  162 */       initTargetMIB(this.snmpTargetMIB);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void addViews(VacmMIB vacm)
/*      */   {
/*  168 */     if (this.execPrim) {
/*  169 */       initVacmMIB(vacm);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void addCommunities(SnmpCommunityMIB communityMIB)
/*      */   {
/*  175 */     if (this.execPrim) {
/*  176 */       initCommunityMIB(communityMIB);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerSnmpMIBs()
/*      */   {
/*  185 */     this.grupoIdent = new UpsIdentGroup(
/*  186 */       "Microsol", 
/*  187 */       this.feeder.getPersistencia().getModeloUPSString(), 
/*  188 */       "1.0", 
/*  189 */       "1.0");
/*      */     
/*  191 */     this.grupoIdent.setUpsIdentName(new OctetString(this.feeder.getPersistencia().getNomeUPS()));
/*  192 */     this.grupoIdent.setUpsPortaPedidos(this.feeder.getPortaPedidos());
/*      */     
/*  194 */     this.grupoBateria = new UpsBatteryGroup(this.modeloUPS);
/*  195 */     this.grupoEntrada = new UpsInputGroup(this.modeloUPS, 1, 1);
/*  196 */     this.grupoSaida = new UpsOutputGroup(1, 1);
/*  197 */     this.grupoControle = new UpsControlGroup(this.modeloUPS);
/*  198 */     this.grupoAlarme = new UpsAlarmGroup();
/*  199 */     this.grupoConfig = new UpsConfigGroup();
/*  200 */     this.grupoTeste = new UpsTestGroup();
/*  201 */     this.grupoBypass = new UpsBypassGroup();
/*      */     
/*      */ 
/*      */ 
/*  205 */     super.registerSnmpMIBs();
/*      */   }
/*      */   
/*      */   protected void registerManagedObjects()
/*      */   {
/*      */     try {
/*  211 */       this.grupoIdent.registerMOs(this.server, null);
/*  212 */       this.grupoBateria.registerMOs(this.server, null);
/*  213 */       this.grupoEntrada.registerMOs(this.server, null);
/*  214 */       this.grupoSaida.registerMOs(this.server, null);
/*  215 */       this.grupoControle.registerMOs(this.server, null);
/*  216 */       this.grupoAlarme.registerMOs(this.server, null);
/*  217 */       this.grupoConfig.registerMOs(this.server, null);
/*  218 */       this.grupoTeste.registerMOs(this.server, null);
/*  219 */       this.grupoBypass.registerMOs(this.server, null);
/*      */     }
/*      */     catch (DuplicateRegistrationException ex) {
/*  222 */       ex.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void actionPerformed(ActionEvent ae)
/*      */   {
/*  232 */     updateUpsIdentGroup();
/*  233 */     updateTestGroup();
/*  234 */     upadateUpsControlGroup();
/*      */     
/*      */ 
/*  237 */     if ((this.grupoSaida.getUpsTipoHisConsumo().getAtualizacao()) && 
/*  238 */       (this.grupoSaida.getUpsTipoHisConsumo().getAtualizacao()))
/*      */     {
/*  240 */       NotificadorHisConsumo notificador = new NotificadorHisConsumo(
/*  241 */         this.grupoSaida, 
/*  242 */         this.notificationOriginator, 
/*  243 */         this.hisConsumo, 
/*  244 */         this.snmpv2MIB.getSysUpTime().get());
/*      */       
/*  246 */       notificador.setDaemon(true);
/*  247 */       notificador.start();
/*      */     }
/*  249 */     saveConfig();
/*  250 */     updateVarAcessoRemoto();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateVarAcessoRemoto()
/*      */   {
/*  259 */     updateConfigGeralSNMP();
/*  260 */     this.feeder.salvaPortaPedidos(this.portaPedidos);
/*  261 */     this.feeder.salvaComunidadeLeitura(this.comunidadeLeitura);
/*  262 */     this.feeder.salvaComunidadeEscrita(this.comunidadeEscrita);
/*      */     
/*  264 */     updateConfigTraps();
/*  265 */     this.feeder.salvaEnderecoGerente(this.ipGerente);
/*  266 */     this.feeder.salvaPortaEnvio(this.portaTraps);
/*  267 */     this.feeder.salvaVSnmp2(new Integer(this.vSNMPTraps));
/*  268 */     this.feeder.salvaProtocolo(this.protocoloTransporte);
/*  269 */     saveConfig();
/*      */     
/*      */ 
/*  272 */     if (this.grupoIdent.getUpsPortaPedidos().getAtualizacao())
/*      */     {
/*      */ 
/*  275 */       this.portaPedidos = this.grupoIdent.getUpsPortaPedidos().getValue().toInt();
/*  276 */       this.feeder.salvaPortaPedidos(this.portaPedidos);
/*  277 */       this.grupoIdent.getUpsPortaPedidos().setAtualizacao(false);
/*  278 */       saveConfig();
/*  279 */       this.feeder.setLocalAdress(this.feeder.getEnderecoIPLocal() + "/" + this.portaPedidos);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateConfigGroup()
/*      */   {
/*  290 */     if (this.feeder.isTensaoEntrada220()) {
/*  291 */       this.grupoConfig.setUpsConfigInputVoltage(220);
/*      */     } else {
/*  293 */       this.grupoConfig.setUpsConfigInputVoltage(110);
/*      */     }
/*  295 */     this.grupoConfig.setUpsConfigInputFreq((int)this.feeder.getFrequenciaEntrada());
/*      */     
/*  297 */     if (this.feeder.isTensaoSaida220()) {
/*  298 */       this.grupoConfig.setUpsConfigOutputVoltage(220);
/*      */     } else {
/*  300 */       this.grupoConfig.setUpsConfigOutputVoltage(110);
/*      */     }
/*      */     
/*  303 */     this.grupoConfig.setUpsConfigOutputFreq((int)this.feeder.getFrequenciaSaida());
/*  304 */     this.grupoConfig.setUpsConfigOutputVA(this.feeder.getPotenciaNominalVA());
/*  305 */     this.grupoConfig.setUpsConfigOutputPower(this.feeder.getPotenciaNominalW());
/*      */     
/*  307 */     this.grupoConfig.setUpsConfigAudibleStatus(2);
/*  308 */     this.grupoConfig.setUpsConfigLowVoltageTransferPoint((int)this.feeder.getLimiteInferiorTensaoEntrada());
/*  309 */     this.grupoConfig.setUpsConfigHighVoltageTransferPoint((int)this.feeder.getLimiteSuperiorTensaoEntrada());
/*      */     
/*      */ 
/*  312 */     if (this.feeder.isModoRede()) {
/*  313 */       this.grupoConfig.setUpsMicrosolRedeLigada(0);
/*      */     } else {
/*  315 */       this.grupoConfig.setUpsMicrosolRedeLigada(1);
/*      */     }
/*  317 */     if (this.feeder.isSuperAquecimento())
/*      */     {
/*  319 */       this.grupoConfig.setUpsMicrosolSuperAquecimento(0);
/*  320 */       this.alarmesUpsMIB[4] = true;
/*      */     }
/*      */     else
/*      */     {
/*  324 */       this.grupoConfig.setUpsMicrosolSuperAquecimento(1);
/*  325 */       this.alarmesUpsMIB[4] = false;
/*      */     }
/*      */     
/*  328 */     if (this.feeder.isSobrecarga())
/*      */     {
/*  330 */       this.grupoConfig.setUpsMicrosolSobrecarga(0);
/*  331 */       this.alarmesUpsMIB[7] = true;
/*      */     }
/*      */     else
/*      */     {
/*  335 */       this.grupoConfig.setUpsMicrosolSobrecarga(1);
/*  336 */       this.alarmesUpsMIB[7] = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void progUpdateTestElapsedTime()
/*      */   {
/*  345 */     this.timerUpsTestElapsedTime.schedule(
/*  346 */       new TimerTask()
/*      */       {
/*      */         public void run() {
/*  349 */           AgenteSGM.this.grupoTeste.setUpsTestElapsedTime(++AgenteSGM.this.numElapsedTime);
/*      */           
/*  351 */           AgenteSGM.this.atualizaUpsTestElapsedTime = false;
/*      */         }
/*      */         
/*      */ 
/*  355 */       }, 1000L);
/*  356 */     this.atualizaUpsTestElapsedTime = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTestGroup()
/*      */   {
/*  364 */     if (this.grupoTeste.getUpsTestId().getAtualizacao())
/*      */     {
/*      */ 
/*  367 */       if (this.grupoTeste.getUpsTestId().getValue().toString() == 
/*  368 */         "1.3.6.1.2.1.33.1.7.7.3")
/*      */       {
/*  370 */         this.grupoTeste.setUpsTestStartTime(
/*  371 */           this.snmpv2MIB.getSysUpTime().get().toInt());
/*  372 */         this.feeder.iniciarAutoteste();
/*  373 */         this.alarmesUpsMIB[23] = true;
/*  374 */         progUpdateTestElapsedTime();
/*      */ 
/*      */       }
/*  377 */       else if (this.grupoTeste.getUpsTestId().getValue().toString() == 
/*  378 */         "1.3.6.1.2.1.33.1.7.7.2")
/*      */       {
/*  380 */         this.feeder.finalizarAutoteste();
/*  381 */         this.grupoTeste.setUpsTestResultsSummary(4);
/*  382 */         this.alarmesUpsMIB[23] = false;
/*  383 */         if (this.atualizaUpsTestElapsedTime)
/*      */         {
/*  385 */           this.timerUpsTestElapsedTime.cancel();
/*  386 */           this.atualizaUpsTestElapsedTime = false;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  391 */       this.grupoTeste.getUpsTestId().setAtualizacao(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBypassGroup()
/*      */   {
/*  404 */     if (this.grupoBypass.getUpsBypassAtivar().getAtualizacao())
/*      */     {
/*  406 */       if (this.grupoBypass.getUpsBypassAtivar().getValue().toString().equalsIgnoreCase("true"))
/*      */       {
/*  408 */         if (this.feeder.ativaBypass()) {
/*  409 */           this.alarmesUpsMIB[10] = true;
/*      */         }
/*  411 */       } else if (this.grupoBypass.getUpsBypassAtivar().getValue().toString().equalsIgnoreCase("false"))
/*      */       {
/*  413 */         if (this.feeder.desativaBypass())
/*  414 */           this.alarmesUpsMIB[10] = false;
/*      */       }
/*  416 */       this.grupoBypass.getUpsBypassAtivar().setAtualizacao(false);
/*      */     }
/*      */     
/*  419 */     if (this.feeder.isBypassAtivado()) {
/*  420 */       this.grupoBypass.setUpsBypassAtivar("true");
/*      */     } else {
/*  422 */       this.grupoBypass.setUpsBypassAtivar("false");
/*      */     }
/*  424 */     this.grupoBypass.setUpsBypassFrequency((int)this.feeder.getFrequenciaBypass() * 10);
/*  425 */     this.grupoBypass.addUpsBypassEntry(
/*  426 */       1, 
/*  427 */       (int)this.feeder.getTensaoBypass(), 
/*  428 */       (int)this.feeder.getCorrenteBypass() * 10, 
/*  429 */       (int)this.feeder.getPotenciaBypass() * 10);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateUpsIdentGroup()
/*      */   {
/*  437 */     this.grupoIdent.setUpsIdentModel(new OctetString(this.feeder.getPersistencia().getModeloUPSString()));
/*  438 */     if (this.grupoIdent.getUpsIdentName().getAtualizacao()) {
/*  439 */       this.feeder.salvaNomeUPS(this.grupoIdent.getUpsIdentName().getValue().toString());
/*  440 */       this.grupoIdent.setUpsIdentNameAtulizacao(false);
/*      */     }
/*      */     
/*  443 */     if (this.grupoIdent.getUpsIdentAttachedDevices().getAtualizacao()) {
/*  444 */       this.feeder.setNomePCUPS(this.grupoIdent.getUpsIdentAttachedDevices().getValue().toString());
/*  445 */       this.grupoIdent.setUpsIdentAttachedDevicesAtualizacao(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateUpsBatteryGroup()
/*      */   {
/*  455 */     if (this.feeder == null)
/*      */     {
/*  457 */       return;
/*      */     }
/*      */     
/*  460 */     if (this.grupoBateria == null)
/*      */     {
/*  462 */       return;
/*      */     }
/*      */     
/*  465 */     this.grupoBateria.setUpsEstimatedMinutesRemaining(this.feeder.getAutonomiaBateria());
/*  466 */     this.grupoBateria.setUpsBatteryVoltage((int)(this.feeder.getTensaoBateria() * 10.0F));
/*  467 */     this.grupoBateria.setUpsBatteryTemperature((int)(this.feeder.getTemperaturaUPS() * 10.0F));
/*  468 */     this.grupoBateria.setUpsEstimatedChargeRemaining(this.feeder.getPercentualBateria());
/*      */     
/*      */ 
/*  471 */     if (this.feeder.isUsandoSomenteBateria())
/*      */     {
/*  473 */       this.alarmesUpsMIB[1] = true;
/*      */       
/*  475 */       if ((this.feeder.isBateriaCritica()) && (this.feeder.isBateriaBaixa()))
/*      */       {
/*  477 */         this.alarmesUpsMIB[2] = false;
/*  478 */         this.alarmesUpsMIB[3] = true;
/*  479 */         this.grupoBateria.setUpsBatteryStatus(
/*  480 */           4);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  498 */       if (!this.enviaTrap) {
/*  499 */         progEnvioUpsTrapOnBattery();
/*      */       }
/*      */       
/*  502 */       if (!this.updateUpsSecondsOnBattery) {
/*  503 */         progUpdateUpsSecondsOnBattery();
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  508 */       this.alarmesUpsMIB[1] = false;
/*  509 */       if ((!this.feeder.isBateriaCritica()) && (this.feeder.isBateriaBaixa()))
/*      */       {
/*  511 */         this.alarmesUpsMIB[3] = false;
/*      */       }
/*  513 */       if ((!this.feeder.isBateriaCritica()) && (!this.feeder.isBateriaBaixa()))
/*      */       {
/*  515 */         this.alarmesUpsMIB[2] = false;
/*  516 */         this.atualizaUpsConfigLowBattTime = true;
/*  517 */         this.grupoConfig.getUpsConfigLowBattTime().setValue(0);
/*      */       }
/*      */       
/*  520 */       if (this.enviaTrap) {
/*  521 */         this.timerUpsTrapOnBattery.cancel();
/*      */       }
/*  523 */       if (this.updateUpsSecondsOnBattery) {
/*  524 */         this.timerUpsSecondsOnBattery.cancel();
/*      */       }
/*      */       
/*  527 */       this.numSecondsOnBattery = 0;
/*  528 */       this.grupoBateria.setUpsSecondsOnBattery(this.numSecondsOnBattery);
/*  529 */       this.grupoConfig.setUpsConfigLowBattTime(0);
/*      */     }
/*      */     
/*  532 */     if (this.feeder.isCarregandoBateria()) {
/*  533 */       this.grupoBateria.setUpsBatteryCarregando(0);
/*      */     }
/*      */     else
/*      */     {
/*  537 */       this.grupoBateria.setUpsBatteryCarregando(1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void progEnvioUpsTrapOnBattery()
/*      */   {
/*  548 */     this.timerUpsTrapOnBattery.schedule(
/*  549 */       new TimerTask()
/*      */       {
/*      */         public void run() {
/*  552 */           AgenteSGM.this.horaAlarme = AgenteSGM.this.snmpv2MIB.getSysUpTime().get();
/*  553 */           NotificadorTrapOnBattery notificador = new NotificadorTrapOnBattery(AgenteSGM.this.grupoBateria, AgenteSGM.this.grupoConfig, AgenteSGM.this.notificationOriginator, AgenteSGM.this.horaAlarme);
/*  554 */           notificador.setDaemon(true);
/*  555 */           notificador.start();
/*  556 */           AgenteSGM.this.enviaTrap = false;
/*      */         }
/*      */         
/*  559 */       }, 60000L);
/*  560 */     this.enviaTrap = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void progUpdateUpsSecondsOnBattery()
/*      */   {
/*  568 */     this.timerUpsSecondsOnBattery.schedule(
/*  569 */       new TimerTask()
/*      */       {
/*      */         public void run() {
/*  572 */           AgenteSGM.this.grupoBateria.setUpsSecondsOnBattery(++AgenteSGM.this.numSecondsOnBattery);
/*  573 */           AgenteSGM.this.updateUpsSecondsOnBattery = false;
/*      */         }
/*      */         
/*      */ 
/*  577 */       }, 1000L);
/*  578 */     this.updateUpsSecondsOnBattery = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateUpsInputGroup()
/*      */   {
/*  585 */     if (this.grupoEntrada.getUpsInputLigar().getAtualizacao())
/*      */     {
/*  587 */       if (this.grupoEntrada.getUpsInputLigar().getValue().toString().equalsIgnoreCase("true"))
/*      */       {
/*  589 */         this.feeder.ligaEntrada();
/*      */ 
/*      */       }
/*  592 */       else if (this.grupoEntrada.getUpsInputLigar().getValue().toString().equalsIgnoreCase("false"))
/*      */       {
/*  594 */         this.feeder.desligaEntrada();
/*      */       }
/*  596 */       this.grupoEntrada.getUpsInputLigar().setAtualizacao(false);
/*      */     }
/*      */     
/*  599 */     if (this.feeder.isEntradaLigada()) {
/*  600 */       this.grupoEntrada.setUpsInputLigar("true");
/*      */     } else {
/*  602 */       this.grupoEntrada.setUpsInputLigar("false");
/*      */     }
/*      */     
/*  605 */     this.tensaoEntrada = this.feeder.getTensaoEntrada();
/*  606 */     this.grupoEntrada.addUpsInputEntry(
/*  607 */       1, 
/*  608 */       (int)(this.feeder.getFrequenciaEntrada() * 10.0F), 
/*  609 */       (int)this.tensaoEntrada, 
/*  610 */       (int)(this.feeder.getCorrenteEntrada() * 10.0F), 
/*  611 */       (int)this.feeder.getPotenciaRealEntrada(), 
/*  612 */       (int)this.feeder.getPotenciaAparenteEntrada());
/*      */     
/*      */ 
/*      */ 
/*  616 */     if ((this.tensaoEntrada < this.feeder.getLimiteInferiorTensaoEntrada()) || 
/*  617 */       (this.tensaoEntrada > this.feeder.getLimiteSuperiorTensaoEntrada())) {
/*  618 */       this.grupoEntrada.incrementUpsInputLineBads();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateUpsOutputGroup()
/*      */   {
/*  626 */     if (this.feeder.isSaidaLigada()) {
/*  627 */       this.grupoSaida.setUpsSaidaLigada(0);
/*      */     } else {
/*  629 */       this.grupoSaida.setUpsSaidaLigada(1);
/*      */     }
/*  631 */     if (this.feeder.isBypassAtivado()) {
/*  632 */       this.grupoSaida.setUpsOutputSource(4);
/*      */     }
/*  634 */     if (this.feeder.isUsandoSomenteBateria()) {
/*  635 */       this.grupoSaida.setUpsOutputSource(5);
/*      */     } else {
/*  637 */       this.grupoSaida.setUpsOutputSource(3);
/*      */     }
/*  639 */     this.grupoSaida.setUpsOutputFrequency((int)this.feeder.getFrequenciaSaida() * 10);
/*  640 */     this.grupoSaida.setUpsOutputNumLines(1);
/*      */     
/*  642 */     this.grupoSaida.addUpsOutputEntry(
/*  643 */       1, 
/*  644 */       (int)this.feeder.getTensaoSaida(), 
/*  645 */       (int)(this.feeder.getCorrenteSaida() * 10.0F), 
/*  646 */       (int)this.feeder.getPotenciaReal(), 
/*  647 */       (int)(this.feeder.getPotenciaAparente() * 100.0F / this.feeder.getPotenciaNominalW()), 
/*  648 */       (int)this.feeder.getPotenciaAparente());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateUpsAlarmGroup()
/*      */   {
/*  657 */     this.horaAlarme = this.snmpv2MIB.getSysUpTime().get();
/*  658 */     this.alarmesMicrosol = this.feeder.getEventos();
/*      */     
/*  660 */     NotificadorTraps notificador = new NotificadorTraps(
/*  661 */       this.grupoAlarme, 
/*  662 */       this.notificationOriginator, 
/*  663 */       this.alarmesUpsMIB, 
/*  664 */       this.alarmesMicrosol, 
/*  665 */       this.horaAlarme);
/*  666 */     notificador.setDaemon(true);
/*  667 */     notificador.start();
/*      */     
/*      */ 
/*  670 */     this.grupoAlarme.setUpsAlarmsPresent(
/*  671 */       new Gauge32(
/*  672 */       this.grupoAlarme.getNumAlarmesAtivos()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void upadateUpsControlGroup()
/*      */   {
/*  684 */     if (this.removeControle)
/*      */     {
/*  686 */       this.grupoControle.setUpsStartupAfterDelay(new Integer32(-1));
/*  687 */       this.removeControle = false;
/*      */     }
/*      */     
/*  690 */     this.tipoShutdown = this.grupoControle.getUpsShutdownType().getValue().toInt();
/*      */     
/*  692 */     if (this.grupoControle.getUpsShutdownAfterDelay().getAtualizacao())
/*      */     {
/*  694 */       verificaDesligamento();
/*  695 */       this.grupoControle.getUpsShutdownAfterDelay().setAtualizacao(false);
/*      */     }
/*  697 */     if (this.grupoControle.getUpsStartupAfterDelay().getAtualizacao())
/*      */     {
/*  699 */       vericaLigamentoSaida();
/*  700 */       this.grupoControle.getUpsStartupAfterDelay().setAtualizacao(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  705 */     if ((this.delayShutdown >= 0) && (!this.grupoControle.getUpsShutdownAfterDelay().getAtualizacao()))
/*      */     {
/*  707 */       if (this.delayShutdown > 0)
/*      */       {
/*  709 */         this.delayShutdown -= 1;
/*  710 */         if (this.delayShutdown <= 5) {
/*  711 */           this.alarmesUpsMIB[22] = true;
/*      */         }
/*      */       } else {
/*  714 */         execDesligamento();
/*      */       }
/*  716 */       this.grupoControle.setUpsShutdownAfterDelay(this.delayShutdown);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  721 */     if ((this.delayStartup >= 0) && (!this.grupoControle.getUpsStartupAfterDelay().getAtualizacao()))
/*      */     {
/*  723 */       if (this.delayStartup > 0) {
/*  724 */         this.delayStartup -= 1;
/*      */       } else {
/*  726 */         execUpsStartUpAfterDelay();
/*      */       }
/*  728 */       this.grupoControle.setUpsStartupAfterDelay(this.delayStartup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void vericaLigamentoSaida()
/*      */   {
/*  742 */     if (this.grupoControle.getUpsStartupAfterDelay().getValue().toInt() == -1)
/*      */     {
/*  744 */       this.delayStartup = -1;
/*      */ 
/*      */     }
/*  747 */     else if (this.grupoControle.getUpsStartupAfterDelay().getValue().toInt() == 0)
/*      */     {
/*  749 */       execUpsStartUpAfterDelay();
/*      */     }
/*  751 */     else if (this.grupoControle.getUpsStartupAfterDelay().getValue().toInt() > 0)
/*      */     {
/*  753 */       this.delayStartup = this.grupoControle.getUpsStartupAfterDelay().getValue().toInt();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void verificaDesligamento()
/*      */   {
/*  764 */     if (this.grupoControle.getUpsShutdownAfterDelay().getValue().toInt() == -1)
/*      */     {
/*  766 */       this.delayShutdown = -1;
/*      */ 
/*      */     }
/*  769 */     else if (this.grupoControle.getUpsShutdownAfterDelay().getValue().toInt() == 0)
/*      */     {
/*  771 */       execDesligamento();
/*      */ 
/*      */     }
/*  774 */     else if (this.grupoControle.getUpsShutdownAfterDelay().getValue().toInt() > 0)
/*      */     {
/*  776 */       this.delayShutdown = this.grupoControle.getUpsShutdownAfterDelay().getValue().toInt();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void execDesligamento()
/*      */   {
/*  784 */     if (this.tipoShutdown == 1)
/*      */     {
/*  786 */       if (this.feeder.desligaSaida()) {
/*  787 */         this.alarmesUpsMIB[10] = true;
/*      */       }
/*  789 */       this.delayShutdown = -1;
/*      */ 
/*      */     }
/*  792 */     else if (this.tipoShutdown == 2)
/*      */     {
/*  794 */       this.alarmesUpsMIB[11] = true;
/*  795 */       this.feeder.desligaUPS();
/*  796 */       this.delayShutdown = -1;
/*      */     }
/*  798 */     if (this.delayShutdown == -1)
/*      */     {
/*  800 */       this.grupoControle.setUpsShutdownAfterDelay(-1);
/*  801 */       this.horaAlarme = this.snmpv2MIB.getSysUpTime().get();
/*  802 */       NotificadorTraps notificador = new NotificadorTraps(
/*  803 */         this.grupoAlarme, 
/*  804 */         this.notificationOriginator, 
/*  805 */         this.alarmesUpsMIB, 
/*  806 */         null, 
/*  807 */         this.horaAlarme);
/*      */       
/*  809 */       notificador.setDaemon(true);
/*  810 */       notificador.start();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void execUpsStartUpAfterDelay()
/*      */   {
/*  817 */     this.delayStartup = -1;
/*  818 */     if (this.feeder.ligaSaida())
/*      */     {
/*  820 */       this.grupoSaida.setUpsOutputLigar("true");
/*  821 */       this.alarmesUpsMIB[10] = false;
/*      */     }
/*      */     else
/*      */     {
/*  825 */       this.grupoSaida.setUpsOutputLigar("false");
/*  826 */       this.grupoControle
/*  827 */         .setUpsStartupAfterDelay(-1);
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateAgendamento()
/*      */   {
/*  833 */     if ((this.grupoControle.getUpsHoraLigar().getAtualizacao()) || 
/*  834 */       (this.grupoControle.getUpsMinLigar().getAtualizacao()) || 
/*  835 */       (this.grupoControle.getUpsHoraDesligar().getAtualizacao()) || 
/*  836 */       (this.grupoControle.getUpsMinDesligar().getAtualizacao()) || 
/*  837 */       (this.grupoControle.getUpsDiasAgenda().getAtualizacao()))
/*      */     {
/*      */ 
/*      */ 
/*  841 */       String[] dias = this.grupoControle.getUpsDiasAgenda().getValue().toString().split("-");
/*  842 */       if (dias.length == this.diasAgenda.length)
/*  843 */         for (int i = 0; i < dias.length - 1; i++)
/*  844 */           if (dias[i].equalsIgnoreCase("true")) {
/*  845 */             this.diasAgenda[(i + 1)] = true;
/*      */           } else
/*  847 */             this.diasAgenda[(i + 1)] = false;
/*  848 */       if (dias[6].equalsIgnoreCase("true")) {
/*  849 */         this.diasAgenda[0] = true;
/*      */       } else {
/*  851 */         this.diasAgenda[0] = false;
/*      */       }
/*  853 */       this.feeder.programaSemana(
/*  854 */         this.diasAgenda, 
/*  855 */         this.grupoControle.getUpsHoraLigar().getValue().toInt(), 
/*  856 */         this.grupoControle.getUpsMinLigar().getValue().toInt(), 
/*  857 */         this.grupoControle.getUpsHoraDesligar().getValue().toInt(), 
/*  858 */         this.grupoControle.getUpsMinDesligar().getValue().toInt());
/*      */       
/*  860 */       this.grupoControle.getUpsHoraLigar().setAtualizacao(false);
/*  861 */       this.grupoControle.getUpsMinLigar().setAtualizacao(false);
/*  862 */       this.grupoControle.getUpsHoraDesligar().setAtualizacao(false);
/*  863 */       this.grupoControle.getUpsMinDesligar().setAtualizacao(false);
/*  864 */       this.grupoControle.getUpsDiasAgenda().setAtualizacao(false);
/*      */     }
/*      */     
/*      */ 
/*  868 */     this.grupoControle.setUpsHoraLigar(this.feeder.getHoraLigar());
/*  869 */     this.grupoControle.setUpsMinLigar(this.feeder.getMinutoLigar());
/*  870 */     this.grupoControle.setUpsHoraDesligar(this.feeder.getHoraDesligar());
/*  871 */     this.grupoControle.setUpsMinDesligar(this.feeder.getMinutoDesligar());
/*  872 */     boolean[] agenda = this.feeder.getDiasSemanaProgramados();
/*  873 */     String agendaS = "";
/*  874 */     for (int i = 0; i < agenda.length; i++)
/*      */     {
/*  876 */       if ((i > 0) && (i <= agenda.length - 1)) {
/*  877 */         agendaS = agendaS + "-";
/*      */       }
/*  879 */       if (agenda[i] != 0) {
/*  880 */         agendaS = agendaS + "true";
/*      */       } else
/*  882 */         agendaS = agendaS + "false";
/*      */     }
/*  884 */     this.grupoControle.setUpsDiasAgenda(agendaS);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void unregisterManagedObjects() {}
/*      */   
/*      */ 
/*      */   public javax.swing.Timer getTimerPerMIB()
/*      */   {
/*  893 */     return this.timerPerMIB;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setControle(Controle controle)
/*      */   {
/*  899 */     this.feeder = controle;
/*      */   }
/*      */   
/*      */ 
/*      */   public Controle getControle()
/*      */   {
/*  905 */     return this.feeder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void notificaDados()
/*      */   {
/*  912 */     updateUpsBatteryGroup();
/*  913 */     updateUpsInputGroup();
/*  914 */     updateUpsOutputGroup();
/*  915 */     updateBypassGroup();
/*  916 */     updateConfigGroup();
/*  917 */     updateAgendamento();
/*  918 */     this.grupoControle.setUpsHorario(this.feeder.getHora() + ":" + this.feeder.getMinutos() + ":" + this.feeder.getSegundos());
/*  919 */     if (this.feeder.isTesteExecutando())
/*      */     {
/*  921 */       if (!this.atualizaUpsTestElapsedTime)
/*      */       {
/*  923 */         progUpdateTestElapsedTime();
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  929 */       this.alarmesUpsMIB[23] = false;
/*  930 */       this.atualizaUpsTestElapsedTime = false;
/*      */     }
/*      */     
/*      */ 
/*  934 */     if (this.grupoControle.getUpsDownloadEventos().getAtualizacao())
/*      */     {
/*  936 */       this.feeder.downloadEventos();
/*  937 */       this.grupoControle.getUpsDownloadEventos().setAtualizacao(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  942 */     updateUpsAlarmGroup();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaFalhaCom()
/*      */   {
/*  951 */     this.horaAlarme = this.snmpv2MIB.getSysUpTime().get();
/*  952 */     this.alarmesUpsMIB[19] = true;
/*  953 */     NotificadorTraps notificador = new NotificadorTraps(
/*  954 */       this.grupoAlarme, 
/*  955 */       this.notificationOriginator, 
/*  956 */       this.alarmesUpsMIB, 
/*  957 */       null, 
/*  958 */       this.horaAlarme);
/*  959 */     notificador.setDaemon(true);
/*  960 */     notificador.start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaRetornoCom()
/*      */   {
/*  968 */     this.horaAlarme = this.snmpv2MIB.getSysUpTime().get();
/*  969 */     this.alarmesUpsMIB[19] = false;
/*  970 */     NotificadorTraps notificador = new NotificadorTraps(
/*  971 */       this.grupoAlarme, 
/*  972 */       this.notificationOriginator, 
/*  973 */       this.alarmesUpsMIB, 
/*  974 */       null, 
/*  975 */       this.horaAlarme);
/*  976 */     notificador.setDaemon(true);
/*  977 */     notificador.start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaFalhaRede() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaRetornoRede() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaBateriaBaixa()
/*      */   {
/*  995 */     this.grupoBateria.setUpsBatteryStatus(3);
/*  996 */     this.alarmesUpsMIB[2] = true;
/*      */     
/*  998 */     if (this.atualizaUpsConfigLowBattTime)
/*      */     {
/* 1000 */       this.grupoConfig.setUpsConfigLowBattTime(
/* 1001 */         this.grupoBateria.getUpsEstimatedMinutesRemaining().getValue());
/*      */       
/* 1003 */       this.atualizaUpsConfigLowBattTime = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaBateriaNormal()
/*      */   {
/* 1013 */     this.grupoBateria.setUpsBatteryStatus(
/* 1014 */       2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaCargaElevada() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaCargaNormal() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaTemperaturaElevada() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaTemperaturaNormal() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaUsandoBateria()
/*      */   {
/* 1049 */     this.grupoSaida.setUpsOutputSource(5);
/* 1050 */     this.alarmesUpsMIB[1] = true;
/*      */     
/*      */ 
/* 1053 */     if (!this.enviaTrap) {
/* 1054 */       progEnvioUpsTrapOnBattery();
/*      */     }
/*      */     
/* 1057 */     if (!this.updateUpsSecondsOnBattery) {
/* 1058 */       progUpdateUpsSecondsOnBattery();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notificaNaoUsaBateria()
/*      */   {
/* 1067 */     this.alarmesUpsMIB[1] = false;
/*      */   }
/*      */   
/*      */   protected void addUsmUser(USM arg0) {}
/*      */   
/*      */   public void notificaComunicacao() {}
/*      */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\AgenteSGM.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */