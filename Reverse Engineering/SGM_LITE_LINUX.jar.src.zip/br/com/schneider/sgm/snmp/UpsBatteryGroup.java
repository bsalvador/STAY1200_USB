/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.snmp.EnumeratedScalar;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ 
/*     */ public class UpsBatteryGroup
/*     */   implements MOGroup
/*     */ {
/*     */   private EnumeratedScalar upsBatteryStatus;
/*     */   private MOScalar upsSecondsOnBattery;
/*     */   private MOScalar upsEstimatedMinutesRemaining;
/*     */   private MOScalar upsEstimatedChargeRemaining;
/*     */   private MOScalar upsBatteryVoltage;
/*     */   private MOScalar upsBatteryCurrent;
/*     */   private MOScalar upsBatteryTemperature;
/*     */   private MOScalar upsBatteryCarregando;
/*     */   private String modeloUPS;
/*     */   private Integer32[] vr;
/*     */   private Integer32 v;
/*     */   
/*     */   public UpsBatteryGroup(String modeloUPS)
/*     */   {
/*  30 */     this.modeloUPS = modeloUPS;
/*  31 */     this.vr = new Integer32[8];
/*  32 */     for (int i = 0; i < this.vr.length; i++) {
/*  33 */       this.vr[i] = new Integer32(-1);
/*     */     }
/*  35 */     this.upsBatteryStatus = 
/*  36 */       new EnumeratedScalar(
/*  37 */       new OID("1.3.6.1.2.1.33.1.2.1.0"), 
/*  38 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  39 */       new Integer32(1), 
/*  40 */       new int[] {
/*  41 */       1, 
/*  42 */       2, 
/*  43 */       3, 
/*  44 */       4 });
/*     */     
/*     */ 
/*     */ 
/*  48 */     this.upsSecondsOnBattery = new MOScalar(
/*  49 */       new OID("1.3.6.1.2.1.33.1.2.2.0"), 
/*  50 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  51 */       new Integer32(0));
/*     */     
/*     */ 
/*  54 */     this.upsEstimatedMinutesRemaining = new MOScalar(
/*  55 */       new OID("1.3.6.1.2.1.33.1.2.3.0"), 
/*  56 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  57 */       new Integer32(0));
/*     */     
/*  59 */     this.upsEstimatedChargeRemaining = new MOScalar(
/*  60 */       new OID("1.3.6.1.2.1.33.1.2.4.0"), 
/*  61 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  62 */       new Integer32(0));
/*     */     
/*     */ 
/*  65 */     this.upsBatteryVoltage = new MOScalar(
/*  66 */       new OID("1.3.6.1.2.1.33.1.2.5.0"), 
/*  67 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  68 */       new Integer32(0));
/*     */     
/*     */ 
/*  71 */     this.upsBatteryCurrent = new MOScalar(
/*  72 */       new OID("1.3.6.1.2.1.33.1.2.6.0"), 
/*  73 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  74 */       new Integer32(0));
/*     */     
/*     */ 
/*  77 */     this.upsBatteryTemperature = new MOScalar(
/*  78 */       new OID("1.3.6.1.2.1.33.1.2.7.0"), 
/*  79 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  80 */       new Integer32(0));
/*     */     
/*  82 */     this.v = new Integer32(-1);
/*  83 */     this.upsBatteryCarregando = new MOScalar(
/*  84 */       new OID("1.3.6.1.2.1.33.1.2.8.0"), 
/*  85 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  86 */       this.v);
/*     */   }
/*     */   
/*     */   public void registerMOs(MOServer server, OctetString context) throws DuplicateRegistrationException
/*     */   {
/*  91 */     server.register(this.upsBatteryStatus, context);
/*  92 */     server.register(this.upsSecondsOnBattery, context);
/*  93 */     server.register(this.upsEstimatedMinutesRemaining, context);
/*  94 */     server.register(this.upsEstimatedChargeRemaining, context);
/*  95 */     server.register(this.upsBatteryCurrent, context);
/*  96 */     server.register(this.upsBatteryVoltage, context);
/*  97 */     server.register(this.upsBatteryTemperature, context);
/*  98 */     server.register(this.upsBatteryCarregando, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context)
/*     */   {
/* 103 */     server.unregister(this.upsBatteryStatus, context);
/* 104 */     server.unregister(this.upsSecondsOnBattery, context);
/* 105 */     server.unregister(this.upsEstimatedMinutesRemaining, context);
/* 106 */     server.unregister(this.upsEstimatedChargeRemaining, context);
/* 107 */     server.unregister(this.upsBatteryCurrent, context);
/* 108 */     server.unregister(this.upsBatteryVoltage, context);
/* 109 */     server.unregister(this.upsBatteryTemperature, context);
/* 110 */     server.unregister(this.upsBatteryCarregando, context);
/*     */   }
/*     */   
/*     */   public String getModeloUPS()
/*     */   {
/* 115 */     return this.modeloUPS;
/*     */   }
/*     */   
/*     */   public void setModeloUPS(String modeloUPS)
/*     */   {
/* 120 */     this.modeloUPS = modeloUPS;
/*     */   }
/*     */   
/*     */   public Integer32 getUpsBatteryCurrent() {
/* 124 */     return (Integer32)this.upsBatteryCurrent.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsBatteryCurrent(int upsBatteryCurrent) {
/* 128 */     this.vr[0].setValue(upsBatteryCurrent);
/* 129 */     this.upsBatteryCurrent.setValue(this.vr[0]);
/*     */   }
/*     */   
/*     */   public void setUpsBatteryCarregando(int upsBatteryCarregando) {
/* 133 */     this.v.setValue(upsBatteryCarregando);
/* 134 */     this.upsBatteryCarregando.setValue(this.v);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsBatteryStatus() {
/* 138 */     return (Integer32)this.upsBatteryStatus.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsBatteryStatus(int upsBatteryStatus) {
/* 142 */     this.vr[1].setValue(upsBatteryStatus);
/* 143 */     this.upsBatteryStatus.setValue(this.vr[1]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsBatteryTemperature() {
/* 147 */     return (Integer32)this.upsBatteryTemperature.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsBatteryTemperature(int upsBatteryTemperature) {
/* 151 */     this.vr[2].setValue(upsBatteryTemperature);
/* 152 */     this.upsBatteryTemperature.setValue(this.vr[2]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsBatteryVoltage() {
/* 156 */     return (Integer32)this.upsBatteryVoltage.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsBatteryVoltage(int upsBatteryVoltage) {
/* 160 */     this.vr[3].setValue(upsBatteryVoltage);
/* 161 */     this.upsBatteryVoltage.setValue(this.vr[3]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsEstimatedChargeRemaining() {
/* 165 */     return (Integer32)this.upsEstimatedChargeRemaining.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsEstimatedChargeRemaining(int upsEstimatedChargeRemaining) {
/* 169 */     this.vr[4].setValue(upsEstimatedChargeRemaining);
/* 170 */     this.upsEstimatedChargeRemaining.setValue(this.vr[4]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsEstimatedMinutesRemaining() {
/* 174 */     return (Integer32)this.upsEstimatedMinutesRemaining.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsEstimatedMinutesRemaining(int upsEstimatedMinutesRemaining) {
/* 178 */     this.vr[5].setValue(upsEstimatedMinutesRemaining);
/* 179 */     this.upsEstimatedMinutesRemaining.setValue(this.vr[5]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsSecondsOnBattery() {
/* 183 */     return (Integer32)this.upsSecondsOnBattery.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsSecondsOnBattery(int upsSecondsOnBattery) {
/* 187 */     this.vr[6].setValue(upsSecondsOnBattery);
/* 188 */     this.upsSecondsOnBattery.setValue(this.vr[6]);
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsBatteryGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */