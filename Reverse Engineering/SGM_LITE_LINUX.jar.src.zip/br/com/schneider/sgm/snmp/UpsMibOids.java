/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ 
/*     */ public class UpsMibOids
/*     */ {
/*     */   public static final String mib2 = "1.3.6.1.2.1";
/*     */   
/*     */   public static final String upsMib = "1.3.6.1.2.1.33";
/*     */   
/*     */   public static final String upsObjects = "1.3.6.1.2.1.33.1";
/*     */   
/*     */   public static final String upsIdent = "1.3.6.1.2.1.33.1.1";
/*     */   
/*     */   public static final String upsBattery = "1.3.6.1.2.1.33.1.2";
/*     */   
/*     */   public static final String upsInput = "1.3.6.1.2.1.33.1.3";
/*     */   
/*     */   public static final String upsOutput = "1.3.6.1.2.1.33.1.4";
/*     */   
/*     */   public static final String upsBypass = "1.3.6.1.2.1.33.1.5";
/*     */   
/*     */   public static final String upsAlarm = "1.3.6.1.2.1.33.1.6";
/*     */   
/*     */   public static final String upsTest = "1.3.6.1.2.1.33.1.7";
/*     */   
/*     */   public static final String upsControl = "1.3.6.1.2.1.33.1.8";
/*     */   
/*     */   public static final String upsConfig = "1.3.6.1.2.1.33.1.9";
/*     */   
/*     */   public static final String upsTraps = "1.3.6.1.2.1.33.2";
/*     */   
/*     */   public static final String upsConformance = "1.3.6.1.2.1.33.3";
/*     */   
/*     */   public static final String upsIdentManufacturer = "1.3.6.1.2.1.33.1.1.1";
/*     */   
/*     */   public static final String upsIdentModel = "1.3.6.1.2.1.33.1.1.2";
/*     */   public static final String upsIdentUPSSoftwareVersion = "1.3.6.1.2.1.33.1.1.3";
/*     */   public static final String upsIdentAgentSoftwareVersion = "1.3.6.1.2.1.33.1.1.4";
/*     */   public static final String upsIdentName = "1.3.6.1.2.1.33.1.1.5";
/*     */   public static final String upsIdentAttachedDevices = "1.3.6.1.2.1.33.1.1.6";
/*     */   public static final String upsPortaPedidos = "1.3.6.1.2.1.33.1.1.7";
/*  42 */   public static final String[] oidsIdent = {
/*  43 */     "1.3.6.1.2.1.33.1.1.1.0", 
/*  44 */     "1.3.6.1.2.1.33.1.1.2.0", 
/*  45 */     "1.3.6.1.2.1.33.1.1.3.0", 
/*  46 */     "1.3.6.1.2.1.33.1.1.4.0", 
/*  47 */     "1.3.6.1.2.1.33.1.1.5.0", 
/*  48 */     "1.3.6.1.2.1.33.1.1.6.0" };
/*     */   
/*     */   public static final String upsBatteryStatus = "1.3.6.1.2.1.33.1.2.1";
/*     */   
/*     */   public static final String upsSecondsOnBattery = "1.3.6.1.2.1.33.1.2.2";
/*     */   
/*     */   public static final String upsEstimatedMinutesRemaining = "1.3.6.1.2.1.33.1.2.3";
/*     */   public static final String upsEstimatedChargeRemaining = "1.3.6.1.2.1.33.1.2.4";
/*     */   public static final String upsBatteryVoltage = "1.3.6.1.2.1.33.1.2.5";
/*     */   public static final String upsBatteryCurrent = "1.3.6.1.2.1.33.1.2.6";
/*     */   public static final String upsBatteryTemperature = "1.3.6.1.2.1.33.1.2.7";
/*     */   public static final String upsBatteryCarregando = "1.3.6.1.2.1.33.1.2.8";
/*  60 */   public static final String[] oidsBattery = {
/*  61 */     "1.3.6.1.2.1.33.1.2.1.0", 
/*  62 */     "1.3.6.1.2.1.33.1.2.2.0", 
/*  63 */     "1.3.6.1.2.1.33.1.2.3.0", 
/*  64 */     "1.3.6.1.2.1.33.1.2.4.0", 
/*  65 */     "1.3.6.1.2.1.33.1.2.5.0", 
/*  66 */     "1.3.6.1.2.1.33.1.2.7.0", 
/*  67 */     "1.3.6.1.2.1.33.1.2.6.0", 
/*  68 */     "1.3.6.1.2.1.33.1.2.8.0" };
/*     */   
/*     */   public static final String upsInputLineBads = "1.3.6.1.2.1.33.1.3.1";
/*     */   
/*     */   public static final String upsInputNumLines = "1.3.6.1.2.1.33.1.3.2";
/*     */   
/*     */   public static final String upsInputLigar = "1.3.6.1.2.1.33.1.3.4";
/*     */   public static final String upsInputTable = "1.3.6.1.2.1.33.1.3.3";
/*     */   public static final String upsInputEntry = "1.3.6.1.2.1.33.1.3.3.1";
/*     */   public static final String upsInputLineIndex = "1.3.6.1.2.1.33.1.3.3.1.1";
/*     */   public static final String upsInputFrequency = "1.3.6.1.2.1.33.1.3.3.1.2";
/*     */   public static final String upsInputVoltage = "1.3.6.1.2.1.33.1.3.3.1.3";
/*     */   public static final String upsInputCurrent = "1.3.6.1.2.1.33.1.3.3.1.4";
/*     */   public static final String upsInputTruePower = "1.3.6.1.2.1.33.1.3.3.1.5";
/*     */   public static final String upsInputPotenciaAparente = "1.3.6.1.2.1.33.1.3.3.1.6";
/*  83 */   public static final String[] oidsInput = {
/*  84 */     "1.3.6.1.2.1.33.1.3.1.0", 
/*  85 */     "1.3.6.1.2.1.33.1.3.2.0", 
/*  86 */     "1.3.6.1.2.1.33.1.3.3.1.2.1", 
/*  87 */     "1.3.6.1.2.1.33.1.3.3.1.3.1", 
/*  88 */     "1.3.6.1.2.1.33.1.3.3.1.4.1", 
/*  89 */     "1.3.6.1.2.1.33.1.3.3.1.5.1", 
/*  90 */     "1.3.6.1.2.1.33.1.3.3.1.6.1" };
/*     */   
/*     */   public static final String upsOutputSource = "1.3.6.1.2.1.33.1.4.1";
/*     */   
/*     */   public static final String upsOutputFrequency = "1.3.6.1.2.1.33.1.4.2";
/*     */   
/*     */   public static final String upsOutputNumLines = "1.3.6.1.2.1.33.1.4.3";
/*     */   
/*     */   public static final String upsOutputTable = "1.3.6.1.2.1.33.1.4.4";
/*     */   public static final String upsOutputLigar = "1.3.6.1.2.1.33.1.4.5";
/*     */   public static final String upsTipoHisConsumo = "1.3.6.1.2.1.33.1.4.6";
/*     */   public static final String upsPeriodoConsumo = "1.3.6.1.2.1.33.1.4.7";
/*     */   public static final String upsResultadoConsumo = "1.3.6.1.2.1.33.1.4.8";
/*     */   public static final String upsSaidaLigada = "1.3.6.1.2.1.33.1.4.9";
/*     */   public static final String upsOutputEntry = "1.3.6.1.2.1.33.1.4.4.1";
/*     */   public static final String upsOutputLineIndex = "1.3.6.1.2.1.33.1.4.4.1.1";
/*     */   public static final String upsOutputVoltage = "1.3.6.1.2.1.33.1.4.4.1.2";
/*     */   public static final String upsOutputCurrent = "1.3.6.1.2.1.33.1.4.4.1.3";
/*     */   public static final String upsOutputPower = "1.3.6.1.2.1.33.1.4.4.1.4";
/*     */   public static final String upsOutputPercentLoad = "1.3.6.1.2.1.33.1.4.4.1.5";
/*     */   public static final String upsOutputPotenciaReal = "1.3.6.1.2.1.33.1.4.4.1.6";
/* 111 */   public static final String[] oidsOutput = {
/* 112 */     "1.3.6.1.2.1.33.1.4.1.0", 
/* 113 */     "1.3.6.1.2.1.33.1.4.2.0", 
/* 114 */     "1.3.6.1.2.1.33.1.4.3.0", 
/* 115 */     "1.3.6.1.2.1.33.1.4.4.1.2.1", 
/* 116 */     "1.3.6.1.2.1.33.1.4.4.1.3.1", 
/* 117 */     "1.3.6.1.2.1.33.1.4.4.1.4.1", 
/* 118 */     "1.3.6.1.2.1.33.1.4.4.1.5.1", 
/* 119 */     "1.3.6.1.2.1.33.1.4.4.1.6.1", 
/* 120 */     "1.3.6.1.2.1.33.1.4.9.0" };
/*     */   
/*     */   public static final String upsBypassFrequency = "1.3.6.1.2.1.33.1.5.1";
/*     */   
/*     */   public static final String upsBypassNumLines = "1.3.6.1.2.1.33.1.5.2";
/*     */   
/*     */   public static final String upsBypassTable = "1.3.6.1.2.1.33.1.5.3";
/*     */   
/*     */   public static final String upsBypassAtivar = "1.3.6.1.2.1.33.1.5.4";
/*     */   
/*     */   public static final String upsBypassEntry = "1.3.6.1.2.1.33.1.5.3.1";
/*     */   public static final String upsBypassLineIndex = "1.3.6.1.2.1.33.1.5.3.1.1";
/*     */   public static final String upsBypassVoltage = "1.3.6.1.2.1.33.1.5.3.1.2";
/*     */   public static final String upsBypassCurrent = "1.3.6.1.2.1.33.1.5.3.1.3";
/*     */   public static final String upsBypassPower = "1.3.6.1.2.1.33.1.5.3.1.4";
/* 135 */   public static final String[] oidsBypass = {
/* 136 */     "1.3.6.1.2.1.33.1.5.1.0", 
/* 137 */     "1.3.6.1.2.1.33.1.5.2.0", 
/* 138 */     "1.3.6.1.2.1.33.1.5.3.1.2.1", 
/* 139 */     "1.3.6.1.2.1.33.1.5.3.1.3.1", 
/* 140 */     "1.3.6.1.2.1.33.1.5.3.1.4.1" };
/*     */   
/*     */   public static final String upsAlarmsPresent = "1.3.6.1.2.1.33.1.6.1";
/*     */   
/*     */   public static final String upsAlarmTable = "1.3.6.1.2.1.33.1.6.2";
/*     */   
/*     */   public static final String upsAlarmEntry = "1.3.6.1.2.1.33.1.6.2.1";
/*     */   
/*     */   public static final String upsAlarmId = "1.3.6.1.2.1.33.1.6.2.1.1";
/*     */   
/*     */   public static final String upsAlarmDescr = "1.3.6.1.2.1.33.1.6.2.1.2";
/*     */   
/*     */   public static final String upsAlarmTime = "1.3.6.1.2.1.33.1.6.2.1.3";
/*     */   
/*     */   public static final String upsWellKnownAlarms = "1.3.6.1.2.1.33.1.6.3";
/*     */   
/*     */   public static final String upsAlarmBatteryBad = "1.3.6.1.2.1.33.1.6.3.1";
/*     */   
/*     */   public static final String upsAlarmOnBattery = "1.3.6.1.2.1.33.1.6.3.2";
/*     */   
/*     */   public static final String upsAlarmLowBattery = "1.3.6.1.2.1.33.1.6.3.3";
/*     */   
/*     */   public static final String upsAlarmDepletedBattery = "1.3.6.1.2.1.33.1.6.3.4";
/*     */   
/*     */   public static final String upsAlarmTempBad = "1.3.6.1.2.1.33.1.6.3.5";
/*     */   public static final String upsAlarmInputBad = "1.3.6.1.2.1.33.1.6.3.6";
/*     */   public static final String upsAlarmOutputBad = "1.3.6.1.2.1.33.1.6.3.7";
/*     */   public static final String upsAlarmOutputOverload = "1.3.6.1.2.1.33.1.6.3.8";
/*     */   public static final String upsAlarmOnBypass = "1.3.6.1.2.1.33.1.6.3.9";
/*     */   public static final String upsAlarmBypassBad = "1.3.6.1.2.1.33.1.6.3.10";
/*     */   public static final String upsAlarmOutputOffAsRequested = "1.3.6.1.2.1.33.1.6.3.11";
/*     */   public static final String upsAlarmUpsOffAsRequested = "1.3.6.1.2.1.33.1.6.3.12";
/*     */   public static final String upsAlarmChargerFailed = "1.3.6.1.2.1.33.1.6.3.13";
/*     */   public static final String upsAlarmUpsOutputOff = "1.3.6.1.2.1.33.1.6.3.14";
/*     */   public static final String upsAlarmUpsSystemOff = "1.3.6.1.2.1.33.1.6.3.15";
/*     */   public static final String upsAlarmFanFailure = "1.3.6.1.2.1.33.1.6.3.16";
/*     */   public static final String upsAlarmFuseFailure = "1.3.6.1.2.1.33.1.6.3.17";
/*     */   public static final String upsAlarmGeneralFault = "1.3.6.1.2.1.33.1.6.3.18";
/*     */   public static final String upsAlarmDiagnosticTestFailed = "1.3.6.1.2.1.33.1.6.3.19";
/*     */   public static final String upsAlarmCommunicationsLost = "1.3.6.1.2.1.33.1.6.3.20";
/*     */   public static final String upsAlarmAwaitingPower = "1.3.6.1.2.1.33.1.6.3.21";
/*     */   public static final String upsAlarmShutdownPending = "1.3.6.1.2.1.33.1.6.3.22";
/*     */   public static final String upsAlarmShutdownImminent = "1.3.6.1.2.1.33.1.6.3.23";
/*     */   public static final String upsAlarmTestInProgress = "1.3.6.1.2.1.33.1.6.3.24";
/*     */   public static final String upsAlarmMicrosol = "1.3.6.1.2.1.33.1.6.3.25";
/*     */   public static final String upsTestId = "1.3.6.1.2.1.33.1.7.1";
/*     */   public static final String upsTestSpinLock = "1.3.6.1.2.1.33.1.7.2";
/*     */   public static final String upsTestResultsSummary = "1.3.6.1.2.1.33.1.7.3";
/*     */   public static final String upsTestResultsDetail = "1.3.6.1.2.1.33.1.7.4";
/*     */   public static final String upsTestStartTime = "1.3.6.1.2.1.33.1.7.5";
/*     */   public static final String upsTestElapsedTime = "1.3.6.1.2.1.33.1.7.6";
/*     */   public static final String upsWellKnownTests = "1.3.6.1.2.1.33.1.7.7";
/*     */   public static final String upsTestNoTestsInitiated = "1.3.6.1.2.1.33.1.7.7.1";
/*     */   public static final String upsTestAbortTestInProgress = "1.3.6.1.2.1.33.1.7.7.2";
/*     */   public static final String upsTestGeneralSystemsTest = "1.3.6.1.2.1.33.1.7.7.3";
/*     */   public static final String upsTestQuickBatteryTest = "1.3.6.1.2.1.33.1.7.7.4";
/*     */   public static final String upsTestDeepBatteryCalibration = "1.3.6.1.2.1.33.1.7.7.5";
/*     */   public static final String upsShutdownType = "1.3.6.1.2.1.33.1.8.1";
/*     */   public static final String upsShutdownAfterDelay = "1.3.6.1.2.1.33.1.8.2";
/*     */   public static final String upsStartupAfterDelay = "1.3.6.1.2.1.33.1.8.3";
/*     */   public static final String upsRebootWithDuration = "1.3.6.1.2.1.33.1.8.4";
/*     */   public static final String upsAutoRestart = "1.3.6.1.2.1.33.1.8.5";
/* 202 */   public static final String[] oidsControl = {
/* 203 */     "1.3.6.1.2.1.33.1.8.1.0", 
/* 204 */     "1.3.6.1.2.1.33.1.8.2.0", 
/* 205 */     "1.3.6.1.2.1.33.1.8.3.0", 
/* 206 */     "1.3.6.1.2.1.33.1.8.4.0", 
/* 207 */     "1.3.6.1.2.1.33.1.8.5.0" };
/*     */   
/*     */   public static final String upsDownloadEventos = "1.3.6.1.2.1.33.1.8.6";
/*     */   
/*     */   public static final String upsHoraLigar = "1.3.6.1.2.1.33.1.8.7";
/*     */   
/*     */   public static final String upsMinLigar = "1.3.6.1.2.1.33.1.8.8";
/*     */   
/*     */   public static final String upsHoraDesligar = "1.3.6.1.2.1.33.1.8.9";
/*     */   public static final String upsMinDesligar = "1.3.6.1.2.1.33.1.8.10";
/*     */   public static final String upsDiasAgenda = "1.3.6.1.2.1.33.1.8.11";
/*     */   public static final String upsHorario = "1.3.6.1.2.1.33.1.8.13";
/* 219 */   public static final String[] oidsAgenda = {
/* 220 */     "1.3.6.1.2.1.33.1.8.7.0", 
/* 221 */     "1.3.6.1.2.1.33.1.8.8.0", 
/* 222 */     "1.3.6.1.2.1.33.1.8.9.0", 
/* 223 */     "1.3.6.1.2.1.33.1.8.10.0", 
/* 224 */     "1.3.6.1.2.1.33.1.8.11.0", 
/* 225 */     "1.3.6.1.2.1.33.1.8.13.0" };
/*     */   
/*     */   public static final String upsConfigInputVoltage = "1.3.6.1.2.1.33.1.9.1";
/*     */   
/*     */   public static final String upsConfigInputFreq = "1.3.6.1.2.1.33.1.9.2";
/*     */   
/*     */   public static final String upsConfigOutputVoltage = "1.3.6.1.2.1.33.1.9.3";
/*     */   
/*     */   public static final String upsConfigOutputFreq = "1.3.6.1.2.1.33.1.9.4";
/*     */   
/*     */   public static final String upsConfigOutputVA = "1.3.6.1.2.1.33.1.9.5";
/*     */   public static final String upsConfigOutputPower = "1.3.6.1.2.1.33.1.9.6";
/*     */   public static final String upsConfigLowBattTime = "1.3.6.1.2.1.33.1.9.7";
/*     */   public static final String upsConfigAudibleStatus = "1.3.6.1.2.1.33.1.9.8";
/*     */   public static final String upsConfigLowVoltageTransferPoint = "1.3.6.1.2.1.33.1.9.9";
/*     */   public static final String upsConfigHighVoltageTransferPoint = "1.3.6.1.2.1.33.1.9.10";
/*     */   public static final String upsMicrosolRedeLigada = "1.3.6.1.2.1.33.1.9.11";
/*     */   public static final String upsMicrosolSuperAquecimento = "1.3.6.1.2.1.33.1.9.12";
/*     */   public static final String upsMicrosolSobrecarga = "1.3.6.1.2.1.33.1.9.13";
/* 244 */   public static final String[] oidsConfig = {
/* 245 */     "1.3.6.1.2.1.33.1.9.1.0", 
/* 246 */     "1.3.6.1.2.1.33.1.9.2.0", 
/* 247 */     "1.3.6.1.2.1.33.1.9.3.0", 
/* 248 */     "1.3.6.1.2.1.33.1.9.4.0", 
/* 249 */     "1.3.6.1.2.1.33.1.9.5.0", 
/* 250 */     "1.3.6.1.2.1.33.1.9.6.0", 
/* 251 */     "1.3.6.1.2.1.33.1.9.7.0", 
/* 252 */     "1.3.6.1.2.1.33.1.9.8.0", 
/* 253 */     "1.3.6.1.2.1.33.1.9.9.0", 
/* 254 */     "1.3.6.1.2.1.33.1.9.10.0" };
/*     */   
/*     */ 
/*     */   public static final String upsTrapOnBattery = "1.3.6.1.2.1.33.2.1";
/*     */   
/*     */ 
/*     */   public static final String upsTrapTestCompleted = "1.3.6.1.2.1.33.2.2";
/*     */   
/*     */   public static final String upsTrapAlarmEntryAdded = "1.3.6.1.2.1.33.2.3";
/*     */   
/*     */   public static final String upsTrapAlarmEntryRemoved = "1.3.6.1.2.1.33.2.4";
/*     */   
/*     */   public static final String upsTrapAlarmMicrosol = "1.3.6.1.2.1.33.2.5";
/*     */   
/*     */   public static final String upsTrapHisConsumo = "1.3.6.1.2.1.33.2.6";
/*     */   
/*     */ 
/*     */   public static String getWellKnownAlarm(int oid)
/*     */   {
/* 273 */     String res = "";
/*     */     
/* 275 */     switch (oid) {
/*     */     case 1: 
/* 277 */       res = "1.3.6.1.2.1.33.1.6.3.1";
/* 278 */       break;
/* 279 */     case 2:  res = "1.3.6.1.2.1.33.1.6.3.2";
/* 280 */       break;
/* 281 */     case 3:  res = "1.3.6.1.2.1.33.1.6.3.3";
/* 282 */       break;
/* 283 */     case 4:  res = "1.3.6.1.2.1.33.1.6.3.4";
/* 284 */       break;
/* 285 */     case 5:  res = "1.3.6.1.2.1.33.1.6.3.5";
/* 286 */       break;
/* 287 */     case 6:  res = "1.3.6.1.2.1.33.1.6.3.6";
/* 288 */       break;
/* 289 */     case 7:  res = "1.3.6.1.2.1.33.1.6.3.7";
/* 290 */       break;
/* 291 */     case 8:  res = "1.3.6.1.2.1.33.1.6.3.8";
/* 292 */       break;
/* 293 */     case 9:  res = "1.3.6.1.2.1.33.1.6.3.9";
/* 294 */       break;
/* 295 */     case 10:  res = "1.3.6.1.2.1.33.1.6.3.10";
/* 296 */       break;
/* 297 */     case 11:  res = "1.3.6.1.2.1.33.1.6.3.11";
/* 298 */       break;
/* 299 */     case 12:  res = "1.3.6.1.2.1.33.1.6.3.12";
/* 300 */       break;
/* 301 */     case 13:  res = "1.3.6.1.2.1.33.1.6.3.13";
/* 302 */       break;
/* 303 */     case 14:  res = "1.3.6.1.2.1.33.1.6.3.14";
/* 304 */       break;
/* 305 */     case 15:  res = "1.3.6.1.2.1.33.1.6.3.15";
/* 306 */       break;
/* 307 */     case 16:  res = "1.3.6.1.2.1.33.1.6.3.16";
/* 308 */       break;
/* 309 */     case 17:  res = "1.3.6.1.2.1.33.1.6.3.17";
/* 310 */       break;
/* 311 */     case 18:  res = "1.3.6.1.2.1.33.1.6.3.18";
/* 312 */       break;
/* 313 */     case 19:  res = "1.3.6.1.2.1.33.1.6.3.19";
/* 314 */       break;
/* 315 */     case 20:  res = "1.3.6.1.2.1.33.1.6.3.20";
/* 316 */       break;
/* 317 */     case 21:  res = "1.3.6.1.2.1.33.1.6.3.21";
/* 318 */       break;
/* 319 */     case 22:  res = "1.3.6.1.2.1.33.1.6.3.22";
/* 320 */       break;
/* 321 */     case 23:  res = "1.3.6.1.2.1.33.1.6.3.23";
/* 322 */       break;
/* 323 */     case 24:  res = "1.3.6.1.2.1.33.1.6.3.24";
/*     */     }
/*     */     
/* 326 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getWellKnownAlarm(String oid)
/*     */   {
/* 337 */     String res = "";
/* 338 */     if (oid.equals("1.3.6.1.2.1.33.1.6.3.1")) { res = "upsAlarmBatteryBad";
/* 339 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.2")) { res = "upsAlarmOnBattery";
/* 340 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.3")) { res = "upsAlarmLowBattery";
/* 341 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.4")) { res = "upsAlarmDepletedBattery";
/* 342 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.5")) { res = "upsAlarmTempBad";
/* 343 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.6")) { res = "upsAlarmInputBad";
/* 344 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.7")) { res = "upsAlarmOutputBad";
/* 345 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.8")) { res = "upsAlarmOutputOverload";
/* 346 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.9")) { res = "upsAlarmOnBypass";
/* 347 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.10")) { res = "upsAlarmBypassBad";
/* 348 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.11")) { res = "upsAlarmOutputOffAsRequested";
/* 349 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.12")) { res = "upsAlarmUpsOffAsRequested";
/* 350 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.13")) { res = "upsAlarmChargerFailed";
/* 351 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.14")) { res = "upsAlarmUpsOutputOff";
/* 352 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.15")) { res = "upsAlarmUpsSystemOff";
/* 353 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.16")) { res = "upsAlarmFanFailure";
/* 354 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.17")) { res = "upsAlarmFuseFailure";
/* 355 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.18")) { res = "upsAlarmGeneralFault";
/* 356 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.19")) { res = "upsAlarmDiagnosticTestFailed";
/* 357 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.20")) { res = "upsAlarmCommunicationsLost";
/* 358 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.21")) { res = "upsAlarmAwaitingPower";
/* 359 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.22")) { res = "upsAlarmShutdownPending";
/* 360 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.23")) { res = "upsAlarmShutdownImminent";
/* 361 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.24")) { res = "upsAlarmTestInProgress";
/*     */     }
/* 363 */     return res;
/*     */   }
/*     */   
/*     */   public static String getWellKnownAlarmToPortuguese(String oid)
/*     */   {
/* 368 */     String res = "";
/* 369 */     if (oid.equals("1.3.6.1.2.1.33.1.6.3.1")) { res = "Bateria Defeituosa";
/* 370 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.2")) { res = "Usando Bateria";
/* 371 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.3")) { res = "Bateria Baixa";
/* 372 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.4")) { res = "Bateria Descarregada";
/* 373 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.5")) { res = "Temperatura Ruim";
/* 374 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.6")) { res = "Entrada Falha";
/* 375 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.7")) { res = "Saï¿½da Falha";
/* 376 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.8")) { res = "Saï¿½da Sobrecarregada";
/* 377 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.9")) { res = "Usando Bypass";
/* 378 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.10")) { res = "Bypass Falho";
/* 379 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.11")) { res = "Saï¿½da Desligada como pedido";
/* 380 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.12")) { res = "Ups desligado como pedido";
/* 381 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.13")) { res = "Carregador Falhou";
/* 382 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.14")) { res = "Saï¿½da Desligada";
/* 383 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.15")) { res = "Sistema do Ups desligado";
/* 384 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.16")) { res = "Falha no Ventilador";
/* 385 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.17")) { res = "Falha no Fusï¿½vel";
/* 386 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.18")) { res = "Falha Geral";
/* 387 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.19")) { res = "Falha no Teste Detectada";
/* 388 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.20")) { res = "Perda de Comunicaï¿½ï¿½o";
/* 389 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.21")) { res = "Esperando forï¿½a de entrada";
/* 390 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.22")) { res = "Shutdown Pendente";
/* 391 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.23")) { res = "Shutdow Iminente";
/* 392 */     } else if (oid.equals("1.3.6.1.2.1.33.1.6.3.24")) { res = "Teste em progresso";
/*     */     }
/* 394 */     return res;
/*     */   }
/*     */   
/*     */   public static final class upsAutoRestartEnum
/*     */   {
/*     */     public static final int on = 1;
/*     */     public static final int off = 2;
/*     */   }
/*     */   
/*     */   public static final class upsBatteryStatusEnum
/*     */   {
/*     */     public static final int unknown = 1;
/*     */     public static final int batteryNormal = 2;
/*     */     public static final int batteryLow = 3;
/*     */     public static final int batteryDepleted = 4;
/*     */   }
/*     */   
/*     */   public static final class upsBypassAtivarEnum
/*     */   {
/*     */     public static final int ativar = 1;
/*     */     public static final int desativar = 2;
/*     */   }
/*     */   
/*     */   public static final class upsConfigAudibleStatusEnum
/*     */   {
/*     */     public static final int disabled = 1;
/*     */     public static final int enabled = 2;
/*     */     public static final int muted = 3;
/*     */   }
/*     */   
/*     */   public static final class upsDownloadEventosEnum
/*     */   {
/*     */     public static final int download = 1;
/*     */     public static final int semDownload = 2;
/*     */   }
/*     */   
/*     */   public static final class upsInputLigarEnum
/*     */   {
/*     */     public static final int ligar = 1;
/*     */     public static final int desligar = 2;
/*     */   }
/*     */   
/*     */   public static final class upsOutputLigarEnum
/*     */   {
/*     */     public static final int ligar = 1;
/*     */     public static final int desligar = 2;
/*     */   }
/*     */   
/*     */   public static final class upsOutputSourceEnum
/*     */   {
/*     */     public static final int other = 1;
/*     */     public static final int none = 2;
/*     */     public static final int normal = 3;
/*     */     public static final int bypass = 4;
/*     */     public static final int battery = 5;
/*     */     public static final int booster = 6;
/*     */     public static final int reducer = 7;
/*     */     public static final int saidaLigada = 8;
/*     */   }
/*     */   
/*     */   public static final class upsShutdownTypeEnum
/*     */   {
/*     */     public static final int abort = -1;
/*     */     public static final int output = 1;
/*     */     public static final int system = 2;
/*     */     public static final int input = 3;
/*     */     public static final int bypass = 4;
/*     */   }
/*     */   
/*     */   public static final class upsTestResultsSummaryEnum
/*     */   {
/*     */     public static final int donePass = 1;
/*     */     public static final int doneWarning = 2;
/*     */     public static final int doneError = 3;
/*     */     public static final int aborted = 4;
/*     */     public static final int inProgress = 5;
/*     */     public static final int noTestsInitiated = 6;
/*     */   }
/*     */   
/*     */   public static final class upsTipoHisConsumoEnum
/*     */   {
/*     */     public static final int diario = 1;
/*     */     public static final int semanal = 2;
/*     */     public static final int mensal = 3;
/*     */     public static final int anual = 4;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsMibOids.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */