/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOAccess;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.snmp.DisplayStringScalar;
/*     */ import org.snmp4j.agent.request.RequestStatus;
/*     */ import org.snmp4j.agent.request.SubRequest;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.Variable;
/*     */ import org.snmp4j.smi.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpsIdentGroup
/*     */   implements MOGroup
/*     */ {
/*     */   private DisplayStringScalar upsIdentManufacter;
/*     */   private DisplayStringScalar upsIdentModel;
/*     */   private DisplayStringScalar upsIdentUPSSoftwareVersion;
/*     */   private DisplayStringScalar upsIdentAgentSoftwareVersion;
/*     */   private UpsIdentDisplayStringScalar upsIdentName;
/*     */   private UpsIdentDisplayStringScalar upsIdentAttachedDevices;
/*     */   private UpsIdentMOScalar upsPortaPedidos;
/*     */   
/*     */   public UpsIdentGroup(String identManufactor, String model, String upsSoftwareVersion, String agentSoftwareVersion)
/*     */   {
/*  34 */     this.upsIdentManufacter = new DisplayStringScalar(
/*  35 */       new OID("1.3.6.1.2.1.33.1.1.1.0"), 
/*  36 */       MOAccessImpl.ACCESS_READ_ONLY, new OctetString(identManufactor), 
/*  37 */       0, 31);
/*     */     
/*     */ 
/*  40 */     this.upsIdentModel = new DisplayStringScalar(
/*  41 */       new OID("1.3.6.1.2.1.33.1.1.2.0"), 
/*  42 */       MOAccessImpl.ACCESS_READ_ONLY, new OctetString(model), 
/*  43 */       0, 31);
/*     */     
/*     */ 
/*  46 */     this.upsIdentUPSSoftwareVersion = new DisplayStringScalar(
/*  47 */       new OID("1.3.6.1.2.1.33.1.1.3.0"), 
/*  48 */       MOAccessImpl.ACCESS_READ_ONLY, new OctetString(upsSoftwareVersion), 
/*  49 */       0, 63);
/*     */     
/*     */ 
/*  52 */     this.upsIdentAgentSoftwareVersion = new DisplayStringScalar(
/*  53 */       new OID("1.3.6.1.2.1.33.1.1.4.0"), 
/*  54 */       MOAccessImpl.ACCESS_READ_ONLY, new OctetString(agentSoftwareVersion), 
/*  55 */       0, 63);
/*     */     
/*  57 */     this.upsIdentName = new UpsIdentDisplayStringScalar(
/*  58 */       new OID("1.3.6.1.2.1.33.1.1.5.0"), 
/*  59 */       MOAccessImpl.ACCESS_READ_WRITE, new OctetString(""), 
/*  60 */       0, 63);
/*     */     
/*  62 */     this.upsIdentAttachedDevices = new UpsIdentDisplayStringScalar(
/*  63 */       new OID("1.3.6.1.2.1.33.1.1.6.0"), 
/*  64 */       MOAccessImpl.ACCESS_READ_WRITE, new OctetString(""), 
/*  65 */       0, 63);
/*     */     
/*     */ 
/*     */ 
/*  69 */     this.upsPortaPedidos = new UpsIdentMOScalar(
/*  70 */       new OID("1.3.6.1.2.1.33.1.1.7.0"), 
/*  71 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  72 */       new Integer32(-1));
/*     */   }
/*     */   
/*     */   public void registerMOs(MOServer server, OctetString context) throws DuplicateRegistrationException
/*     */   {
/*  77 */     server.register(this.upsIdentManufacter, context);
/*  78 */     server.register(this.upsIdentModel, context);
/*  79 */     server.register(this.upsIdentUPSSoftwareVersion, context);
/*  80 */     server.register(this.upsIdentAgentSoftwareVersion, context);
/*  81 */     server.register(this.upsIdentName, context);
/*  82 */     server.register(this.upsIdentAttachedDevices, context);
/*  83 */     server.register(this.upsPortaPedidos, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context) {
/*  87 */     server.unregister(this.upsIdentManufacter, context);
/*  88 */     server.unregister(this.upsIdentModel, context);
/*  89 */     server.unregister(this.upsIdentUPSSoftwareVersion, context);
/*  90 */     server.unregister(this.upsIdentAgentSoftwareVersion, context);
/*  91 */     server.unregister(this.upsIdentName, context);
/*  92 */     server.unregister(this.upsIdentAttachedDevices, context);
/*  93 */     server.unregister(this.upsPortaPedidos, context);
/*     */   }
/*     */   
/*     */   class UpsIdentDisplayStringScalar extends DisplayStringScalar
/*     */   {
/*  98 */     public boolean atualizacao = false;
/*     */     
/*     */     public UpsIdentDisplayStringScalar(OID oid, MOAccess access, OctetString value, int minSize, int maxSize) {
/* 101 */       super(access, value, minSize, maxSize);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 106 */       RequestStatus status = request.getStatus();
/* 107 */       VariableBinding vb = request.getVariableBinding();
/* 108 */       request.setUndoValue(getValue());
/* 109 */       setValue(vb.getVariable());
/* 110 */       status.setPhaseComplete(true);
/* 111 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 115 */       RequestStatus status = request.getStatus();
/* 116 */       if ((request.getUndoValue() != null) && 
/* 117 */         ((request.getUndoValue() instanceof Variable))) {
/* 118 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 119 */         status.setErrorStatus(errorStatus);
/* 120 */         status.setPhaseComplete(true);
/* 121 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 124 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 129 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 133 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */   class UpsIdentMOScalar
/*     */     extends MOScalar
/*     */   {
/* 140 */     private boolean atualizacao = false;
/*     */     
/*     */     public UpsIdentMOScalar(OID arg0, MOAccess arg1, Variable arg2) {
/* 143 */       super(arg1, arg2);
/*     */     }
/*     */     
/*     */ 
/*     */     public void commit(SubRequest request)
/*     */     {
/* 149 */       RequestStatus status = request.getStatus();
/* 150 */       VariableBinding vb = request.getVariableBinding();
/* 151 */       request.setUndoValue(getValue());
/* 152 */       setValue(vb.getVariable());
/* 153 */       status.setPhaseComplete(true);
/* 154 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 158 */       RequestStatus status = request.getStatus();
/* 159 */       if ((request.getUndoValue() != null) && 
/* 160 */         ((request.getUndoValue() instanceof Variable))) {
/* 161 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 162 */         status.setErrorStatus(errorStatus);
/* 163 */         status.setPhaseComplete(true);
/* 164 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 167 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 172 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 176 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public OctetString getUpsIdentAgentSoftwareVersion()
/*     */   {
/* 184 */     return (OctetString)this.upsIdentAgentSoftwareVersion.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsIdentAgentSoftwareVersion(OctetString upsIdentAgentSoftwareVersion)
/*     */   {
/* 189 */     this.upsIdentAgentSoftwareVersion.setValue(upsIdentAgentSoftwareVersion);
/*     */   }
/*     */   
/*     */   public UpsIdentDisplayStringScalar getUpsIdentAttachedDevices() {
/* 193 */     return this.upsIdentAttachedDevices;
/*     */   }
/*     */   
/*     */   public void setUpsIdentAttachedDevices(OctetString upsIdentAttachedDevices)
/*     */   {
/* 198 */     this.upsIdentAttachedDevices.setValue(upsIdentAttachedDevices);
/*     */   }
/*     */   
/*     */   public void setUpsIdentAttachedDevicesAtualizacao(boolean valor) {
/* 202 */     this.upsIdentAttachedDevices.setAtualizacao(valor);
/*     */   }
/*     */   
/*     */   public OctetString getUpsIdentManufacter() {
/* 206 */     return (OctetString)this.upsIdentManufacter.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsIdentManufacter(OctetString upsIdentManufacter) {
/* 210 */     this.upsIdentManufacter.setValue(upsIdentManufacter);
/*     */   }
/*     */   
/*     */   public OctetString getUpsIdentModel() {
/* 214 */     return (OctetString)this.upsIdentModel.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsIdentModel(OctetString upsIdentModel) {
/* 218 */     this.upsIdentModel.setValue(upsIdentModel);
/*     */   }
/*     */   
/*     */   public UpsIdentDisplayStringScalar getUpsIdentName() {
/* 222 */     return this.upsIdentName;
/*     */   }
/*     */   
/*     */   public void setUpsIdentName(OctetString upsIdentName) {
/* 226 */     this.upsIdentName.setValue(upsIdentName);
/*     */   }
/*     */   
/*     */   public void setUpsIdentNameAtulizacao(boolean valor)
/*     */   {
/* 231 */     this.upsIdentName.setAtualizacao(valor);
/*     */   }
/*     */   
/*     */   public OctetString getUpsIdentUPSSoftwareVersion() {
/* 235 */     return (OctetString)this.upsIdentUPSSoftwareVersion.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsIdentUPSSoftwareVersion(OctetString upsIdentUPSSoftwareVersion)
/*     */   {
/* 240 */     this.upsIdentUPSSoftwareVersion.setValue(upsIdentUPSSoftwareVersion);
/*     */   }
/*     */   
/*     */   public UpsIdentMOScalar getUpsPortaPedidos() {
/* 244 */     return this.upsPortaPedidos;
/*     */   }
/*     */   
/*     */   public void setUpsPortaPedidos(int upsPortaPedidos) {
/* 248 */     this.upsPortaPedidos.setValue(new Integer32(upsPortaPedidos));
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsIdentGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */