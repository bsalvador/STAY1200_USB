/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.DefaultMOMutableRow2PC;
/*     */ import org.snmp4j.agent.mo.DefaultMOMutableTableModel;
/*     */ import org.snmp4j.agent.mo.DefaultMOTable;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOColumn;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.MOTableIndex;
/*     */ import org.snmp4j.agent.mo.MOTableRow;
/*     */ import org.snmp4j.agent.mo.MOTableSubIndex;
/*     */ import org.snmp4j.agent.mo.snmp.AutonomousType;
/*     */ import org.snmp4j.smi.Gauge32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.TimeTicks;
/*     */ import org.snmp4j.smi.Variable;
/*     */ 
/*     */ 
/*     */ public class UpsAlarmGroup
/*     */   implements MOGroup
/*     */ {
/*     */   private MOScalar upsAlarmsPresent;
/*     */   private static final int colUpsAlarmDescr = 2;
/*     */   private static final int colUpsAlarmTime = 3;
/*     */   private static final int idxUpaAlarmDescr = 0;
/*     */   private static final int idxUpaAlarmTime = 1;
/*  31 */   private static MOTableSubIndex[] upsAlarmEntryIndexes = {
/*  32 */     new MOTableSubIndex(2, 1, 24) };
/*     */   
/*  34 */   private static MOTableIndex upsAlarmEntryIndex = new MOTableIndex(upsAlarmEntryIndexes, false);
/*     */   
/*     */   private DefaultMOTable upsAlarmEntry;
/*     */   
/*     */   private DefaultMOMutableTableModel upsAlarmEntryModel;
/*  39 */   private int numAlarmesAtivos = 0;
/*     */   
/*     */   public UpsAlarmGroup()
/*     */   {
/*  43 */     this.upsAlarmsPresent = new MOScalar(
/*  44 */       new OID(
/*  45 */       "1.3.6.1.2.1.33.1.6.1.0"), 
/*  46 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  47 */       new Gauge32(0L));
/*     */     
/*     */ 
/*  50 */     MOColumn[] upsAlarmEntryColumns = new MOColumn[2];
/*     */     
/*  52 */     upsAlarmEntryColumns[0] = 
/*  53 */       new AutonomousType(
/*  54 */       2, 
/*  55 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  56 */       new OID(), 
/*  57 */       false);
/*     */     
/*     */ 
/*  60 */     upsAlarmEntryColumns[1] = 
/*  61 */       new MOColumn(
/*  62 */       3, 
/*  63 */       67, 
/*  64 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/*     */ 
/*  68 */     this.upsAlarmEntry = new DefaultMOTable(
/*  69 */       new OID("1.3.6.1.2.1.33.1.6.2.1"), 
/*  70 */       upsAlarmEntryIndex, 
/*  71 */       upsAlarmEntryColumns);
/*     */     
/*  73 */     this.upsAlarmEntryModel = ((DefaultMOMutableTableModel)this.upsAlarmEntry.getModel());
/*     */   }
/*     */   
/*     */   public void registerMOs(MOServer server, OctetString context) throws DuplicateRegistrationException
/*     */   {
/*  78 */     server.register(this.upsAlarmsPresent, context);
/*  79 */     server.register(this.upsAlarmEntry, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context) {
/*  83 */     server.unregister(this.upsAlarmsPresent, context);
/*  84 */     server.unregister(this.upsAlarmEntry, context);
/*     */   }
/*     */   
/*     */   public Gauge32 getUpsAlarmsPresent() {
/*  88 */     return (Gauge32)this.upsAlarmsPresent.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsAlarmsPresent(Gauge32 upsAlarmsPresent) {
/*  92 */     this.upsAlarmsPresent.setValue(upsAlarmsPresent);
/*     */   }
/*     */   
/*     */   public void addUpsAlarmEntry(int alarmId, String alarmDescr, long alarmTime)
/*     */   {
/*  97 */     this.upsAlarmEntryModel.addRow(
/*  98 */       new DefaultMOMutableRow2PC(
/*  99 */       new OID(String.valueOf(alarmId)), 
/* 100 */       new Variable[] {
/* 101 */       new OID(alarmDescr), 
/* 102 */       new TimeTicks(alarmTime) }));
/*     */     
/*     */ 
/*     */ 
/* 106 */     addNumAlarmesAtivos();
/*     */   }
/*     */   
/*     */   public MOTableRow removeUpsAlarmEntry(int index)
/*     */   {
/* 111 */     dimNumAlarmesAtivos();
/* 112 */     return this.upsAlarmEntryModel.removeRow(new OID(String.valueOf(index)));
/*     */   }
/*     */   
/*     */   public MOTableRow getUpsAlarmRow(int index)
/*     */   {
/* 117 */     return this.upsAlarmEntryModel.getRow(new OID(String.valueOf(index)));
/*     */   }
/*     */   
/*     */   public void addNumAlarmesAtivos()
/*     */   {
/* 122 */     if (this.numAlarmesAtivos < 25) {
/* 123 */       this.numAlarmesAtivos += 1;
/*     */     } else {
/* 125 */       this.numAlarmesAtivos += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public void dimNumAlarmesAtivos() {
/* 130 */     if (this.numAlarmesAtivos != 0) {
/* 131 */       this.numAlarmesAtivos -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getNumAlarmesAtivos() {
/* 136 */     return this.numAlarmesAtivos;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsAlarmGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */