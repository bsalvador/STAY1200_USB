/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ 
/*     */ public class SnmpMibsOids
/*     */ {
/*     */   public static final String snmpTargetObjects = "1.3.6.1.6.3.12.1";
/*     */   
/*     */   public static final String snmpTargetSpinLock = "1.3.6.1.6.3.12.1.1";
/*     */   
/*     */   public static final String snmpTargetAddrTable = "1.3.6.1.6.3.12.1.2";
/*     */   
/*     */   public static final String snmpTargetAddrEntry = "1.3.6.1.6.3.12.1.2.1";
/*     */   
/*     */   public static final String snmpTargetAddrName = "1.3.6.1.6.3.12.1.2.1.1";
/*     */   public static final String snmpTargetAddrTDomain = "1.3.6.1.6.3.12.1.2.1.2";
/*     */   public static final String snmpTargetAddrTAddress = "1.3.6.1.6.3.12.1.2.1.3";
/*     */   public static final String snmpTargetAddrTimeout = "1.3.6.1.6.3.12.1.2.1.4";
/*     */   public static final String snmpTargetAddrRetryCount = "1.3.6.1.6.3.12.1.2.1.5";
/*     */   public static final String snmpTargetAddrTagList = "1.3.6.1.6.3.12.1.2.1.6";
/*     */   public static final String snmpTargetAddrParams = "1.3.6.1.6.3.12.1.2.1.7";
/*     */   public static final String snmpTargetAddrStorageType = "1.3.6.1.6.3.12.1.2.1.8";
/*     */   public static final String snmpTargetAddrRowStatus = "1.3.6.1.6.3.12.1.2.1.9";
/*  23 */   public static String[] snmpTargetAddrObjects = {
/*  24 */     "1.3.6.1.6.3.12.1.2.1.2", 
/*  25 */     "1.3.6.1.6.3.12.1.2.1.3", 
/*  26 */     "1.3.6.1.6.3.12.1.2.1.4", 
/*  27 */     "1.3.6.1.6.3.12.1.2.1.5", 
/*  28 */     "1.3.6.1.6.3.12.1.2.1.6", 
/*  29 */     "1.3.6.1.6.3.12.1.2.1.7", 
/*  30 */     "1.3.6.1.6.3.12.1.2.1.8", 
/*  31 */     "1.3.6.1.6.3.12.1.2.1.9" };
/*     */   
/*     */   public static final String snmpTargetParamsTable = "1.3.6.1.6.3.12.1.3";
/*     */   
/*     */   public static final String snmpTargetParamsEntry = "1.3.6.1.6.3.12.1.3.1";
/*     */   
/*     */   public static final String snmpTargetParamsName = "1.3.6.1.6.3.12.1.3.1.1";
/*     */   
/*     */   public static final String snmpTargetParamsMPModel = "1.3.6.1.6.3.12.1.3.1.2";
/*     */   
/*     */   public static final String snmpTargetParamsSecurityModel = "1.3.6.1.6.3.12.1.3.1.3";
/*     */   public static final String snmpTargetParamsSecurityName = "1.3.6.1.6.3.12.1.3.1.4";
/*     */   public static final String snmpTargetParamsSecurityLevel = "1.3.6.1.6.3.12.1.3.1.5";
/*     */   public static final String snmpTargetParamsStorageType = "1.3.6.1.6.3.12.1.3.1.6";
/*     */   public static final String snmpTargetParamsRowStatus = "1.3.6.1.6.3.12.1.3.1.7";
/*  46 */   public static final String[] snmpTargetParamsObjects = {
/*  47 */     "1.3.6.1.6.3.12.1.3.1.2", 
/*  48 */     "1.3.6.1.6.3.12.1.3.1.3", 
/*  49 */     "1.3.6.1.6.3.12.1.3.1.4", 
/*  50 */     "1.3.6.1.6.3.12.1.3.1.5", 
/*  51 */     "1.3.6.1.6.3.12.1.3.1.6", 
/*  52 */     "1.3.6.1.6.3.12.1.3.1.7" };
/*     */   
/*     */   public static final String snmpUnavailableContexts = "1.3.6.1.6.3.12.1.4";
/*     */   
/*     */   public static final String snmpUnknownContexts = "1.3.6.1.6.3.12.1.5";
/*     */   
/*     */   public static final String snmpNotifyObjects = "1.3.6.1.6.3.13.1";
/*     */   
/*     */   public static final String snmpNotifyTable = "1.3.6.1.6.3.13.1.1";
/*     */   
/*     */   public static final String snmpNotifyEntry = "1.3.6.1.6.3.13.1.1.1";
/*     */   
/*     */   public static final String snmpNotifyName = "1.3.6.1.6.3.13.1.1.1.1";
/*     */   
/*     */   public static final String snmpNotifyTag = "1.3.6.1.6.3.13.1.1.1.2";
/*     */   public static final String snmpNotifyType = "1.3.6.1.6.3.13.1.1.1.3";
/*     */   public static final String snmpNotifyStorageType = "1.3.6.1.6.3.13.1.1.1.4";
/*     */   public static final String snmpNotifyRowStatus = "1.3.6.1.6.3.13.1.1.1.5";
/*  70 */   public static final String[] snmpNotifyTableObjects = {
/*  71 */     "1.3.6.1.6.3.13.1.1.1.2", 
/*  72 */     "1.3.6.1.6.3.13.1.1.1.3", 
/*  73 */     "1.3.6.1.6.3.13.1.1.1.4", 
/*  74 */     "1.3.6.1.6.3.13.1.1.1.5" };
/*     */   
/*     */   public static final String vacmMIBObjects = "1.3.6.1.6.3.16.1";
/*     */   
/*     */   public static final String vacmContextTable = "1.3.6.1.6.3.16.1.1";
/*     */   
/*     */   public static final String vacmContextEntry = "1.3.6.1.6.3.16.1.1.1";
/*     */   
/*     */   public static final String vacmContextName = "1.3.6.1.6.3.16.1.1.1.1";
/*     */   
/*     */   public static final String vacmSecurityToGroupTable = "1.3.6.1.6.3.16.1.2";
/*     */   
/*     */   public static final String vacmSecurityToGroupEntry = "1.3.6.1.6.3.16.1.2.1";
/*     */   
/*     */   public static final String vacmSecurityModel = "1.3.6.1.6.3.16.1.2.1.1";
/*     */   
/*     */   public static final String vacmSecurityName = "1.3.6.1.6.3.16.1.2.1.2";
/*     */   
/*     */   public static final String vacmGroupName = "1.3.6.1.6.3.16.1.2.1.3";
/*     */   
/*     */   public static final String vacmSecurityToGroupStorageType = "1.3.6.1.6.3.16.1.2.1.4";
/*     */   
/*     */   public static final String vacmSecurityToGroupStatus = "1.3.6.1.6.3.16.1.2.1.5";
/*     */   
/*     */   public static final String vacmAccessTable = "1.3.6.1.6.3.16.1.4";
/*     */   
/*     */   public static final String vacmAccessEntry = "1.3.6.1.6.3.16.1.4.1";
/*     */   
/*     */   public static final String vacmAccessContextPrefix = "1.3.6.1.6.3.16.1.4.1.1";
/*     */   
/*     */   public static final String vacmAccessSecurityModel = "1.3.6.1.6.3.16.1.4.1.2";
/*     */   public static final String vacmAccessSecurityLevel = "1.3.6.1.6.3.16.1.4.1.3";
/*     */   public static final String vacmAccessContextMatch = "1.3.6.1.6.3.16.1.4.1.4";
/*     */   public static final String vacmAccessReadViewName = "1.3.6.1.6.3.16.1.4.1.5";
/*     */   public static final String vacmAccessWriteViewName = "1.3.6.1.6.3.16.1.4.1.6";
/*     */   public static final String vacmAccessNotifyViewName = "1.3.6.1.6.3.16.1.4.1.7";
/*     */   public static final String vacmAccessStorageType = "1.3.6.1.6.3.16.1.4.1.8";
/*     */   public static final String vacmAccessStatus = "1.3.6.1.6.3.16.1.4.1.9";
/*     */   public static final String vacmMIBViews = "1.3.6.1.6.3.16.1.5";
/*     */   public static final String vacmViewSpinLock = "1.3.6.1.6.3.16.1.5.1";
/*     */   public static final String vacmViewTreeFamilyTable = "1.3.6.1.6.3.16.1.5.2";
/*     */   public static final String vacmViewTreeFamilyEntry = "1.3.6.1.6.3.16.1.5.2.1";
/*     */   public static final String vacmViewTreeFamilyViewName = "1.3.6.1.6.3.16.1.5.2.1.1";
/*     */   public static final String vacmViewTreeFamilySubtree = "1.3.6.1.6.3.16.1.5.2.1.2";
/*     */   public static final String vacmViewTreeFamilyMask = "1.3.6.1.6.3.16.1.5.2.1.3";
/*     */   public static final String vacmViewTreeFamilyType = "1.3.6.1.6.3.16.1.5.2.1.4";
/*     */   public static final String vacmViewTreeFamilyStorageType = "1.3.6.1.6.3.16.1.5.2.1.5";
/*     */   public static final String vacmViewTreeFamilyStatus = "1.3.6.1.6.3.16.1.5.2.1.6";
/*     */   public static final String usmMIBObjects = "1.3.6.1.6.3.15.1";
/*     */   public static final String usmUser = "1.3.6.1.6.3.15.1.2";
/*     */   public static final String usmUserSpinLock = "1.3.6.1.6.3.15.1.2.1";
/*     */   public static final String usmUserTable = "1.3.6.1.6.3.15.1.2.2";
/*     */   public static final String usmUserEntry = "1.3.6.1.6.3.15.1.2.2.1";
/*     */   public static final String usmUserEngineID = "1.3.6.1.6.3.15.1.2.2.1.1";
/*     */   public static final String usmUserName = "1.3.6.1.6.3.15.1.2.2.1.2";
/*     */   public static final String usmUserSecurityName = "1.3.6.1.6.3.15.1.2.2.1.3";
/*     */   public static final String usmUserCloneFrom = "1.3.6.1.6.3.15.1.2.2.1.4";
/*     */   public static final String usmUserAuthProtocol = "1.3.6.1.6.3.15.1.2.2.1.5";
/*     */   public static final String usmUserAuthKeyChange = "1.3.6.1.6.3.15.1.2.2.1.6";
/*     */   public static final String usmUserOwnAuthKeyChange = "1.3.6.1.6.3.15.1.2.2.1.7";
/*     */   public static final String usmUserPrivProtocol = "1.3.6.1.6.3.15.1.2.2.1.8";
/*     */   public static final String usmUserPrivKeyChange = "1.3.6.1.6.3.15.1.2.2.1.9";
/*     */   public static final String usmUserOwnPrivKeyChange = "1.3.6.1.6.3.15.1.2.2.1.10";
/*     */   public static final String usmUserPublic = "1.3.6.1.6.3.15.1.2.2.1.11";
/*     */   public static final String usmUserStorageType = "1.3.6.1.6.3.15.1.2.2.1.12";
/*     */   public static final String usmUserStatus = "1.3.6.1.6.3.15.1.2.2.1.13";
/* 140 */   public static final String[] usmUserObjects = {
/* 141 */     "1.3.6.1.6.3.15.1.2.2.1.3", 
/*     */     
/* 143 */     "1.3.6.1.6.3.15.1.2.2.1.5", 
/* 144 */     "1.3.6.1.6.3.15.1.2.2.1.7", 
/* 145 */     "1.3.6.1.6.3.15.1.2.2.1.8", 
/* 146 */     "1.3.6.1.6.3.15.1.2.2.1.10", 
/*     */     
/* 148 */     "1.3.6.1.6.3.15.1.2.2.1.12", 
/* 149 */     "1.3.6.1.6.3.15.1.2.2.1.13" };
/*     */   public static final String snmpUDPDomain = "1.3.6.1.6.1.1";
/*     */   public static final String transportDomainUdpIpv4 = "1.3.6.1.2.1.100.1.1";
/*     */   public static final String transportDomainUdpIpv6 = "1.3.6.1.2.1.100.1.2";
/*     */   public static final String transportDomainUdpIpv4z = "1.3.6.1.2.1.100.1.3";
/*     */   public static final String transportDomainUdpIpv6z = "1.3.6.1.2.1.100.1.4";
/*     */   public static final String transportDomainTcpIpv4 = "1.3.6.1.2.1.100.1.5";
/*     */   public static final String transportDomainTcpIpv6 = "1.3.6.1.2.1.100.1.6";
/*     */   public static final String transportDomainTcpIpv4z = "1.3.6.1.2.1.100.1.7";
/*     */   public static final String transportDomainTcpIpv6z = "1.3.6.1.2.1.100.1.8";
/*     */   public static final String snmpCommunityMIBObjects = "1.3.6.1.6.3.18.1";
/*     */   public static final String snmpCommunityTable = "1.3.6.1.6.3.18.1.1";
/*     */   public static final String snmpCommunityEntry = "1.3.6.1.6.3.18.1.1.1";
/*     */   public static final String snmpCommunityIndex = "1.3.6.1.6.3.18.1.1.1.1";
/*     */   public static final String snmpCommunityName = "1.3.6.1.6.3.18.1.1.1.2";
/*     */   public static final String snmpCommunitySecurityName = "1.3.6.1.6.3.18.1.1.1.3";
/*     */   public static final String snmpCommunityContextEngineID = "1.3.6.1.6.3.18.1.1.1.4";
/*     */   public static final String snmpCommunityContextName = "1.3.6.1.6.3.18.1.1.1.5";
/*     */   public static final String snmpCommunityTransportTag = "1.3.6.1.6.3.18.1.1.1.6";
/*     */   public static final String snmpCommunityStorageType = "1.3.6.1.6.3.18.1.1.1.7";
/*     */   public static final String snmpCommunityStatus = "1.3.6.1.6.3.18.1.1.1.8";
/*     */   
/*     */   public static final class NotifyEnum
/*     */   {
/*     */     public static final String inform = "2";
/*     */     public static final String trap = "1";
/*     */   }
/*     */   
/*     */   public static final class RowStatus
/*     */   {
/*     */     public static final String notExistant = "0";
/*     */     public static final String active = "1";
/*     */     public static final String notInService = "2";
/*     */     public static final String notReady = "3";
/*     */     public static final String createAndGo = "4";
/*     */     public static final String createAndWait = "5";
/*     */     public static final String destroy = "6";
/*     */   }
/*     */   
/*     */   public static final class StorageType
/*     */   {
/*     */     public static final String other = "1";
/*     */     public static final String volatile_ = "2";
/*     */     public static final String nonVolatile = "3";
/*     */     public static final String permanent = "4";
/*     */     public static final String readOnly = "5";
/*     */   }
/*     */   
/*     */   public static final class VacmContextMatch
/*     */   {
/*     */     public static final String vacmExactMatch = "1";
/*     */     public static final String vacmPrefixMatch = "2";
/*     */   }
/*     */   
/*     */   public static final class VacmThreeFamilyType
/*     */   {
/*     */     public static final String vacmViewIncluded = "1";
/*     */     public static final String vacmViewExcluded = "2";
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\SnmpMibsOids.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */