/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOAccess;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.snmp.EnumeratedScalar;
/*     */ import org.snmp4j.agent.request.RequestStatus;
/*     */ import org.snmp4j.agent.request.SubRequest;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.Variable;
/*     */ import org.snmp4j.smi.VariableBinding;
/*     */ 
/*     */ public class UpsControlGroup implements org.snmp4j.agent.MOGroup
/*     */ {
/*     */   private UpsControlEnumeratedScalar upsShutdownType;
/*     */   private UpsControlEnumeratedScalar upsDownloadEventos;
/*     */   private UpsControlMOScalar upsShutdownAfterDelay;
/*     */   private UpsControlMOScalar upsStartupAfterDelay;
/*     */   private UpsControlMOScalar upsRebootWithDuration;
/*     */   private UpsControlMOScalar upsHoraLigar;
/*     */   private UpsControlMOScalar upsMinLigar;
/*     */   private UpsControlMOScalar upsHoraDesligar;
/*     */   private UpsControlMOScalar upsMinDesligar;
/*     */   private UpsControlMOScalar upsDiasAgenda;
/*     */   private MOScalar upsHorario;
/*     */   private UpsControlEnumeratedScalar upsAutoRestart;
/*     */   
/*     */   public UpsControlGroup(String modeloUPS)
/*     */   {
/*  34 */     this.upsShutdownType = new UpsControlEnumeratedScalar(
/*  35 */       new OID("1.3.6.1.2.1.33.1.8.1.0"), 
/*  36 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  37 */       new Integer32(2), 
/*  38 */       new int[] {
/*  39 */       1, 
/*  40 */       2 });
/*     */     
/*     */ 
/*     */ 
/*  44 */     this.upsShutdownAfterDelay = new UpsControlMOScalar(
/*  45 */       new OID("1.3.6.1.2.1.33.1.8.2.0"), 
/*  46 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  47 */       new Integer32(-1));
/*     */     
/*     */ 
/*  50 */     this.upsStartupAfterDelay = new UpsControlMOScalar(
/*  51 */       new OID("1.3.6.1.2.1.33.1.8.3.0"), 
/*  52 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  53 */       new Integer32(-1));
/*     */     
/*     */ 
/*  56 */     this.upsRebootWithDuration = new UpsControlMOScalar(
/*  57 */       new OID("1.3.6.1.2.1.33.1.8.4.0"), 
/*  58 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  59 */       new Integer32(-1));
/*     */     
/*     */ 
/*  62 */     this.upsAutoRestart = new UpsControlEnumeratedScalar(
/*  63 */       new OID("1.3.6.1.2.1.33.1.8.5.0"), 
/*  64 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  65 */       new Integer32(2), 
/*  66 */       new int[] {
/*  67 */       1, 
/*  68 */       2 });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  73 */     this.upsHoraLigar = new UpsControlMOScalar(
/*  74 */       new OID("1.3.6.1.2.1.33.1.8.7.0"), 
/*  75 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  76 */       new Integer32(-1));
/*     */     
/*     */ 
/*  79 */     this.upsMinLigar = new UpsControlMOScalar(
/*  80 */       new OID("1.3.6.1.2.1.33.1.8.8.0"), 
/*  81 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  82 */       new Integer32(-1));
/*     */     
/*     */ 
/*  85 */     this.upsHoraDesligar = new UpsControlMOScalar(
/*  86 */       new OID("1.3.6.1.2.1.33.1.8.9.0"), 
/*  87 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  88 */       new Integer32(-1));
/*     */     
/*     */ 
/*  91 */     this.upsMinDesligar = new UpsControlMOScalar(
/*  92 */       new OID("1.3.6.1.2.1.33.1.8.10.0"), 
/*  93 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  94 */       new Integer32(-1));
/*     */     
/*     */ 
/*  97 */     this.upsDiasAgenda = new UpsControlMOScalar(
/*  98 */       new OID("1.3.6.1.2.1.33.1.8.11.0"), 
/*  99 */       MOAccessImpl.ACCESS_READ_WRITE, 
/* 100 */       new OctetString(""));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 105 */     this.upsDownloadEventos = new UpsControlEnumeratedScalar(
/* 106 */       new OID("1.3.6.1.2.1.33.1.8.6.0"), 
/* 107 */       MOAccessImpl.ACCESS_READ_WRITE, 
/* 108 */       new Integer32(1), 
/* 109 */       new int[] {
/* 110 */       1, 
/* 111 */       2 });
/*     */     
/*     */ 
/*     */ 
/* 115 */     this.upsHorario = new MOScalar(
/* 116 */       new OID("1.3.6.1.2.1.33.1.8.13.0"), 
/* 117 */       MOAccessImpl.ACCESS_READ_ONLY, 
/* 118 */       new OctetString(""));
/*     */   }
/*     */   
/*     */   public void registerMOs(MOServer server, OctetString context) throws DuplicateRegistrationException
/*     */   {
/* 123 */     server.register(this.upsShutdownType, context);
/* 124 */     server.register(this.upsShutdownAfterDelay, context);
/* 125 */     server.register(this.upsStartupAfterDelay, context);
/* 126 */     server.register(this.upsRebootWithDuration, context);
/* 127 */     server.register(this.upsAutoRestart, context);
/*     */     
/* 129 */     server.register(this.upsDownloadEventos, context);
/* 130 */     server.register(this.upsHoraLigar, context);
/* 131 */     server.register(this.upsMinLigar, context);
/* 132 */     server.register(this.upsHoraDesligar, context);
/* 133 */     server.register(this.upsMinDesligar, context);
/* 134 */     server.register(this.upsDiasAgenda, context);
/* 135 */     server.register(this.upsHorario, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context)
/*     */   {
/* 140 */     server.unregister(this.upsShutdownType, context);
/* 141 */     server.unregister(this.upsShutdownAfterDelay, context);
/* 142 */     server.unregister(this.upsStartupAfterDelay, context);
/* 143 */     server.unregister(this.upsRebootWithDuration, context);
/* 144 */     server.unregister(this.upsAutoRestart, context);
/*     */     
/* 146 */     server.unregister(this.upsDownloadEventos, context);
/* 147 */     server.unregister(this.upsHoraLigar, context);
/* 148 */     server.unregister(this.upsMinLigar, context);
/* 149 */     server.unregister(this.upsHoraDesligar, context);
/* 150 */     server.unregister(this.upsMinDesligar, context);
/* 151 */     server.unregister(this.upsDiasAgenda, context);
/* 152 */     server.unregister(this.upsHorario, context);
/*     */   }
/*     */   
/*     */   class UpsControlMOScalar
/*     */     extends MOScalar
/*     */   {
/* 158 */     private boolean atualizacao = false;
/*     */     
/*     */     public UpsControlMOScalar(OID arg0, MOAccess arg1, Variable arg2) {
/* 161 */       super(arg1, arg2);
/*     */     }
/*     */     
/*     */ 
/*     */     public void commit(SubRequest request)
/*     */     {
/* 167 */       RequestStatus status = request.getStatus();
/* 168 */       VariableBinding vb = request.getVariableBinding();
/* 169 */       request.setUndoValue(getValue());
/* 170 */       setValue(vb.getVariable());
/* 171 */       status.setPhaseComplete(true);
/* 172 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 176 */       RequestStatus status = request.getStatus();
/* 177 */       if ((request.getUndoValue() != null) && 
/* 178 */         ((request.getUndoValue() instanceof Variable))) {
/* 179 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 180 */         status.setErrorStatus(errorStatus);
/* 181 */         status.setPhaseComplete(true);
/* 182 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 185 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 190 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 194 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */   class UpsControlEnumeratedScalar
/*     */     extends EnumeratedScalar
/*     */   {
/* 201 */     private boolean atualizacao = false;
/*     */     
/*     */     public UpsControlEnumeratedScalar(OID arg0, MOAccess arg1, Integer32 arg2, int[] arg3) {
/* 204 */       super(arg1, arg2, arg3);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 209 */       RequestStatus status = request.getStatus();
/* 210 */       VariableBinding vb = request.getVariableBinding();
/* 211 */       request.setUndoValue(getValue());
/* 212 */       setValue(vb.getVariable());
/* 213 */       status.setPhaseComplete(true);
/* 214 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 218 */       RequestStatus status = request.getStatus();
/* 219 */       if ((request.getUndoValue() != null) && 
/* 220 */         ((request.getUndoValue() instanceof Variable))) {
/* 221 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 222 */         status.setErrorStatus(errorStatus);
/* 223 */         status.setPhaseComplete(true);
/* 224 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 227 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 232 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 236 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setUpsAutoRestart(Integer32 upsAutoRestart)
/*     */   {
/* 243 */     this.upsAutoRestart.setValue(upsAutoRestart);
/*     */   }
/*     */   
/*     */   public void setUpsRebootWithDuration(Integer32 upsRebootWithDuration) {
/* 247 */     this.upsRebootWithDuration.setValue(upsRebootWithDuration);
/*     */   }
/*     */   
/*     */   public void setUpsShutdownAfterDelay(int upsShutdownAfterDelay) {
/* 251 */     this.upsShutdownAfterDelay.setValue(new Integer32(upsShutdownAfterDelay));
/*     */   }
/*     */   
/*     */   public void setUpsShutdownType(Integer32 upsShutdownType) {
/* 255 */     this.upsShutdownType.setValue(upsShutdownType);
/*     */   }
/*     */   
/*     */   public void setUpsStartupAfterDelay(Integer32 upsStartupAfterDelay) {
/* 259 */     this.upsStartupAfterDelay.setValue(upsStartupAfterDelay);
/*     */   }
/*     */   
/*     */   public UpsControlEnumeratedScalar getUpsAutoRestart() {
/* 263 */     return this.upsAutoRestart;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsRebootWithDuration() {
/* 267 */     return this.upsRebootWithDuration;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsShutdownAfterDelay() {
/* 271 */     return this.upsShutdownAfterDelay;
/*     */   }
/*     */   
/*     */   public UpsControlEnumeratedScalar getUpsShutdownType() {
/* 275 */     return this.upsShutdownType;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsStartupAfterDelay() {
/* 279 */     return this.upsStartupAfterDelay;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsHoraLigar() {
/* 283 */     return this.upsHoraLigar;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsMinLigar() {
/* 287 */     return this.upsMinLigar;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsHoraDesligar() {
/* 291 */     return this.upsHoraDesligar;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsMinDesligar() {
/* 295 */     return this.upsMinDesligar;
/*     */   }
/*     */   
/*     */   public UpsControlMOScalar getUpsDiasAgenda() {
/* 299 */     return this.upsDiasAgenda;
/*     */   }
/*     */   
/*     */   public UpsControlEnumeratedScalar getUpsDownloadEventos() {
/* 303 */     return this.upsDownloadEventos;
/*     */   }
/*     */   
/*     */   public void setUpsDownloadEventos(Integer32 upsDownloadEventos) {
/* 307 */     this.upsDownloadEventos.setValue(upsDownloadEventos);
/*     */   }
/*     */   
/*     */   public void setUpsDiasAgenda(String upsDiasAgenda) {
/* 311 */     this.upsDiasAgenda.setValue(new OctetString(upsDiasAgenda));
/*     */   }
/*     */   
/*     */   public void setUpsHorario(String horario) {
/* 315 */     this.upsHorario.setValue(new OctetString(horario));
/*     */   }
/*     */   
/*     */   public void setUpsHoraDesligar(int upsHoraDesligar) {
/* 319 */     this.upsHoraDesligar.setValue(new Integer32(upsHoraDesligar));
/*     */   }
/*     */   
/*     */   public void setUpsHoraLigar(int upsHoraLigar) {
/* 323 */     this.upsHoraLigar.setValue(new Integer32(upsHoraLigar));
/*     */   }
/*     */   
/*     */   public void setUpsMinDesligar(int upsMinDesligar) {
/* 327 */     this.upsMinDesligar.setValue(new Integer32(upsMinDesligar));
/*     */   }
/*     */   
/*     */   public void setUpsMinLigar(int upsMinLigar) {
/* 331 */     this.upsMinLigar.setValue(new Integer32(upsMinLigar));
/*     */   }
/*     */   
/*     */   public void setUpsRebootWithDuration(int upsRebootWithDuration) {
/* 335 */     this.upsRebootWithDuration.setValue(new Integer32(upsRebootWithDuration));
/*     */   }
/*     */   
/*     */   public void setUpsShutdownType(int upsShutdownType) {
/* 339 */     this.upsShutdownType.setValue(new Integer32(upsShutdownType));
/*     */   }
/*     */   
/*     */   public void setUpsStartupAfterDelay(int upsStartupAfterDelay) {
/* 343 */     this.upsStartupAfterDelay.setValue(new Integer32(upsStartupAfterDelay));
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsControlGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */