/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.snmp.EnumeratedScalar;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ 
/*     */ public class UpsConfigGroup
/*     */   implements MOGroup
/*     */ {
/*     */   private MOScalar upsConfigInputVoltage;
/*     */   private MOScalar upsConfigInputFreq;
/*     */   private MOScalar upsConfigOutputVoltage;
/*     */   private MOScalar upsConfigOutputFreq;
/*     */   private MOScalar upsConfigOutputVA;
/*     */   private MOScalar upsConfigOutputPower;
/*     */   private MOScalar upsConfigLowBattTime;
/*     */   private EnumeratedScalar upsConfigAudibleStatus;
/*     */   private MOScalar upsConfigLowVoltageTransferPoint;
/*     */   private MOScalar upsConfigHighVoltageTransferPoint;
/*     */   private MOScalar upsMicrosolRedeLigada;
/*     */   private MOScalar upsMicrosolSuperAquecimento;
/*     */   private MOScalar upsMicrosolSobrecarga;
/*     */   private Integer32[] valores;
/*     */   
/*     */   public UpsConfigGroup()
/*     */   {
/*  33 */     this.valores = new Integer32[13];
/*  34 */     for (int i = 0; i < this.valores.length; i++) {
/*  35 */       this.valores[i] = new Integer32(0);
/*     */     }
/*  37 */     this.upsConfigInputVoltage = new MOScalar(
/*  38 */       new OID("1.3.6.1.2.1.33.1.9.1.0"), 
/*  39 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  40 */       this.valores[0]);
/*     */     
/*  42 */     this.upsConfigInputFreq = new MOScalar(
/*  43 */       new OID("1.3.6.1.2.1.33.1.9.2.0"), 
/*  44 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  45 */       this.valores[1]);
/*     */     
/*  47 */     this.upsConfigOutputVoltage = new MOScalar(
/*  48 */       new OID("1.3.6.1.2.1.33.1.9.3.0"), 
/*  49 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  50 */       this.valores[2]);
/*     */     
/*  52 */     this.upsConfigOutputFreq = new MOScalar(
/*  53 */       new OID("1.3.6.1.2.1.33.1.9.4.0"), 
/*  54 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  55 */       this.valores[3]);
/*     */     
/*  57 */     this.upsConfigOutputVA = new MOScalar(
/*  58 */       new OID("1.3.6.1.2.1.33.1.9.5.0"), 
/*  59 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  60 */       this.valores[4]);
/*     */     
/*  62 */     this.upsConfigOutputPower = new MOScalar(
/*  63 */       new OID("1.3.6.1.2.1.33.1.9.6.0"), 
/*  64 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  65 */       this.valores[5]);
/*     */     
/*  67 */     this.upsConfigLowBattTime = new MOScalar(
/*  68 */       new OID("1.3.6.1.2.1.33.1.9.7.0"), 
/*  69 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  70 */       this.valores[6]);
/*     */     
/*  72 */     this.upsConfigAudibleStatus = new EnumeratedScalar(
/*  73 */       new OID("1.3.6.1.2.1.33.1.9.8.0"), 
/*  74 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  75 */       this.valores[7], 
/*  76 */       new int[] {
/*  77 */       1, 
/*  78 */       2, 
/*  79 */       3 });
/*     */     
/*     */ 
/*  82 */     this.upsConfigLowVoltageTransferPoint = new MOScalar(
/*  83 */       new OID("1.3.6.1.2.1.33.1.9.9.0"), 
/*  84 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  85 */       this.valores[8]);
/*     */     
/*  87 */     this.upsConfigHighVoltageTransferPoint = new MOScalar(
/*  88 */       new OID("1.3.6.1.2.1.33.1.9.10.0"), 
/*  89 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  90 */       this.valores[9]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  95 */     this.upsMicrosolRedeLigada = new MOScalar(
/*  96 */       new OID("1.3.6.1.2.1.33.1.9.11.0"), 
/*  97 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  98 */       this.valores[10]);
/*     */     
/*     */ 
/* 101 */     this.upsMicrosolSuperAquecimento = new MOScalar(
/* 102 */       new OID("1.3.6.1.2.1.33.1.9.12.0"), 
/* 103 */       MOAccessImpl.ACCESS_READ_ONLY, 
/* 104 */       this.valores[11]);
/*     */     
/*     */ 
/* 107 */     this.upsMicrosolSobrecarga = new MOScalar(
/* 108 */       new OID("1.3.6.1.2.1.33.1.9.13.0"), 
/* 109 */       MOAccessImpl.ACCESS_READ_ONLY, 
/* 110 */       this.valores[12]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerMOs(MOServer server, OctetString context)
/*     */     throws DuplicateRegistrationException
/*     */   {
/* 118 */     server.register(this.upsConfigInputVoltage, context);
/* 119 */     server.register(this.upsConfigInputFreq, context);
/* 120 */     server.register(this.upsConfigOutputVoltage, context);
/* 121 */     server.register(this.upsConfigOutputFreq, context);
/* 122 */     server.register(this.upsConfigOutputVA, context);
/* 123 */     server.register(this.upsConfigOutputPower, context);
/* 124 */     server.register(this.upsConfigLowBattTime, context);
/* 125 */     server.register(this.upsConfigAudibleStatus, context);
/* 126 */     server.register(this.upsConfigLowVoltageTransferPoint, context);
/* 127 */     server.register(this.upsConfigHighVoltageTransferPoint, context);
/*     */     
/* 129 */     server.register(this.upsMicrosolRedeLigada, context);
/* 130 */     server.register(this.upsMicrosolSuperAquecimento, context);
/* 131 */     server.register(this.upsMicrosolSobrecarga, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context)
/*     */   {
/* 136 */     server.unregister(this.upsConfigInputVoltage, context);
/* 137 */     server.unregister(this.upsConfigInputFreq, context);
/* 138 */     server.unregister(this.upsConfigOutputVoltage, context);
/* 139 */     server.unregister(this.upsConfigOutputFreq, context);
/* 140 */     server.unregister(this.upsConfigOutputVA, context);
/* 141 */     server.unregister(this.upsConfigOutputPower, context);
/* 142 */     server.unregister(this.upsConfigLowBattTime, context);
/* 143 */     server.unregister(this.upsConfigAudibleStatus, context);
/* 144 */     server.unregister(this.upsConfigLowVoltageTransferPoint, context);
/* 145 */     server.unregister(this.upsConfigHighVoltageTransferPoint, context);
/*     */     
/* 147 */     server.unregister(this.upsMicrosolRedeLigada, context);
/* 148 */     server.unregister(this.upsMicrosolSuperAquecimento, context);
/* 149 */     server.unregister(this.upsMicrosolSobrecarga, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Integer32 getUpsConfigAudibleStatus()
/*     */   {
/* 156 */     return (Integer32)this.upsConfigAudibleStatus.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigAudibleStatus(int upsConfigAudibleStatus) {
/* 160 */     this.valores[7].setValue(upsConfigAudibleStatus);
/* 161 */     this.upsConfigAudibleStatus.setValue(this.valores[7]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigHighVoltageTransferPoint() {
/* 165 */     return (Integer32)this.upsConfigHighVoltageTransferPoint.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigHighVoltageTransferPoint(int upsConfigHighVoltageTransferPoint)
/*     */   {
/* 170 */     this.valores[9].setValue(upsConfigHighVoltageTransferPoint);
/* 171 */     this.upsConfigHighVoltageTransferPoint.setValue(this.valores[9]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigInputFreq() {
/* 175 */     return (Integer32)this.upsConfigInputFreq.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigInputFreq(int upsConfigInputFreq) {
/* 179 */     this.valores[1].setValue(upsConfigInputFreq);
/* 180 */     this.upsConfigInputFreq.setValue(this.valores[1]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigLowBattTime() {
/* 184 */     return (Integer32)this.upsConfigLowBattTime.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigLowBattTime(int upsConfigLowBattTime) {
/* 188 */     this.valores[6].setValue(upsConfigLowBattTime);
/* 189 */     this.upsConfigLowBattTime.setValue(this.valores[6]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigLowVoltageTransferPoint() {
/* 193 */     return (Integer32)this.upsConfigLowVoltageTransferPoint.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigLowVoltageTransferPoint(int upsConfigLowVoltageTransferPoint)
/*     */   {
/* 198 */     this.valores[8].setValue(upsConfigLowVoltageTransferPoint);
/* 199 */     this.upsConfigLowVoltageTransferPoint.setValue(this.valores[8]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigOutputFreq() {
/* 203 */     return (Integer32)this.upsConfigOutputFreq.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigOutputFreq(int upsConfigOutputFreq) {
/* 207 */     this.valores[3].setValue(upsConfigOutputFreq);
/* 208 */     this.upsConfigOutputFreq.setValue(this.valores[3]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigOutputPower() {
/* 212 */     return (Integer32)this.upsConfigOutputPower.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigOutputPower(int upsConfigOutputPower) {
/* 216 */     this.valores[5].setValue(upsConfigOutputPower);
/* 217 */     this.upsConfigOutputPower.setValue(this.valores[5]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigOutputVA() {
/* 221 */     return (Integer32)this.upsConfigOutputVA.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigOutputVA(int upsConfigOutputVA) {
/* 225 */     this.valores[4].setValue(upsConfigOutputVA);
/* 226 */     this.upsConfigOutputVA.setValue(this.valores[4]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigOutputVoltage() {
/* 230 */     return (Integer32)this.upsConfigOutputVoltage.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigOutputVoltage(int upsConfigOutputVoltage) {
/* 234 */     this.valores[2].setValue(upsConfigOutputVoltage);
/* 235 */     this.upsConfigOutputVoltage.setValue(this.valores[2]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsConfigInputVoltage() {
/* 239 */     return (Integer32)this.upsConfigInputVoltage.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsConfigInputVoltage(int upsConfigInputVoltage) {
/* 243 */     this.valores[0].setValue(upsConfigInputVoltage);
/* 244 */     this.upsConfigInputVoltage.setValue(this.valores[0]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsMicrosolRedeLigada() {
/* 248 */     return (Integer32)this.upsMicrosolRedeLigada.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsMicrosolRedeLigada(int upsMicrosolRedeLigada) {
/* 252 */     this.valores[10].setValue(upsMicrosolRedeLigada);
/* 253 */     this.upsMicrosolRedeLigada.setValue(this.valores[10]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsMicrosolSuperAquecimento() {
/* 257 */     return (Integer32)this.upsMicrosolSuperAquecimento.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsMicrosolSuperAquecimento(int upsMicrosolSuperAquecimento) {
/* 261 */     this.valores[11].setValue(upsMicrosolSuperAquecimento);
/* 262 */     this.upsMicrosolSuperAquecimento.setValue(this.valores[11]);
/*     */   }
/*     */   
/*     */   public Integer32 getUpsMicrosolSobrecarga() {
/* 266 */     return (Integer32)this.upsMicrosolSobrecarga.getValue();
/*     */   }
/*     */   
/*     */   public void setUpsMicrosolSobrecarga(int upsMicrosolSobrecarga) {
/* 270 */     this.valores[12].setValue(upsMicrosolSobrecarga);
/* 271 */     this.upsMicrosolSobrecarga.setValue(this.valores[12]);
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsConfigGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */