/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ 
/*     */ public class UpsMibRino
/*     */ {
/*     */   public static final String mib2 = "1.3.6.1.2.1";
/*     */   
/*     */   public static final String upsMib = "1.3.6.1.2.1.3.3";
/*     */   
/*     */   public static final String upsObjects = "1.3.6.1.2.1.3.3.1";
/*     */   
/*     */   public static final String upsIdent = "1.3.6.1.2.1.3.3.1.1";
/*     */   
/*     */   public static final String upsBattery = "1.3.6.1.2.1.3.3.1.2";
/*     */   
/*     */   public static final String upsInput = "1.3.6.1.2.1.3.3.1.3";
/*     */   
/*     */   public static final String upsOutput = "1.3.6.1.2.1.3.3.1.4";
/*     */   
/*     */   public static final String upsBypass = "1.3.6.1.2.1.3.3.1.5";
/*     */   
/*     */   public static final String upsAlarm = "1.3.6.1.2.1.3.3.1.6";
/*     */   
/*     */   public static final String upsTest = "1.3.6.1.2.1.3.3.1.7";
/*     */   public static final String upsControl = "1.3.6.1.2.1.3.3.1.8";
/*     */   public static final String upsConfig = "1.3.6.1.2.1.3.3.1.9";
/*     */   public static final String upsStatus = "1.3.6.1.2.1.3.3.1.10";
/*     */   public static final String upsCommand = "1.3.6.1.2.1.3.3.1.11";
/*     */   public static final String upsGeneral = "1.3.6.1.2.1.3.3.1.12";
/*     */   public static final String upsTraps = "1.3.6.1.2.1.3.3.2";
/*     */   public static final String upsConformance = "1.3.6.1.2.1.3.3.3";
/*     */   public static final String upsIdentManufacturer = "1.3.6.1.2.1.3.3.1.1.1";
/*     */   public static final String upsIdentModel = "1.3.6.1.2.1.3.3.1.1.2";
/*     */   public static final String upsIdentUPSSoftwareVersion = "1.3.6.1.2.1.3.3.1.1.3";
/*     */   public static final String upsIdentAgentSoftwareVersion = "1.3.6.1.2.1.3.3.1.1.4";
/*     */   public static final String upsIdentName = "1.3.6.1.2.1.3.3.1.1.5";
/*     */   public static final String upsIdentAttachedDevices = "1.3.6.1.2.1.3.3.1.1.6";
/*     */   public static final String upsIdentSerialName = "1.3.6.1.2.1.3.3.1.1.7";
/*     */   public static final String upsIdentOutputPower = "1.3.6.1.2.1.3.3.1.1.8";
/*     */   public static final String upsIdentOutputPowerFactor = "1.3.6.1.2.1.3.3.1.1.9";
/*  41 */   public static final String[] oidsIdent = {
/*  42 */     "1.3.6.1.2.1.3.3.1.1.1.0", 
/*  43 */     "1.3.6.1.2.1.3.3.1.1.2.0", 
/*  44 */     "1.3.6.1.2.1.3.3.1.1.3.0", 
/*  45 */     "1.3.6.1.2.1.3.3.1.1.4.0", 
/*  46 */     "1.3.6.1.2.1.3.3.1.1.5.0", 
/*  47 */     "1.3.6.1.2.1.3.3.1.1.6.0" };
/*     */   
/*     */   public static final String upsBatteryStatus = "1.3.6.1.2.1.3.3.1.2.1";
/*     */   
/*     */   public static final String upsSecondsOnBattery = "1.3.6.1.2.1.3.3.1.2.2";
/*     */   
/*     */   public static final String upsEstimatedMinutesRemaining = "1.3.6.1.2.1.3.3.1.2.3";
/*     */   
/*     */   public static final String upsEstimatedChargeRemaining = "1.3.6.1.2.1.3.3.1.2.4";
/*     */   
/*     */   public static final String upsBatteryVoltage = "1.3.6.1.2.1.3.3.1.2.5";
/*     */   
/*     */   public static final String upsBatteryCurrent = "1.3.6.1.2.1.3.3.1.2.6";
/*     */   
/*     */   public static final String upsBatteryTemperature = "1.3.6.1.2.1.3.3.1.2.7";
/*     */   public static final String upsBatteryCarregando = "1.3.6.1.2.1.3.3.1.2.8";
/*  63 */   public static final String[] oidsBattery = {
/*  64 */     "1.3.6.1.2.1.3.3.1.2.1.0", 
/*  65 */     "1.3.6.1.2.1.3.3.1.2.2.0", 
/*  66 */     "1.3.6.1.2.1.3.3.1.2.3.0", 
/*  67 */     "1.3.6.1.2.1.3.3.1.2.4.0", 
/*  68 */     "1.3.6.1.2.1.3.3.1.2.5.0", 
/*  69 */     "1.3.6.1.2.1.3.3.1.2.7.0", 
/*  70 */     "1.3.6.1.2.1.3.3.1.2.6.0" };
/*     */   
/*     */   public static final String upsInputLineBads = "1.3.6.1.2.1.3.3.1.3.1";
/*     */   
/*     */   public static final String upsInputNumLines = "1.3.6.1.2.1.3.3.1.3.2";
/*     */   
/*     */   public static final String upsInputLigar = "1.3.6.1.2.1.3.3.1.3.4";
/*     */   
/*     */   public static final String upsInputTable = "1.3.6.1.2.1.3.3.1.3.3";
/*     */   public static final String upsInputEntry = "1.3.6.1.2.1.3.3.1.3.3.1";
/*     */   public static final String upsInputLineIndex = "1.3.6.1.2.1.3.3.1.3.3.1.1";
/*     */   public static final String upsInputFrequency = "1.3.6.1.2.1.3.3.1.3.3.1.2";
/*     */   public static final String upsInputVoltage = "1.3.6.1.2.1.3.3.1.3.3.1.3";
/*     */   public static final String upsInputCurrent = "1.3.6.1.2.1.3.3.1.3.3.1.4";
/*     */   public static final String upsInputTruePower = "1.3.6.1.2.1.3.3.1.3.3.1.5";
/*     */   public static final String upsInputNominalVoltage = "1.3.6.1.2.1.3.3.1.3.3.1.6";
/*     */   public static final String upsInputVoltageDown = "1.3.6.1.2.1.3.3.1.3.3.1.7";
/*     */   public static final String upsInputVoltageUp = "1.3.6.1.2.1.3.3.1.3.3.1.8";
/*     */   public static final String upsInputVAPower = "1.3.6.1.2.1.3.3.1.3.3.1.9";
/*     */   public static final String upsInputPowerFactor = "1.3.6.1.2.1.3.3.1.3.3.1.10";
/*  90 */   public static final String[] oidsInput = {
/*  91 */     "1.3.6.1.2.1.3.3.1.3.1.0", 
/*  92 */     "1.3.6.1.2.1.3.3.1.3.2.0", 
/*  93 */     "1.3.6.1.2.1.3.3.1.3.3.1.2.0", 
/*  94 */     "1.3.6.1.2.1.3.3.1.3.3.1.3.0", 
/*  95 */     "1.3.6.1.2.1.3.3.1.3.3.1.4.0", 
/*  96 */     "1.3.6.1.2.1.3.3.1.3.3.1.5.0" };
/*     */   
/*     */   public static final String upsOutputSource = "1.3.6.1.2.1.3.3.1.4.1";
/*     */   
/*     */   public static final String upsOutputFrequency = "1.3.6.1.2.1.3.3.1.4.2";
/*     */   
/*     */   public static final String upsOutputNumLines = "1.3.6.1.2.1.3.3.1.4.3";
/*     */   
/*     */   public static final String upsOutputTable = "1.3.6.1.2.1.3.3.1.4.4";
/*     */   
/*     */   public static final String upsOutputEntry = "1.3.6.1.2.1.3.3.1.4.4.1";
/*     */   
/*     */   public static final String upsOutputLineIndex = "1.3.6.1.2.1.3.3.1.4.4.1.1";
/*     */   
/*     */   public static final String upsOutputVoltage = "1.3.6.1.2.1.3.3.1.4.4.1.2";
/*     */   
/*     */   public static final String upsOutputCurrent = "1.3.6.1.2.1.3.3.1.4.4.1.3";
/*     */   
/*     */   public static final String upsOutputTruePower = "1.3.6.1.2.1.3.3.1.4.4.1.4";
/*     */   public static final String upsOutputPercentLoad = "1.3.6.1.2.1.3.3.1.4.4.1.5";
/*     */   public static final String upsOutputPowerWatts = "1.3.6.1.2.1.3.3.1.4.4.1.6";
/*     */   public static final String upsOutputPowerFactor = "1.3.6.1.2.1.3.3.1.4.4.1.7";
/*     */   public static final String upsOutputVoltageDown = "1.3.6.1.2.1.3.3.1.4.4.1.8";
/*     */   public static final String upsOutputVoltageUp = "1.3.6.1.2.1.3.3.1.4.4.1.9";
/*     */   public static final String upsOutputNominalVoltage = "1.3.6.1.2.1.3.3.1.4.4.1.10";
/* 121 */   public static final String[] oidsOutput = {
/* 122 */     "1.3.6.1.2.1.3.3.1.4.1.0", 
/* 123 */     "1.3.6.1.2.1.3.3.1.4.2.0", 
/* 124 */     "1.3.6.1.2.1.3.3.1.4.3.0", 
/* 125 */     "1.3.6.1.2.1.3.3.1.4.4.1.2.0", 
/* 126 */     "1.3.6.1.2.1.3.3.1.4.4.1.3.0", 
/* 127 */     "1.3.6.1.2.1.3.3.1.4.4.1.4.0", 
/* 128 */     "1.3.6.1.2.1.3.3.1.4.4.1.5.0" };
/*     */   
/*     */ 
/*     */   public static final String upsBypassFrequency = "1.3.6.1.2.1.3.3.1.5.1";
/*     */   
/*     */   public static final String upsBypassNumLines = "1.3.6.1.2.1.3.3.1.5.2";
/*     */   
/*     */   public static final String upsBypassTable = "1.3.6.1.2.1.3.3.1.5.3";
/*     */   
/*     */   public static final String upsBypassEntry = "1.3.6.1.2.1.3.3.1.5.3.1";
/*     */   
/*     */   public static final String upsBypassLineIndex = "1.3.6.1.2.1.3.3.1.5.3.1.1";
/*     */   
/*     */   public static final String upsBypassVoltage = "1.3.6.1.2.1.3.3.1.5.3.1.2";
/*     */   
/*     */   public static final String upsBypassCurrent = "1.3.6.1.2.1.3.3.1.5.3.1.3";
/*     */   
/*     */   public static final String upsBypassPower = "1.3.6.1.2.1.3.3.1.5.3.1.4";
/*     */   
/* 147 */   public static final String[] oidsBypass = {
/* 148 */     "1.3.6.1.2.1.3.3.1.5.1.0", 
/* 149 */     "1.3.6.1.2.1.3.3.1.5.2.0", 
/* 150 */     "1.3.6.1.2.1.3.3.1.5.3.1.2.0", 
/* 151 */     "1.3.6.1.2.1.3.3.1.5.3.1.3.0", 
/* 152 */     "1.3.6.1.2.1.3.3.1.5.3.1.4.0" };
/*     */   
/*     */   public static final String upsAlarmsPresent = "1.3.6.1.2.1.3.3.1.6.1";
/*     */   
/*     */   public static final String upsAlarmTable = "1.3.6.1.2.1.3.3.1.6.2";
/*     */   
/*     */   public static final String upsAlarmEntry = "1.3.6.1.2.1.3.3.1.6.2.1";
/*     */   
/*     */   public static final String upsAlarmId = "1.3.6.1.2.1.3.3.1.6.2.1.1.0";
/*     */   
/*     */   public static final String upsAlarmDescr = "1.3.6.1.2.1.3.3.1.6.2.1.2.0";
/*     */   
/*     */   public static final String upsAlarmTime = "1.3.6.1.2.1.3.3.1.6.2.1.3.0";
/*     */   
/*     */   public static final String upsWellKnownAlarms = "1.3.6.1.2.1.3.3.1.6.2.1.2.3";
/*     */   
/*     */   public static final String upsAlarmBatteryBad = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.1";
/*     */   
/*     */   public static final String upsAlarmOnBattery = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.2";
/*     */   
/*     */   public static final String upsAlarmLowBattery = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.3";
/*     */   
/*     */   public static final String upsAlarmDepletedBattery = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.4";
/*     */   
/*     */   public static final String upsAlarmTempBad = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.5";
/*     */   
/*     */   public static final String upsAlarmInputBad = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.6";
/*     */   
/*     */   public static final String upsAlarmOutputBad = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.7";
/*     */   
/*     */   public static final String upsAlarmOutputOverload = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.8";
/*     */   
/*     */   public static final String upsAlarmOnBypass = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.9";
/*     */   public static final String upsAlarmBypassBad = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.10";
/*     */   public static final String upsAlarmOutputOffAsRequested = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.11";
/*     */   public static final String upsAlarmUpsOffAsRequested = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.12";
/*     */   public static final String upsAlarmChargerFailed = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.13";
/*     */   public static final String upsAlarmUpsOutputOff = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.14";
/*     */   public static final String upsAlarmUpsSystemOff = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.15";
/*     */   public static final String upsAlarmFanFailure = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.16";
/*     */   public static final String upsAlarmFuseFailure = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.17";
/*     */   public static final String upsAlarmGeneralFault = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.18";
/*     */   public static final String upsAlarmDiagnosticTestFailed = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.19";
/*     */   public static final String upsAlarmCommunicationsLost = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.20";
/*     */   public static final String upsAlarmAwaitingPower = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.21";
/*     */   public static final String upsAlarmShutdownPending = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.22";
/*     */   public static final String upsAlarmShutdownImminent = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.23";
/*     */   public static final String upsAlarmTestInProgress = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.24";
/*     */   public static final String upsAlarmInputDown = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.25";
/*     */   public static final String upsAlarmInputOver = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.26";
/*     */   public static final String upsAlarmInputReturn = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.27";
/*     */   public static final String upsAlarmOutputOn = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.28";
/*     */   public static final String upsAlarmOutputDAPAC = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.29";
/*     */   public static final String upsAlarmOutputShortCircuit = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.30";
/*     */   public static final String upsAlarmBatteryChanged = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.31";
/*     */   public static final String upsAlarmBatteryVeryLow = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.32";
/*     */   public static final String upsTestId = "1.3.6.1.2.1.3.3.1.7.1";
/*     */   public static final String upsTestSpinLock = "1.3.6.1.2.1.3.3.1.7.2";
/*     */   public static final String upsTestResultsSummary = "1.3.6.1.2.1.3.3.1.7.3";
/*     */   public static final String upsTestResultsDetail = "1.3.6.1.2.1.3.3.1.7.4";
/*     */   public static final String upsTestStartTime = "1.3.6.1.2.1.3.3.1.7.5";
/*     */   public static final String upsTestElapsedTime = "1.3.6.1.2.1.3.3.1.7.6";
/*     */   public static final String upsWellKnownTests = "1.3.6.1.2.1.3.3.1.7.7";
/*     */   public static final String upsTestNoTestsInitiated = "1.3.6.1.2.1.3.3.1.7.7.1";
/*     */   public static final String upsTestAbortTestInProgress = "1.3.6.1.2.1.3.3.1.7.7.2";
/*     */   public static final String upsTestGeneralSystemsTest = "1.3.6.1.2.1.3.3.1.7.7.3";
/*     */   public static final String upsTestQuickBatteryTest = "1.3.6.1.2.1.3.3.1.7.7.4";
/*     */   public static final String upsTestDeepBatteryCalibration = "1.3.6.1.2.1.3.3.1.7.7.5";
/*     */   public static final String upsShutdownType = "1.3.6.1.2.1.3.3.1.8.1";
/*     */   public static final String upsShutdownAfterDelay = "1.3.6.1.2.1.3.3.1.8.2";
/*     */   public static final String upsStartupAfterDelay = "1.3.6.1.2.1.3.3.1.8.3";
/*     */   public static final String upsRebootWithDuration = "1.3.6.1.2.1.3.3.1.8.4";
/*     */   public static final String upsAutoRestart = "1.3.6.1.2.1.3.3.1.8.5";
/*     */   public static final String upsControlWeekDay = "1.3.6.1.2.1.3.3.1.8.6";
/*     */   public static final String upsControlTurnOnTime = "1.3.6.1.2.1.3.3.1.8.7";
/*     */   public static final String upsControlTurnOffTime = "1.3.6.1.2.1.3.3.1.8.8";
/*     */   public static final String upsControlInternalTime = "1.3.6.1.2.1.3.3.1.8.9";
/*     */   public static final String upsControlInternalTimeOk = "1.3.6.1.2.1.3.3.1.8.10";
/*     */   public static final String upsControlProgramPermission = "1.3.6.1.2.1.3.3.1.8.11";
/*     */   public static final String upsControlInternalDate = "1.3.6.1.2.1.3.3.1.8.12";
/*     */   public static final String upsControlDataBase = "1.3.6.1.2.1.3.3.1.8.13";
/* 233 */   public static final String[] oidsControl = {
/*     */   
/* 235 */     "1.3.6.1.2.1.33.1.8.2.0", 
/* 236 */     "1.3.6.1.2.1.33.1.8.3.0" };
/*     */   
/*     */   public static final String upsConfigInputVoltage = "1.3.6.1.2.1.3.3.1.9.1";
/*     */   
/*     */   public static final String upsConfigInputFreq = "1.3.6.1.2.1.3.3.1.9.2";
/*     */   
/*     */   public static final String upsConfigOutputVoltage = "1.3.6.1.2.1.3.3.1.9.3";
/*     */   
/*     */   public static final String upsConfigOutputFreq = "1.3.6.1.2.1.3.3.1.9.4";
/*     */   
/*     */   public static final String upsConfigOutputVA = "1.3.6.1.2.1.3.3.1.9.5";
/*     */   
/*     */   public static final String upsConfigOutputPower = "1.3.6.1.2.1.3.3.1.9.6";
/*     */   
/*     */   public static final String upsConfigLowBattTime = "1.3.6.1.2.1.3.3.1.9.7";
/*     */   public static final String upsConfigAudibleStatus = "1.3.6.1.2.1.3.3.1.9.8";
/*     */   public static final String upsConfigLowVoltageTransferPoint = "1.3.6.1.2.1.3.3.1.9.9";
/*     */   public static final String upsConfigHighVoltageTransferPoint = "1.3.6.1.2.1.3.3.1.9.10";
/*     */   public static final String upsConfigDAPC = "1.3.6.1.2.1.3.3.1.9.11";
/*     */   public static final String upsConfigInputLowLimitFrequency = "1.3.6.1.2.1.3.3.1.9.12";
/*     */   public static final String upsConfigInputHighLimitFrequency = "1.3.6.1.2.1.3.3.1.9.13";
/*     */   public static final String upsConfigInputSens = "1.3.6.1.2.1.3.3.1.9.14";
/*     */   public static final String upsConfigOutputLowLimitFrequency = "1.3.6.1.2.1.3.3.1.9.15";
/*     */   public static final String upsConfigOutputHighLimitFrequency = "1.3.6.1.2.1.3.3.1.9.16";
/*     */   public static final String upsConfigBattMaxCurrentCharge = "1.3.6.1.2.1.3.3.1.9.17";
/*     */   public static final String upsConfigBattMinCurrentCharge = "1.3.6.1.2.1.3.3.1.9.18";
/*     */   public static final String upsConfigBattMaxVoltageCharge = "1.3.6.1.2.1.3.3.1.9.19";
/*     */   public static final String upsConfigBattMinVoltageCharge = "1.3.6.1.2.1.3.3.1.9.20";
/*     */   public static final String upsConfigPermissionMonitoring = "1.3.6.1.2.1.3.3.1.9.21";
/*     */   public static final String upsConfigPermissionManagement = "1.3.6.1.2.1.3.3.1.9.22";
/*     */   public static final String upsConfigBattMinVoltageOn = "1.3.6.1.2.1.3.3.1.9.23";
/*     */   public static final String upsConfigBattMaxVoltageOn = "1.3.6.1.2.1.3.3.1.9.24";
/*     */   public static final String upsConfigBattMinVoltageOff = "1.3.6.1.2.1.3.3.1.9.25";
/*     */   public static final String upsConfigBattMaxVoltageOff = "1.3.6.1.2.1.3.3.1.9.26";
/* 270 */   public static final String[] oidsConfig = {
/* 271 */     "1.3.6.1.2.1.3.3.1.9.1.0", 
/* 272 */     "1.3.6.1.2.1.3.3.1.9.2.0", 
/* 273 */     "1.3.6.1.2.1.3.3.1.9.3.0", 
/* 274 */     "1.3.6.1.2.1.3.3.1.9.4.0", 
/* 275 */     "1.3.6.1.2.1.3.3.1.9.5.0", 
/* 276 */     "1.3.6.1.2.1.3.3.1.9.6.0", 
/* 277 */     "1.3.6.1.2.1.3.3.1.9.7.0", 
/* 278 */     "1.3.6.1.2.1.3.3.1.9.8.0", 
/* 279 */     "1.3.6.1.2.1.3.3.1.9.9.0", 
/* 280 */     "1.3.6.1.2.1.3.3.1.9.10.0" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 299 */   public static final String[] oidsConfigRino = {
/* 300 */     "1.3.6.1.2.1.3.3.1.3.3.1.6.0", 
/* 301 */     "1.3.6.1.2.1.3.3.1.4.4.1.10.0", 
/* 302 */     "1.3.6.1.2.1.3.3.1.4.4.1.6.0" };
/*     */   
/*     */   public static final String upsStatusInputDown = "1.3.6.1.2.1.3.3.1.10.1";
/*     */   
/*     */   public static final String upsStatusInputOver = "1.3.6.1.2.1.3.3.1.10.2";
/*     */   
/*     */   public static final String upsStatusInputReturn = "1.3.6.1.2.1.3.3.1.10.3";
/*     */   
/*     */   public static final String upsStatusOutputOff = "1.3.6.1.2.1.3.3.1.10.4";
/*     */   
/*     */   public static final String upsStatusOutputOn = "1.3.6.1.2.1.3.3.1.10.5";
/*     */   
/*     */   public static final String upsStatusOutputDAPAC = "1.3.6.1.2.1.3.3.1.10.6";
/*     */   
/*     */   public static final String upsStatusOutputOverload = "1.3.6.1.2.1.3.3.1.10.7";
/*     */   
/*     */   public static final String upsStatusOutputShortCircuito = "1.3.6.1.2.1.3.3.1.10.8";
/*     */   public static final String upsStatusBatteryCharged = "1.3.6.1.2.1.3.3.1.10.9";
/*     */   public static final String upsStatusBatteryLow = "1.3.6.1.2.1.3.3.1.10.10";
/*     */   public static final String upsStatusBatteryVeryLow = "1.3.6.1.2.1.3.3.1.10.11";
/*     */   public static final String upsStatusBatteryDepleted = "1.3.6.1.2.1.3.3.1.10.12";
/* 323 */   public static final String[] oidsStatus = {
/* 324 */     "1.3.6.1.2.1.3.3.1.10.1.0", 
/* 325 */     "1.3.6.1.2.1.3.3.1.10.2.0", 
/* 326 */     "1.3.6.1.2.1.3.3.1.10.3.0", 
/* 327 */     "1.3.6.1.2.1.3.3.1.10.4.0", 
/* 328 */     "1.3.6.1.2.1.3.3.1.10.5.0", 
/* 329 */     "1.3.6.1.2.1.3.3.1.10.6.0", 
/* 330 */     "1.3.6.1.2.1.3.3.1.10.7.0", 
/* 331 */     "1.3.6.1.2.1.3.3.1.10.8.0", 
/* 332 */     "1.3.6.1.2.1.3.3.1.10.9.0", 
/* 333 */     "1.3.6.1.2.1.3.3.1.10.10.0", 
/* 334 */     "1.3.6.1.2.1.3.3.1.10.11.0", 
/* 335 */     "1.3.6.1.2.1.3.3.1.10.12.0" };
/*     */   
/*     */   public static final String upsCommandShutdown = "1.3.6.1.2.1.3.3.1.11.1";
/*     */   
/*     */   public static final String upsCommandShutdownReturn = "1.3.6.1.2.1.3.3.1.11.2";
/*     */   
/*     */   public static final String upsCommandInputTurnOnOff = "1.3.6.1.2.1.3.3.1.11.3";
/*     */   
/*     */   public static final String upsCommandSetInternalTime = "1.3.6.1.2.1.3.3.1.11.4";
/*     */   
/*     */   public static final String upsCommandSetProgram = "1.3.6.1.2.1.3.3.1.11.5";
/*     */   public static final String upsCommandSetInputRegulation = "1.3.6.1.2.1.3.3.1.11.6";
/*     */   public static final String upsCommandSetOutputRegulation = "1.3.6.1.2.1.3.3.1.11.7";
/*     */   public static final String upsCommandSetBatteryRegulation = "1.3.6.1.2.1.3.3.1.11.8";
/*     */   public static final String upsCommandSetBypass = "1.3.6.1.2.1.3.3.1.11.9";
/*     */   public static final String upsCommandSetAutoTest = "1.3.6.1.2.1.3.3.1.11.10";
/*     */   public static final String upsCommandSetAudibleStatus = "1.3.6.1.2.1.3.3.1.11.11";
/*     */   public static final String upsCommandSetDAPAC = "1.3.6.1.2.1.3.3.1.11.12";
/* 353 */   public static final String[] oidsCommand = {
/* 354 */     "1.3.6.1.2.1.3.3.1.11.1.0", 
/* 355 */     "1.3.6.1.2.1.3.3.1.11.2.0", 
/* 356 */     "1.3.6.1.2.1.3.3.1.11.3.0", 
/* 357 */     "1.3.6.1.2.1.3.3.1.11.4.4", 
/* 358 */     "1.3.6.1.2.1.3.3.1.11.5.5", 
/* 359 */     "1.3.6.1.2.1.3.3.1.11.6.6", 
/* 360 */     "1.3.6.1.2.1.3.3.1.11.7.0", 
/* 361 */     "1.3.6.1.2.1.3.3.1.11.8.0", 
/* 362 */     "1.3.6.1.2.1.3.3.1.11.9.0", 
/* 363 */     "1.3.6.1.2.1.3.3.1.11.10.0", 
/* 364 */     "1.3.6.1.2.1.3.3.1.11.11.0", 
/* 365 */     "1.3.6.1.2.1.3.3.1.11.12.0" };
/*     */   
/*     */ 
/*     */   public static final String upsEfficience = "1.3.6.1.2.1.3.3.1.12.1";
/*     */   
/*     */   public static final String upsBoostVoltage = "1.3.6.1.2.1.3.3.1.12.2";
/*     */   
/* 372 */   public static final String[] oidsGeneral = {
/* 373 */     "1.3.6.1.2.1.3.3.1.12.1.0", 
/* 374 */     "1.3.6.1.2.1.3.3.1.12.2.0" };
/*     */   
/*     */ 
/*     */   public static final String upsTrapOnBattery = "1.3.6.1.2.1.3.3.2.1";
/*     */   
/*     */ 
/*     */   public static final String upsTrapTestCompleted = "1.3.6.1.2.1.3.3.2.2";
/*     */   
/*     */ 
/*     */   public static final String upsTrapAlarmEntryAdded = "1.3.6.1.2.1.3.3.2.3";
/*     */   
/*     */   public static final String upsTrapAlarmEntryRemoved = "1.3.6.1.2.1.3.3.2.4";
/*     */   
/*     */   public static final String upsTrapAlarmMicrosol = "1.3.6.1.2.1.3.3.2.5";
/*     */   
/*     */   public static final String upsTrapHisConsumo = "1.3.6.1.2.1.3.3.2.6";
/*     */   
/*     */ 
/*     */   public static String getWellKnownAlarm(int oid)
/*     */   {
/* 394 */     String res = "";
/*     */     
/* 396 */     switch (oid) {
/*     */     case 1: 
/* 398 */       res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.1";
/* 399 */       break;
/* 400 */     case 2:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.2";
/* 401 */       break;
/* 402 */     case 3:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.3";
/* 403 */       break;
/* 404 */     case 4:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.4";
/* 405 */       break;
/* 406 */     case 5:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.5";
/* 407 */       break;
/* 408 */     case 6:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.6";
/* 409 */       break;
/* 410 */     case 7:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.7";
/* 411 */       break;
/* 412 */     case 8:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.8";
/* 413 */       break;
/* 414 */     case 9:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.9";
/* 415 */       break;
/* 416 */     case 10:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.10";
/* 417 */       break;
/* 418 */     case 11:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.11";
/* 419 */       break;
/* 420 */     case 12:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.12";
/* 421 */       break;
/* 422 */     case 13:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.13";
/* 423 */       break;
/* 424 */     case 14:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.14";
/* 425 */       break;
/* 426 */     case 15:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.15";
/* 427 */       break;
/* 428 */     case 16:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.16";
/* 429 */       break;
/* 430 */     case 17:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.17";
/* 431 */       break;
/* 432 */     case 18:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.18";
/* 433 */       break;
/* 434 */     case 19:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.19";
/* 435 */       break;
/* 436 */     case 20:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.20";
/* 437 */       break;
/* 438 */     case 21:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.21";
/* 439 */       break;
/* 440 */     case 22:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.22";
/* 441 */       break;
/* 442 */     case 23:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.23";
/* 443 */       break;
/* 444 */     case 24:  res = "1.3.6.1.2.1.3.3.1.6.2.1.2.3.24";
/*     */     }
/*     */     
/* 447 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getWellKnownAlarm(String oid)
/*     */   {
/* 457 */     String res = "";
/* 458 */     if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.1")) { res = "upsAlarmBatteryBad";
/* 459 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.2")) { res = "upsAlarmOnBattery";
/* 460 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.3")) { res = "upsAlarmLowBattery";
/* 461 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.4")) { res = "upsAlarmDepletedBattery";
/* 462 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.5")) { res = "upsAlarmTempBad";
/* 463 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.6")) { res = "upsAlarmInputBad";
/* 464 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.7")) { res = "upsAlarmOutputBad";
/* 465 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.8")) { res = "upsAlarmOutputOverload";
/* 466 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.9")) { res = "upsAlarmOnBypass";
/* 467 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.10")) { res = "upsAlarmBypassBad";
/* 468 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.11")) { res = "upsAlarmOutputOffAsRequested";
/* 469 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.12")) { res = "upsAlarmUpsOffAsRequested";
/* 470 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.13")) { res = "upsAlarmChargerFailed";
/* 471 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.14")) { res = "upsAlarmUpsOutputOff";
/* 472 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.15")) { res = "upsAlarmUpsSystemOff";
/* 473 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.16")) { res = "upsAlarmFanFailure";
/* 474 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.17")) { res = "upsAlarmFuseFailure";
/* 475 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.18")) { res = "upsAlarmGeneralFault";
/* 476 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.19")) { res = "upsAlarmDiagnosticTestFailed";
/* 477 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.20")) { res = "upsAlarmCommunicationsLost";
/* 478 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.21")) { res = "upsAlarmAwaitingPower";
/* 479 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.22")) { res = "upsAlarmShutdownPending";
/* 480 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.23")) { res = "upsAlarmShutdownImminent";
/* 481 */     } else if (oid.equals("1.3.6.1.2.1.3.3.1.6.2.1.2.3.24")) { res = "upsAlarmTestInProgress";
/*     */     }
/* 483 */     return res;
/*     */   }
/*     */   
/*     */   public static final class upsAutoRestartEnum
/*     */   {
/*     */     public static final int on = 1;
/*     */     public static final int off = 2;
/*     */   }
/*     */   
/*     */   public static final class upsBatteryStatusEnum
/*     */   {
/*     */     public static final int unknown = 1;
/*     */     public static final int batteryNormal = 2;
/*     */     public static final int batteryLow = 3;
/*     */     public static final int batteryDepleted = 4;
/*     */   }
/*     */   
/*     */   public static final class upsConfigAudibleStatusEnum
/*     */   {
/*     */     public static final int disabled = 1;
/*     */     public static final int enabled = 2;
/*     */     public static final int muted = 3;
/*     */   }
/*     */   
/*     */   public static final class upsDownloadEventosEnum
/*     */   {
/*     */     public static final int download = 1;
/*     */     public static final int semDownload = 2;
/*     */   }
/*     */   
/*     */   public static final class upsOutputSourceEnum
/*     */   {
/*     */     public static final int other = 1;
/*     */     public static final int none = 2;
/*     */     public static final int normal = 3;
/*     */     public static final int bypass = 4;
/*     */     public static final int battery = 5;
/*     */     public static final int booster = 6;
/*     */     public static final int reducer = 7;
/*     */     public static final int saidaLigada = 8;
/*     */   }
/*     */   
/*     */   public static final class upsShutdownTypeEnum
/*     */   {
/*     */     public static final int abort = -1;
/*     */     public static final int output = 1;
/*     */     public static final int system = 2;
/*     */     public static final int input = 3;
/*     */     public static final int bypass = 4;
/*     */   }
/*     */   
/*     */   public static final class upsTestResultsSummaryEnum
/*     */   {
/*     */     public static final int donePass = 1;
/*     */     public static final int doneWarning = 2;
/*     */     public static final int doneError = 3;
/*     */     public static final int aborted = 4;
/*     */     public static final int inProgress = 5;
/*     */     public static final int noTestsInitiated = 6;
/*     */   }
/*     */   
/*     */   public static final class upsTipoHisConsumoEnum
/*     */   {
/*     */     public static final int diario = 1;
/*     */     public static final int semanal = 2;
/*     */     public static final int mensal = 3;
/*     */     public static final int anual = 4;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsMibRino.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */