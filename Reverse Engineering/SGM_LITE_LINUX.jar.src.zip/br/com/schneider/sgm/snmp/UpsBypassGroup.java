/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOAccess;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.DefaultMOMutableTableModel;
/*     */ import org.snmp4j.agent.mo.DefaultMOTable;
/*     */ import org.snmp4j.agent.mo.DefaultMOTableRow;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOMutableColumn;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.MOTableIndex;
/*     */ import org.snmp4j.agent.mo.MOTableRow;
/*     */ import org.snmp4j.agent.mo.MOTableSubIndex;
/*     */ import org.snmp4j.agent.mo.snmp.DisplayStringScalar;
/*     */ import org.snmp4j.agent.request.RequestStatus;
/*     */ import org.snmp4j.agent.request.SubRequest;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.Variable;
/*     */ import org.snmp4j.smi.VariableBinding;
/*     */ 
/*     */ public class UpsBypassGroup implements MOGroup
/*     */ {
/*     */   private MOScalar upsBypassFrequency;
/*     */   private MOScalar upsBypassNumLines;
/*     */   private UpsBypassDisplayStringScalar upsBypassAtivar;
/*     */   public static final int colUpsBypassVoltage = 2;
/*     */   public static final int colUpsBypassCurrent = 3;
/*     */   public static final int colUpsBypassPower = 4;
/*     */   private static final int idxUpsBypassVoltage = 0;
/*     */   private static final int idxUpsBypassCurrent = 1;
/*     */   private static final int idxUpsBypassPower = 2;
/*  36 */   private static MOTableSubIndex[] upsBypassEntryIndexes = {
/*  37 */     new MOTableSubIndex(2, 1, Integer.MAX_VALUE) };
/*     */   
/*  39 */   private static MOTableIndex upsBypassEntryIndex = new MOTableIndex(upsBypassEntryIndexes, true);
/*     */   
/*     */   private DefaultMOTable upsBypassEntry;
/*     */   private DefaultMOMutableTableModel upsBypassEntryModel;
/*     */   private Integer32[] vr;
/*     */   private OID linhaUsada;
/*     */   private OctetString bypassAtivar;
/*     */   
/*     */   public UpsBypassGroup()
/*     */   {
/*  49 */     this.linhaUsada = new OID("1");
/*  50 */     this.vr = new Integer32[3];
/*  51 */     for (int i = 0; i < this.vr.length; i++) {
/*  52 */       this.vr[i] = new Integer32(0);
/*     */     }
/*     */     
/*  55 */     this.upsBypassFrequency = new MOScalar(
/*  56 */       new OID("1.3.6.1.2.1.33.1.5.1.0"), 
/*  57 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  58 */       new Integer32(0));
/*     */     
/*     */ 
/*  61 */     this.upsBypassNumLines = new MOScalar(
/*  62 */       new OID("1.3.6.1.2.1.33.1.5.2.0"), 
/*  63 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  64 */       new Integer32(1));
/*     */     
/*     */ 
/*     */ 
/*  68 */     this.bypassAtivar = new OctetString("");
/*  69 */     this.upsBypassAtivar = 
/*  70 */       new UpsBypassDisplayStringScalar(
/*  71 */       new OID("1.3.6.1.2.1.33.1.5.4.0"), 
/*  72 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  73 */       this.bypassAtivar, 0, 5);
/*     */     
/*  75 */     MOMutableColumn[] upsBypassEntryColumns = new MOMutableColumn[this.vr.length];
/*  76 */     upsBypassEntryColumns[0] = 
/*  77 */       new MOMutableColumn(
/*  78 */       2, 
/*  79 */       2, 
/*  80 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*     */ 
/*  83 */     upsBypassEntryColumns[1] = 
/*  84 */       new MOMutableColumn(
/*  85 */       3, 
/*  86 */       2, 
/*  87 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*  89 */     upsBypassEntryColumns[2] = 
/*  90 */       new MOMutableColumn(
/*  91 */       4, 
/*  92 */       2, 
/*  93 */       MOAccessImpl.ACCESS_READ_ONLY);
/*     */     
/*  95 */     this.upsBypassEntry = new DefaultMOTable(
/*  96 */       new OID("1.3.6.1.2.1.33.1.5.3.1"), 
/*  97 */       upsBypassEntryIndex, 
/*  98 */       upsBypassEntryColumns);
/*     */     
/* 100 */     this.upsBypassEntryModel = new DefaultMOMutableTableModel();
/* 101 */     this.upsBypassEntry.setModel(this.upsBypassEntryModel);
/*     */     
/* 103 */     addUpsBypassEntry(
/* 104 */       1, 
/* 105 */       0, 
/* 106 */       0, 
/* 107 */       0);
/*     */   }
/*     */   
/*     */   public void registerMOs(MOServer server, OctetString context)
/*     */     throws DuplicateRegistrationException
/*     */   {
/* 113 */     server.register(this.upsBypassFrequency, context);
/* 114 */     server.register(this.upsBypassNumLines, context);
/* 115 */     server.register(this.upsBypassAtivar, context);
/* 116 */     server.register(this.upsBypassEntry, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context)
/*     */   {
/* 121 */     server.unregister(this.upsBypassFrequency, context);
/* 122 */     server.unregister(this.upsBypassNumLines, context);
/* 123 */     server.unregister(this.upsBypassAtivar, context);
/* 124 */     server.unregister(this.upsBypassEntry, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUpsBypassEntry(int index, int bypassVoltage, int bypassCurrent, int bypassPower)
/*     */   {
/* 135 */     this.linhaUsada.setValue(String.valueOf(index));
/* 136 */     this.vr[0].setValue(bypassVoltage);
/* 137 */     this.vr[1].setValue(bypassCurrent);
/* 138 */     this.vr[2].setValue(bypassPower);
/*     */     
/* 140 */     DefaultMOTableRow row = new DefaultMOTableRow(new OID(String.valueOf(index)), this.vr);
/*     */     
/* 142 */     this.upsBypassEntryModel.addRow(row);
/*     */   }
/*     */   
/*     */ 
/*     */   public MOTableRow removeUpsBypassEntry(OID index)
/*     */   {
/* 148 */     return this.upsBypassEntryModel.removeRow(index);
/*     */   }
/*     */   
/*     */ 
/*     */   public int getUpsBypassFrequency()
/*     */   {
/* 154 */     return this.upsBypassFrequency.getValue().toInt();
/*     */   }
/*     */   
/*     */   public int getUpsBypassNumLines() {
/* 158 */     return this.upsBypassNumLines.getValue().toInt();
/*     */   }
/*     */   
/*     */   public void setUpsBypassNumLines(Integer32 upsBypassNumLines) {
/* 162 */     this.upsBypassNumLines.setValue(upsBypassNumLines);
/*     */   }
/*     */   
/*     */   public MOTableRow getUpsBypassRow(OID index)
/*     */   {
/* 167 */     return this.upsBypassEntryModel.getRow(index);
/*     */   }
/*     */   
/*     */   public UpsBypassDisplayStringScalar getUpsBypassAtivar() {
/* 171 */     return this.upsBypassAtivar;
/*     */   }
/*     */   
/*     */   public void setUpsBypassAtivar(String upsBypassAtivar) {
/* 175 */     this.bypassAtivar.setValue(upsBypassAtivar);
/* 176 */     this.upsBypassAtivar.setValue(this.bypassAtivar);
/*     */   }
/*     */   
/*     */   public void setUpsBypassFrequency(int upsBypassFrequency) {
/* 180 */     this.upsBypassFrequency.setValue(new Integer32(upsBypassFrequency));
/*     */   }
/*     */   
/*     */   public void setUpsBypassNumLines(int upsNumLines) {
/* 184 */     this.upsBypassNumLines.setValue(new Integer32(upsNumLines));
/*     */   }
/*     */   
/*     */   class UpsBypassDisplayStringScalar extends DisplayStringScalar
/*     */   {
/* 189 */     public boolean atualizacao = false;
/*     */     
/*     */     public UpsBypassDisplayStringScalar(OID oid, MOAccess access, OctetString value, int minSize, int maxSize) {
/* 192 */       super(access, value, minSize, maxSize);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 197 */       RequestStatus status = request.getStatus();
/* 198 */       VariableBinding vb = request.getVariableBinding();
/* 199 */       request.setUndoValue(getValue());
/* 200 */       setValue(vb.getVariable());
/* 201 */       status.setPhaseComplete(true);
/* 202 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 206 */       RequestStatus status = request.getStatus();
/* 207 */       if ((request.getUndoValue() != null) && 
/* 208 */         ((request.getUndoValue() instanceof Variable))) {
/* 209 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 210 */         status.setErrorStatus(errorStatus);
/* 211 */         status.setPhaseComplete(true);
/* 212 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 215 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 220 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 224 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsBypassGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */