/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.snmp4j.TransportMapping;
/*     */ import org.snmp4j.agent.BaseAgent;
/*     */ import org.snmp4j.agent.CommandProcessor;
/*     */ import org.snmp4j.agent.mo.DefaultMOTable;
/*     */ import org.snmp4j.agent.mo.MOTable;
/*     */ import org.snmp4j.agent.mo.MOTableRow;
/*     */ import org.snmp4j.agent.mo.snmp.SnmpCommunityMIB;
/*     */ import org.snmp4j.agent.mo.snmp.SnmpNotificationMIB;
/*     */ import org.snmp4j.agent.mo.snmp.SnmpTargetMIB;
/*     */ import org.snmp4j.agent.mo.snmp.TransportDomains;
/*     */ import org.snmp4j.agent.mo.snmp.VacmMIB;
/*     */ import org.snmp4j.mp.MPv3;
/*     */ import org.snmp4j.security.USM;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.TcpAddress;
/*     */ import org.snmp4j.smi.UdpAddress;
/*     */ import org.snmp4j.smi.Variable;
/*     */ import org.snmp4j.transport.DefaultTcpTransportMapping;
/*     */ import org.snmp4j.transport.DefaultUdpTransportMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AgenteSNMP
/*     */   extends BaseAgent
/*     */ {
/*     */   protected UdpAddress localUdpAddress;
/*     */   protected TcpAddress localTcpAddress;
/*     */   protected int portaPedidos;
/*     */   protected String comunidadeLeitura;
/*     */   protected String comunidadeEscrita;
/*  41 */   protected final String index1Escrita = "private";
/*  42 */   protected final String index2Escrita = "private2";
/*  43 */   protected final String index1Leitura = "public";
/*  44 */   protected final String index2Leitura = "public2";
/*  45 */   protected final String indexTargetMIB = "sgm";
/*     */   
/*     */ 
/*     */   protected String ipGerente;
/*     */   
/*     */ 
/*     */   protected int portaTraps;
/*     */   
/*     */   protected int vSNMPTraps;
/*     */   
/*     */   protected String protocoloTransporte;
/*     */   
/*     */ 
/*     */   public AgenteSNMP(File bootCounterFile, File configFile, String address)
/*     */   {
/*  60 */     super(bootCounterFile, configFile, new CommandProcessor(new OctetString(MPv3.createLocalEngineID())));
/*     */     
/*     */ 
/*     */ 
/*  64 */     this.localUdpAddress = new UdpAddress(address);
/*  65 */     this.localTcpAddress = new TcpAddress(address);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerManagedObjects() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void unregisterManagedObjects() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addUsmUser(USM arg0) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addNotificationTargets(SnmpTargetMIB targetMIB, SnmpNotificationMIB notificationMIB)
/*     */   {
/*  92 */     targetMIB.addDefaultTDomains();
/*     */     
/*  94 */     notificationMIB.addNotifyEntry(new OctetString("default"), 
/*  95 */       new OctetString("notify"), 
/*  96 */       1, 
/*  97 */       3);
/*     */     
/*  99 */     initTargetMIB(targetMIB);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addViews(VacmMIB vacm)
/*     */   {
/* 105 */     initVacmMIB(vacm);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initVacmMIB(VacmMIB vacm)
/*     */   {
/* 111 */     vacm.addGroup(
/* 112 */       1, 
/* 113 */       new OctetString("private"), 
/* 114 */       new OctetString("leituraescrita"), 
/* 115 */       3);
/*     */     
/* 117 */     vacm.addGroup(
/* 118 */       2, 
/* 119 */       new OctetString("private"), 
/* 120 */       new OctetString("leituraescrita"), 
/* 121 */       3);
/*     */     
/*     */ 
/* 124 */     vacm.addGroup(
/* 125 */       1, 
/* 126 */       new OctetString("public"), 
/* 127 */       new OctetString("soleitura"), 
/* 128 */       3);
/*     */     
/* 130 */     vacm.addGroup(
/* 131 */       2, 
/* 132 */       new OctetString("public"), 
/* 133 */       new OctetString("soleitura"), 
/* 134 */       3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */     vacm.addAccess(
/* 142 */       new OctetString("soleitura"), 
/* 143 */       new OctetString(), 
/* 144 */       0, 
/* 145 */       1, 
/* 146 */       1, 
/* 147 */       new OctetString("fullReadView"), 
/* 148 */       new OctetString(""), 
/* 149 */       new OctetString("fullNotifyView"), 
/* 150 */       3);
/*     */     
/* 152 */     vacm.addAccess(
/* 153 */       new OctetString("leituraescrita"), 
/* 154 */       new OctetString(), 
/* 155 */       0, 
/* 156 */       1, 
/* 157 */       1, 
/* 158 */       new OctetString("fullReadView"), 
/* 159 */       new OctetString("fullWriteView"), 
/* 160 */       new OctetString("fullNotifyView"), 
/* 161 */       3);
/*     */     
/*     */ 
/*     */ 
/* 165 */     vacm.addViewTreeFamily(
/* 166 */       new OctetString("fullReadView"), 
/* 167 */       new OID("1.3"), 
/* 168 */       new OctetString(), 
/* 169 */       1, 
/* 170 */       3);
/*     */     
/* 172 */     vacm.addViewTreeFamily(
/* 173 */       new OctetString("fullWriteView"), 
/* 174 */       new OID("1.3"), 
/* 175 */       new OctetString(), 
/* 176 */       1, 
/* 177 */       3);
/*     */     
/* 179 */     vacm.addViewTreeFamily(
/* 180 */       new OctetString("fullNotifyView"), 
/* 181 */       new OID("1.3"), 
/* 182 */       new OctetString(), 
/* 183 */       1, 
/* 184 */       3);
/*     */   }
/*     */   
/*     */   protected void initTargetMIB(SnmpTargetMIB targetMIB)
/*     */   {
/* 189 */     targetMIB.addTargetParams(new OctetString("sgm"), 
/* 190 */       0, 
/* 191 */       1, 
/* 192 */       new OctetString("private"), 
/* 193 */       1, 
/* 194 */       3);
/* 195 */     targetMIB.addTargetAddress(new OctetString("sgm"), 
/* 196 */       TransportDomains.transportDomainUdpIpv4, 
/* 197 */       new OctetString(new UdpAddress("127.0.0.1/162").getValue()), 
/* 198 */       200, 1, 
/* 199 */       new OctetString("notify"), 
/* 200 */       new OctetString("sgm"), 
/* 201 */       3);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initCommunityMIB(SnmpCommunityMIB communityMIB)
/*     */   {
/* 207 */     Variable[] com3sec = { new OctetString("public"), 
/* 208 */       new OctetString("public"), 
/* 209 */       getAgent().getContextEngineID(), 
/* 210 */       new OctetString(), 
/* 211 */       new OctetString(), 
/* 212 */       new Integer32(3), 
/* 213 */       new Integer32(1) };
/*     */     
/* 215 */     MOTableRow row3 = communityMIB.getSnmpCommunityEntry().createRow(
/* 216 */       new OctetString("public").toSubIndex(true), com3sec);
/* 217 */     communityMIB.getSnmpCommunityEntry().addRow(row3);
/*     */     
/*     */ 
/* 220 */     Variable[] com4sec = { new OctetString("private"), 
/* 221 */       new OctetString("private"), 
/* 222 */       getAgent().getContextEngineID(), 
/* 223 */       new OctetString(), 
/* 224 */       new OctetString(), 
/* 225 */       new Integer32(3), 
/* 226 */       new Integer32(1) };
/*     */     
/* 228 */     MOTableRow row4 = communityMIB.getSnmpCommunityEntry().createRow(
/* 229 */       new OctetString("private").toSubIndex(true), com4sec);
/* 230 */     communityMIB.getSnmpCommunityEntry().addRow(row4);
/*     */   }
/*     */   
/*     */   protected void initTransportMappings() throws IOException {
/* 234 */     this.transportMappings = new TransportMapping[2];
/* 235 */     this.transportMappings[0] = new DefaultUdpTransportMapping(this.localUdpAddress);
/* 236 */     this.transportMappings[1] = new DefaultTcpTransportMapping(this.localTcpAddress);
/*     */   }
/*     */   
/* 239 */   public String getLocalAddress() { return this.localUdpAddress.toString(); }
/*     */   
/*     */   public void setLocalAddress(String address) {
/* 242 */     this.localUdpAddress.setValue(address);
/* 243 */     this.localTcpAddress.setValue(address);
/*     */   }
/*     */   
/*     */   protected void addCommunities(SnmpCommunityMIB communityMIB)
/*     */   {
/* 248 */     initCommunityMIB(communityMIB);
/*     */   }
/*     */   
/*     */   public boolean changeReadOnlyComunityString(String antiga, String nova)
/*     */   {
/* 253 */     String index = "public";
/*     */     
/* 255 */     if (this.snmpCommunityMIB.getSnmpCommunityEntry().removeRow(new OctetString(index).toSubIndex(true)) == null)
/*     */     {
/* 257 */       index = "public2";
/* 258 */       if (this.snmpCommunityMIB.getSnmpCommunityEntry().removeRow(new OctetString(index).toSubIndex(true)) == null) {
/* 259 */         return false;
/*     */       }
/* 261 */       index = "public";
/*     */     }
/*     */     else {
/* 264 */       index = "public2";
/*     */     }
/*     */     
/* 267 */     Variable[] com3sec = { new OctetString(nova), 
/* 268 */       new OctetString(nova), 
/* 269 */       getAgent().getContextEngineID(), 
/* 270 */       new OctetString(), 
/* 271 */       new OctetString(), 
/* 272 */       new Integer32(3), 
/* 273 */       new Integer32(1) };
/*     */     
/* 275 */     MOTableRow row3 = this.snmpCommunityMIB.getSnmpCommunityEntry().createRow(
/* 276 */       new OctetString(index).toSubIndex(true), com3sec);
/*     */     
/* 278 */     if (!this.snmpCommunityMIB.getSnmpCommunityEntry().addRow(row3)) {
/* 279 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 283 */     if ((this.vacmMIB.removeGroup(1, new OctetString(antiga))) && 
/* 284 */       (this.vacmMIB.removeGroup(2, new OctetString(antiga))))
/*     */     {
/*     */ 
/* 287 */       this.vacmMIB.addGroup(
/* 288 */         1, 
/* 289 */         new OctetString(nova), 
/* 290 */         new OctetString("soleitura"), 
/* 291 */         3);
/* 292 */       this.vacmMIB.addGroup(
/* 293 */         2, 
/* 294 */         new OctetString(nova), 
/* 295 */         new OctetString("soleitura"), 
/* 296 */         3);
/* 297 */       return true;
/*     */     }
/*     */     
/* 300 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean changeReadWriteComunityString(String antiga, String nova)
/*     */   {
/* 309 */     String index = "private";
/*     */     
/* 311 */     if (this.snmpCommunityMIB.getSnmpCommunityEntry().removeRow(new OctetString(index).toSubIndex(true)) == null)
/*     */     {
/* 313 */       index = "private2";
/* 314 */       if (this.snmpCommunityMIB.getSnmpCommunityEntry().removeRow(new OctetString(index).toSubIndex(true)) == null) {
/* 315 */         return false;
/*     */       }
/* 317 */       index = "private";
/*     */     }
/*     */     else {
/* 320 */       index = "private2";
/*     */     }
/*     */     
/* 323 */     Variable[] com3sec = { new OctetString(nova), 
/* 324 */       new OctetString(nova), 
/* 325 */       getAgent().getContextEngineID(), 
/* 326 */       new OctetString(), 
/* 327 */       new OctetString(), 
/* 328 */       new Integer32(3), 
/* 329 */       new Integer32(1) };
/*     */     
/* 331 */     MOTableRow row3 = this.snmpCommunityMIB.getSnmpCommunityEntry().createRow(
/* 332 */       new OctetString(index).toSubIndex(true), com3sec);
/*     */     
/* 334 */     if (!this.snmpCommunityMIB.getSnmpCommunityEntry().addRow(row3)) {
/* 335 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 339 */     if ((this.vacmMIB.removeGroup(1, new OctetString(antiga))) && 
/* 340 */       (this.vacmMIB.removeGroup(2, new OctetString(antiga))))
/*     */     {
/*     */ 
/* 343 */       this.vacmMIB.addGroup(
/* 344 */         1, 
/* 345 */         new OctetString(nova), 
/* 346 */         new OctetString("leituraescrita"), 
/* 347 */         3);
/* 348 */       this.vacmMIB.addGroup(
/* 349 */         2, 
/* 350 */         new OctetString(nova), 
/* 351 */         new OctetString("leituraescrita"), 
/* 352 */         3);
/*     */       
/*     */ 
/* 355 */       MOTableRow row = this.snmpTargetMIB.removeTargetParams(new OctetString("sgm"));
/* 356 */       if (row == null) {
/* 357 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 361 */       return this.snmpTargetMIB.addTargetParams(
/* 362 */         new OctetString("sgm"), 
/* 363 */         row.getValue(0).toInt(), 
/* 364 */         row.getValue(1).toInt(), 
/* 365 */         new OctetString(nova), 
/* 366 */         row.getValue(3).toInt(), 
/* 367 */         3);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 372 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean changeConfigTraps(String ipGerente, int portaEnvio, int versao, String protocoloTransporte, String comEscrita)
/*     */   {
/* 381 */     if ((this.snmpTargetMIB.removeTargetAddress(new OctetString("sgm")) != null) && 
/* 382 */       (this.snmpTargetMIB.removeTargetParams(new OctetString("sgm")) != null))
/*     */     {
/*     */ 
/* 385 */       int mp = 0;int secModel = 0;
/*     */       
/* 387 */       if (versao == 1)
/*     */       {
/* 389 */         mp = 0;
/* 390 */         secModel = 1;
/*     */       }
/*     */       else
/*     */       {
/* 394 */         mp = 1;
/* 395 */         secModel = 2;
/*     */       }
/*     */       
/*     */       OctetString end;
/*     */       OID pt;
/*     */       OctetString end;
/* 401 */       if (protocoloTransporte.equalsIgnoreCase("udp"))
/*     */       {
/* 403 */         OID pt = new OID(TransportDomains.transportDomainUdpIpv4);
/* 404 */         end = new OctetString(new UdpAddress(ipGerente + "/" + portaEnvio).getValue());
/*     */       }
/*     */       else
/*     */       {
/* 408 */         pt = new OID(TransportDomains.transportDomainTcpIpv4);
/* 409 */         end = new OctetString(new TcpAddress(ipGerente + "/" + portaEnvio).getValue());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 416 */       if (this.snmpTargetMIB.addTargetParams(new OctetString("sgm"), mp, secModel, new OctetString(comEscrita), 1, 3))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 423 */         if (this.snmpTargetMIB.addTargetAddress(new OctetString("sgm"), pt, end, 200, 1, new OctetString("notify"), new OctetString("sgm"), 3))
/* 411 */           return true; } return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 427 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateConfigGeralSNMP()
/*     */   {
/* 433 */     String index = "public";
/* 434 */     OctetString com = (OctetString)this.snmpCommunityMIB.getSnmpCommunityEntry()
/* 435 */       .getValue(
/* 436 */       new OID(
/* 437 */       "1.3.6.1.6.3.18.1.1.1.2." + 
/* 438 */       new OctetString(index).toSubIndex(true).toString()));
/*     */     
/*     */ 
/* 441 */     if (com == null)
/*     */     {
/* 443 */       index = "public2";
/* 444 */       com = (OctetString)this.snmpCommunityMIB.getSnmpCommunityEntry()
/* 445 */         .getValue(
/* 446 */         new OID(
/* 447 */         "1.3.6.1.6.3.18.1.1.1.2." + 
/* 448 */         new OctetString(index).toSubIndex(true).toString()));
/*     */     }
/*     */     
/*     */ 
/* 452 */     if (com != null)
/*     */     {
/* 454 */       if (!this.comunidadeLeitura.equals(com.toString())) {
/* 455 */         this.comunidadeLeitura = com.toString();
/*     */       }
/*     */     }
/*     */     
/* 459 */     index = "private";
/* 460 */     com = (OctetString)this.snmpCommunityMIB.getSnmpCommunityEntry()
/* 461 */       .getValue(
/* 462 */       new OID(
/* 463 */       "1.3.6.1.6.3.18.1.1.1.2." + 
/* 464 */       new OctetString(index).toSubIndex(true).toString()));
/*     */     
/*     */ 
/* 467 */     if (com == null)
/*     */     {
/* 469 */       index = "private2";
/* 470 */       com = (OctetString)this.snmpCommunityMIB.getSnmpCommunityEntry()
/* 471 */         .getValue(
/* 472 */         new OID(
/* 473 */         "1.3.6.1.6.3.18.1.1.1.2." + 
/* 474 */         new OctetString(index).toSubIndex(true).toString()));
/*     */     }
/*     */     
/*     */ 
/* 478 */     if (com != null)
/*     */     {
/* 480 */       if (!this.comunidadeEscrita.equals(com.toString())) {
/* 481 */         this.comunidadeEscrita = com.toString();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void updateConfigTraps()
/*     */   {
/* 490 */     String ipGerente = this.ipGerente + "/" + this.portaTraps;
/*     */     
/* 492 */     String ipAtual = "";
/*     */     
/* 494 */     if (this.snmpTargetMIB.getTargetAddress(
/* 495 */       new OctetString("sgm")) != null) {
/* 496 */       ipAtual = 
/* 497 */         this.snmpTargetMIB.getTargetAddress(new OctetString("sgm")).toString();
/*     */     }
/* 499 */     if (!ipGerente.equals(ipAtual))
/*     */     {
/* 501 */       String[] ipPorta = ipAtual.split("/");
/* 502 */       if (ipPorta.length > 1)
/*     */       {
/* 504 */         this.ipGerente = ipPorta[0];
/* 505 */         this.portaTraps = Integer.parseInt(ipPorta[1]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 510 */     OID tpAtual = (OID)this.snmpTargetMIB.getSnmpTargetAddrEntry()
/* 511 */       .getValue(new OID(
/* 512 */       "1.3.6.1.6.3.12.1.2.1.2." + 
/* 513 */       new OctetString("sgm").toSubIndex(true)));
/* 514 */     if (tpAtual != null)
/*     */     {
/*     */ 
/* 517 */       if ("1.3.6.1.2.1.100.1.1".equals(tpAtual.toString()))
/*     */       {
/* 519 */         this.protocoloTransporte = "udp";
/*     */       }
/* 521 */       else if ("1.3.6.1.2.1.100.1.5".equals(tpAtual.toString()))
/*     */       {
/* 523 */         this.protocoloTransporte = "tcp";
/*     */       }
/*     */     }
/* 526 */     if (this.snmpTargetMIB.getTargetParamsRow(
/* 527 */       new OctetString("sgm")) != null)
/*     */     {
/* 529 */       int vs = this.snmpTargetMIB.getTargetParamsRow(
/* 530 */         new OctetString("sgm")).getValue(0).toInt();
/*     */       
/* 532 */       if (vs == 0) {
/* 533 */         this.vSNMPTraps = 1;
/* 534 */       } else if (vs == 1) {
/* 535 */         this.vSNMPTraps = 2;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void initConfigGeralSNMP(int portaPedidos, String comunidadeLeitura, String comunidadeEscrita) {
/* 541 */     this.portaPedidos = portaPedidos;
/* 542 */     this.comunidadeLeitura = comunidadeLeitura;
/* 543 */     this.comunidadeEscrita = comunidadeEscrita;
/*     */   }
/*     */   
/*     */   public void initConfigTraps(String ipGerente, int portaEnvio, int versao, String protocoloTransporte)
/*     */   {
/* 548 */     this.ipGerente = ipGerente;
/* 549 */     this.portaTraps = portaEnvio;
/* 550 */     this.vSNMPTraps = versao;
/* 551 */     this.protocoloTransporte = protocoloTransporte;
/*     */   }
/*     */   
/*     */   public void saveConfigSNMP()
/*     */   {
/* 556 */     saveConfig();
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\AgenteSNMP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */