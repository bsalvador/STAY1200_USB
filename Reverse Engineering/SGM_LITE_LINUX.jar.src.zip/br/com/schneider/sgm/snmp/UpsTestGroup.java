/*     */ package br.com.schneider.sgm.snmp;
/*     */ 
/*     */ import org.snmp4j.agent.DuplicateRegistrationException;
/*     */ import org.snmp4j.agent.MOAccess;
/*     */ import org.snmp4j.agent.MOGroup;
/*     */ import org.snmp4j.agent.MOServer;
/*     */ import org.snmp4j.agent.mo.MOAccessImpl;
/*     */ import org.snmp4j.agent.mo.MOScalar;
/*     */ import org.snmp4j.agent.mo.snmp.DisplayStringScalar;
/*     */ import org.snmp4j.agent.mo.snmp.EnumeratedScalar;
/*     */ import org.snmp4j.agent.mo.snmp.TestAndIncr;
/*     */ import org.snmp4j.agent.request.RequestStatus;
/*     */ import org.snmp4j.agent.request.SubRequest;
/*     */ import org.snmp4j.smi.Integer32;
/*     */ import org.snmp4j.smi.OID;
/*     */ import org.snmp4j.smi.OctetString;
/*     */ import org.snmp4j.smi.TimeTicks;
/*     */ import org.snmp4j.smi.Variable;
/*     */ import org.snmp4j.smi.VariableBinding;
/*     */ 
/*     */ 
/*     */ public class UpsTestGroup
/*     */   implements MOGroup
/*     */ {
/*     */   private UpsTestDisplayStringScalar upsTestId;
/*     */   private TestAndIncr upsTestSpinLock;
/*     */   private EnumeratedScalar upsTestResultsSummary;
/*     */   private DisplayStringScalar upsTestResultsDetail;
/*     */   private MOScalar upsTestStartTime;
/*     */   private MOScalar upsTestElapsedTime;
/*     */   
/*     */   public UpsTestGroup()
/*     */   {
/*  34 */     this.upsTestId = new UpsTestDisplayStringScalar(
/*  35 */       new OID("1.3.6.1.2.1.33.1.7.1.0"), 
/*  36 */       MOAccessImpl.ACCESS_READ_WRITE, 
/*  37 */       new OctetString("1.3.6.1.2.1.33.1.7.7.1"), 
/*  38 */       0, 255);
/*     */     
/*     */ 
/*  41 */     this.upsTestSpinLock = new TestAndIncr(new OID("1.3.6.1.2.1.33.1.7.2.0"));
/*     */     
/*  43 */     this.upsTestResultsSummary = new EnumeratedScalar(
/*  44 */       new OID("1.3.6.1.2.1.33.1.7.3.0"), 
/*  45 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  46 */       new Integer32(6), 
/*  47 */       new int[] {
/*  48 */       1, 
/*  49 */       2, 
/*  50 */       3, 
/*  51 */       4, 
/*  52 */       5, 
/*  53 */       6 });
/*     */     
/*     */ 
/*     */ 
/*  57 */     this.upsTestResultsDetail = new DisplayStringScalar(
/*  58 */       new OID("1.3.6.1.2.1.33.1.7.4.0"), 
/*  59 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  60 */       new OctetString(""));
/*     */     
/*     */ 
/*  63 */     this.upsTestStartTime = new MOScalar(
/*  64 */       new OID("1.3.6.1.2.1.33.1.7.5.0"), 
/*  65 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  66 */       new TimeTicks(0L));
/*     */     
/*     */ 
/*  69 */     this.upsTestElapsedTime = new MOScalar(
/*  70 */       new OID("1.3.6.1.2.1.33.1.7.6.0"), 
/*  71 */       MOAccessImpl.ACCESS_READ_ONLY, 
/*  72 */       new Integer32(0));
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerMOs(MOServer server, OctetString context)
/*     */     throws DuplicateRegistrationException
/*     */   {
/*  79 */     server.register(this.upsTestId, context);
/*  80 */     server.register(this.upsTestSpinLock, context);
/*  81 */     server.register(this.upsTestResultsSummary, context);
/*  82 */     server.register(this.upsTestResultsDetail, context);
/*  83 */     server.register(this.upsTestStartTime, context);
/*  84 */     server.register(this.upsTestElapsedTime, context);
/*     */   }
/*     */   
/*     */   public void unregisterMOs(MOServer server, OctetString context)
/*     */   {
/*  89 */     server.unregister(this.upsTestId, context);
/*  90 */     server.unregister(this.upsTestSpinLock, context);
/*  91 */     server.unregister(this.upsTestResultsSummary, context);
/*  92 */     server.unregister(this.upsTestResultsDetail, context);
/*  93 */     server.unregister(this.upsTestStartTime, context);
/*  94 */     server.unregister(this.upsTestElapsedTime, context);
/*     */   }
/*     */   
/*     */   class UpsTestDisplayStringScalar
/*     */     extends DisplayStringScalar
/*     */   {
/* 100 */     public boolean atualizacao = false;
/*     */     
/*     */     public UpsTestDisplayStringScalar(OID oid, MOAccess access, OctetString value, int minSize, int maxSize) {
/* 103 */       super(access, value, minSize, maxSize);
/*     */     }
/*     */     
/*     */     public void commit(SubRequest request)
/*     */     {
/* 108 */       RequestStatus status = request.getStatus();
/* 109 */       VariableBinding vb = request.getVariableBinding();
/* 110 */       request.setUndoValue(getValue());
/* 111 */       setValue(vb.getVariable());
/* 112 */       status.setPhaseComplete(true);
/* 113 */       this.atualizacao = true;
/*     */     }
/*     */     
/*     */     public void undo(SubRequest request) {
/* 117 */       RequestStatus status = request.getStatus();
/* 118 */       if ((request.getUndoValue() != null) && 
/* 119 */         ((request.getUndoValue() instanceof Variable))) {
/* 120 */         int errorStatus = setValue((Variable)request.getUndoValue());
/* 121 */         status.setErrorStatus(errorStatus);
/* 122 */         status.setPhaseComplete(true);
/* 123 */         this.atualizacao = true;
/*     */       }
/*     */       else {
/* 126 */         status.setErrorStatus(15);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean getAtualizacao() {
/* 131 */       return this.atualizacao;
/*     */     }
/*     */     
/*     */     public void setAtualizacao(boolean valor) {
/* 135 */       this.atualizacao = valor;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getUpsTestElapsedTime()
/*     */   {
/* 142 */     return this.upsTestElapsedTime.getValue().toInt();
/*     */   }
/*     */   
/*     */   public void setUpsTestElapsedTime(int upsTestElapsedTime)
/*     */   {
/* 147 */     this.upsTestElapsedTime.setValue(new Integer32(upsTestElapsedTime));
/*     */   }
/*     */   
/*     */   public UpsTestDisplayStringScalar getUpsTestId()
/*     */   {
/* 152 */     return this.upsTestId;
/*     */   }
/*     */   
/*     */   public void setUpsTestId(String upsTestId)
/*     */   {
/* 157 */     this.upsTestId.setValue(new OctetString(upsTestId));
/*     */   }
/*     */   
/*     */   public String getUpsTestResultsDetail()
/*     */   {
/* 162 */     return this.upsTestResultsDetail.getValue().toString();
/*     */   }
/*     */   
/*     */   public void setUpsTestResultsDetail(String upsTestResultsDetail)
/*     */   {
/* 167 */     this.upsTestResultsDetail.setValue(new OctetString(upsTestResultsDetail));
/*     */   }
/*     */   
/*     */   public String getUpsTestResultsSummary()
/*     */   {
/* 172 */     return this.upsTestResultsSummary.getValue().toString();
/*     */   }
/*     */   
/*     */   public void setUpsTestResultsSummary(int upsTestResultsSummary)
/*     */   {
/* 177 */     this.upsTestResultsSummary.setValue(new Integer32(upsTestResultsSummary));
/*     */   }
/*     */   
/*     */   public int getUpsTestSpinLock()
/*     */   {
/* 182 */     return this.upsTestSpinLock.getValue().toInt();
/*     */   }
/*     */   
/*     */   public void setUpsTestSpinLock(TestAndIncr upsTestSpinLock)
/*     */   {
/* 187 */     this.upsTestSpinLock = upsTestSpinLock;
/*     */   }
/*     */   
/*     */   public int getUpsTestStartTime()
/*     */   {
/* 192 */     return this.upsTestStartTime.getValue().toInt();
/*     */   }
/*     */   
/*     */   public void setUpsTestStartTime(int upsTestStartTime)
/*     */   {
/* 197 */     this.upsTestStartTime.setValue(new Integer32(upsTestStartTime));
/*     */   }
/*     */   
/*     */   public void setTestIdAtualizacao(boolean valor)
/*     */   {
/* 202 */     this.upsTestId.atualizacao = valor;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\snmp\UpsTestGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */