/*     */ package br.com.schneider.sgm.rmi;
/*     */ 
/*     */ import br.com.schneider.sgm.controle.Controle;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Scanner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServidorRMI
/*     */   extends UnicastRemoteObject
/*     */ {
/*     */   private static final long serialVersionUID = -8522236889550538760L;
/*  23 */   private static MensageiroRMI m = new MensageiroImpl();
/*     */   
/*     */ 
/*     */   public ServidorRMI()
/*     */     throws RemoteException
/*     */   {}
/*     */   
/*     */   public void start(Controle controle, Boolean segurarPrompt)
/*     */   {
/*     */     try
/*     */     {
/*  34 */       m.setControle(controle);
/*     */     }
/*     */     catch (RemoteException e1) {
/*  37 */       e1.printStackTrace();
/*     */     }
/*     */     
/*  40 */     System.setProperty("java.rmi.server.codebase", m.getClass()
/*  41 */       .getProtectionDomain().getCodeSource().getLocation().toString());
/*     */     
/*     */ 
/*     */ 
/*  45 */     System.setProperty("java.security.policy", 
/*  46 */       PolicyFileLocator.getLocationOfPolicyFile());
/*     */     
/*     */ 
/*     */ 
/*  50 */     if (System.getSecurityManager() == null) {
/*  51 */       System.setSecurityManager(new SecurityManager());
/*     */     }
/*  53 */     Registry registry = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  58 */       registry = LocateRegistry.createRegistry(1099);
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/*     */       try {
/*  63 */         registry = LocateRegistry.getRegistry(1099);
/*     */       }
/*     */       catch (RemoteException e2) {
/*  66 */         System.err.println("Registro não pode ser inicializado");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  72 */     if (System.getSecurityManager() == null) {
/*  73 */       System.setSecurityManager(new SecurityManager());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  80 */       MensageiroRMI stub = (MensageiroRMI)exportObject(m, 0);
/*     */       
/*  82 */       String nome = "sgm-rmi";
/*  83 */       registry.rebind(nome, stub);
/*     */       
/*     */ 
/*  86 */       if (segurarPrompt.booleanValue()) {
/*  87 */         waitForExit();
/*     */       }
/*     */     } catch (RemoteException e) {
/*  90 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void waitForExit()
/*     */   {
/* 101 */     System.out.println("___________________________________________________________________________\n");
/* 102 */     System.out.println("Controlador do Serviço_SGM instalado no Sistema Operacional com sucesso...");
/* 103 */     System.out.println("___________________________________________________________________________");
/* 104 */     System.out.println("Obs.: Caso você esteja utilizando o prompt/console, digite 's + enter' para");
/* 105 */     System.out.println("finalizar o programa. Caso contrário, desconsidere esta observação.");
/* 106 */     System.out.println("___________________________________________________________________________");
/* 107 */     Scanner scanner = new Scanner(System.in);
/*     */     String in;
/*     */     do {
/* 110 */       in = scanner.next();
/* 111 */     } while (!in.equalsIgnoreCase("s"));
/* 112 */     System.out.println();
/* 113 */     System.exit(0);
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\rmi\ServidorRMI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */