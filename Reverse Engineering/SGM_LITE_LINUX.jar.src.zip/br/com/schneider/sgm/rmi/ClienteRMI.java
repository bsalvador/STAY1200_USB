/*     */ package br.com.schneider.sgm.rmi;
/*     */ 
/*     */ import br.com.schneider.sgm.comunicacao.Communication;
/*     */ import br.com.schneider.sgm.controle.Controle;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.rmi.ConnectException;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClienteRMI
/*     */ {
/*  21 */   private static String nome = "sgm-rmi";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String abrirPortaUsbDoServico(Controle gui)
/*     */   {
/*     */     try
/*     */     {
/*  31 */       if (isObjetoResgistrado()) {
/*  32 */         gui.getDriver().close();
/*     */         
/*  34 */         MensageiroRMI m = (MensageiroRMI)Naming.lookup(nome);
/*     */         
/*  36 */         if (m != null) {
/*  37 */           m.iniciarUsoPortaUSB();
/*     */         }
/*  39 */         return "Não foi possível, via RMI, abrir a porta USB.";
/*     */       }
/*     */     }
/*     */     catch (RemoteException ex) {
/*  43 */       System.out.println(ex.getMessage());
/*     */     } catch (MalformedURLException e) {
/*  45 */       e.printStackTrace();
/*     */     } catch (NotBoundException e) {
/*  47 */       e.printStackTrace();
/*     */     }
/*  49 */     return "Não foi possível acessar o serviço via RMI";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String fecharPortaUsbUtilizadaPeloServico()
/*     */   {
/*     */     try
/*     */     {
/*  60 */       File config = new File(System.getenv("APPDATA") + File.separator + "APC" + File.separator + "XML" + File.separator + "config.sgm");
/*  61 */       Boolean primeiraExec = Boolean.valueOf(!config.exists());
/*     */       
/*  63 */       if (primeiraExec.booleanValue()) {
/*  64 */         return "";
/*     */       }
/*     */       
/*  67 */       int cont = 0;
/*     */       
/*     */ 
/*     */       do
/*     */       {
/*  72 */         if (isObjetoResgistrado())
/*     */         {
/*     */ 
/*  75 */           MensageiroRMI m = (MensageiroRMI)Naming.lookup(nome);
/*  76 */           if (m != null) {
/*  77 */             m.fecharUsoPortaUSB();
/*     */           }
/*     */           
/*  80 */           return "Porta USB do seviço fechada com sucesso";
/*     */         }
/*     */         
/*  83 */         sleep(1000);
/*  84 */         cont++;
/*     */       }
/*  86 */       while (cont != 300);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  91 */       Runtime.getRuntime().exec("start rmiregistry");
/*     */       
/*     */ 
/*     */ 
/*     */       do
/*     */       {
/*  97 */         if (isObjetoResgistrado())
/*     */         {
/*     */ 
/* 100 */           MensageiroRMI m = (MensageiroRMI)Naming.lookup(nome);
/* 101 */           if (m != null) {
/* 102 */             m.fecharUsoPortaUSB();
/*     */           }
/*     */           
/* 105 */           return "Porta USB do seviço fechada com sucesso";
/*     */         }
/*     */         
/* 108 */         sleep(1000);
/* 109 */         cont++;
/*     */       }
/* 111 */       while (cont != 180);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 116 */       String msgErro = "Não foi possível, via RMI, fechar a porta USB após 3 min. de tentativas.";
/* 117 */       System.out.println(msgErro);
/* 118 */       return msgErro;
/*     */     }
/*     */     catch (RemoteException ex)
/*     */     {
/* 122 */       System.out.println(ex.getMessage());
/*     */     } catch (MalformedURLException e) {
/* 124 */       e.printStackTrace();
/*     */     } catch (NotBoundException e) {
/* 126 */       e.printStackTrace();
/*     */     } catch (Exception e) {
/* 128 */       System.out.println(e.getMessage());
/*     */     }
/*     */     
/* 131 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String fecharPortaUsbUtilizadaPeloServico2()
/*     */   {
/*     */     try
/*     */     {
/* 143 */       int cont = 0;
/*     */       
/*     */ 
/*     */       do
/*     */       {
/* 148 */         if (isObjetoResgistrado())
/*     */         {
/*     */ 
/* 151 */           MensageiroRMI m = (MensageiroRMI)Naming.lookup(nome);
/* 152 */           if (m != null) {
/* 153 */             m.fecharUsoPortaUSB();
/*     */           }
/*     */           
/* 156 */           return "Porta USB do seviço fechada com sucesso";
/*     */         }
/*     */         
/* 159 */         sleep(1000);
/* 160 */         cont++;
/*     */       }
/* 162 */       while (cont != 60);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 167 */       String msgErro = "Não foi possível, via RMI, fechar a porta USB após 1 min. de tentativas.";
/* 168 */       System.out.println(msgErro);
/* 169 */       return msgErro;
/*     */     }
/*     */     catch (RemoteException ex) {
/* 172 */       System.out.println(ex.getMessage());
/*     */     } catch (MalformedURLException e) {
/* 174 */       e.printStackTrace();
/*     */     } catch (NotBoundException e) {
/* 176 */       e.printStackTrace();
/*     */     } catch (Exception e) {
/* 178 */       System.out.println(e.getMessage());
/*     */     }
/*     */     
/* 181 */     return "";
/*     */   }
/*     */   
/*     */   private void sleep(int time)
/*     */   {
/*     */     try {
/* 187 */       Thread.sleep(time);
/*     */     } catch (InterruptedException e) {
/* 189 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean isObjetoResgistrado() throws RemoteException {
/* 194 */     return isObjetoResgistrado(nome);
/*     */   }
/*     */   
/*     */   private static boolean isObjetoResgistrado(String nome) {
/*     */     try {
/* 199 */       Registry registry = LocateRegistry.getRegistry();
/*     */       
/* 201 */       if (nome == null) {
/* 202 */         return false;
/*     */       }
/* 204 */       if (registry == null) {
/* 205 */         return false;
/*     */       }
/* 207 */       if (registry.list() == null)
/* 208 */         return false;
/*     */       String[] arrayOfString;
/* 210 */       int j = (arrayOfString = registry.list()).length; for (int i = 0; i < j; i++) { String nomedoObjetoRegistrado = arrayOfString[i];
/* 211 */         if (nome.equals(nomedoObjetoRegistrado)) {
/* 212 */           System.out.print(nomedoObjetoRegistrado);
/* 213 */           return true;
/*     */         }
/*     */       }
/* 216 */       return false;
/*     */     }
/*     */     catch (ConnectException e) {
/* 219 */       return false;
/*     */     } catch (RemoteException e) {}
/* 221 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\rmi\ClienteRMI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */