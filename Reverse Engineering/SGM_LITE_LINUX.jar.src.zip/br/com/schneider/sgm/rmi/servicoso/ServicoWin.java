/*    */ package br.com.schneider.sgm.rmi.servicoso;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServicoWin
/*    */ {
/*    */   public void iniciar()
/*    */   {
/*    */     try
/*    */     {
/* 14 */       Runtime.getRuntime().exec("cmd /c net start \"Controle\"");
/*    */     } catch (IOException e) {
/* 16 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void parar()
/*    */   {
/* 24 */     File config = new File(System.getenv("APPDATA") + File.separator + "APC" + File.separator + "XML" + File.separator + "config.sgm");
/* 25 */     Boolean primeiraExec = Boolean.valueOf(!config.exists());
/*    */     
/* 27 */     if (primeiraExec.booleanValue()) {
/* 28 */       return;
/*    */     }
/*    */     try
/*    */     {
/* 32 */       Runtime.getRuntime().exec("cmd /c net stop \"Controle\"");
/*    */     } catch (IOException e) {
/* 34 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\rmi\servicoso\ServicoWin.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */