/*    */ package br.com.schneider.sgm.rmi;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolicyFileLocator
/*    */ {
/*    */   public static final String POLICY_FILE_NAME = "/allow_all.policy";
/*    */   
/*    */   public static String getLocationOfPolicyFile()
/*    */   {
/*    */     try
/*    */     {
/* 22 */       File tempFile = File.createTempFile("Servidor", ".policy");
/*    */       
/* 24 */       InputStream is = PolicyFileLocator.class
/* 25 */         .getResourceAsStream("/allow_all.policy");
/*    */       
/* 27 */       BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
/* 28 */       int read = 0;
/*    */       
/* 30 */       while ((read = is.read()) != -1) {
/* 31 */         writer.write(read);
/*    */       }
/* 33 */       writer.close();
/* 34 */       tempFile.deleteOnExit();
/*    */       
/* 36 */       return tempFile.getAbsolutePath();
/*    */     } catch (IOException e) {
/* 38 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\rmi\PolicyFileLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */