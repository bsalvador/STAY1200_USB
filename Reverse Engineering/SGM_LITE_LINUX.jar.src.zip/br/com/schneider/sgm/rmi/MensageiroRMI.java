package br.com.schneider.sgm.rmi;

import br.com.schneider.sgm.controle.Controle;
import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface MensageiroRMI
  extends Remote
{
  public abstract void fecharUsoPortaUSB()
    throws RemoteException;
  
  public abstract void iniciarUsoPortaUSB()
    throws RemoteException;
  
  public abstract void setControle(Controle paramControle)
    throws RemoteException;
}


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\rmi\MensageiroRMI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */