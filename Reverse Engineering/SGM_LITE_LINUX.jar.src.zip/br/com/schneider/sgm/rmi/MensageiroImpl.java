/*    */ package br.com.schneider.sgm.rmi;
/*    */ 
/*    */ import br.com.schneider.sgm.comunicacao.Communication;
/*    */ import br.com.schneider.sgm.controle.Controle;
/*    */ import java.io.PrintStream;
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MensageiroImpl
/*    */   extends RemoteException
/*    */   implements MensageiroRMI
/*    */ {
/*    */   private static final long serialVersionUID = 1177334165723453142L;
/*    */   private Controle servico;
/*    */   
/*    */   public void fecharUsoPortaUSB()
/*    */     throws RemoteException
/*    */   {
/* 23 */     System.out.println("Chamada de Método remoto -->> fecharUsoPortaUSB()");
/*    */     
/* 25 */     this.servico.getDriver().close();
/*    */     
/* 27 */     if (this.servico.getPersistencia() != null) {
/* 28 */       this.servico.fechaPersistenciaServico();
/*    */     }
/*    */   }
/*    */   
/*    */   public void iniciarUsoPortaUSB() throws RemoteException {
/* 33 */     System.out.println("Chamada de Método  remoto -->> iniciarUsoPortaUSB()");
/* 34 */     this.servico.abrePersistenciaServico();
/*    */     
/* 36 */     if (this.servico.getDriver() != null)
/* 37 */       this.servico.getDriver().restart();
/*    */   }
/*    */   
/*    */   public Controle getControle() {
/* 41 */     return this.servico;
/*    */   }
/*    */   
/*    */   public void setControle(Controle controle) {
/* 45 */     this.servico = controle;
/*    */   }
/*    */ }


/* Location:              C:\SGM_LIGHT\SGM_LITE_LINUX.jar!\br\com\schneider\sgm\rmi\MensageiroImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */